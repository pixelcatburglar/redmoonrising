--
-- PostgreSQL database dump
--

\restrict Kh4g74IaXBr62SbmjrgNUu4rLlCOGBeZS5LvBPbAfsPe4PAfwji00sSUHa480He

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookmarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookmarks (
    "bookmarkID" integer NOT NULL,
    "ownerID" integer DEFAULT 0 NOT NULL,
    "itemID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    flag integer DEFAULT 0,
    memo text DEFAULT ''::text NOT NULL,
    created bigint DEFAULT 0 NOT NULL,
    x double precision DEFAULT 0,
    y double precision DEFAULT 0,
    z double precision DEFAULT 0,
    "locationID" integer DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN bookmarks."bookmarkID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bookmarks."bookmarkID" IS 'PROVEN as a key the client holds: notepad.py:384 and :631 look up self.bookmarknotes[''B:'' + str(id)] where id is a bookmarkID, and addressbook.GetBookmarks() is indexed by it (notepad.py:437-438 `if bookmarkid in bookmarks`). Given a sequence default in 0002 -- the dump had none.';


--
-- Name: COLUMN bookmarks."ownerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bookmarks."ownerID" IS 'Owning character (or corp). No index existed in the shipped schema even though every query filters on it -- added in 0016.';


--
-- Name: COLUMN bookmarks.memo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bookmarks.memo IS 'Hint + comment packed into one string; the client splits it -- notepad.py:439 `(hint, comment) = eve.LocalSvc(''addressbook'').UnzipMemo(bookmark.memo)`. Do not try to parse it server-side.';


--
-- Name: COLUMN bookmarks.created; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bookmarks.created IS 'Windows FILETIME. bigint, not the shipped int: the bookmark UI renders it through util.FmtDate.';


--
-- Name: bookmarks_bookmarkID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."bookmarks_bookmarkID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookmarks_bookmarkID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."bookmarks_bookmarkID_seq" OWNED BY public.bookmarks."bookmarkID";


--
-- Name: bookmarks bookmarkID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks ALTER COLUMN "bookmarkID" SET DEFAULT nextval('public."bookmarks_bookmarkID_seq"'::regclass);


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookmarks ("bookmarkID", "ownerID", "itemID", "typeID", flag, memo, created, x, y, z, "locationID") FROM stdin;
\.


--
-- Name: bookmarks_bookmarkID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."bookmarks_bookmarkID_seq"', 1, true);


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY ("bookmarkID");


--
-- Name: bookmarks_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookmarks_owner_idx ON public.bookmarks USING btree ("ownerID");


--
-- Name: bookmarks_owner_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookmarks_owner_ix ON public.bookmarks USING btree ("ownerID");


--
-- Name: INDEX bookmarks_owner_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.bookmarks_owner_ix IS 'bookmark.GetBookmarks is entirely "mine"; the shipped table had no index on ownerID.';


--
-- PostgreSQL database dump complete
--

\unrestrict Kh4g74IaXBr62SbmjrgNUu4rLlCOGBeZS5LvBPbAfsPe4PAfwji00sSUHa480He

