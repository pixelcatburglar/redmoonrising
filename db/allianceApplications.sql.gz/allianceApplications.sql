--
-- PostgreSQL database dump
--

\restrict jFxJgilMl0hXXfyipQ1ZGlSUieC4xL2N6z82h5fFz5s05yhhsjd1QoObtRKjDW4

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: allianceApplications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."allianceApplications" (
    "allianceID" integer NOT NULL,
    "corporationID" integer NOT NULL,
    "applicationText" text DEFAULT ''::text NOT NULL,
    "applicationDateTime" bigint DEFAULT 0 NOT NULL,
    state smallint DEFAULT 1 NOT NULL,
    deleted smallint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "allianceApplications"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."allianceApplications" IS 'Corp applications to join an alliance. Serves corpRegistry.ApplyToJoinAlliance / GetAllianceApplications / DeleteAllianceApplication and allianceRegistry.GetApplications / UpdateApplication.';


--
-- Name: COLUMN "allianceApplications"."allianceID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceApplications"."allianceID" IS 'PROVEN: all_ui_applications.py:91,123,154,222; the index key of the corp-side GetAllianceApplications result (bco_alliance.py:37).';


--
-- Name: COLUMN "allianceApplications"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceApplications"."corporationID" IS 'PROVEN: all_ui_applications.py:56,127,154,271,295; 1st arg of the alliance-side UpdateApplication (all_cso_applications.py:26).';


--
-- Name: COLUMN "allianceApplications"."applicationText"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceApplications"."applicationText" IS 'PROVEN: all_ui_applications.py:248-249 and :317/:323 (textedit, maxLength 1000); 2nd arg of ApplyToJoinAlliance (bco_alliance.py:34).';


--
-- Name: COLUMN "allianceApplications"."applicationDateTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceApplications"."applicationDateTime" IS 'INFERRED. Windows FILETIME. The corp equivalent IS read (corp_ui_applications.py:310) but the alliance UI does not render a date.';


--
-- Name: COLUMN "allianceApplications".state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceApplications".state IS 'PROVEN, and the NAME MATTERS: all_ui_applications.py:121 reads application.state (crpApplications calls the same concept "status"). Values from eveConstants: allianceApplicationNew 1, Accepted 2, Effective 3, Rejected 4.';


--
-- Name: COLUMN "allianceApplications".deleted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceApplications".deleted IS 'INFERRED 0/1 soft delete for DeleteAllianceApplication (bco_alliance.py:44).';


--
-- Data for Name: allianceApplications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."allianceApplications" ("allianceID", "corporationID", "applicationText", "applicationDateTime", state, deleted) FROM stdin;
\.


--
-- Name: allianceApplications allianceApplications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."allianceApplications"
    ADD CONSTRAINT "allianceApplications_pkey" PRIMARY KEY ("allianceID", "corporationID");


--
-- Name: allianceapps_corp_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX allianceapps_corp_ix ON public."allianceApplications" USING btree ("corporationID");


--
-- Name: INDEX allianceapps_corp_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.allianceapps_corp_ix IS 'The corp-side view of its own applications (bco_alliance.py:37).';



--
-- PostgreSQL database dump complete
--

\unrestrict jFxJgilMl0hXXfyipQ1ZGlSUieC4xL2N6z82h5fFz5s05yhhsjd1QoObtRKjDW4

