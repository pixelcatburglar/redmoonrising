--
-- PostgreSQL database dump
--

\restrict Lu6Qi6wcSpg30d0hvdBZO2ie0zzthejoaeMCeEBKh4pmopTQ6UcVrE9g3x7J3U0

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channelChars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."channelChars" (
    "channelID" integer DEFAULT 0 NOT NULL,
    "corpID" integer DEFAULT 0 NOT NULL,
    "charID" integer DEFAULT 0 NOT NULL,
    "allianceID" integer DEFAULT 0 NOT NULL,
    role integer DEFAULT 0 NOT NULL,
    extra integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: channelChars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."channelChars" ("channelID", "corpID", "charID", "allianceID", role, extra) FROM stdin;
\.


--
-- Name: channelChars channelChars_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."channelChars"
    ADD CONSTRAINT "channelChars_pkey" PRIMARY KEY ("channelID", "charID");


--
-- Name: channelChars_allianceID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "channelChars_allianceID_idx" ON public."channelChars" USING btree ("allianceID");


--
-- Name: channelChars_charID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "channelChars_charID_idx" ON public."channelChars" USING btree ("charID");


--
-- Name: channelChars_corpID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "channelChars_corpID_idx" ON public."channelChars" USING btree ("corpID");


--
-- PostgreSQL database dump complete
--

\unrestrict Lu6Qi6wcSpg30d0hvdBZO2ie0zzthejoaeMCeEBKh4pmopTQ6UcVrE9g3x7J3U0

