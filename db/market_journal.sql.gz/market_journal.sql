--
-- PostgreSQL database dump
--

\restrict pcY7Q4DgdwObjYJM6Rrn07ebdS9XMBYeRQPbNydfrJBWtyrNnYe1gtEIxzpIZQd

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_journal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_journal (
    "characterID" integer DEFAULT 0 NOT NULL,
    "refID" integer NOT NULL,
    "transDate" bigint,
    "refTypeID" integer DEFAULT 0 NOT NULL,
    "ownerID1" integer DEFAULT 0 NOT NULL,
    "ownerID2" integer DEFAULT 0 NOT NULL,
    "argID1" text,
    "accountID" integer DEFAULT 0 NOT NULL,
    amount double precision DEFAULT 0 NOT NULL,
    balance double precision DEFAULT 0 NOT NULL,
    reason text,
    "accountKey" integer DEFAULT 0 NOT NULL
);


--
-- Name: market_journal_refID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."market_journal_refID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: market_journal_refID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."market_journal_refID_seq" OWNED BY public.market_journal."refID";


--
-- Name: market_journal refID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_journal ALTER COLUMN "refID" SET DEFAULT nextval('public."market_journal_refID_seq"'::regclass);


--
-- Data for Name: market_journal; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.market_journal ("characterID", "refID", "transDate", "refTypeID", "ownerID1", "ownerID2", "argID1", "accountID", amount, balance, reason, "accountKey") FROM stdin;
\.


--
-- Name: market_journal_refID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."market_journal_refID_seq"', 1, false);


--
-- Name: market_journal market_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_journal
    ADD CONSTRAINT market_journal_pkey PRIMARY KEY ("refID");


--
-- Name: market_journal_owner1_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_journal_owner1_ix ON public.market_journal USING btree ("ownerID1");


--
-- Name: INDEX market_journal_owner1_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_journal_owner1_ix IS 'ownerID1/ownerID2 are the two parties the wallet renders (corp_ui_accounts.py:203-215 reads row.ownerID1 and row.ownerID2); reconciliation queries look up by either.';


--
-- Name: market_journal_owner2_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_journal_owner2_ix ON public.market_journal USING btree ("ownerID2");


--
-- Name: INDEX market_journal_owner2_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_journal_owner2_ix IS 'See market_journal_owner1_ix.';


--
-- Name: market_journal_owner_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_journal_owner_ix ON public.market_journal USING btree ("characterID", "accountKey", "transDate" DESC);


--
-- Name: INDEX market_journal_owner_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_journal_owner_ix IS 'account.GetJournal(accountKey, fromDate, refTypeID, corpAccount, refID, rev): corp_ui_accounts.py:190-203 asks once per market_keyMap row, so (owner, key, date) is the access path. The shipped table had no index but the primary key.';


--
-- Name: market_journal_ref_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_journal_ref_ix ON public.market_journal USING btree ("refTypeID");


--
-- Name: market_journal_reftype_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_journal_reftype_ix ON public.market_journal USING btree ("refTypeID");


--
-- Name: INDEX market_journal_reftype_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_journal_reftype_ix IS 'The GetJournal refTypeID filter (market_refTypes is the static side; wallet.py renders refTypeID through util.FmtStandardRefType).';


--
-- PostgreSQL database dump complete
--

\unrestrict pcY7Q4DgdwObjYJM6Rrn07ebdS9XMBYeRQPbNydfrJBWtyrNnYe1gtEIxzpIZQd

