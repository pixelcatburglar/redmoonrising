--
-- PostgreSQL database dump
--

\restrict tqY1gSFBwxFm74aBcd30Cskxp2f0rKTOfT2ya5ud6Y141hCu2ls4eAnXBgAP5oy

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: factionRaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."factionRaces" (
    "factionID" integer DEFAULT 0 NOT NULL,
    "raceID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: factionRaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."factionRaces" ("factionID", "raceID") FROM stdin;
500001	1
500002	2
500003	4
500004	8
500005	16
500006	1
500006	2
500006	4
500006	8
500007	2
500008	4
500009	8
500010	1
500010	8
500011	1
500011	2
500011	4
500011	8
500012	4
500013	1
500013	2
500013	4
500013	8
500014	8
500015	2
500016	1
500016	2
500016	4
500016	8
500017	16
500018	1
500018	8
500019	1
500019	2
500019	4
500019	8
500020	1
500021	1
500021	2
500021	4
500021	8
500021	16
\.


--
-- Name: factionRaces factionRaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."factionRaces"
    ADD CONSTRAINT "factionRaces_pkey" PRIMARY KEY ("factionID", "raceID");


--
-- PostgreSQL database dump complete
--

\unrestrict tqY1gSFBwxFm74aBcd30Cskxp2f0rKTOfT2ya5ud6Y141hCu2ls4eAnXBgAP5oy

