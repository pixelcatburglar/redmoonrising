--
-- PostgreSQL database dump
--

\restrict CV11cDgsMp96mcPhPh2w400fGg7IXnbRsI6Gc65Tq1TQNGqBMcbNapxox4Bw7nl

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBeards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBeards" (
    "beardID" integer DEFAULT 0 NOT NULL,
    "beardName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrBeards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBeards" ("beardID", "beardName") FROM stdin;
1	1
2	10
3	11
4	12
5	13
6	14
7	15
8	16
9	17
10	2
11	22
12	4
13	7
14	8
15	9
16	None
17	18
18	3
19	5
20	6
21	Heavy black
22	Musket
23	Mustache
24	19
25	20
26	21
27	23
28	24
29	25
30	Unnamed
31	Unshaven
32	Unshaven Moustache
33	Dark Moustache
34	Dark Long Moustache
35	Shaven
36	Moustache
37	Grey Moustache
\.


--
-- Name: chrBeards chrBeards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBeards"
    ADD CONSTRAINT "chrBeards_pkey" PRIMARY KEY ("beardID");


--
-- PostgreSQL database dump complete
--

\unrestrict CV11cDgsMp96mcPhPh2w400fGg7IXnbRsI6Gc65Tq1TQNGqBMcbNapxox4Bw7nl

