--
-- PostgreSQL database dump
--

\restrict fGgyS9jwhpoh7Gpf9lMDyaTb6P7LzdeXSXKxB8v6LScbH4Jxx6hEWFe7MKnqkJF

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tutorials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tutorials (
    "tutorialID" integer DEFAULT 0 NOT NULL,
    "tutorialVName" text DEFAULT ''::text NOT NULL,
    "nextTutorialID" integer
);


--
-- Data for Name: tutorials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tutorials ("tutorialID", "tutorialVName", "nextTutorialID") FROM stdin;
5	Aura : Station Tutorial	6
6	Ship Hangar and boarding	7
7	Character Sheet	8
8	The Items Hangar	9
9	Reprocessing - Selling minerals	11
11	Wallet	12
12	Market	13
13	Fittings, station service	14
14	Map	16
15	Communication with other pilots	23
16	Undock	\N
17	Aura : Flight tutorial	37
18	Navigation, manual	21
19	Navigation, Automatic	38
21	Overview	19
23	The Warp Drive	28
24	Reap the rewards	31
27	Aura : Being pod-killed	\N
28	Attack the Pirate!	24
31	Activating Acceleration Gate	34
32	Assets	48
33	Corporations and applying	45
34	Engage more dangerous enemies	35
35	Mining	36
36	Attain the prize container	39
37	The Control Console	18
38	Lock/unlock & Concord	15
39	Returning home	40
40	Reprocess veldspar	32
41	Aura : Insurance	\N
42	Aura : Cloning	\N
43	Aura : Losing a ship	\N
44	Agents	47
45	Help	44
46	Repairshop	33
47	Revealing the full UI	\N
48	Map & travel planning	49
49	Use Assets to set destination	46
50	Aura : Creating a chat channel	\N
51	Aura : Insufficient skill to fit a module	\N
\.


--
-- Name: tutorials tutorials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tutorials
    ADD CONSTRAINT tutorials_pkey PRIMARY KEY ("tutorialID");


--
-- PostgreSQL database dump complete
--

\unrestrict fGgyS9jwhpoh7Gpf9lMDyaTb6P7LzdeXSXKxB8v6LScbH4Jxx6hEWFe7MKnqkJF

