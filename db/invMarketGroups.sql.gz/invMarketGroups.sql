--
-- PostgreSQL database dump
--

\restrict ycdqlUCbefesQDveMy3S7p2FLpW2ZN7MTuKP1EegBzXU4hvhX6VQy2B3kz07Rkc

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invMarketGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invMarketGroups" (
    "marketGroupID" integer NOT NULL,
    "parentGroupID" integer,
    "marketGroupName" text,
    description text,
    "graphicID" integer,
    "hasTypes" integer
);


--
-- Data for Name: invMarketGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invMarketGroups" ("marketGroupID", "parentGroupID", "marketGroupName", description, "graphicID", "hasTypes") FROM stdin;
2	475	Blueprints	Design sheets for the construction of complicated machines and equipment.	2703	0
4	\N	Ships	Capsule-fitted vessels of all shapes and sizes, from frigate to battleship.	1443	0
5	4	Frigates	Small, fast vessels suited to a variety of purposes.	1443	0
6	4	Cruisers	The middle children of the starship industry, but not to be underestimated.	1443	0
7	4	Battleships	The foundations of any respectable fighting force.	1443	0
8	4	Industrial Ships	Built for the transportation of vast amounts of cargo.	1443	0
9	\N	Ship Equipment	Everything the dedicated pilot needs to outfit their ship.	1432	0
10	9	Turrets & Bays	Everything you need to hurt your fellow man and then some.	367	0
11	9	Ammunition & Charges	Strike hard, strike true.	1299	0
14	9	Hull & Armor	Everything you need to strengthen your ship against the dangers of space.	68	0
18	533	Minerals	Minerals harvested from refined asteroid ore.	\N	1
19	\N	Trade Goods	A selection of commodities and goods in varying states of supply and demand.	2340	0
20	19	Industrial Goods	Various products used in a variety of industries.	\N	1
22	19	Radioactive Goods	Chemicals and waste, dripping with radiation. Handle with caution.	\N	1
23	19	Passengers	Living, breathing cargo.	\N	1
24	\N	Skills & Accessories	Point yourself in the direction of personal growth.	2563	0
27	24	Implants	Microchips, hard-wired to the brainstem.	2062	0
52	9	Propulsion	When the need for speed overwhelms, look no further.	397	0
54	475	Ore	Chunks of raw material harvested from asteroids.	1277	0
61	5	Caldari	Caldari frigate designs.	\N	1
64	5	Minmatar	Minmatar frigate designs.	\N	1
65	533	Construction Components	Components used in the manufacture of Tech II vessels and equipment.	1436	0
72	5	Amarr	Amarr frigate designs.	\N	1
73	6	Minmatar	Minmatar cruiser designs.	\N	1
74	6	Amarr	Amarr cruiser designs.	\N	1
75	6	Caldari	Caldari cruiser designs.	\N	1
76	6	Gallente	Gallente cruiser designs.	\N	1
77	5	Gallente	Gallente frigate designs.	\N	1
78	7	Minmatar	Minmatar battleship designs.	\N	1
79	7	Amarr	Amarr battleship designs.	\N	1
80	7	Caldari	Caldari battleship designs.	\N	1
81	7	Gallente	Gallente battleship designs.	\N	1
82	8	Minmatar	Minmatar industrial designs.	\N	1
83	8	Gallente	Gallente industrial designs.	\N	1
84	8	Caldari	Caldari industrial designs.	\N	1
85	8	Amarr	Amarr industrial designs.	\N	1
86	10	Hybrid Turrets	Hybrid turrets are specifically designed to house railguns and blasters.	2277	0
87	10	Projectile Turrets	Built to house cannons capable of firing superheated gunshells.	387	0
88	10	Laser Turrets	Laser turrets are built to house beam and pulse lasers.	2253	0
99	11	Projectile Ammo	Metal-cased shells, fired by artillery guns and autocannons.	1004	0
100	11	Hybrid Charges	Combination shell / plasma core charges designed for railguns and blasters.	1047	0
101	11	Frequency Crystals	Modulate energy weapon beams into several different frequencies.	1131	0
102	851	Small	Small frequency crystals, for use with frigate-sized lasers.	\N	1
103	851	Medium	Medium frequency crystals, for use with cruiser-sized lasers.	\N	1
105	851	Large	Large frequency crystals, for use with battleship-sized lasers.	\N	1
106	848	Large	Large hybrid shells, fired by battleship-sized guns.	\N	1
107	848	Small	Small hybrid shells, fired by frigate-sized guns.	\N	1
108	848	Medium	Medium hybrid shells, fired by cruiser-sized guns.	\N	1
109	845	Large	Large projectile shells, fired by battleship-sized guns.	\N	1
112	845	Medium	Medium projectile shells, fired by cruiser-sized guns.	\N	1
113	845	Small	Small projectile shells, fired by frigate-sized guns.	\N	1
114	11	Missiles	Jet-propelled projectiles with variable payloads.	1334	0
115	114	Auto-Targeting	For when targeting systems fail.	1335	0
116	114	Defender	The anti-missile missile.	\N	1
117	114	Light Missiles	Jet-propelled projectiles for standard-sized launchers.	192	0
118	114	Rockets	Hundreds of tiny bites will wear away even the toughest opponent.	1352	0
120	11	Scan Probes	Scanner systems for analysis of environmental data.	\N	1
126	554	Shield Rechargers	Provide an increase to the shield's recharge rate.	\N	1
128	554	Shield Transporters	Transfer shield energy to another ship.	86	0
131	52	Microwarpdrives	Ultra-advanced propulsion subsystems giving a massive speed boost.	\N	1
132	52	Propulsion Upgrades	Hull modifications designed to increase a ship's speed.	\N	1
133	14	Armor Plates	Reinforced armor plates for additional protection.	\N	1
134	14	Armor Repair Systems	Nano-assembler technology at its best. Repair armor on the fly.	\N	1
135	14	Hull Upgrades	Hull modifications with various applications.	\N	1
138	10	Mining Lasers	For the dedicated space rock plunderer.	\N	1
139	11	Cap Booster Charges	Fuel for the furnace.	\N	1
140	10	Missile Launchers	For the launching of jet-propelled guided missiles.	168	0
141	9	Smartbombs	Omnidirectional energy blasts.  The loner's best friend in hostile territory.	112	0
143	10	Weapon Upgrades	Subsystems designed to improve weapon efficiency.	2531	0
150	24	Skills	Knowledge is power.	33	0
157	9	Drones	Self-propelled, remote-controlled robots for deep space operations.	1084	0
158	157	Mining Drones	The miner's little helpers.	\N	1
159	157	Combat Drones	Tiny warriors, not to be underestimated.	1084	0
204	2	Ships	Blueprints of capsule-fitted space ships.	2703	0
205	204	Frigates	Blueprints of frigate-class vessels.	2703	0
206	204	Cruisers	Blueprints of cruiser-class vessels.	2703	0
207	204	Battleships	Blueprints of battleship-class vessels.	2703	0
208	204	Industrial Ships	Blueprints of industrial-class vessels.	2703	0
209	2	Ship Equipment	Blueprints of modules and equipment for capsule-fitted vessels.	2703	0
210	209	Turrets & Bays	Blueprints of weapons systems for capsule-fitted vessels.	2703	0
211	209	Ammunition & Charges	Blueprints of ammunition and charges.	2703	0
212	209	Shield & Energy	Blueprints of shield and energy-related modules.	2703	0
213	209	Sensors & Electronics	Blueprints of sensor and electronic systems.	2703	0
214	209	Hull & Armor	Blueprints of hull and armor systems.	2703	0
252	209	Propulsion	Blueprints of propulsion systems.	2703	0
261	205	Caldari	Blueprints of Caldari frigate designs.	\N	1
264	205	Minmatar	Blueprints of Minmatar frigate designs.	\N	1
265	800	Ship Components	Ship component blueprints.	\N	1
272	205	Amarr	Blueprints of Amarr frigate designs.	\N	1
273	206	Minmatar	Blueprints of Minmatar cruiser designs.	\N	1
274	206	Amarr	Blueprints of Amarr cruiser designs.	\N	1
275	206	Caldari	Blueprints of Caldari cruiser designs.	\N	1
276	206	Gallente	Blueprints of Gallente cruiser designs.	\N	1
277	205	Gallente	Blueprints of Gallente frigate designs.	\N	1
278	207	Minmatar	Blueprints of Minmatar battleship designs.	\N	1
279	207	Amarr	Blueprints of Amarr battleship designs.	\N	1
280	207	Caldari	Blueprints of Caldari battleship designs.	\N	1
281	207	Gallente	Blueprints of Gallente battleship designs.	\N	1
282	208	Minmatar	Blueprints of Minmatar industrial designs.	\N	1
283	208	Gallente	Blueprints of Gallente industrial designs.	\N	1
284	208	Caldari	Blueprints of Caldari industrial designs.	\N	1
285	208	Amarr	Blueprints of Amarr industrial designs.	\N	1
286	210	Hybrid Turrets	Blueprints of hybrid turrets for capsule-fitted vessels.	2703	0
287	210	Projectile Turrets	Blueprints of projectile turrets for capsule-fitted vessels.	2703	0
288	210	Laser Turrets	Blueprints of laser turrets for capsule-fitted ships.	2703	0
289	286	Large	Blueprints of large hybrid turrets.	\N	1
290	286	Medium	Blueprints of medium hybrid turrets.	\N	1
291	286	Small	Blueprints of small hybrid turrets.	\N	1
292	288	Small	Blueprints of small laser turrets.	\N	1
293	288	Medium	Blueprints of medium laser turrets.	\N	1
295	288	Large	Blueprints of large laser turrets.	\N	1
296	287	Small	Blueprints of small projectile turrets.	\N	1
297	287	Medium	Blueprints of medium projectile turrets.	\N	1
298	287	Large	Blueprints of large projectile turrets.	\N	1
299	211	Projectile Ammo	Projectile ammo blueprints.	2703	0
300	211	Hybrid Charges	Hybrid charge blueprints.	2703	0
301	211	Frequency Crystals	Frequency crystal blueprints.	2703	0
302	301	Small	Blueprints of small frequency crystals.	\N	1
303	301	Medium	Blueprints of medium frequency crystals.	\N	1
305	301	Large	Blueprints of large frequency crystals.	\N	1
306	300	Large	Blueprints of large hybrid ammunition.	\N	1
307	300	Small	Blueprints of small hybrid ammunition.	\N	1
308	300	Medium	Blueprints of medium hybrid ammunition.	\N	1
309	299	Large	Blueprints of large projectile ammunition.	\N	1
312	299	Medium	Blueprints of medium projectile ammunition.	\N	1
313	299	Small	Blueprints of small projectile ammunition.	\N	1
314	211	Missiles	Missile blueprints.	2703	0
315	314	Auto-Targeting	Blueprints of friend-or-foe missiles.	\N	1
316	314	Defender	Blueprints of defender missiles.	\N	1
317	314	Targeted	Blueprints of targeted missiles.	\N	1
318	314	Rockets	Blueprints of rockets.	\N	1
320	211	Scan Probes	Blueprints of scan probes.	\N	1
322	213	Sensor Upgrades	Blueprints of sensor upgrades.	\N	1
323	213	Jammers & Scramblers	Blueprints of jammers and scramblers.	\N	1
324	213	Sensor Subsystems	Blueprints of sensor subsystems.	\N	1
325	213	Scanners	Blueprints of scanners.	\N	1
326	212	Shield Upgrades	Blueprints of shield upgrades.	\N	1
327	212	Energy Upgrades	Blueprints of energy upgrades.	\N	1
328	212	Shield Subsystems	Blueprints of shield subsystems.	\N	1
329	212	Energy SubSystems	Blueprints of energy subsystems.	\N	1
331	252	Propulsion Subsystems	Blueprints of propulsion subsystems.	\N	1
332	252	Propulsion Upgrades	Blueprints of propulsion upgrades.	\N	1
333	214	Armor Upgrades	Blueprints of armor upgrades.	\N	1
334	214	Repair Systems	Blueprints of repair systems.	\N	1
335	214	Hull Upgrades	Blueprints of hull upgrades.	\N	1
338	210	Mining Lasers	Blueprints of mining lasers.	\N	1
339	211	Booster Charges	Blueprints of booster charges.	\N	1
340	210	Missile Launchers	Blueprints of missile launchers.	\N	1
341	209	Smartbombs	Blueprints of smartbombs.	\N	1
343	210	Weapon Upgrades	Blueprints of weapon upgrades.	\N	1
357	209	Drones	Blueprints of drone designs.	2703	0
358	357	Mining Drones	Blueprints of mining drone designs.	\N	1
359	357	Combat Drones	Blueprints of combat drone designs.	\N	1
363	210	Drone Bays	Blueprints of drone bays.	\N	1
364	150	Gunnery	The core of the combat arts: how to use your guns.	\N	1
365	150	Corporation Management	Running a well-oiled operation is a fine art.	\N	1
366	150	Drones	Skills pertaining to the efficient operation of drones.	\N	1
367	150	Electronics	Skills pertaining to management of a starfaring vessel's electronic systems.	\N	1
368	150	Engineering	Skills pertaining to management of a starfaring vessel's hardwired onboard systems.	\N	1
369	150	Industry	Skills pertaining to the efficient use of manufacturing facilities and refineries.	\N	1
370	150	Leadership	Skills pertaining to the efficient coordination of the pilots under your command.	\N	1
371	150	Learning	Build your brain.	\N	1
372	150	Mechanic	Skills pertaining to the building and management of a starfaring vessel's mechanical systems.	\N	1
373	150	Missiles	Skills pertaining to the efficient use of jet-propelled warheads.	\N	1
374	150	Navigation	How to make your way through space as quickly and efficiently as possible.	\N	1
375	150	Science	Skills pertaining to various fields of scientific knowledge.	\N	1
376	150	Social	Skills pertaining to efficient navigation through the social landscape.	\N	1
377	150	Spaceship command	Skills required for the piloting of all shapes and sizes of capsule-fitted vessel.	\N	1
378	150	Trade	The knowledge required to build a commercial empire.	\N	1
379	404	Cargo Containers	For deep-space storage of valuable materials.	\N	1
380	141	Micro	The smallest smartbombs available, for when powergrid and CPU are scarce.	\N	1
381	141	Large	Battleship-sized smartbombs.	\N	1
382	141	Small	Frigate-sized smartbombs.	\N	1
383	141	Medium	Cruiser-sized smartbombs.	\N	1
387	114	Torpedoes	Devastating jet-propelled projectiles carrying huge payloads.	1349	0
390	314	Torpedos	Blueprints of torpedos.	\N	1
391	4	Shuttles	Fast and cheap vessels for easy transport.	1443	0
393	391	Amarr	Amarr shuttle designs.	\N	1
394	391	Minmatar	Minmatar shuttle designs.	\N	1
395	391	Gallente	Gallente shuttle designs.	\N	1
396	391	Caldari	Caldari shuttle designs.	\N	1
398	533	Tools	Construction tools and research databases used in Tech II manufacturing.	\N	1
399	4	Interceptors	Lightning-fast, highly maneuverable frigates.	1443	0
400	399	Amarr	Amarr interceptor designs.	\N	1
401	399	Caldari	Caldari interceptor designs.	\N	1
402	399	Gallente	Gallente interceptor designs.	\N	1
403	399	Minmatar	Minmatar interceptor designs.	\N	1
404	9	Deployable Equipment	Chuck it into space and leave it there. If you like.	16	0
405	404	Warp Disruption Fields	Trap a fly in your web.	\N	1
406	209	Deployable Equipment	Blueprints of deployable equipment.	2703	0
407	406	Warp Disruption Fields	Warp disruption field blueprints.	\N	1
408	204	Interceptors	Blueprints of interceptor-class vessels.	2703	0
410	408	Amarr	Blueprints of Amarr interceptor designs.	\N	1
411	408	Caldari	Blueprints of Caldari interceptor designs.	\N	1
412	408	Gallente	Blueprints of Gallente interceptor designs.	\N	1
413	408	Minmatar	Blueprints of Minmatar interceptor designs.	\N	1
414	204	Shuttles	Blueprints of shuttle-class vessels.	2703	0
415	414	Amarr	Blueprints of Amarr shuttle designs.	\N	1
416	414	Caldari	Blueprints of Caldari shuttle designs.	\N	1
417	414	Gallente	Blueprints of Gallente shuttle designs.	\N	1
418	414	Minmatar	Blueprints of Minmatar shuttle designs.	\N	1
419	204	Covert Ops	Blueprints of covert ops-class vessels.	2703	0
420	4	Covert Ops	Frigates designed for clandestine operations.	1443	0
421	420	Amarr	Amarr covert ops designs.	\N	1
422	420	Caldari	Caldari covert ops designs.	\N	1
423	420	Gallente	Gallente covert ops designs.	\N	1
424	420	Minmatar	Minmatar covert ops designs.	\N	1
425	419	Amarr	Blueprints of Amarr covert ops designs.	\N	1
427	419	Caldari	Blueprints of Caldari covert ops designs.	\N	1
428	419	Gallente	Blueprints of Gallente covert ops designs.	\N	1
429	419	Minmatar	Blueprints of Minmatar covert ops designs.	\N	1
430	213	Cloaking Devices	Blueprints of cloaking devices.	\N	1
432	4	Assault Ships	Sturdy and powerful frigates built for all-out combat.	1443	0
433	432	Amarr	Amarr assault ship designs.	\N	1
434	432	Caldari	Caldari assault ship designs.	\N	1
435	432	Gallente	Gallente assault ship designs.	\N	1
436	432	Minmatar	Minmatar assault ship designs.	\N	1
437	4	Logistics	Support ships, engineered for field assistance in large engagements.	1443	0
438	437	Amarr	Amarr logistics vessel designs.	\N	1
439	437	Caldari	Caldari logistics vessel designs.	\N	1
440	437	Gallente	Gallente logistics vessel designs.	\N	1
441	437	Minmatar	Minmatar logistics vessel designs.	\N	1
442	204	Logistics	Blueprints of Logistics-class vessels.	2703	0
443	442	Amarr	Blueprints of Amarr logistics designs.	\N	1
444	442	Caldari	Blueprints of Caldari logistics designs.	\N	1
445	442	Gallente	Blueprints of Gallente logistics designs.	\N	1
446	442	Minmatar	Blueprints of Minmatar logistics designs.	\N	1
448	4	Heavy Assault Ships	Sturdy and powerful cruisers built for all-out combat.	1443	0
449	448	Amarr	Amarr heavy assault ship designs.	\N	1
450	448	Caldari	Caldari heavy assault ship designs.	\N	1
451	448	Gallente	Gallente heavy assault ship designs.	\N	1
452	448	Minmatar	Minmatar heavy assault ship designs.	\N	1
453	204	Heavy Assault Ships	Blueprints of heavy assault-class vessels.	2703	0
454	453	Amarr	Blueprints of Amarr heavy assault ship designs.	\N	1
455	453	Caldari	Blueprints of Caldari heavy assault ship designs.	\N	1
456	453	Gallente	Blueprints of Gallente heavy assault ship designs.	\N	1
457	453	Minmatar	Blueprints of Minmatar heavy assault ship designs.	\N	1
458	204	Assault Ships	Blueprints of assault-class vessels.	2703	0
459	458	Amarr	Blueprints of Amarr assault ship designs.	\N	1
461	458	Caldari	Blueprints of Caldari assault ship designs.	\N	1
462	458	Gallente	Blueprints of Gallente assault ship designs.	\N	1
463	458	Minmatar	Blueprints of Minmatar assault ship designs.	\N	1
464	4	Destroyers	Anti-frigate gunboats.  The middle ground between a frigate and a cruiser.	1443	0
465	464	Amarr	Amarr destroyer designs.	\N	1
466	464	Caldari	Caldari destroyer designs.	\N	1
467	464	Gallente	Gallente destroyer designs.	\N	1
468	464	Minmatar	Minmatar destroyer designs.	\N	1
469	4	Battlecruisers	A class of powerful combat vessels midway between cruisers and battleships.	1443	0
470	469	Amarr	Amarr battlecruiser designs.	\N	1
471	469	Caldari	Caldari battlecruiser designs.	\N	1
472	469	Gallente	Gallente battlecruiser designs.	\N	1
473	469	Minmatar	Minmatar battlecruiser designs.	\N	1
475	\N	Manufacture & Research	Everything the budding scientist or builder needs to set up shop.	1436	0
476	533	Ice Products	Materials harvested from interstellar ice ores.	\N	1
477	\N	Starbase Structures	Your interstellar home-away-from-home.	2564	0
478	477	Control Towers	The starbase's backbone.	\N	1
479	477	Missile Batteries	Stationary missile batteries for starbase defense.	\N	1
480	477	Turret Batteries	Stationary turret batteries for starbase defense.	2564	0
481	477	Electronic Warfare Batteries	Batteries providing electronic countermeasures for starbase defense.	\N	1
482	477	Refining Arrays	Anchorable refinery structures.	\N	1
483	477	Silos	For storing or providing resources, or regulating material flow in industrial processes.	\N	1
484	477	Ship Maintenance Arrays	Mobile hangar and fitting structures.	\N	1
485	477	Shield Hardening Arrays	Anchorable structures for the boosting of a control tower's shield resistances.	\N	1
488	477	Moon Harvesting Arrays	Deployable arrays designed to gather minerals from moons.	\N	1
490	477	Reactors	Deployable structures where chemical processes take place.	\N	1
491	19	Narcotics	Substances that tinker with brain chemistry and induce altered states.	\N	1
492	19	Consumer Products	Grease the wheels of the capitalistic machine.	\N	1
493	54	Ice Ore	Various types of interstellar ice.	\N	1
494	4	Mining Barges	Lumbering, voracious hulks, expressly created for ore accumulation.	1443	0
495	494	ORE	ORE Syndicate mining barge designs.	\N	1
496	204	Mining Barges	Blueprints of mining barge-class vessels.	2703	0
497	496	ORE	Blueprints of ORE mining barge designs.	\N	1
499	533	Advanced Materials	Materials used for Tech II vessel and equipment production.	\N	1
500	533	Processed Materials	Compounds used in complex reactions.	\N	1
501	533	Raw Materials	Pure elements and other raw materials from nature.	\N	1
502	845	Extra Large	Fired by dreadnaught-sized guns and stationary defense systems.	\N	1
503	851	Extra Large	For use with dreadnought-sized lasers and stationary defense systems.	\N	1
504	848	Extra Large	Fired by dreadnought-sized guns and stationary defense systems.	\N	1
505	114	Citadel Torpedoes	The most powerful missiles to be found anywhere.	\N	1
506	477	Corporate Hangar Array	Communal hangar structures with divisional compartments.	\N	1
507	475	Reactions	Chemical processes where compounds are combined to create new molecular structures.	2665	0
508	507	Simple Reactions	Chemical processes through which raw materials are made into compounds.	\N	1
509	507	Complex Reactions	Chemical processes through which compounds are combined into complex materials.	\N	1
512	54	Arkonor	Sub-types of arkonor ore.	\N	1
514	54	Bistot	Sub-types of bistot ore.	\N	1
515	54	Pyroxeres	Sub-types of Pyroxeres ore.	\N	1
516	54	Plagioclase	Sub-types of plagioclase ore.	\N	1
517	54	Spodumain	Sub-types of spodumain ore.	\N	1
518	54	Veldspar	Sub-types of veldspar ore.	\N	1
519	54	Scordite	Sub-types of scordite ore.	\N	1
521	54	Crokite	Sub-types of crokite ore.	\N	1
522	54	Dark Ochre	Sub-types of dark ochre ore.	\N	1
523	54	Kernite	Sub-types of kernite ore.	\N	1
525	54	Gneiss	Sub-types of gneiss ore.	\N	1
526	54	Omber	Sub-types of omber ore.	\N	1
527	54	Hedbergite	Sub-types of hedbergite ore.	\N	1
528	54	Hemorphite	Sub-types of hemorphite ore.	\N	1
529	54	Jaspet	Sub-types of jaspet ore.	\N	1
530	54	Mercoxit	An extremely rare and valuable ore, yielding a unique mineral.	\N	1
531	27	Skill Hardwiring	Implants designed to increase a pilot's aptitude in a specialized area.	2224	0
532	27	Attribute Enhancers	Implants designed to augment specific aspects of the pilot's mental make-up.	2062	0
533	475	Materials	The building blocks of your life in space.	1201	0
535	14	Armor Hardeners	Electronically enhanced armor plating augmentation.	\N	1
537	14	Remote Repair Systems	Patch up your comrades at a distance.	\N	1
538	14	Hull Repair Systems	For on-the-fly structural restoration.	\N	1
540	14	Resistance Plating	Mechanically enhanced armor plating augmentation.	\N	1
541	14	Energized Plating	An advanced form of mechanically enhanced armor plating upgrades.	\N	1
542	52	Afterburners	Provide additional thrust to the ship's engines.	\N	1
550	554	Shield Resistance Amplifiers	Strengthen various aspects of the shields' subatomic containment fields.	\N	1
551	554	Shield Extenders	Boost the maximum strength of the ship's shield system.	1044	0
552	554	Shield Boosters	Convert energy from the ship's core into additional shield power.	84	0
553	554	Shield Hardeners	Computerized systems designed to give a temporary increase in shield resistance.	\N	1
554	9	Shield	Strengthen your barriers.	69	0
555	86	Railguns	Railguns use magnetic rails to fire solid chunks of matter at hypersonic speed.	368	0
556	86	Blasters	Blasters fire magnetically contained balls of subatomic particles.	369	0
557	88	Beam Lasers	Beam lasers fire a concentrated, persistent stream of energy at their target.	364	0
558	88	Pulse Lasers	Pulse lasers emit an oscillating energy beam at their target.	2261	0
559	87	Autocannons	Autocannons are effective at close ranges and possess great tracking ability.	383	0
560	87	Artillery Cannons	Slow-firing long-range cannons, able to deal crippling blows with great economy.	382	0
561	556	Small	Fast-tracking, low-damage blasters, for use on frigates.	\N	1
562	556	Medium	Medium-sized blasters, for use on cruisers.	\N	1
563	556	Large	Slow-tracking, high-damage blasters, for use on battleships.	\N	1
564	555	Small	Fast-tracking, low-damage railguns, for use on frigates.	\N	1
565	555	Medium	Medium-sized railguns, for use on cruisers.	\N	1
566	555	Large	Slow-tracking, high-damage railguns, for use on battleships.	\N	1
567	557	Small	Small beam lasers, suitable for frigate use.	\N	1
568	557	Medium	Medium beam lasers, suitable for cruiser use.	\N	1
569	557	Large	Large beam lasers, suitable for battleship use.	\N	1
570	558	Small	Small pulse lasers, suitable for frigate use.	\N	1
572	558	Medium	Medium pulse lasers, suitable for cruiser use.	\N	1
573	558	Large	Large pulse lasers, suitable for battleship use.	\N	1
574	559	Small	Frigate-sized autocannons, effective at very close ranges.	\N	1
575	559	Medium	Cruiser-sized weapons. Deliver a rapid-fire barrage of shells at close ranges.	\N	1
576	559	Large	Battleship-sized autocannons. Deal massive damage, up close and personal.	\N	1
577	560	Small	Small artillery cannons, suitable for frigate use.	\N	1
578	560	Medium	Medium artillery cannons, suitable for cruiser use.	\N	1
579	560	Large	Large artillery cannons, suitable for battleship use.	\N	1
580	114	Cruise Missiles	Lifting-wing, jet-propelled guided missiles with heavy payloads.	184	0
581	114	Heavy Missiles	Jet-propelled projectiles for heavy launchers.	186	0
582	204	Destroyers	Blueprints of destroyer-class vessels.	2703	0
583	582	Amarr	Blueprints of Amarr destroyer designs.	\N	1
584	582	Caldari	Blueprints of Caldari destroyer designs.	\N	1
585	582	Gallente	Blueprints of Gallente destroyer designs.	\N	1
586	582	Minmatar	Blueprints of Minmatar destroyer designs.	\N	1
588	204	Battlecruisers	Blueprints of battlecruiser-class vessels.	2703	0
589	588	Amarr	Blueprints of Amarr battlecruiser designs.	\N	1
590	588	Caldari	Blueprints of Caldari battlecruiser designs.	\N	1
591	588	Gallente	Blueprints of Gallente battlecruiser designs.	\N	1
592	588	Minmatar	Blueprints of Minmatar battlecruiser designs.	\N	1
593	11	Mining Crystals	Frequency crystals custom-cut for different ore types.	\N	1
594	480	Projectile	Projectile turret batteries.	\N	1
595	480	Hybrid	Hybrid turret batteries.	\N	1
596	480	Laser	Laser turret batteries.	\N	1
597	299	Extra Large	Blueprints of capital-sized projectile ammunition.	\N	1
598	300	Extra Large	Blueprints of capital-sized hybrid ammunition.	\N	1
599	301	Extra Large	Blueprints of capital-sized frequency crystals.	\N	1
600	128	Capital	Capital ship-sized shield transport units.	\N	1
601	128	Large	Battleship-sized shield transport units.	\N	1
602	128	Medium	Cruiser-sized shield transport units.	\N	1
603	128	Small	Frigate-sized shield transport units.	\N	1
604	128	Micro	The smallest of the shield transporters, for when CPU and powergrid are scarce.	\N	1
605	551	Small	Frigate-class shield extension systems.	\N	1
606	551	Medium	Cruiser-class shield extension systems.	\N	1
607	551	Micro	The smallest of the shield extenders, for when CPU and powergrid are scarce.	\N	1
608	551	Large	Battleship-class shield extension systems.	\N	1
609	552	Small	Frigate-class shield boosters.	\N	1
610	552	Medium	Cruiser-class shield boosters.	\N	1
611	552	Large	Battleship-class shield boosters.	\N	1
612	552	Extra Large	Supercharged shield boosting units for advanced battleship pilots.	\N	1
613	552	Boost Amplifiers	Focus and amplify the efficiency of shield boosting modules.	\N	1
614	19	Criminal Evidence	Proof positive of a bounty hunter's job well done.	2302	0
615	14	Damage Controls	Containment field emitters and redundancy systems for prevention of critical system damage.	\N	1
616	19	Insignias	DNA-imprinted personal insignias.	2552	0
617	314	Citadel Torpedos	Blueprints of citadel torpedoes.	\N	1
618	532	Implant Slot 1	Implants intended for Subcervical Processing Slot 1.	\N	1
619	532	Implant Slot 2	Implants intended for Subcervical Processing Slot 2.	\N	1
620	532	Implant Slot 3	Implants intended for Subcervical Processing Slot 3.	\N	1
621	532	Implant Slot 4	Implants intended for Subcervical Processing Slot 4.	\N	1
622	532	Implant Slot 5	Implants intended for Subcervical Processing Slot 5.	\N	1
623	531	Implant Slot 6	Implants intended for Subcervical Processing Slot 6.	\N	1
624	531	Implant Slot 7	Implants intended for Subcervical Processing Slot 7.	\N	1
625	531	Implant Slot 8	Implants intended for Subcervical Processing Slot 8.	\N	1
626	531	Implant Slot 9	Implants intended for Subcervical Processing Slot 9.	\N	1
627	531	Implant Slot 10	Implants intended for Subcervical Processing Slot 10.	\N	1
629	4	Transport Ships	Advanced technologies for the transportation of valuable materials.	1443	0
630	629	Amarr	Amarr transport ship designs.	\N	1
631	629	Caldari	Caldari transport ship designs.	\N	1
632	629	Gallente	Gallente transport ship designs.	\N	1
633	629	Minmatar	Minmatar transport ship designs.	\N	1
634	204	Transport Ships	Blueprints of transport-class vessels.	2703	0
635	634	Amarr	Blueprints of Amarr transport designs.	\N	1
636	634	Caldari	Blueprints of Caldari transport designs.	\N	1
637	634	Gallente	Blueprints of Gallente transport designs.	\N	1
638	634	Minmatar	Blueprints of Minmatar transport designs.	\N	1
639	140	Rocket Launchers	For the launching of swift-moving rocket projectiles.	\N	1
640	140	Standard Launchers	For the launching of light missiles.	\N	1
641	140	Assault Launchers	Fast-launching, cruiser-sized standard missile bays.	\N	1
642	140	Heavy Launchers	For the launching of heavy missiles.	\N	1
643	140	Cruise Launchers	For the launching of cruise missiles.  Can also fit torpedoes.	\N	1
644	140	Siege Launchers	For the launching of torpedoes and cruise missiles.	\N	1
645	143	Ballistic Control Systems	Systems designed to improve missile launcher efficiency.	\N	1
646	143	Gyrostabilizers	Systems designed to improve projectile weapon efficiency.	\N	1
647	143	Heat Sinks	Systems designed to improve laser weapon efficiency.	\N	1
648	143	Magnetic Field Stabilizers	Systems designed to improve hybrid weapon efficiency.	\N	1
655	9	Engineering Equipment	Everything you need to upgrade your powercore.	70	0
656	9	Electronics and Sensor Upgrades	Give your onboard computer systems some love.	104	0
657	9	Electronic Warfare	Mounds of electronic wizardry, for that extra edge.	111	0
658	655	Power Diagnostic Systems	Monitor and optimize the power grid and capacitor systems.	\N	1
659	655	Reactor Control Units	Run power core optimization subroutines for maximum efficiency.	\N	1
660	655	Auxilliary Power Controls	Supplementary systems providing a flat boost to powercore energy.	\N	1
661	655	Energy Destabilizer	Neutralize a portion of the target ship's capacitor energy.	1283	0
662	655	Energy Vampires	Steal the other guy's thunder.	1029	0
663	655	Energy Transfer Arrays	Systems allowing transfer of capacitor energy to another ship.	1035	0
664	655	Capacitor Batteries	Allow the capacitor to store more energy.	892	0
665	655	Capacitor Rechargers	Provide a boost to the capacitor's recharge rate.	\N	1
666	655	Capacitor Flux Coils	Increase capacitor recharge rate while lowering maximum capacitor capacity.	\N	1
667	655	Capacitor Power Relays	Increase capacitor recharge rate at the expense of shield boosting capability.	\N	1
668	655	Capacitor Boosters	Provide quick injections of power into the capacitor.	1031	0
669	656	Signal Amplifiers	Augment a ship's targeting range and target acquisition time.	\N	1
670	656	Automated Targeting Systems	For automated targeting of hostiles.	\N	1
671	656	Sensor Boosters	Provide a boost to a ship's targeting range and target acquisition time.	\N	1
672	656	Passive Targeting Systems	Allow for surreptitious targeting of hostiles.	\N	1
673	656	Remote Sensor Boosters	Augment target ship's targeting range and target acquisition time.	\N	1
674	656	Scanners	Auxiliary scanner modules.  Information is power.	107	0
675	656	Cloaking Devices	Use advanced spatial distortion technology to render ships invisible.	\N	1
676	656	CPU Upgrades	Provide an increase in the ship's CPU output.	\N	1
677	657	Electronic Counter Measures	Designed to disrupt and lock down enemy ships' sensor arrays.	109	0
678	657	ECM Bursts	Targeting jammers emitting multi-frequency disruptive signals.	\N	1
679	657	Remote Sensor Dampers	Decrease the targeting speed and range of target ship.	\N	1
680	657	Tracking Disruptors	Disrupt the turret range and tracking speed of the target ship.	\N	1
681	657	Sensor Backup Arrays	Beef up your sensor strength to resist target jamming.	104	0
682	657	Warp Jammers	Your foes aren't going anywhere.	\N	1
683	657	Stasis Webifiers	Slow them down, then smack them down.	\N	1
685	657	ECCM	Auxiliary systems giving a boost to sensor strength for a short time.	104	0
686	657	Projected ECCM	Boost a target ship's sensor strength for a short time.	\N	1
687	554	Shield Flux Coils	Increase shield recharge rate while lowering maximum shield capacity.	\N	1
688	554	Shield Power Relays	Divert power from ship's core to shields, increasing shield recharge rate.	\N	1
689	661	Small	Frigate-sized energy destabilizers.	\N	1
690	661	Medium	Cruiser-sized energy destabilizers.	\N	1
691	661	Heavy	Battleship-sized energy destabilizers.	\N	1
692	662	Small	Frigate-sized energy vampires.	\N	1
693	662	Medium	Cruiser-sized energy vampires.	\N	1
694	662	Heavy	Battleship-sized energy vampires.	\N	1
695	663	Small	Frigate-sized energy transfer arrays.	\N	1
696	663	Medium	Cruiser-sized energy transfer arrays.	\N	1
697	663	Large	Battleship-sized energy transfer arrays.	\N	1
698	668	Micro	Small capacitor boosters, for when powergrid and CPU are scarce.	\N	1
699	668	Small	Frigate-sized capacitor boosters.	\N	1
700	668	Medium	Cruiser-sized capacitor boosters.	\N	1
701	668	Heavy	Battleship-sized capacitor boosters.	\N	1
702	664	Micro	Give a small increase in capacitor energy.	\N	1
703	664	Small	Frigate-sized capacitor batteries.	\N	1
704	664	Medium	Cruiser-sized capacitor batteries.	\N	1
705	664	Large	Battleship-sized capacitor batteries.	\N	1
706	143	Tracking Computers	Computerized systems designed to improve turret tracking.	\N	1
707	143	Tracking Enhancers	Hardwired systems designed to improve turret tracking.	\N	1
708	143	Tracking Links	Designed to give a boost to another ship's tracking speed.	\N	1
711	674	Cargo Scanners	For remote scanning of a target ship's cargo hold.	\N	1
712	674	Scan Probe Launchers	Launcher bays designed to fire scan probes for stellar triangulation.	\N	1
713	674	Ship Scanners	Provide tactical analysis of a target ship's capabilities.	\N	1
714	674	Data and Composition Scanners	For analysis of the composition of materials.	\N	1
715	677	Magnetometric Jammers	Targeting jammers specialized for use against magnetometric sensors.	\N	1
716	677	Ladar Jammers	Targeting jammers specialized for use against ladar sensors.	\N	1
717	677	Gravimetric Jammers	Targeting jammers specialized for use against gravimetric sensors.	\N	1
718	677	Radar Jammers	Targeting jammers specialized for use against radar sensors.	\N	1
719	677	Multi Spectrum Jammers	Targeting jammers that induce multispectral sensor disruption.	\N	1
720	681	Gravimetric Backups Arrays	Reduces the sensors' vulnerability to gravimetric jamming.	\N	1
721	681	LADAR Backup Arrays	Reduces the sensors' vulnerability to Ladar jamming.	\N	1
722	681	RADAR Backup Arrays	Reduces the sensors' vulnerability to Radar jamming.	\N	1
723	681	Magnetometric Backup Arrays	Reduces the sensors' vulnerability to magnetometric jamming.	\N	1
724	681	Multi-Frequency Backup Arrays	Reduces the sensors' vulnerability to multiple forms of jamming.	\N	1
725	685	Gravimetric Sensors	Boost a ship's gravimetric sensor strength for a short duration.	\N	1
726	685	Ladar Sensors	Boost a ship's ladar sensor strength for a short duration.	\N	1
727	685	Magnetometric Sensors	Boost a ship's magnetometric sensor strength for a short duration.	\N	1
728	685	Multi-Spectrum Sensors	Boost a ship's sensors across the spectrum for a short duration.	\N	1
729	685	Radar Sensors	Boost a ship's radar sensor strength for a short duration.	\N	1
730	616	Amarr Navy	Officially sanctioned Amarr Navy insignias.	\N	1
731	616	Ammatar Navy	Officially sanctioned Ammatar Navy insignias.	\N	1
732	616	Caldari Navy	Officially sanctioned Caldari Navy insignias.	\N	1
733	616	CONCORD	Officially sanctioned CONCORD insignias.	\N	1
734	616	Gallente Navy	Officially sanctioned Gallente Navy insignias.	\N	1
735	616	Khanid Navy	Officially sanctioned Khanid Navy insignias.	\N	1
736	616	Minmatar Fleet	Officially sanctioned Minmatar Fleet insignias.	\N	1
737	616	Individuals	Individual identification tags.	\N	1
738	19	Nexus Chips	For storage of artificial intelligence systems.	\N	1
739	19	Criminal Dog Tags	Criminal organizations' identification tags.	2325	0
740	739	Angels	Angel Cartel identification tags.	\N	1
741	739	Blood Raiders	Blood Raider identification tags.	\N	1
742	739	Dark Blood	Dark Blood identification tags.	\N	1
743	739	Domination	Angel Dominations identification tags.	\N	1
744	739	Dread Guristas	Dread Guristas identification tags.	\N	1
745	739	Guristas	Guristas identification tags.	\N	1
746	739	Sansha	Sansha's Nation identification tags.	\N	1
747	739	Serpentis	Serpentis identification tags.	\N	1
748	739	Shadow Serpentis	Shadow Serpentis identification tags.	\N	1
749	739	True Sansha	True Sansha identification tags.	\N	1
750	739	Commanders	The identification tags of CONCORD's most wanted.	\N	1
751	614	Overseer's Personal Effects	Proof that there's one less evil bastard in the world.	2039	1
752	614	Criminal DNA Patterns	Physical proof of a dastardly villain's demise.	2302	1
753	211	Mining Crystals	Blueprints of mining crystals.	\N	1
754	19	Political Paraphernalia		\N	1
757	657	Target Painters	Project an electronic signal towards a target, increasing its signature radius.	\N	1
759	533	Alloys & Compounds	Various compounds composed of asteroid ores.	\N	1
760	9	Civilian Modules	Modules whose specifications are geared toward use on rookie ships.	\N	1
761	4	Dreadnoughts	Capital ships created for extended sieges of stationary installations.	1443	0
762	761	Amarr	Amarr dreadnought designs.	\N	1
763	761	Caldari	Caldari dreadnought designs.	\N	1
764	761	Gallente	Gallente dreadnought designs.	\N	1
765	761	Minmatar	Minmatar dreadnought designs.	\N	1
766	4	Freighters	Capital ships, able to transport a world and a half and then some.	1443	0
767	766	Amarr	Amarr freighter designs.	\N	1
768	766	Caldari	Caldari freighter designs.	\N	1
769	766	Gallente	Gallente freighter designs.	\N	1
770	766	Minmatar	Minmatar freighter designs.	\N	1
771	556	Extra Large	Capital ship blasters, for use on dreadnoughts and titans.	\N	1
772	555	Extra Large	Capital ship railguns, for use on dreadnoughts and titans.	\N	1
773	557	Extra Large	Capital ship beam lasers, for use on dreadnoughts and titans.	\N	1
774	558	Extra Large	Capital ship pulse lasers, for use on dreadnoughts and titans.	\N	1
775	560	Extra Large	Capital ship artillery cannons, for use on dreadnoughts and titans.	\N	1
776	559	Extra Large	Capital ship autocannons, for use on dreadnoughts and titans.	\N	1
777	140	Citadel Launchers	For the launching of citadel torpedoes.  Can only be fitted on dreadnoughts and titans.	\N	1
778	552	Capital	Shield boosters for capital ships	\N	1
779	9	Gang Assist Modules	Modules used to assist gang members.	2858	1
780	533	Station Components	Modular items used in the manufacture of Space Stations.	\N	1
781	533	Capital Ship Components	Modular components used in the manufacture of capital ships.	\N	1
782	204	Dreadnoughts	Blueprints of dreadnought-class vessels.	2703	0
783	782	Amarr	Blueprints of Amarr dreadnought designs.	\N	1
784	782	Caldari	Blueprints of Caldari dreadnought designs.	\N	1
785	782	Gallente	Blueprints of Gallente dreadnought designs.	\N	1
786	782	Minmatar	Blueprints of Minmatar dreadnought designs.	\N	1
787	204	Freighters	Blueprints of freighter-class vessels.	2703	0
788	787	Amarr	Blueprints of Amarr freighter designs.	\N	1
789	787	Caldari	Blueprints of Caldari freighter designs.	\N	1
790	787	Gallente	Blueprints of Gallente freighter designs.	\N	1
791	787	Minmatar	Blueprints of Minmatar freighter designs.	\N	1
792	286	Extra Large	Blueprints of capital-sized hybrid turrets.	\N	1
793	287	Extra Large	Blueprints of capital-sized projectile turrets.	\N	1
794	288	Extra Large	Blueprints of capital-sized laser turrets.	\N	1
796	800	Capital Ship Components	Capital ship component blueprints.	\N	1
798	800	Construction Platforms	Blueprints for construction platforms.	\N	1
799	209	Gang Assist Modules	Gang assist module blueprints.	\N	1
800	2	Components	Blueprints for intermediary items used in the production of more advanced items.	2703	0
801	143	Siege Modules	Modules designed to augment and enhance a capital ship's siege warfare abilities.	\N	1
802	65	Amarr	Components used in the manufacture of Amarrian Tech II equipment.	\N	1
803	65	Caldari	Components used in the manufacture of Caldari Tech II equipment.	\N	1
804	65	Gallente	Components used in the manufacture of Gallentean Tech II equipment.	\N	1
805	65	Minmatar	Components used in the manufacture of Matari Tech II equipment.	\N	1
806	533	Prototypes and Datafiles	Materials used in the construction of specific factional equipment.	2889	0
807	533	Artifacts and Lore	Ancient remnants of long-lost civilizations.	2887	0
808	806	Angel	Materials used in the construction of specific factional equipment.	\N	1
809	806	Guristas	Materials used in the construction of specific factional equipment.	\N	1
810	807	Sleeper	Artifacts of the Sleeper civilization.	\N	1
811	807	Talocan	Artifacts of the Talocan civilization.	\N	1
812	4	Titans	Fathers of the fleet, the biggest of the big.	1443	0
813	812	Amarr	Amarr titan designs.	\N	1
814	812	Caldari	Caldari titan designs.	\N	1
815	812	Gallente	Gallente titan designs.	\N	1
816	812	Minmatar	Minmatar titan designs.	\N	1
817	4	Carriers	Capital warships, able to transport and deploy hordes of smaller vessels into the field.	1443	0
818	817	Amarr	Amarr carrier designs.	\N	1
819	817	Caldari	Caldari carrier designs.	\N	1
820	817	Gallente	Gallente carrier designs.	\N	1
821	817	Minmatar	Minmatar carrier designs.	\N	1
822	4	Command Ships	Battlecruiser-class vessels, designed to aid their allies on the battlefield.	1443	0
823	4	Interdictors	Destroyer-class vessels, designed to pull other vessels out of warp.	1443	0
824	4	Recon Ships	Cruisers specialized in reconaissance operations and electronic warfare.	1443	0
825	822	Amarr	Amarr command ship designs.	\N	1
826	823	Amarr	Amarr interdictor designs.	\N	1
827	824	Amarr	Amarr recon ship designs.	\N	1
828	822	Caldari	Caldari command ship designs.	\N	1
829	823	Caldari	Caldari interdictor designs.	\N	1
830	824	Caldari	Caldari recon ship designs.	\N	1
831	822	Gallente	Gallente command ship designs.	\N	1
832	823	Gallente	Gallente interdictor designs.	\N	1
833	824	Gallente	Gallente recon ship designs.	\N	1
834	822	Minmatar	Minmatar command ship designs.	\N	1
835	823	Minmatar	Minmatar interdictor designs.	\N	1
836	824	Minmatar	Minmatar recon ship designs.	\N	1
837	159	Light Scout Drones	Light Scout Drones	\N	1
838	159	Medium Scout Drones	Medium Scout Drones	\N	1
839	159	Heavy Attack Drones	Heavy Attack Drones	\N	1
840	159	Fighters	Single-pilot combat vessels, deployable from carriers and motherships.	\N	1
841	157	Electronic Warfare Drones	Electronic Warfare Drones	\N	1
842	157	Logistic Drones	Logistic Drones	\N	1
843	157	Combat Utility Drones	Combat Utility Drones	\N	1
845	99	Standard Ammo	Standard projectile rounds.	1308	0
846	99	Advanced Artillery Ammo	Ultra-heavy shells incorporating cutting-edge technology.	1287	0
847	99	Advanced Autocannon Ammo	Sophisticated autocannon munitions incorporating cutting-edge technology.	1291	0
848	100	Standard Charges	Standard hybrid slugs.	1047	0
849	100	Advanced Blaster Charges	Technologically advanced blaster ammunition.	1310	0
850	100	Advanced Railgun Charges	Technologically advanced railgun ammunition.	1311	0
851	101	Standard Crystals		1142	0
852	101	Advanced Beam Laser Crystal	Technologically advanced beam laser crystals.	1145	0
853	101	Advanced Pulse Laser Crystal	Technologically advanced pulse laser crystals.	1140	0
854	846	Large	Large ADAR ammunition, fired by battleship-sized guns.	\N	1
855	846	Medium	Medium ADAR ammunition, fired by cruiser-sized guns.	\N	1
856	846	Small	Small ADAR ammunition, fired by frigate-sized guns.	\N	1
857	847	Large	Large ADAC ammunition, fired by battleship-sized guns.	\N	1
858	847	Medium	Medium ADAC ammunition, fired by cruiser-sized guns.	\N	1
859	847	Small	Small ADAC ammunition, fired by frigate-sized guns.	\N	1
860	849	Large	Large advanced hybrid shells, fired by battleship-sized guns.	\N	1
861	849	Medium	Medium advanced hybrid shells, fired by cruiser-sized guns.	\N	1
862	849	Small	Small advanced hybrid shells, fired by frigate-sized guns.	\N	1
863	850	Large	Large advanced railgun ammunition, fired by battleship-sized guns.	\N	1
864	850	Medium	Medium advanced railgun ammunition, fired by cruiser-sized guns.	\N	1
865	850	Small	Small advanced railgun ammunition, fired by frigate-sized guns.	\N	1
866	852	Large	Large advanced beam laser crystals, for use with battleship-sized lasers.	\N	1
867	852	Medium	Medium advanced beam laser crystals, for use with cruiser-sized lasers.	\N	1
868	852	Small	Small advanced beam laser crystals, for use with frigate-sized lasers.	\N	1
869	853	Large	Large advanced pulse laser crystals, for use with battleship-sized lasers.	\N	1
870	853	Medium	Medium advanced pulse laser crystals, for use with cruiser-sized lasers.	\N	1
871	853	Small	Small advanced pulse laser crystals, for use with frigate-sized lasers.	\N	1
872	656	Tractor Beams	Tractor Beams	\N	1
873	357	Miscellaneous Drones	The rest of the drone BPs	\N	1
874	4	Exhumers	Elite Mining Barges	1443	0
875	874	ORE	ORE exhumer designs.	\N	1
878	204	Titans	Blueprints of titan-class vessels.	2703	0
879	204	Carriers	Blueprints of carrier- and mothership-class vessels.	2703	0
880	204	Interdictors	Blueprints of interdictor-class vessels.	2703	0
881	204	Command Ships	Blueprints of command ship-class vessels.	2703	0
882	204	Recon Ships	Blueprints of recon ship-class designs.	2703	0
883	204	Exhumers	Exhumers	2703	0
884	878	Amarr	Blueprints of Amarr titan designs.	\N	1
885	878	Caldari	Blueprints of Caldari titan designs.	\N	1
886	878	Gallente	Blueprints of Gallente titan designs.	\N	1
887	878	Minmatar	Blueprints of Minmatar titan designs.	\N	1
888	879	Amarr	Blueprints of Amarr carrier and mothership designs.	\N	1
889	879	Caldari	Blueprints of Caldari carrier and mothership designs.	\N	1
890	879	Gallente	Blueprints of Gallente carrier and mothership designs.	\N	1
891	879	Minmatar	Blueprints of Minmatar carrier and mothership designs.	\N	1
892	880	Amarr	Blueprints of Amarr interdictor designs.	\N	1
893	880	Caldari	Blueprints of Caldari interdictor designs.	\N	1
894	880	Gallente	Blueprints of Gallente interdictor designs.	\N	1
895	880	Minmatar	Blueprints of Minmatar interdictor designs.	\N	1
896	881	Amarr	Blueprints of Amarr command ship designs.	\N	1
897	881	Caldari	Blueprints of Caldari command ship designs.	\N	1
898	881	Gallente	Blueprints of Gallente command ship designs.	\N	1
899	881	Minmatar	Blueprints of Minmatar command ship designs.	\N	1
900	882	Amarr	Blueprints of Amarr recon ship designs.	\N	1
901	882	Caldari	Blueprints of Caldari recon ship designs.	\N	1
902	882	Gallente	Blueprints of Gallente recon ship designs.	\N	1
903	882	Minmatar	Blueprints of Minmatar recon ship designs.	\N	1
904	883	ORE	Blueprints of ORE exhumer designs.	\N	1
905	213	Tractor Beams	Blueprints of tractor beams.	\N	1
906	806	Bloodraider	Materials used in the construction of specific factional equipment.	\N	1
907	806	Serpentis	Materials used in the construction of specific factional equipment.	\N	1
908	807	Yan Jung	Artifacts of the Yan Jung civilization.	\N	1
909	807	Takmahl	Artifacts of the Takmahl civilization.	\N	1
910	663	Capital	Capital ship-sized energy transfer arrays.	\N	1
911	159	Sentry Drones	Deployable watchdogs.	\N	1
912	10	Doomsday Devices	The titan's fist.	\N	1
913	210	Doomsday Devices	Doomsday Devices	\N	1
914	115	Standard Auto-Targeting	Standard Auto-Targeting	\N	1
915	115	Advanced High Damage Auto-Targeting	Advanced High Damage Auto-Targeting	\N	1
916	115	Advanced High Precision Auto-Targeting	Advanced High Precision Auto-Targeting	\N	1
917	117	Advanced High Precision Light Missiles	Advanced High Precision Light Missiles	\N	1
918	580	Advanced High Precision Cruise Missiles	Advanced High Precision Cruise Missiles	\N	1
919	581	Advanced High Precision Heavy Missiles	Advanced High Precision Heavy Missiles	\N	1
920	117	Standard Light Missiles	Standard Light Missiles	\N	1
921	580	Standard Cruise Missiles	Standard Cruise Missiles	\N	1
922	118	Standard Rockets	Standard Rockets	\N	1
923	387	Standard Torpedoes	Standard Torpedoes	\N	1
924	581	Standard Heavy Missiles	Standard Heavy Missiles	\N	1
925	580	Advanced High Damage Cruise Missiles	Advanced High Damage Cruise Missiles	\N	1
926	581	Advanced High Damage Heavy Missiles	Advanced High Damage Heavy Missiles	\N	1
927	117	Advanced High Damage Light Missiles	Advanced High Damage Light Missiles	\N	1
928	118	Advanced Long Range Rockets	Advanced Long Range Rockets	\N	1
929	387	Advanced Long Range Torpedoes	Advanced Long Range Torpedoes	\N	1
930	118	Advanced Anti-Ship Rockets	Advanced Anti-Ship Rockets	\N	1
931	387	Advanced Anti-Ship Torpedoes	Advanced Anti-Ship Torpedoes	\N	1
932	477	Assembly Arrays	Structures which house manufacturing facilities.	\N	1
933	477	Mobile Laboratory	Structurs with research facilities.	\N	1
935	10	Mining Upgrades	Subsystems designed to improve mining laser efficiency.	\N	1
937	210	Mining Upgrades	Blueprints of mining upgrades.	\N	1
938	157	Drone Upgrades	Subsystems designed to increase drone efficiency.	\N	1
939	210	Drone Upgrades	Blueprints of drone upgrades.	\N	1
940	19	Starbase Charters		\N	1
941	2	Tool		\N	1
\.


--
-- Name: invMarketGroups invMarketGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invMarketGroups"
    ADD CONSTRAINT "invMarketGroups_pkey" PRIMARY KEY ("marketGroupID");


--
-- PostgreSQL database dump complete
--

\unrestrict ycdqlUCbefesQDveMy3S7p2FLpW2ZN7MTuKP1EegBzXU4hvhX6VQy2B3kz07Rkc

