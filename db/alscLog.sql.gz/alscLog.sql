--
-- PostgreSQL database dump
--

\restrict kF1WybOqw5npQ9I9LO8sjPZKitFhw8CpQn067ySGluG3lgPaTpiQyPOkqqrGcpC

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alscLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."alscLog" (
    "logID" bigint NOT NULL,
    "containerID" integer NOT NULL,
    "logDateTime" bigint NOT NULL,
    "inventoryMgrLocationID" integer NOT NULL,
    "locationID" integer NOT NULL,
    flag integer DEFAULT 0 NOT NULL,
    "actorID" integer NOT NULL,
    "actionID" integer NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    arg1 integer,
    arg2 integer
);


--
-- Name: TABLE "alscLog"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."alscLog" IS 'Audit trail of an Audit Log Secure Container. Serves the bound-object call ALSCLogGet(fromDate, fromLogID, forward) (AuditLogSecureContainerLogViewer.py:81); the viewer pages on logID (:89-92).';


--
-- Name: COLUMN "alscLog"."logID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."logID" IS 'PROVEN: AuditLogSecureContainerLogViewer.py:89-92 tracks max/min of log.logID and :75-76 defaults the cursor to 1, so it must be a positive ascending integer.';


--
-- Name: COLUMN "alscLog"."containerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."containerID" IS 'INFERRED as a column: the call is bound to the container (menusvc.py:1382 eve.GetInventoryFromId(itemID)), so the container ID never appears in the row.';


--
-- Name: COLUMN "alscLog"."logDateTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."logDateTime" IS 'Windows FILETIME. PROVEN: AuditLogSecureContainerLogViewer.py:155 util.FmtDate(log.logDateTime) (header "DateTime"); also the fromDate paging argument.';


--
-- Name: COLUMN "alscLog"."inventoryMgrLocationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."inventoryMgrLocationID" IS 'PROVEN: AuditLogSecureContainerLogViewer.py:156 cfg.evelocations.Get(log.inventoryMgrLocationID).locationName (header "Location"); :93 compares it to log.locationID to decide whether the item was in a personal hangar.';


--
-- Name: COLUMN "alscLog"."locationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."locationID" IS 'PROVEN: AuditLogSecureContainerLogViewer.py:93 and :104 cfg.evelocations.GetIfExists(log.locationID) -- the immediate location, which may not resolve to a name (hence GetIfExists and the flag fallback at :106).';


--
-- Name: COLUMN "alscLog".flag; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog".flag IS 'eveFlags.flagID. PROVEN: AuditLogSecureContainerLogViewer.py:95-100 maps flagHangar/flagCorpSAG2..flagCorpSAG7 to corp divisions 1..7 for the "Sub Location" column and falls back to printing the raw flag at :106.';


--
-- Name: COLUMN "alscLog"."actorID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."actorID" IS 'PROVEN: AuditLogSecureContainerLogViewer.py:158 cfg.eveowners.Get(log.actorID).ownerName (header "Who").';


--
-- Name: COLUMN "alscLog"."actionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog"."actionID" IS 'PROVEN: AuditLogSecureContainerLogViewer.py:110-149 branches on const.ALSCActionAssemble / Repackage / SetName / SetPassword / Add / Lock / Unlock / EnterPassword / Configure. Live eveConstants shows ALSCActionAdd = 6 and ALSCActionLock = 7, so the set is a small dense enum.';


--
-- Name: COLUMN "alscLog".status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog".status IS 'PROVEN 0/1: AuditLogSecureContainerLogViewer.py:159 [''Fail'',''Success''][log.status].';


--
-- Name: COLUMN "alscLog".arg1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog".arg1 IS 'PROVEN, POLYMORPHIC on actionID: an ownerID for Assemble (:112 cfg.eveowners.Get(log.arg1)), a typeID for Add/Lock/Unlock (:131,:135,:139 cfg.invtypes.Get(log.arg1)), an SCCPasswordType for SetPassword/EnterPassword (:123-127, :142-146), unused for Repackage/SetName/Configure.';


--
-- Name: COLUMN "alscLog".arg2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."alscLog".arg2 IS 'PROVEN, POLYMORPHIC: a typeID for Assemble (:113 cfg.invtypes.Get(log.arg2).typeName), a raw quantity for Add/Lock/Unlock (:132,:136,:140 print it directly), unused otherwise.';


--
-- Name: alscLog_logID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."alscLog" ALTER COLUMN "logID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."alscLog_logID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: alscLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."alscLog" ("logID", "containerID", "logDateTime", "inventoryMgrLocationID", "locationID", flag, "actorID", "actionID", status, arg1, arg2) FROM stdin;
\.


--
-- Name: alscLog_logID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."alscLog_logID_seq"', 1, false);


--
-- Name: alscLog alscLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."alscLog"
    ADD CONSTRAINT "alscLog_pkey" PRIMARY KEY ("logID");


--
-- Name: alsclog_container_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alsclog_container_ix ON public."alscLog" USING btree ("containerID", "logID");


--
-- Name: INDEX alsclog_container_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.alsclog_container_ix IS 'ALSCLogGet(fromDate, fromLogID, forward) pages on logID within one container (AuditLogSecureContainerLogViewer.py:81).';


--
-- Name: alsclog_date_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alsclog_date_ix ON public."alscLog" USING btree ("containerID", "logDateTime");


--
-- Name: INDEX alsclog_date_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.alsclog_date_ix IS 'The fromDate half of the same call.';


--
-- PostgreSQL database dump complete
--

\unrestrict kF1WybOqw5npQ9I9LO8sjPZKitFhw8CpQn067ySGluG3lgPaTpiQyPOkqqrGcpC

