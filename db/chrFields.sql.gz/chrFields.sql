--
-- PostgreSQL database dump
--

\restrict ElCQxekfdsaiK2wIU7AAQKoqQ4L4ozVtc8zQmOGxqereozRopuOdlt2RFHolmGU

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrFields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrFields" (
    "departmentID" integer DEFAULT 0 NOT NULL,
    "fieldID" integer DEFAULT 0 NOT NULL,
    "fieldName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "skillTypeID1" integer DEFAULT 0 NOT NULL,
    "skillTypeID2" integer DEFAULT 0 NOT NULL,
    "typeID" integer,
    "typeQuantity" integer DEFAULT 0 NOT NULL,
    "typeID2" text,
    "typeQuantity2" integer DEFAULT 0 NOT NULL,
    "graphicID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrFields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrFields" ("departmentID", "fieldID", "fieldName", description, "skillTypeID1", "skillTypeID2", "typeID", "typeQuantity", "typeID2", "typeQuantity2", "graphicID") FROM stdin;
1	1	Advanced Gunnery	Teaches advanced targeting and firing techniques.	3300	3429	\N	0	\N	0	1432
1	2	Improved Laser  Weapons	Teaches improved handling of laser type weapons.	3303	3300	\N	0	\N	0	352
1	3	Rocketry	Teaches the fundamentals of missile ballistics.	3319	3320	\N	0	\N	0	1345
2	4	Command	Courses on leadership and group commanding.	3348	3331	\N	0	\N	0	1444
2	5	Pilot	Advanced studies on ship handling and navigation.	3449	3455	\N	0	\N	0	1443
2	6	Recon	Teaches advanced scanning and surveillance techniques.	3426	3431	\N	0	\N	0	74
3	7	Physics	Teaches how to use analytical thinking to research and develop hi-tech equipment.	3402	3403	\N	0	\N	0	1459
3	8	Applied Science	Courses in astrometry and how to use it for financial and scientific benefits.	3402	3413	\N	0	\N	0	1460
3	9	Biology	Teaches the fundamentals of human anatomy, which allows better use of cyber implants and gene therapy.	3405	3402	\N	0	\N	0	1461
4	10	Market Fundamental	Advanced courses on the market and the economy.	3443	3444	\N	0	\N	0	1462
4	11	Management	Teaches corporate and personnel management.	3443	3363	\N	0	\N	0	1463
4	12	Public Relations	Focuses on social and personal interaction skills. 	3355	3348	\N	0	\N	0	1464
5	13	Force Fields	Advanced studies on force field and energy shield technologies.	3402	3416	\N	0	\N	0	69
5	14	Reactor Technology	Instructs on ship power cores and general energy management.	3402	3417	\N	0	\N	0	1445
5	15	Electronics	Courses in handling of electronic equipment and electrical principles.	3402	3426	\N	0	\N	0	1405
6	16	Mining	Courses on astrophysics and metallurgy, with the focus being on efficient asteroid mining techniques.	3386	3385	\N	0	\N	0	1061
6	17	Manufacturing	Teaches factory management and operations.	3387	3380	\N	0	\N	0	1446
6	18	Ship Repair	Teaches advanced mechanical techniques as well as repair-robot handling.	3392	3393	\N	0	\N	0	80
7	19	Advanced Gunnery	Teaches advanced targeting and firing techniques.	3300	3429	\N	0	\N	0	1432
7	20	Improved Projectile Weapons	Teaches improved handling of projectile type weapons.	3302	3300	\N	0	\N	0	392
7	21	Rocketry	Teaches the fundamentals of missile ballistics.	3319	3320	\N	0	\N	0	1345
8	22	Command	Courses on leadership and group commanding.	3348	3329	\N	0	\N	0	1444
8	23	Pilot	Advanced studies on ship handling and navigation.	3455	3449	\N	0	\N	0	1443
8	24	Recon	Teaches advanced scanning and surveillance techniques.	3426	3431	\N	0	\N	0	74
9	25	Physics	Teaches how to use analytical thinking to research and develop hi-tech equipment.	3402	3403	\N	0	\N	0	1459
9	26	Applied Science	Courses in astrometry and how to use it for financial and scientific benefits.	3402	3413	\N	0	\N	0	1460
9	27	Biology	Teaches the fundamentals of human anatomy, which allows better use of cyber implants and gene therapy.	3402	3405	\N	0	\N	0	1461
10	28	Market Fundamental	Advanced courses on the market and the economy.	3444	3443	\N	0	\N	0	1462
10	29	Management	Teaches corporate and personnel management.	3363	3443	\N	0	\N	0	1463
10	30	Public Relations	Focuses on social and personal interaction skills. 	3356	3348	\N	0	\N	0	1464
11	31	Force Fields	Advanced studies on force field and energy shield technologies.	3402	3416	\N	0	\N	0	69
11	32	Reactor Technology	Instructs on ship power cores and general energy management.	3417	3413	\N	0	\N	0	1445
11	33	Electronics	Courses in handling of electronic equipment and electrical principles.	3426	3402	\N	0	\N	0	1405
12	34	Mining	Courses on astrophysics and metallurgy, with the focus being on efficient asteroid mining techniques.	3386	3385	\N	0	\N	0	1061
12	35	Manufacturing	Teaches factory management and operations.	3380	3387	\N	0	\N	0	1446
12	36	Ship Repair	Teaches advanced mechanical techniques as well as repair-robot handling.	3392	3393	\N	0	\N	0	80
13	37	Advanced Gunnery	Teaches advanced targeting and firing techniques.	3300	3429	\N	0	\N	0	1432
13	38	Improved Hybrid Weapons	Teaches improved handling of hybrid type weapons.	3301	3300	\N	0	\N	0	375
13	39	Rocketry	Teaches the fundamentals of missile ballistics.	3319	3320	\N	0	\N	0	1345
14	40	Command	Courses on leadership and group commanding.	3348	3330	\N	0	\N	0	1444
14	41	Pilot	Advanced studies on ship handling and navigation.	3449	3455	\N	0	\N	0	1443
14	42	Recon	Teaches advanced scanning and surveillance techniques.	3426	3431	\N	0	\N	0	74
15	43	Physics	Teaches how to use analytical thinking to research and develop hi-tech equipment.	3402	3403	\N	0	\N	0	1459
15	44	Applied Science	Courses in astrometry and how to use it for financial and scientific benefits.	3402	3413	\N	0	\N	0	1460
15	45	Biology	Teaches the fundamentals of human anatomy, which allows better use of cyber implants and gene therapy.	3405	3402	\N	0	\N	0	1461
16	46	Market Fundamental	Advanced courses on the market and the economy.	3443	3385	\N	0	\N	0	1462
16	47	Management	Teaches corporate and personnel management.	3443	3363	\N	0	\N	0	1463
16	48	Public Relations	Focuses on social and personal interaction skills. 	3355	3348	\N	0	\N	0	1464
17	49	Force Fields	Advanced studies on force field and energy shield technologies.	3402	3416	\N	0	\N	0	69
17	50	Reactor Technology	Instructs on ship power cores and general energy management.	3402	3417	\N	0	\N	0	1445
17	51	Electronics	Courses in handling of electronic equipment and electrical principles.	3402	3426	\N	0	\N	0	1405
18	52	Mining	Courses on astrophysics and metallurgy, with the focus being on efficient asteroid mining techniques.	3386	3385	\N	0	\N	0	1061
18	53	Manufacturing	Teaches factory management and operations.	3387	3380	\N	0	\N	0	1446
18	54	Ship Repair	Teaches advanced mechanical techniques as well as repair-robot handling.	3392	3393	\N	0	\N	0	80
19	55	Advanced Gunnery	Teaches advanced targeting and firing techniques.	3300	3429	\N	0	\N	0	1432
19	56	Improved Hybrid Weapons	Teaches improved handling of hybrid type weapons.	3301	3300	\N	0	\N	0	377
19	57	Rocketry	Teaches the fundamentals of missile ballistics.	3319	3320	\N	0	\N	0	1345
20	58	Command	Courses on leadership and group commanding.	3348	3328	\N	0	\N	0	1444
20	59	Pilot	Advanced studies on ship handling and navigation.	3449	3455	\N	0	\N	0	1443
20	60	Recon	Teaches advanced scanning and surveillance techniques.	3426	3431	\N	0	\N	0	74
21	61	Physics	Teaches how to use analytical thinking to research and develop hi-tech equipment.	3402	3403	\N	0	\N	0	1459
21	62	Applied Science	Courses in astrometry and how to use it for financial and scientific benefits.	3402	3413	\N	0	\N	0	1460
21	63	Biology	Teaches the fundamentals of human anatomy, which allows better use of cyber implants and gene therapy.	3405	3402	\N	0	\N	0	1461
22	64	Market Fundamental	Advanced courses on the market and the economy.	3443	3444	\N	0	\N	0	1462
22	65	Management	Teaches corporate and personnel management.	3443	3363	\N	0	\N	0	1463
22	66	Public Relations	Focuses on social and personal interaction skills. 	3355	3348	\N	0	\N	0	1464
23	67	Force Fields	Advanced studies on force field and energy shield technologies.	3402	3416	\N	0	\N	0	69
23	68	Reactor Technology	Instructs on ship power cores and general energy management.	3402	3417	\N	0	\N	0	1445
23	69	Electronics	Courses in handling of electronic equipment and electrical principles.	3402	3426	\N	0	\N	0	1405
24	70	Mining	Courses on astrophysics and metallurgy, with the focus being on efficient asteroid mining techniques.	3386	3385	\N	0	\N	0	1061
24	71	Manufacturing	Teaches factory management and operations.	3387	3380	\N	0	\N	0	1446
24	72	Ship Repair	Teaches advanced mechanical techniques as well as repair-robot handling.	3392	3393	\N	0	\N	0	80
25	73	Advanced Gunnery	Teaches advanced targeting and firing techniques.	3300	3429	\N	0	\N	0	1432
25	74	Improved Hybrid Weapons	Teaches improved handling of hybrid type weapons.	3301	3300	\N	0	\N	0	375
25	75	Rocketry	Teaches the fundamentals of missile ballistics.	3319	3320	\N	0	\N	0	1345
26	76	Command	Courses on leadership and group commanding.	3348	3330	\N	0	\N	0	1444
26	77	Pilot	Advanced studies on ship handling and navigation.	3449	3455	\N	0	\N	0	1443
26	78	Recon	Teaches advanced scanning and surveillance techniques.	3426	3431	\N	0	\N	0	74
27	79	Physics	Teaches how to use analytical thinking to research and develop hi-tech equipment.	3402	3403	\N	0	\N	0	1459
27	80	Applied Science	Courses in astrometry and how to use it for financial and scientific benefits.	3402	3413	\N	0	\N	0	1460
27	81	Biology	Teaches the fundamentals of human anatomy, which allows better use of cyber implants and gene therapy.	3405	3402	\N	0	\N	0	1461
28	82	Market Fundamental	Advanced courses on the market and the economy.	3443	3385	\N	0	\N	0	1462
28	83	Management	Teaches corporate and personnel management.	3443	3363	\N	0	\N	0	1463
28	84	Public Relations	Focuses on social and personal interaction skills. 	3355	3348	\N	0	\N	0	1464
29	85	Force Fields	Advanced studies on force field and energy shield technologies.	3402	3416	\N	0	\N	0	69
29	86	Reactor Technology	Instructs on ship power cores and general energy management.	3402	3417	\N	0	\N	0	1445
29	87	Electronics	Courses in handling of electronic equipment and electrical principles.	3402	3426	\N	0	\N	0	1405
30	88	Mining	Courses on astrophysics and metallurgy, with the focus being on efficient asteroid mining techniques.	3386	3385	\N	0	\N	0	1061
30	89	Manufacturing	Teaches factory management and operations.	3387	3380	\N	0	\N	0	1446
30	90	Ship Repair	Teaches advanced mechanical techniques as well as repair-robot handling.	3392	3393	\N	0	\N	0	80
\.


--
-- Name: chrFields chrFields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrFields"
    ADD CONSTRAINT "chrFields_pkey" PRIMARY KEY ("fieldID");


--
-- PostgreSQL database dump complete
--

\unrestrict ElCQxekfdsaiK2wIU7AAQKoqQ4L4ozVtc8zQmOGxqereozRopuOdlt2RFHolmGU

