--
-- PostgreSQL database dump
--

\restrict f9JHNYDaIYtE2nIqTHTI7KQeVGMZ0HhfdFegaP1or0V611WXYG0cfhWfxiLKW3h

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLSkins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLSkins" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "skinID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLSkins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLSkins" ("bloodlineID", gender, "skinID", npc) FROM stdin;
1	0	1	0
1	0	2	0
1	0	3	0
1	0	4	0
1	0	5	0
1	0	6	0
1	0	7	0
1	1	1	0
1	1	2	0
1	1	3	0
1	1	4	0
1	1	5	0
1	1	7	0
1	1	8	0
1	1	11	0
2	0	1	0
2	0	2	0
2	0	3	0
2	0	4	0
2	0	5	0
2	0	6	0
2	0	7	0
2	0	8	0
2	0	11	0
2	1	1	0
2	1	2	0
2	1	3	0
2	1	4	0
2	1	5	0
2	1	6	0
2	1	7	0
2	1	8	0
3	0	1	0
3	0	2	0
3	0	3	0
3	0	4	0
3	0	5	0
3	0	6	0
3	0	7	0
3	0	8	0
3	0	12	0
3	0	13	0
3	0	14	0
3	0	15	0
3	0	16	0
3	1	1	0
3	1	2	0
3	1	3	0
3	1	4	0
3	1	5	0
3	1	12	0
3	1	14	0
3	1	17	0
3	1	18	0
3	1	19	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	1	1	0
4	1	2	0
4	1	3	0
4	1	4	0
4	1	5	0
4	1	7	0
4	1	8	0
4	1	9	0
4	1	10	0
4	1	11	0
4	1	12	0
5	0	1	0
5	0	2	0
5	0	3	0
5	0	4	0
5	0	5	0
5	0	6	0
5	1	1	0
5	1	2	0
5	1	3	0
5	1	4	0
5	1	5	0
5	1	12	0
5	1	20	0
5	1	21	0
5	1	22	0
6	0	1	0
6	0	2	0
6	0	3	0
6	0	4	0
6	0	5	0
6	0	6	0
6	0	7	0
6	0	8	0
6	1	1	0
6	1	2	0
6	1	3	0
6	1	4	0
6	1	5	0
6	1	6	0
6	1	12	0
6	1	13	0
6	1	14	0
6	1	22	0
6	1	23	0
6	1	24	0
7	0	1	0
7	0	2	0
7	0	3	0
7	0	4	0
7	0	5	0
7	0	6	0
7	0	7	0
7	0	8	0
7	0	9	0
7	0	11	0
7	1	1	0
7	1	2	0
7	1	3	0
7	1	4	0
7	1	5	0
7	1	7	0
7	1	8	0
7	1	9	0
7	1	10	0
7	1	11	0
7	1	25	0
8	0	1	0
8	0	2	0
8	0	3	0
8	0	4	0
8	0	5	0
8	0	6	0
8	1	1	0
8	1	2	0
8	1	3	0
8	1	4	0
8	1	5	0
8	1	6	0
8	1	7	0
8	1	26	0
8	1	27	0
10	1	28	0
10	1	29	0
11	0	50	0
11	0	51	0
11	0	52	0
11	0	53	0
11	1	12	0
11	1	22	0
11	1	52	0
11	1	54	0
11	1	55	0
11	1	56	0
11	1	57	0
11	1	58	0
11	1	59	0
12	0	14	0
12	0	45	0
12	0	46	0
12	0	47	0
12	0	48	0
12	0	49	0
12	1	12	0
12	1	13	0
12	1	15	0
12	1	22	0
12	1	58	0
12	1	60	0
12	1	65	0
12	1	66	0
13	0	14	0
13	0	30	0
13	0	31	0
13	0	32	0
13	0	33	0
13	0	34	0
13	0	35	0
13	0	36	0
13	0	44	0
13	1	13	0
13	1	14	0
13	1	67	0
13	1	68	0
13	1	69	0
13	1	70	0
13	1	71	0
14	0	37	0
14	0	38	0
14	0	39	0
14	0	40	0
14	0	41	0
14	0	42	0
14	0	43	0
14	0	44	0
14	1	12	0
14	1	58	0
14	1	60	0
14	1	61	0
14	1	62	0
14	1	63	0
14	1	64	0
14	1	65	0
\.


--
-- Name: chrBLSkins chrBLSkins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLSkins"
    ADD CONSTRAINT "chrBLSkins_pkey" PRIMARY KEY ("bloodlineID", gender, "skinID");


--
-- PostgreSQL database dump complete
--

\unrestrict f9JHNYDaIYtE2nIqTHTI7KQeVGMZ0HhfdFegaP1or0V611WXYG0cfhWfxiLKW3h

