--
-- PostgreSQL database dump
--

\restrict 9ecvfmtXdwOETcDKf3e2hj2AdJoMy9bS544PsTDUwfHkCCRLD5YKiIrF4iDeR3D

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eveRoles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."eveRoles" (
    "roleID" bigint DEFAULT 0 NOT NULL,
    "roleName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: eveRoles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."eveRoles" ("roleID", "roleName", description) FROM stdin;
536870912	ACCOUNTMANAGEMENT	May manage user accounts
32	ADMIN	Administrator
67108864	BROADCAST	Broadcast messages in ESP
2048	CENTURION	Role for senior volunteers (Polaris)
2097152	CHTADMINISTRATOR	Administrate chat channels
1048576	CHTINVISIBLE	Invisible in chat channels
1073741824	DUNGEONMASTER	Design and master dungeons
16384	EBS	Eve Backend System
1024	GDH	Game Design High
512	GDL	Game Design Low
4	GDNPC	Game Design NPC
16	GMH	Game Master High
8	GML	Game Master Low
8388608	HEALOTHERS	/heal on others
4194304	HEALSELF	/heal on yourself
33554432	HOSTING	Hardware hosting and administration
128	HTTP	HTTP/ESP
262144	LEGIONEER	Role for junior volunteers
1	LOGIN	
268435456	N00BIE	Newbie dude
16777216	NEWSREPORTER	Forum and in-game news reporting role.
256	PETITIONEE	Users that may handle petitions
2	PLAYER	
65536	PROGRAMMER	Role for executing Python code in the context of the server
8192	QA	Quality Assurance
131072	REMOTESERVICE	
32768	ROLEADMIN	Administration of roles
64	SERVICE	
4294967295	SPAWN	Allowing /entity and /spawn
524288	TRANSLATION	Permission to do translations in the translation system
134217728	TRANSLATIONADMIN	Permission to do administer translations in the translation system
4294967295	TRANSLATIONEDITOR	Approves or Rejects translations
4096	WORLDMOD	World Modeling
\.


--
-- Name: eveRoles eveRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."eveRoles"
    ADD CONSTRAINT "eveRoles_pkey" PRIMARY KEY ("roleName");


--
-- PostgreSQL database dump complete
--

\unrestrict 9ecvfmtXdwOETcDKf3e2hj2AdJoMy9bS544PsTDUwfHkCCRLD5YKiIrF4iDeR3D

