--
-- PostgreSQL database dump
--

\restrict fuLBWclfwMgU4yxb3A3aRc25NSGp7iyLwUzrDE2DIjolR2TCwmUyBlBgxUGQJyG

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invOreYield; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invOreYield" (
    "typeID" integer DEFAULT 0 NOT NULL,
    "yieldTypeID" integer DEFAULT 0 NOT NULL,
    "yieldPercent" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: invOreYield; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invOreYield" ("typeID", "yieldTypeID", "yieldPercent") FROM stdin;
\.


--
-- Name: invOreYield invOreYield_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invOreYield"
    ADD CONSTRAINT "invOreYield_pkey" PRIMARY KEY ("typeID", "yieldTypeID");


--
-- Name: invOreYield_yieldTypeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invOreYield_yieldTypeID_idx" ON public."invOreYield" USING btree ("yieldTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict fuLBWclfwMgU4yxb3A3aRc25NSGp7iyLwUzrDE2DIjolR2TCwmUyBlBgxUGQJyG

