--
-- PostgreSQL database dump
--

\restrict GpggcmpL8yksQXCVZte5pZfnoLoLxqsTWEXJtoTs6FuxvtPKSWT4S6BsFuWPch8

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrNPCStandings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrNPCStandings" (
    "characterID" integer DEFAULT 0 NOT NULL,
    "fromID" integer DEFAULT 0 NOT NULL,
    standing double precision DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "chrNPCStandings"."fromID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrNPCStandings"."fromID" IS 'PROVEN: standingsvc.py:165 indexes npccharstandings on ''fromID''. NPC corp / faction / agent -> this character.';


--
-- Data for Name: chrNPCStandings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrNPCStandings" ("characterID", "fromID", standing) FROM stdin;
\.


--
-- Name: chrNPCStandings chrNPCStandings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrNPCStandings"
    ADD CONSTRAINT "chrNPCStandings_pkey" PRIMARY KEY ("characterID", "fromID");


--
-- Name: chrnpcstandings_from_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chrnpcstandings_from_ix ON public."chrNPCStandings" USING btree ("fromID");


--
-- Name: INDEX chrnpcstandings_from_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.chrnpcstandings_from_ix IS 'Standings from one NPC entity to all characters -- needed by the standing recalculation jobs (eventStandingReCalc* constants).';


--
-- PostgreSQL database dump complete
--

\unrestrict GpggcmpL8yksQXCVZte5pZfnoLoLxqsTWEXJtoTs6FuxvtPKSWT4S6BsFuWPch8

