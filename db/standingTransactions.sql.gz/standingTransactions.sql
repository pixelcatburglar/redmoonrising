--
-- PostgreSQL database dump
--

\restrict CHvMozaBxC2wpdzrNRFOlPPdsMRiGJ20qWzUdTNkBm8mdrUCMErKQXN1U6ywZu3

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: standingTransactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."standingTransactions" (
    "eventID" bigint NOT NULL,
    "eventTypeID" integer NOT NULL,
    "eventDateTime" bigint NOT NULL,
    "fromID" integer NOT NULL,
    "toID" integer NOT NULL,
    "originalFromID" integer NOT NULL,
    "originalToID" integer NOT NULL,
    modification double precision DEFAULT 0 NOT NULL,
    int_1 integer,
    int_2 integer,
    int_3 integer,
    msg text
);


--
-- Name: TABLE "standingTransactions"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."standingTransactions" IS 'Standing event log. Serves standing2.GetStandingTransactions(fromID, toID, direction, eventID, eventType, eventDateTime) (standingsvc.py:683), 25 rows per page ordered by eventID (standingsvc.py:689-690). Rendered by the SHARED formatter common/script/util/format.py:514-620.';


--
-- Name: COLUMN "standingTransactions"."eventID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."eventID" IS 'PROVEN: standingsvc.py:689 reads .eventID off row 0 and feeds it back as the paging cursor. bigint because this log is append-only and unbounded.';


--
-- Name: COLUMN "standingTransactions"."eventTypeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."eventTypeID" IS 'PROVEN, AND THE NAME DIFFERS FROM THE ARGUMENT: format.py:521 onwards branches on transaction.eventTypeID, while GetStandingTransactions takes it as `eventType`. Values are the static eveConstants eventStanding* set (25..154).';


--
-- Name: COLUMN "standingTransactions"."eventDateTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."eventDateTime" IS 'Windows FILETIME. PROVEN: standingsvc.py:698 util.FmtDate(each.eventDateTime,''ls''); also a query argument.';


--
-- Name: COLUMN "standingTransactions"."fromID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."fromID" IS 'PROVEN: format.py:525-527 cfg.eveowners.Get(transaction.fromID).name; also the 1st query argument.';


--
-- Name: COLUMN "standingTransactions"."toID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."toID" IS 'PROVEN: format.py:564; also the 2nd query argument.';


--
-- Name: COLUMN "standingTransactions"."originalFromID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."originalFromID" IS 'PROVEN: format.py:564-565. When a derived modification cascades, this is the owner the ORIGINAL change was from -- the client says so explicitly in the body text.';


--
-- Name: COLUMN "standingTransactions"."originalToID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions"."originalToID" IS 'PROVEN: format.py:564-565, the target of the original change.';


--
-- Name: COLUMN "standingTransactions".modification; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions".modification IS 'PROVEN: standingsvc.py:699 renders each.modification * 100.0 as a percentage; format.py:597 tests >= 0.0. The delta applied, NOT the resulting standing.';


--
-- Name: COLUMN "standingTransactions".int_1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions".int_1 IS 'PROVEN, POLYMORPHIC: an ownerID for combat/property/slash events (format.py:533 cfg.eveowners.Prime([transaction.int_1]), :562 PirateKillSecurityStatus, :576 SlashSet actor, :585 PlayerCorpSetStanding actor).';


--
-- Name: COLUMN "standingTransactions".int_2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions".int_2 IS 'PROVEN: a locationID for combat/property events -- format.py:534 cfg.evelocations.Prime([transaction.int_2]).';


--
-- Name: COLUMN "standingTransactions".int_3; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions".int_3 IS 'PROVEN: a typeID for combat/property events -- format.py:536 cfg.invtypes.Get(transaction.int_3).name (the ship/structure destroyed).';


--
-- Name: COLUMN "standingTransactions".msg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."standingTransactions".msg IS 'PROVEN: the free-text reason (format.py:576 SlashSet, :581 PlayerSetStanding, :585 PlayerCorpSetStanding) or a mission name (:588-591). EXCEPTION: for eventStandingAgentMissionBonus (80) format.py:598 does cPickle.loads(binascii.a2b_hex(transaction.msg)) -- a hex-encoded pickle, so this column is text and must round-trip bytes exactly.';


--
-- Name: standingTransactions_eventID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."standingTransactions" ALTER COLUMN "eventID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."standingTransactions_eventID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: standingTransactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."standingTransactions" ("eventID", "eventTypeID", "eventDateTime", "fromID", "toID", "originalFromID", "originalToID", modification, int_1, int_2, int_3, msg) FROM stdin;
\.


--
-- Name: standingTransactions_eventID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."standingTransactions_eventID_seq"', 1, false);


--
-- Name: standingTransactions standingTransactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."standingTransactions"
    ADD CONSTRAINT "standingTransactions_pkey" PRIMARY KEY ("eventID");


--
-- Name: standingtx_pair_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX standingtx_pair_ix ON public."standingTransactions" USING btree ("fromID", "toID", "eventID" DESC);


--
-- Name: INDEX standingtx_pair_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.standingtx_pair_ix IS 'standing2.GetStandingTransactions(fromID, toID, direction, eventID, ...) pages 25 at a time on eventID (standingsvc.py:683-690).';


--
-- Name: standingtx_to_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX standingtx_to_ix ON public."standingTransactions" USING btree ("toID", "eventID" DESC);


--
-- Name: INDEX standingtx_to_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.standingtx_to_ix IS 'The direction=towards-me variant of the same query.';


--
-- PostgreSQL database dump complete
--

\unrestrict CHvMozaBxC2wpdzrNRFOlPPdsMRiGJ20qWzUdTNkBm8mdrUCMErKQXN1U6ywZu3

