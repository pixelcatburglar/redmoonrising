--
-- PostgreSQL database dump
--

\restrict fLf2FjfclyjtOffO2nbX8rXLqc7oY5Lfzmug5CkvILDAOh0DwxLen6wO0C7QGv1

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ownerStandings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ownerStandings" (
    "fromID" integer NOT NULL,
    "toID" integer NOT NULL,
    standing double precision DEFAULT 0 NOT NULL,
    reason text,
    "setAt" bigint
);


--
-- Name: TABLE "ownerStandings"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ownerStandings" IS 'Standings declared by a non-character owner, and NPC standings towards a corp. Feeds the corpstandings and npccorpstandings slots of standing2.GetMyStandings (standingsvc.py:155) and receives standing2.SetCorpStanding (standingsvc.py:131).';


--
-- Name: COLUMN "ownerStandings"."fromID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ownerStandings"."fromID" IS 'PROVEN as a wire column: standingsvc.py:164 indexes npccorpstandings on ''fromID''. The declaring owner -- a corp, an alliance, or an NPC corp/faction.';


--
-- Name: COLUMN "ownerStandings"."toID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ownerStandings"."toID" IS 'PROVEN as a wire column: standingsvc.py:162 indexes corpstandings on ''toID''; 1st arg of SetCorpStanding (standingsvc.py:127).';


--
-- Name: COLUMN "ownerStandings".standing; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ownerStandings".standing IS 'PROVEN: standingsvc.py:188 `standing = standing.standing`. double precision; the UI renders it as a percentage (standingsvc.py:699 `''%-2.4f'' %% (each.modification * 100.0)` for the log, and -10.0..10.0 for the value).';


--
-- Name: COLUMN "ownerStandings".reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ownerStandings".reason IS 'PROVEN as an argument: 3rd arg of SetCorpStanding (standingsvc.py:127) and SetPlayerStanding (:114). Not read back off a standing row -- it surfaces through the standing transaction log instead (format.py:576 transaction.msg).';


--
-- Name: COLUMN "ownerStandings"."setAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ownerStandings"."setAt" IS 'INFERRED. Windows FILETIME of the last change; the decay job (eventStandingDecay 49) needs a baseline.';


--
-- Data for Name: ownerStandings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ownerStandings" ("fromID", "toID", standing, reason, "setAt") FROM stdin;
\.


--
-- Name: ownerStandings ownerStandings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ownerStandings"
    ADD CONSTRAINT "ownerStandings_pkey" PRIMARY KEY ("fromID", "toID");


--
-- Name: ownerstandings_to_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ownerstandings_to_ix ON public."ownerStandings" USING btree ("toID");


--
-- Name: INDEX ownerstandings_to_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ownerstandings_to_ix IS 'npccorpstandings: standingsvc.py:164 indexes that rowset on fromID, but the QUERY is "everything towards my corp", i.e. by toID.';


--
-- PostgreSQL database dump complete
--

\unrestrict fLf2FjfclyjtOffO2nbX8rXLqc7oY5Lfzmug5CkvILDAOh0DwxLen6wO0C7QGv1

