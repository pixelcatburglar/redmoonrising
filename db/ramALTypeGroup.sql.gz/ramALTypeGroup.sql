--
-- PostgreSQL database dump
--

\restrict Vf0LaLgrqTB71k43BE6t8fc7vznBjihzkCiIzM6PrfuUeAiHtfOfQvr0E5Ss7ne

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramALTypeGroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramALTypeGroup" (
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "activityID" integer DEFAULT 0 NOT NULL,
    "groupID" integer DEFAULT 0 NOT NULL,
    "timeMultiplier" double precision DEFAULT 0 NOT NULL,
    "materialMultiplier" double precision DEFAULT 0 NOT NULL
);


--
-- Data for Name: ramALTypeGroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramALTypeGroup" ("assemblyLineTypeID", "activityID", "groupID", "timeMultiplier", "materialMultiplier") FROM stdin;
6	1	25	1	1
6	1	26	1	1
6	1	27	1	1
6	1	28	1	1
6	1	31	1	1
6	1	324	1	1
6	1	358	1	1
6	1	380	1	1
6	1	381	1	1
6	1	419	1	1
6	1	420	1	1
6	1	463	1	1
6	1	485	1	1
6	1	513	1	1
6	1	540	1	1
6	1	541	1	1
6	1	543	1	1
6	1	547	1	1
10	1	30	1	1
10	1	485	0.75	1
10	1	513	0.75	1
10	1	547	0.75	1
10	1	659	1	1
17	1	25	1	1
17	1	31	1	1
17	1	420	1	1
17	1	549	1	1
18	1	324	1	1
18	1	541	1	1
19	1	26	1	1
19	1	28	1	1
19	1	419	1	1
19	1	463	1	1
20	1	358	1	1
20	1	380	1	1
20	1	540	1	1
20	1	543	1	1
21	1	27	1	1
21	1	485	1	1
21	1	513	1	1
21	1	547	1	1
22	1	381	1	1
26	1	97	1	1
26	1	100	1	1
26	1	101	1	1
26	1	299	1	1
26	1	470	1	1
26	1	544	1	1
26	1	545	1	1
26	1	639	1	1
26	1	640	1	1
26	1	641	1	1
27	1	332	1	1
27	1	334	1	1
27	1	536	1	1
31	1	25	1	1
31	1	26	1	1
31	1	27	1	1
31	1	28	1	1
31	1	31	1	1
31	1	324	1	1
31	1	358	1	1
31	1	380	1	1
31	1	381	1	1
31	1	419	1	1
31	1	420	1	1
31	1	463	1	1
31	1	485	1	1
31	1	513	1	1
31	1	540	1	1
31	1	541	1	1
31	1	543	1	1
31	1	547	1	1
35	1	25	1	1
35	1	26	1	1
35	1	27	1	1
35	1	28	1	1
35	1	31	1	1
35	1	324	1	1
35	1	358	1	1
35	1	380	1	1
35	1	381	1	1
35	1	419	1	1
35	1	420	1	1
35	1	463	1	1
35	1	513	1	1
35	1	540	1	1
35	1	541	1	1
35	1	543	1	1
37	1	303	1	1
\.


--
-- Name: ramALTypeGroup ramALTypeGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramALTypeGroup"
    ADD CONSTRAINT "ramALTypeGroup_pkey" PRIMARY KEY ("assemblyLineTypeID", "groupID");


--
-- PostgreSQL database dump complete
--

\unrestrict Vf0LaLgrqTB71k43BE6t8fc7vznBjihzkCiIzM6PrfuUeAiHtfOfQvr0E5Ss7ne

