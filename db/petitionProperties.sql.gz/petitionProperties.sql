--
-- PostgreSQL database dump
--

\restrict MN77T5t7BebJ6QY5HuwU6FuoAFKhXcZdA8XLflpsqx3GTz0e3swJ0w1nFXhfaNf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitionProperties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."petitionProperties" (
    "petitionID" integer NOT NULL,
    k text NOT NULL,
    v text DEFAULT ''::text NOT NULL
);


--
-- Name: TABLE "petitionProperties"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."petitionProperties" IS 'Per-petition answers to the category''s required fields. Assembled into the p.properties dict, which the client iterates with .iterkeys() and indexes by key (petition.py:507-509) and which may be None.';


--
-- Name: COLUMN "petitionProperties"."petitionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionProperties"."petitionID" IS 'Parent petition.';


--
-- Name: COLUMN "petitionProperties".k; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionProperties".k IS 'PROVEN: the dict KEY the client renders as a label (petition.py:508); matches petitionCategoryProperties."k".';


--
-- Name: COLUMN "petitionProperties".v; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionProperties".v IS 'PROVEN: the dict VALUE the client renders as text (petition.py:508 p.properties[pk]).';


--
-- Data for Name: petitionProperties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."petitionProperties" ("petitionID", k, v) FROM stdin;
\.


--
-- Name: petitionProperties petitionProperties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."petitionProperties"
    ADD CONSTRAINT "petitionProperties_pkey" PRIMARY KEY ("petitionID", k);



--
-- PostgreSQL database dump complete
--

\unrestrict MN77T5t7BebJ6QY5HuwU6FuoAFKhXcZdA8XLflpsqx3GTz0e3swJ0w1nFXhfaNf

