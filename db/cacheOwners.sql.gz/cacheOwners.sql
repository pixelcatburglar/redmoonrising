--
-- PostgreSQL database dump
--

\restrict DKikPqSu2m1hYp2in4yOkOtb5637a7jkSdT2h28xb4PPEsc1Q3guakEaR20ucVi

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cacheOwners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."cacheOwners" (
    "ownerID" integer DEFAULT 0 NOT NULL,
    "ownerName" text DEFAULT ''::text NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: cacheOwners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."cacheOwners" ("ownerID", "ownerName", "typeID") FROM stdin;
0	(none)	0
\.


--
-- Name: cacheOwners cacheOwners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."cacheOwners"
    ADD CONSTRAINT "cacheOwners_pkey" PRIMARY KEY ("ownerID");


--
-- PostgreSQL database dump complete
--

\unrestrict DKikPqSu2m1hYp2in4yOkOtb5637a7jkSdT2h28xb4PPEsc1Q3guakEaR20ucVi

