-- Foreign keys between tables, added after every table file has loaded.

ALTER TABLE ONLY public."allianceApplications"
    ADD CONSTRAINT "allianceApplications_allianceID_fkey" FOREIGN KEY ("allianceID") REFERENCES public.alliances("allianceID");

ALTER TABLE ONLY public."allianceMembers"
    ADD CONSTRAINT "allianceMembers_allianceID_fkey" FOREIGN KEY ("allianceID") REFERENCES public.alliances("allianceID");

ALTER TABLE ONLY public."crpSanctionedActions"
    ADD CONSTRAINT "crpSanctionedActions_voteCaseID_fkey" FOREIGN KEY ("voteCaseID") REFERENCES public."crpVoteCases"("voteCaseID") ON DELETE CASCADE;

ALTER TABLE ONLY public."crpVoteOptions"
    ADD CONSTRAINT "crpVoteOptions_voteCaseID_fkey" FOREIGN KEY ("voteCaseID") REFERENCES public."crpVoteCases"("voteCaseID") ON DELETE CASCADE;

ALTER TABLE ONLY public."crpVotes"
    ADD CONSTRAINT "crpVotes_voteCaseID_fkey" FOREIGN KEY ("voteCaseID") REFERENCES public."crpVoteCases"("voteCaseID") ON DELETE CASCADE;

ALTER TABLE ONLY public."killLogParticipants"
    ADD CONSTRAINT "killLogParticipants_killID_fkey" FOREIGN KEY ("killID") REFERENCES public."killLog"("killID") ON DELETE CASCADE;

ALTER TABLE ONLY public."petitionCategoryProperties"
    ADD CONSTRAINT "petitionCategoryProperties_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES public."petitionCategories"("categoryID") ON DELETE CASCADE;

ALTER TABLE ONLY public."petitionLog"
    ADD CONSTRAINT "petitionLog_petitionID_fkey" FOREIGN KEY ("petitionID") REFERENCES public.petitions("petitionID") ON DELETE CASCADE;

ALTER TABLE ONLY public."petitionMessages"
    ADD CONSTRAINT "petitionMessages_petitionID_fkey" FOREIGN KEY ("petitionID") REFERENCES public.petitions("petitionID") ON DELETE CASCADE;

ALTER TABLE ONLY public."petitionProperties"
    ADD CONSTRAINT "petitionProperties_petitionID_fkey" FOREIGN KEY ("petitionID") REFERENCES public.petitions("petitionID") ON DELETE CASCADE;
