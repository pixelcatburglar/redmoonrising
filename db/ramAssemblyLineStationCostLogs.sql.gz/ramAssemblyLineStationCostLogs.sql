--
-- PostgreSQL database dump
--

\restrict HkAiFe84fd833gWkVu2CQIaZn6CHm2NWiULtLL58EUqVFNvhzaxFA0ITwZlqleC

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramAssemblyLineStationCostLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramAssemblyLineStationCostLogs" (
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "stationID" integer DEFAULT 0 NOT NULL,
    "logDateTime" bigint DEFAULT 0 NOT NULL,
    _usage double precision DEFAULT 0 NOT NULL,
    "costPerHour" double precision DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "ramAssemblyLineStationCostLogs"."logDateTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramAssemblyLineStationCostLogs"."logDateTime" IS 'Windows FILETIME. bigint, not the dump''s char(20). INFERRED: no client call reads this table directly -- it feeds the installation-cost calculation behind ramProxy.GetInstallationDetails.';


--
-- Data for Name: ramAssemblyLineStationCostLogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramAssemblyLineStationCostLogs" ("assemblyLineTypeID", "stationID", "logDateTime", _usage, "costPerHour") FROM stdin;
\.


--
-- Name: ramAssemblyLineStationCostLogs ramAssemblyLineStationCostLogs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramAssemblyLineStationCostLogs"
    ADD CONSTRAINT "ramAssemblyLineStationCostLogs_pkey" PRIMARY KEY ("assemblyLineTypeID", "stationID", "logDateTime");


--
-- Name: ramAssemblyLineStationCostLogs_stationID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ramAssemblyLineStationCostLogs_stationID_idx" ON public."ramAssemblyLineStationCostLogs" USING btree ("stationID");


--
-- PostgreSQL database dump complete
--

\unrestrict HkAiFe84fd833gWkVu2CQIaZn6CHm2NWiULtLL58EUqVFNvhzaxFA0ITwZlqleC

