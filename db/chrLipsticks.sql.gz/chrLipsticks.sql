--
-- PostgreSQL database dump
--

\restrict IY1Cq9osW0aALG0w3B7xIDfHQnBaiqD0U7BhUbnV3wcYy3iis6rfKSETBMDkOp5

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrLipsticks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrLipsticks" (
    "lipstickID" integer DEFAULT 0 NOT NULL,
    "lipstickName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrLipsticks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrLipsticks" ("lipstickID", "lipstickName") FROM stdin;
1	1
2	2
3	3
4	4
5	5
6	6
7	Black gloss
8	Blue punk
9	Copperred
10	Crimson
11	Flaming lips
12	Gloss
13	Gold
14	Golden gloss
15	Luminant blue
16	Metallic diffused
17	None
18	Red gloss
19	Soft darkred
20	Soft purple
21	Taste of blood
22	14
23	15
24	7
25	8
26	9
27	Rose metal
28	Bourgogne gloss
29	Dark purple
30	Glossy
31	Pale rose
32	Purple gloss
33	Rose
34	Rust
35	Velvet light
36	White dot
37	10
38	12
39	-none
40	Grey gloss
41	Lead
42	11
43	13
44	16
45	17
46	Bright purple
47	Purple glossy
48	Subtle glossy purple
49	Subtle glossy pink
50	Subtle
51	Softgloss
52	Soft Rose
53	Glossy rose
54	Glossy pink
55	Subtle gloss
56	pink gloss
57	Heavy glossy
58	grey
59	Glossy red
60	Fiery red
61	Supergloss
62	Subtle pink
63	subtle bronzy
64	Pink superglossy
65	Pink glossy
66	Pink
67	Dark brown glossy
68	Crimson supergloss
\.


--
-- Name: chrLipsticks chrLipsticks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrLipsticks"
    ADD CONSTRAINT "chrLipsticks_pkey" PRIMARY KEY ("lipstickID");


--
-- PostgreSQL database dump complete
--

\unrestrict IY1Cq9osW0aALG0w3B7xIDfHQnBaiqD0U7BhUbnV3wcYy3iis6rfKSETBMDkOp5

