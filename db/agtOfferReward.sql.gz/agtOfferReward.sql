--
-- PostgreSQL database dump
--

\restrict R09xz1xClavJl6YsNWgNjWBGVGynf6U66LeZsa3pJ9murP6pzm0aNc03vQSQIzW

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtOfferReward; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtOfferReward" (
    "offerID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    quantity integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: agtOfferReward; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtOfferReward" ("offerID", "typeID", quantity) FROM stdin;
\.


--
-- Name: agtOfferReward agtOfferReward_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtOfferReward"
    ADD CONSTRAINT "agtOfferReward_pkey" PRIMARY KEY ("offerID", "typeID");


--
-- Name: agtOfferReward_typeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtOfferReward_typeID_idx" ON public."agtOfferReward" USING btree ("typeID");


--
-- PostgreSQL database dump complete
--

\unrestrict R09xz1xClavJl6YsNWgNjWBGVGynf6U66LeZsa3pJ9murP6pzm0aNc03vQSQIzW

