--
-- PostgreSQL database dump
--

\restrict 0BArdLom1wl22QR4Da9Y0GK5ogsNkYjwhzdPa6MJCShk2c97DqbrDBk50MaEuad

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: spawnBounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."spawnBounds" (
    "spawnID" integer DEFAULT 0 NOT NULL,
    "pointIndex" smallint DEFAULT 0 NOT NULL,
    x double precision DEFAULT 0 NOT NULL,
    y double precision DEFAULT 0 NOT NULL,
    z double precision DEFAULT 0 NOT NULL
);


--
-- Data for Name: spawnBounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."spawnBounds" ("spawnID", "pointIndex", x, y, z) FROM stdin;
1	0	1337258224155.34	62467364324.661	415036661760
2	0	1337258153444.66	62467435035.339	415036661760
3	0	1337258153444.66	62467364324.661	415036661760
4	0	1337258224155.34	62467435035.339	415036661760
5	0	1337258188800	62467435035.339	415036626404.661
6	0	1337258188800	62467364324.661	415036697115.339
7	0	1337258188800	62467364324.661	415036626404.661
8	0	1337258188800	62467435035.339	415036697115.339
9	0	700004	5000	500
10	0	700004	0	500
\.


--
-- Name: spawnBounds spawnBounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."spawnBounds"
    ADD CONSTRAINT "spawnBounds_pkey" PRIMARY KEY ("spawnID", "pointIndex");


--
-- PostgreSQL database dump complete
--

\unrestrict 0BArdLom1wl22QR4Da9Y0GK5ogsNkYjwhzdPa6MJCShk2c97DqbrDBk50MaEuad

