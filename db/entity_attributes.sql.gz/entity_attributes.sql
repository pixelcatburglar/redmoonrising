--
-- PostgreSQL database dump
--

\restrict cCyKekqUYUvbIKrAHn7Q1UxazMqYTVupZjDSrs26fbRNBsrTxBhCocK9qAbtUHe

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: entity_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entity_attributes (
    "itemID" integer DEFAULT 0 NOT NULL,
    "attributeID" integer DEFAULT 0 NOT NULL,
    "valueInt" bigint,
    "valueFloat" double precision
);


--
-- Name: COLUMN entity_attributes."valueInt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_attributes."valueInt" IS 'Signed integer override of a dogma attribute for one item. Exactly one of valueInt/valueFloat is set; the info window formats the two differently (infosvc.py:1108-1124), so the split is load-bearing, not redundant.';


--
-- Name: COLUMN entity_attributes."valueFloat"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.entity_attributes."valueFloat" IS 'Signed float attribute value. Holds negative values (resistance bonuses) and the -1 blueprint sentinel; corp_ui_votes.py:364 tests licensedProductionRunsRemaining != -1.';


--
-- Data for Name: entity_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entity_attributes ("itemID", "attributeID", "valueInt", "valueFloat") FROM stdin;
\.


--
-- Name: entity_attributes entity_attributes_one_value; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.entity_attributes
    ADD CONSTRAINT entity_attributes_one_value CHECK ((("valueInt" IS NULL) <> ("valueFloat" IS NULL))) NOT VALID;


--
-- Name: entity_attributes entity_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_attributes
    ADD CONSTRAINT entity_attributes_pkey PRIMARY KEY ("itemID", "attributeID");


--
-- Name: entity_attributes_attributeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "entity_attributes_attributeID_idx" ON public.entity_attributes USING btree ("attributeID");


--
-- PostgreSQL database dump complete
--

\unrestrict cCyKekqUYUvbIKrAHn7Q1UxazMqYTVupZjDSrs26fbRNBsrTxBhCocK9qAbtUHe

