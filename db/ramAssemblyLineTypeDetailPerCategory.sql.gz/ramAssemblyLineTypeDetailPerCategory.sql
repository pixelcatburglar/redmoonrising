--
-- PostgreSQL database dump
--

\restrict 9cDHe8fpt4nh8PpNONVyJjVpHAOzSMT9MY4YvgyGp7UrwuvdA3rh16fHlyNf063

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramAssemblyLineTypeDetailPerCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramAssemblyLineTypeDetailPerCategory" (
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "categoryID" integer DEFAULT 0 NOT NULL,
    "timeMultiplier" double precision,
    "materialMultiplier" double precision
);


--
-- Data for Name: ramAssemblyLineTypeDetailPerCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramAssemblyLineTypeDetailPerCategory" ("assemblyLineTypeID", "categoryID", "timeMultiplier", "materialMultiplier") FROM stdin;
2	6	5	5
2	7	1	1
2	8	1	1
2	18	1	1
3	7	1	1
5	9	1	1
6	2	1	1
6	4	1	1
6	5	1	1
6	7	1	1
6	8	1	1
6	17	1	1
6	18	1	1
6	22	1	1
6	23	1	1
7	9	1	1
8	9	1	1
11	6	1	1
11	7	1	1
11	8	1	1
11	18	1	1
12	6	1	1
12	7	1	1
12	8	1	1
12	18	1	1
13	6	1	1
13	7	1	1
13	8	1	1
13	18	1	1
23	2	1	1
23	4	1	1
23	5	1	1
23	7	1	1
23	17	1	1
23	22	1	1
24	2	1	1
24	4	1	1
24	5	1	1
24	7	1	1
24	22	1	1
25	8	1	1
28	9	1	1
29	9	1	1
30	9	1	1
31	2	1	1
31	4	1	1
31	5	1	1
31	7	1	1
31	8	1	1
31	17	1	1
31	18	1	1
31	22	1	1
31	23	1	1
32	9	1	1
33	9	1	1
34	9	1	1
35	2	1	1
35	4	1	1
35	5	1	1
35	7	1	1
35	8	1	1
35	17	1	1
35	18	1	1
35	22	1	1
35	23	1	1
36	6	1	1
36	7	1	1
36	8	1	1
38	6	1	1
38	7	1	1
38	8	1	1
39	6	1	1
39	7	1	1
39	8	1	1
40	6	1	1
40	7	1	1
40	8	1	1
43	2	1	1
43	4	1	1
43	5	1	1
43	7	1	1
43	8	1	1
43	17	1	1
43	18	1	1
43	22	1	1
43	23	1	1
45	2	1	1
45	4	1	1
45	5	1	1
45	7	1	1
45	8	1	1
45	17	1	1
45	18	1	1
45	22	1	1
45	23	1	1
46	2	1	1
46	4	1	1
46	5	1	1
46	7	0.8	1
46	8	1	1
46	17	1	1
46	18	1	1
46	22	1	1
46	23	1	1
47	2	1	1
47	4	1	1
47	5	1	1
47	7	1	1
47	8	1	1
47	17	1	1
47	18	1	1
47	22	1	1
47	23	1	1
48	2	1	1
48	4	1	1
48	5	1	1
48	7	1	1
48	8	1	1
48	17	1	1
48	18	1	1
48	22	1	1
48	23	1	1
52	2	1	1
52	4	1	1
52	5	1	1
52	7	0.6	1
52	8	1	1
52	17	1	1
52	18	1	1
52	22	1	1
52	23	1	1
54	2	1	1
54	4	1	1
54	5	1	1
54	7	1	1
54	8	1	1
54	17	1	1
54	18	1	1
54	22	1	1
54	23	1	1
56	2	1	1
56	4	1	1
56	5	1	1
56	7	1	1
56	8	1	1
56	17	1	1
56	18	1	1
56	22	1	1
56	23	1	1
57	2	1	1
57	4	1	1
57	5	1	1
57	7	1	1
57	8	1	1
57	17	1	1
57	18	1	1
57	22	1	1
57	23	1	1
58	2	1	1
58	4	1	1
58	5	1	1
58	7	1	1
58	8	1	1
58	17	1	1
58	18	1	1
58	22	1	1
58	23	1	1
59	2	1	1
59	4	1	1
59	5	1	1
59	7	1	1
59	8	1	1
59	17	1	1
59	18	1	1
59	22	1	1
59	23	1	1
60	2	1	1
60	4	1	1
60	5	1	1
60	7	1	1
60	8	1	1
60	17	1	1
60	18	1	1
60	22	1	1
60	23	1	1
61	2	1	1
61	4	1	1
61	5	1	1
61	7	1	1
61	8	1	1
61	17	1	1
61	18	1	1
61	22	1	1
61	23	1	1
62	2	1	1
62	4	1	1
62	5	1	1
62	7	0.4	1
62	8	1	1
62	17	1	1
62	18	1	1
62	22	1	1
66	2	1	1
66	4	1	1
66	5	1	1
66	7	1	1
66	8	1	1
66	17	1	1
66	18	1	1
66	22	1	1
66	23	1	1
67	2	1	1
67	4	1	1
67	5	1	1
67	7	1	1
67	8	1	1
67	17	1	1
67	18	1	1
67	22	1	1
67	23	1	1
68	2	1	1
68	4	1	1
68	5	1	1
68	7	1	1
68	8	1	1
68	17	1	1
68	18	1	1
68	22	1	1
68	23	1	1
69	9	1	1
70	2	1	1
70	4	1	1
70	5	1	1
70	7	1	1
70	8	1	1
70	17	1	1
70	18	1	1
70	22	1	1
70	23	1	1
71	9	1	1
72	9	1	1
73	9	1	1
74	9	1	1
75	9	1	1
76	9	1	1
77	9	1	1
78	9	1	1
79	2	1	1
79	4	1	1
79	5	1	1
79	7	1	1
79	8	1	1
79	17	1	1
79	18	1	1
79	22	1	1
79	23	1	1
80	2	1	1
80	4	1	1
80	5	1	1
80	7	1	1
80	8	1	1
80	17	1	1
80	18	1	1
80	22	1	1
80	23	1	1
81	9	1	1
82	9	1	1
83	9	1	1
84	9	1	1
85	9	1	1
86	9	1	1
87	9	1	1
88	9	1	1
89	9	1	1
90	9	1	1
91	9	1	1
92	9	1	1
93	2	1	1
93	4	1	1
93	5	1	1
93	7	1	1
93	8	1	1
93	17	1	1
93	18	1	1
93	22	1	1
93	23	1	1
96	2	1	1
96	4	1	1
96	5	1	1
96	7	1	1
96	8	1	1
96	17	1	1
96	18	1	1
96	22	1	1
96	23	1	1
105	2	1	1
105	4	1	1
105	5	1	1
105	7	1	1
105	8	1	1
105	17	1	1
105	18	1	1
105	22	1	1
105	23	1	1
107	9	1	1
108	9	1	1
109	9	1	1
110	9	1	1
111	9	1	1
112	9	1	1
113	9	1	1
114	9	1	1
115	9	1	1
127	9	1	1
128	9	1	1
129	9	1	1
130	9	1	1
131	9	1	1
132	9	1	1
133	9	1	1
134	9	1	1
136	2	1	1
136	4	1	1
136	5	1	1
136	7	1	1
136	8	1	1
136	17	1	1
136	18	1	1
136	22	1	1
136	23	1	1
137	2	1	1
137	4	1	1
137	5	1	1
137	7	1	1
137	8	1	1
137	17	1	1
137	18	1	1
137	22	1	1
137	23	1	1
138	9	1	1
145	25	1	1
146	9	1	1
147	9	1	1
148	9	1	1
149	6	1	1
149	7	1	1
149	8	1	1
149	9	1	1
150	7	0.95	1
150	8	0.9	1
\.


--
-- Name: ramAssemblyLineTypeDetailPerCategory ramAssemblyLineTypeDetailPerCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramAssemblyLineTypeDetailPerCategory"
    ADD CONSTRAINT "ramAssemblyLineTypeDetailPerCategory_pkey" PRIMARY KEY ("assemblyLineTypeID", "categoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict 9cDHe8fpt4nh8PpNONVyJjVpHAOzSMT9MY4YvgyGp7UrwuvdA3rh16fHlyNf063

