--
-- PostgreSQL database dump
--

\restrict qfdVqSogOiJS2JEbETeOWYcUOYrMcoUMGRS1AkHRCpclAexDPKDVDUmN2CQY1hg

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrSchools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrSchools" (
    "raceID" integer,
    "schoolID" integer NOT NULL,
    "schoolName" text,
    description text,
    "graphicID" integer,
    "corporationID" integer,
    "agentID" integer,
    "newAgentID" integer
);


--
-- Data for Name: chrSchools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrSchools" ("raceID", "schoolID", "schoolName", description, "graphicID", "corporationID", "agentID", "newAgentID") FROM stdin;
4	11	Imperial Academy	The Imperial Academy is rooted in tradition and generally considered sub-par to the more modern military institutes found in the other empires. However, it is the only one of its kind within the Amarr Empire, thus serving a vital function.	1447	1000166	3010801	3018681
4	12	Hedion University	Hedion University is located in the Hedion system - the first solar system colonized by the Amarrians after their own. The university was founded by spirited and liberal scholars free from the scrutinizing eye of the emperor and his theologians.	1448	1000165	3010791	3018680
4	13	Royal Amarr Institute	One of the oldest educational facilities in the world of EVE, the institute's origin date from the era when the Amarrians where still confined to their continent on Amarr Prime; before the empire and the Great Reclaiming.	1449	1000077	3013332	3018682
2	14	Republic Military School	The Republic Military School was for a long time the bastard child of the Minmatar education system - it existed because it was perceived as needed, but it had no support; most military personnel were Gallente trained. But in recent years, as the republic tries to ascertain its total independence, effort has been made to transform the RMS into a top-notch military school.	1450	1000170	3010841	3018678
2	15	Republic University	The Republic University was founded by Minmatar emigrates as a show of support for the fledgling republic shortly after its inception. The school is modeled after the University of Caille and based on the Gallentean education system.	1451	1000171	3010851	3018679
2	16	Pator Tech School	Pator Tech School was founded on the principle of helping gifted Minmatar children to be better qualified for high-level positions; something the republic was in dire need of when assembling a new government and administration virtually from scratch. This principle has held intact to this day, even if the foundations of the republic were firmly set a long time ago.	1458	1000172	3010861	3018677
1	17	State War Academy	The State War Academy was founded shortly after the Caldari State came into being while the war with the Gallente Federation was still in full swing. Due to this, the academy has always had a very combat oriented slant, as opposed to the broader scope of ship handling.	1452	1000167	3010811	3018676
1	18	Science and Trade Institute	Like all Caldari schools STI has a very formal curriculum that focuses primarily on the practical side of education. This results in a very dull and tedious learning process, but one that is remarkably efficient.	1453	1000045	3012249	3018675
1	19	School of Applied Knowledge	The School of Applied Knowledge focuses mainly on technical studies and is considered the best school for aspiring engineers. The school collaborates with many leading Caldari corporations, which benefits the school, the companies and not the least the students.	1455	1000044	3012239	3018672
8	20	Federal Navy Academy	The Federation Navy acts upon a recent policy of upgrading the professionalism of its cadets. The result is a leaner, meaner academy with much stricter entry requirements than before and even stricter tutoring.	1454	1000168	3010821	3018684
8	21	University of Caille	The largest school in the world of EVE, with almost half a million students, the UoC has long acted as a melting pot for cultures and ideas from all over. As befits its status UoC offers a wide range of studies, but is best known for its extensive anthropology department.	1456	1000115	3009793	3018685
8	22	Center for Advanced Studies	Originally conceived as a think-tank for researchers at Chemal Tech the CAS evolved into an independent education facility that today is considered one of the very best technical schools in the world of EVE.	1457	1000169	3010831	3018683
16	23	Society of Conscious Thought	The Society of Conscious Thought was founded some 300 years ago. Since then it has seen many guises, including spiritual healing-house and political power-block. Today, it is one of the finest and most respected educational facilities in the world of EVE. As it is only loosely connected to the Jove state the Society admits non-Jovian students. For them, being admitted to a Society school is a great honor and an almost certain ticket to a prestigious position later in life.	\N	1000131	3010177	\N
16	24	Material Institute	The Jovians, with all their power and resources, are not always very pragmatic. The Material Institute was founded precisely to combat this. Most Jovians are already well schooled in the technical aspects, but they need some tutoring on the practical application for use in industry and manufacturing.	\N	1000177	3010484	\N
16	25	Academy of Aggressive Behaviour	Most Jovians have had their aggressive instincts curbed or even removed through genetic engineering. The Academy for Aggressive Behaviour, responsible for training space cadets, uses the latest in gene therapies to re-introuduce the base instincts to their students to ensure the animalistic nature of humans, so important for fighting, is alive and fresh in them.	\N	1000178	3010447	\N
\.


--
-- Name: chrSchools chrSchools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrSchools"
    ADD CONSTRAINT "chrSchools_pkey" PRIMARY KEY ("schoolID");


--
-- PostgreSQL database dump complete
--

\unrestrict qfdVqSogOiJS2JEbETeOWYcUOYrMcoUMGRS1AkHRCpclAexDPKDVDUmN2CQY1hg

