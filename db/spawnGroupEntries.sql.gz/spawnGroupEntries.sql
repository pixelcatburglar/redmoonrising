--
-- PostgreSQL database dump
--

\restrict qyAiGD6q8Dw7DFneKcxvwZ6ELN4JHUcWiqjgTzs3jcgl8eLPL9h7lbGDTVga7oi

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: spawnGroupEntries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."spawnGroupEntries" (
    "spawnGroupID" integer DEFAULT 0 NOT NULL,
    "npcTypeID" integer DEFAULT 0 NOT NULL,
    quantity smallint DEFAULT 1 NOT NULL,
    probability double precision DEFAULT 1 NOT NULL,
    "ownerID" integer DEFAULT 0 NOT NULL,
    "corporationID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: spawnGroupEntries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."spawnGroupEntries" ("spawnGroupID", "npcTypeID", quantity, probability, "ownerID", "corporationID") FROM stdin;
1	3739	1	1	1000044	1000044
\.


--
-- Name: spawnGroupEntries spawnGroupEntries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."spawnGroupEntries"
    ADD CONSTRAINT "spawnGroupEntries_pkey" PRIMARY KEY ("spawnGroupID", "npcTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict qyAiGD6q8Dw7DFneKcxvwZ6ELN4JHUcWiqjgTzs3jcgl8eLPL9h7lbGDTVga7oi

