--
-- PostgreSQL database dump
--

\restrict fEZzFeeyFAioFVUmqBTGg5HKIcjxGkOyuPueXe3ff7m7VJB4M778kBMjER4c2L7

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: botRelations; Type: TABLE; Schema: public; Owner: rmr
--

CREATE TABLE public."botRelations" (
    "sideID" integer NOT NULL,
    "charID" integer NOT NULL,
    heat real DEFAULT 0 NOT NULL,
    favor real DEFAULT 0 NOT NULL,
    flags integer DEFAULT 0 NOT NULL,
    "updatedAt" bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public."botRelations" OWNER TO rmr;

--
-- Name: TABLE "botRelations"; Type: COMMENT; Schema: public; Owner: rmr
--

COMMENT ON TABLE public."botRelations" IS 'MADE: what each bot alliance (or corporation outside one) holds against or for each player: heat from losses, favor from help, and what it has done about it (bots::relations).';


--
-- Name: botRelations botRelations_pkey; Type: CONSTRAINT; Schema: public; Owner: rmr
--

ALTER TABLE ONLY public."botRelations"
    ADD CONSTRAINT "botRelations_pkey" PRIMARY KEY ("sideID", "charID");


--
-- PostgreSQL database dump complete
--

\unrestrict fEZzFeeyFAioFVUmqBTGg5HKIcjxGkOyuPueXe3ff7m7VJB4M778kBMjER4c2L7

