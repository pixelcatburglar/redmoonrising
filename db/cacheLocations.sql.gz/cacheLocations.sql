--
-- PostgreSQL database dump
--

\restrict qkaigKECcDgDg9nYQQjeacZdBBxExelyt7JdyrnHrtmj4zexo719Exfb6U9xjNf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cacheLocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."cacheLocations" (
    "locationID" integer DEFAULT 0 NOT NULL,
    "locationName" text DEFAULT ''::text NOT NULL,
    x double precision DEFAULT 0 NOT NULL,
    y double precision DEFAULT 0 NOT NULL,
    z double precision DEFAULT 0 NOT NULL
);


--
-- Data for Name: cacheLocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."cacheLocations" ("locationID", "locationName", x, y, z) FROM stdin;
0	(none)	0	0	0
\.


--
-- Name: cacheLocations cacheLocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."cacheLocations"
    ADD CONSTRAINT "cacheLocations_pkey" PRIMARY KEY ("locationID");


--
-- PostgreSQL database dump complete
--

\unrestrict qkaigKECcDgDg9nYQQjeacZdBBxExelyt7JdyrnHrtmj4zexo719Exfb6U9xjNf

