--
-- PostgreSQL database dump
--

\restrict Szt1zAPfhxfoEMhL0qA0PdS3ueFJmcV2gPGIpNOwg3xOixv7vJdS3nKlqpKhAcu

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLLights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLLights" (
    "lightID" integer DEFAULT 0 NOT NULL,
    "lightName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrBLLights; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLLights" ("lightID", "lightName") FROM stdin;
1	Backlit
2	Blue
3	Blue night
4	Coolblue
5	Drama sidelights
6	Flashlight
7	Icy
8	Moonlight
9	Nocturne
10	Overcast
11	Pale yellow backlit
12	Red alert
13	Sidelight
14	Singleside
15	Soft
16	Soft sidelight
17	Softly
18	Studiolights
19	UnderlitV2
20	Yellowsidelights
\.


--
-- Name: chrBLLights chrBLLights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLLights"
    ADD CONSTRAINT "chrBLLights_pkey" PRIMARY KEY ("lightID");


--
-- PostgreSQL database dump complete
--

\unrestrict Szt1zAPfhxfoEMhL0qA0PdS3ueFJmcV2gPGIpNOwg3xOixv7vJdS3nKlqpKhAcu

