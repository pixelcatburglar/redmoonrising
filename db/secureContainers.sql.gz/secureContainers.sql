--
-- PostgreSQL database dump
--

\restrict qiM6KULsb7Nj5ebHbxeLIhJXdIGxcLPIW1db3VTtGcl09cuYU9OA4dljlsNfxrM

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: secureContainers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."secureContainers" (
    "itemID" integer NOT NULL,
    config integer DEFAULT 0 NOT NULL,
    "passwordGeneral" text,
    "passwordConfig" text
);


--
-- Name: TABLE "secureContainers"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."secureContainers" IS 'Per-container ALSC configuration and passwords. Serves the bound-object calls ALSCConfigGet / ALSCConfigSet / SetPassword on an inventory container (menusvc.py:1383, :1422, :1359). Absent row == config 0 and no passwords.';


--
-- Name: COLUMN "secureContainers"."itemID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."secureContainers"."itemID" IS 'entity.itemID of the container. PROVEN: every call is made on eve.GetInventoryFromId(itemID) (menusvc.py:1382) and the menu entries pass invItem.itemID (menusvc.py:223).';


--
-- Name: COLUMN "secureContainers".config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."secureContainers".config IS 'Bitmask returned by ALSCConfigGet and written by ALSCConfigSet. PROVEN bits: const.ALSCPasswordNeededToOpen | ToLock | ToUnlock | ToViewAuditLog, tested as `value & config == value` (menusvc.py:1407) and recombined by summation (menusvc.py:1421).';


--
-- Name: COLUMN "secureContainers"."passwordGeneral"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."secureContainers"."passwordGeneral" IS 'The general (open/take) password, SCCPasswordTypeGeneral = 1 in eveConstants. PROVEN: SetPassword(which, old, new) (menusvc.py:1359) with which chosen from the two SCCPasswordType* constants (menusvc.py:1433-1435). Also used by groupConstructionPlatform ("access password", menusvc.py:223).';


--
-- Name: COLUMN "secureContainers"."passwordConfig"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."secureContainers"."passwordConfig" IS 'The configuration password, SCCPasswordTypeConfig = 2 in eveConstants. Guards ALSCConfigSet and RetrievePasswordALSC (menusvc.py:1425). Also the construction platform''s "build password".';


--
-- Data for Name: secureContainers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."secureContainers" ("itemID", config, "passwordGeneral", "passwordConfig") FROM stdin;
\.


--
-- Name: secureContainers secureContainers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."secureContainers"
    ADD CONSTRAINT "secureContainers_pkey" PRIMARY KEY ("itemID");


--
-- PostgreSQL database dump complete
--

\unrestrict qiM6KULsb7Nj5ebHbxeLIhJXdIGxcLPIW1db3VTtGcl09cuYU9OA4dljlsNfxrM

