--
-- PostgreSQL database dump
--

\restrict eL9SPler2dahjaxzsGSZbTthAmXWPHMZ6cPdVIfIevphBRpb6STG6UE1jPbf2f6

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtMissionTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtMissionTypes" (
    "missionTypeID" integer NOT NULL,
    "missionTypeName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: agtMissionTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtMissionTypes" ("missionTypeID", "missionTypeName") FROM stdin;
\.


--
-- Name: agtMissionTypes agtMissionTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtMissionTypes"
    ADD CONSTRAINT "agtMissionTypes_pkey" PRIMARY KEY ("missionTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict eL9SPler2dahjaxzsGSZbTthAmXWPHMZ6cPdVIfIevphBRpb6STG6UE1jPbf2f6

