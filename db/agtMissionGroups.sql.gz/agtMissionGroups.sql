--
-- PostgreSQL database dump
--

\restrict 0oUmljQ13XtmX2NMfGxzf2fPVOMaJermPamV7XJHvVcqo9reyIwbPVxojan9K1a

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtMissionGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtMissionGroups" (
    "corporationID" integer DEFAULT 0 NOT NULL,
    "divisionID" integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    "missionID" integer
);


--
-- Data for Name: agtMissionGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtMissionGroups" ("corporationID", "divisionID", level, "missionID") FROM stdin;
\.


--
-- Name: agtMissionGroups agtMissionGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtMissionGroups"
    ADD CONSTRAINT "agtMissionGroups_pkey" PRIMARY KEY ("corporationID", "divisionID", level);


--
-- Name: agtMissionGroups_divisionID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtMissionGroups_divisionID_idx" ON public."agtMissionGroups" USING btree ("divisionID");


--
-- Name: agtMissionGroups_missionID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtMissionGroups_missionID_idx" ON public."agtMissionGroups" USING btree ("missionID");


--
-- PostgreSQL database dump complete
--

\unrestrict 0oUmljQ13XtmX2NMfGxzf2fPVOMaJermPamV7XJHvVcqo9reyIwbPVxojan9K1a

