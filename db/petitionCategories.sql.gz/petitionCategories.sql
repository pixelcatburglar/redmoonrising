--
-- PostgreSQL database dump
--

\restrict Aol5t4WYmdUZMQkPLZQjTBfKlT6hf6XrKGCSWYitgd3sSGohRZv4hNBHvGcYocU

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitionCategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."petitionCategories" (
    "categoryID" integer NOT NULL,
    "displayName" text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "escalatesTo" integer
);


--
-- Name: TABLE "petitionCategories"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."petitionCategories" IS 'CONFIG table for petitioner.GetCategories / GetCategoryName. Must be seeded -- the create-petition form is built from it (petition.py:354-360). Category 1 is the UI default (petition.py:355); 4 and 5 attach the chat log and 7 suppresses the combat log (petition.py:435, :447).';


--
-- Name: COLUMN "petitionCategories"."categoryID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategories"."categoryID" IS 'PROVEN: petition.py:297 `if each.categoryID == id`, :355 the ==1 default, :357 used as the checkbox key.';


--
-- Name: COLUMN "petitionCategories"."displayName"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategories"."displayName" IS 'PROVEN: petition.py:357 and :401 render r.displayName.';


--
-- Name: COLUMN "petitionCategories".description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategories".description IS 'PROVEN, STRUCTURED: petition.py:356 does r.description.split(''::''); element 0 is the purpose text and every later element becomes an "Open Browser" button URL (petition.py:358-360).';


--
-- Name: COLUMN "petitionCategories"."escalatesTo"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategories"."escalatesTo" IS 'INFERRED as a column of this table: p.escalatesTo is read off the PETITION row (petition.py:490) and is most naturally a property of its category.';


--
-- Data for Name: petitionCategories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."petitionCategories" ("categoryID", "displayName", description, "escalatesTo") FROM stdin;
\.


--
-- Name: petitionCategories petitionCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."petitionCategories"
    ADD CONSTRAINT "petitionCategories_pkey" PRIMARY KEY ("categoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict Aol5t4WYmdUZMQkPLZQjTBfKlT6hf6XrKGCSWYitgd3sSGohRZv4hNBHvGcYocU

