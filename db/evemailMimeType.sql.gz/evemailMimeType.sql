--
-- PostgreSQL database dump
--

\restrict 9gvzOrvRYwqK6D0a4SKDVy30YnjzdyfepYVTJK885lPRaAHccelKmmwNPUU8fJI

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: evemailMimeType; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."evemailMimeType" (
    "mimeTypeID" integer NOT NULL,
    "mimeType" text DEFAULT ''::text NOT NULL,
    "binary" smallint DEFAULT 0 NOT NULL
);


--
-- Data for Name: evemailMimeType; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."evemailMimeType" ("mimeTypeID", "mimeType", "binary") FROM stdin;
1	text/plain	0
\.


--
-- Name: evemailMimeType evemailMimeType_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."evemailMimeType"
    ADD CONSTRAINT "evemailMimeType_pkey" PRIMARY KEY ("mimeTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict 9gvzOrvRYwqK6D0a4SKDVy30YnjzdyfepYVTJK885lPRaAHccelKmmwNPUU8fJI

