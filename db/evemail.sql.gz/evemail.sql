--
-- PostgreSQL database dump
--

\restrict Afu9b292LwkTxCBeN8tW2dkrA64E9A4UnUdGGzxmtec3xEcVKXYlSntLCepxN6A

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: evemail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evemail (
    "channelID" integer DEFAULT 0 NOT NULL,
    "messageID" integer NOT NULL,
    "senderID" integer DEFAULT 0 NOT NULL,
    subject text DEFAULT ''::text NOT NULL,
    created bigint DEFAULT 0 NOT NULL,
    read smallint DEFAULT 0 NOT NULL
);


--
-- Name: evemail_messageID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."evemail_messageID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evemail_messageID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."evemail_messageID_seq" OWNED BY public.evemail."messageID";


--
-- Name: evemail messageID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evemail ALTER COLUMN "messageID" SET DEFAULT nextval('public."evemail_messageID_seq"'::regclass);


--
-- Data for Name: evemail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evemail ("channelID", "messageID", "senderID", subject, created, read) FROM stdin;
\.


--
-- Name: evemail_messageID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."evemail_messageID_seq"', 1, false);


--
-- Name: evemail evemail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evemail
    ADD CONSTRAINT evemail_pkey PRIMARY KEY ("messageID");


--
-- Name: evemail_channel_created_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evemail_channel_created_ix ON public.evemail USING btree ("channelID", created DESC);


--
-- Name: INDEX evemail_channel_created_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.evemail_channel_created_ix IS 'Mail is delivered INTO a channel -- LSC.Page(receivers, subject, body, attachments) where each receiver is a channelID (newmessage.py:173) -- and the inbox lists newest first. channelID is the one column every mail query filters on and the shipped table had no index on it at all.';


--
-- Name: evemail_sender_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evemail_sender_ix ON public.evemail USING btree ("senderID");


--
-- Name: INDEX evemail_sender_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.evemail_sender_ix IS 'Sent-mail view; inbox.py reads msg.senderID.';


--
-- Name: evemail_unread_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX evemail_unread_ix ON public.evemail USING btree ("channelID") WHERE (read = 0);


--
-- Name: INDEX evemail_unread_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.evemail_unread_ix IS 'Unread count / notification badge. Note the shipped design flaw: "read" is per MESSAGE, not per recipient, so a mail to a corp channel has one shared read flag.';


--
-- PostgreSQL database dump complete
--

\unrestrict Afu9b292LwkTxCBeN8tW2dkrA64E9A4UnUdGGzxmtec3xEcVKXYlSntLCepxN6A

