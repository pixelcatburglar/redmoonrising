--
-- PostgreSQL database dump
--

\restrict j56DPIw7Z98JVZ80R2HdZbBuB2PzEc6LyUSvY74WYLZRpEpopu89aNbhHKlbHQE

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramALTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramALTypes" (
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "assemblyLineTypeName" text DEFAULT ''::text NOT NULL,
    "typeName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "activityID" integer DEFAULT 0 NOT NULL,
    "baseTimeMultiplier" double precision DEFAULT 0 NOT NULL,
    "baseMaterialMultiplier" double precision DEFAULT 0 NOT NULL,
    volume double precision DEFAULT 0 NOT NULL
);


--
-- Data for Name: ramALTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramALTypes" ("assemblyLineTypeID", "assemblyLineTypeName", "typeName", description, "activityID", "baseTimeMultiplier", "baseMaterialMultiplier", volume) FROM stdin;
2	Lab Slot	Lab Slot	Copying	5	1	1	1
3	Reverse Engineering	Reverse Engineering	Reverse Engineering	7	1	1	1
5	STATION copying	STATION copying	STATION copying	5	1	1	1
6	STATION manufacturing	STATION manufacturing	STATION manufacturing	1	1	1	1
7	STATION material productivity	STATION material productivity	STATION material productivity	4	1	1	1
8	STATION productivity time	STATION productivity time	STATION productivity time	3	1	1	1
10	Capital Ship Assembly	Capital Ship Assembly	Capital Ship Assembly	1	1	1	1
11	ME Research	ME Research	ME Research	4	1	1	1
12	PE Research	PE Research	PE Research	3	1	1	1
13	Manufacturing	Manufacturing	Manufacturing	1	1	1	1
17	Small Ship Assembly Array	Small Ship Assembly Array	Small Ship Assembly Array\r\n	1	0.75	1	1
18	Advanced Small Ship Assembly Array	Advanced Small Ship Assembly Array	Advanced Small Ship Assembly Array\r\n	1	0.75	1.1	1
19	Medium Ship Assembly Array	Medium Ship Assembly Array	Medium Ship Assembly Array\r\n	1	0.75	1	1
20	Advanced Medium Ship Assembly Array	Advanced Medium Ship Assembly Array	Advanced Medium Ship Assembly Array\r\n	1	0.75	1.1	1
21	Large Ship Assembly Array	Large Ship Assembly Array	Large Ship Assembly Array\r\n	1	0.75	1	1
22	Advanced Large Ship Assembly Array	Advanced Large Ship Assembly Array	Advanced Large Ship Assembly Array\r\n	1	0.75	1.1	1
23	Rapid Equipment Assembly Array	Rapid Equipment Assembly Array	Rapid Equipment Assembly Array\r\n	1	0.65	1.2	1
24	Efficient Equipment Assembly Array	Efficient Equipment Assembly Array	Efficient Equipment Assembly Array\r\n	1	0.8	1	1
25	Ammunition Assembly Array	Ammunition Assembly Array	Ammunition Assembly Array	1	0.75	1	1
26	Drone Assembly Array	Drone Assembly Array	Drone Assembly Array	1	0.75	1	1
27	Component Assembly Array	Component Assembly Array	Component Assembly Array	1	0.75	1.1	1
28	Mobile Laboratory ME	Mobile Laboratory ME	Mobile Laboratory ME	4	0.75	1	1
29	Mobile Laboratory PE	Mobile Laboratory PE	Mobile Laboratory PE	3	0.75	1	1
30	Mobile Laboratory Copying	Mobile Laboratory Copying	Mobile Laboratory Copying	5	0.75	1	1
31	Amarr Outpost Manufacturing	Amarr Outpost Manufacturing	Amarr Outpost Manufacturing	1	0.7	1	1
32	Caldari Outpost ME Research	Caldari Outpost ME Research	Caldari Outpost ME Research	4	0.7	0.95	1
33	Caldari Outpost PE Research	Caldari Outpost PE Research	Caldari Outpost PE Research	3	0.7	0.95	1
34	Caldari Outpost Copying	Caldari Outpost Copying	Caldari Outpost Copying	5	0.7	0.95	1
35	STATION 0.5+ Manufacturing	STATION 0.5+ Manufacturing	STATION 0.5+ Manufacturing	1	1	1	1
36	Invention	Invention		8	1	1	1
37	Booster Manufacturing	Booster Manufacturing	Booster Manufacturing	1	1	1	1
\.


--
-- Name: ramALTypes ramALTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramALTypes"
    ADD CONSTRAINT "ramALTypes_pkey" PRIMARY KEY ("assemblyLineTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict j56DPIw7Z98JVZ80R2HdZbBuB2PzEc6LyUSvY74WYLZRpEpopu89aNbhHKlbHQE

