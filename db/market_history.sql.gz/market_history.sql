--
-- PostgreSQL database dump
--

\restrict enaXskGoRFO2hrKtUpygaStCRkkEyYgrKf2Q7JBUg8va6HLvG6VK4OlC1UhLVff

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_history (
    "regionID" integer NOT NULL,
    "typeID" integer NOT NULL,
    "historyDate" bigint NOT NULL,
    "lowPrice" double precision DEFAULT 0 NOT NULL,
    "highPrice" double precision DEFAULT 0 NOT NULL,
    "avgPrice" double precision DEFAULT 0 NOT NULL,
    volume bigint DEFAULT 0 NOT NULL,
    orders integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE market_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.market_history IS 'Daily price history per region and type. GetOldPriceHistory must emit ascending historyDate (marketsvc.py:273); historyDate is a day-aligned FILETIME.';


--
-- Name: COLUMN market_history."regionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history."regionID" IS 'INFERRED name; the SCOPE is proven -- marketsvc.py:103-105 clears the whole market cache on a session regionid change, so history is per region. Never sent to the client.';


--
-- Name: COLUMN market_history."typeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history."typeID" IS 'invTypes.typeID. The only argument GetOldPriceHistory/GetNewPriceHistory take (marketsvc.py:266-267). Not sent to the client either -- the six wire columns are positions 0..5 only.';


--
-- Name: COLUMN market_history."historyDate"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history."historyDate" IS 'Windows FILETIME, midnight of the day. Position 0. NAME PROVEN: marketsvc.py:273 `while lastTime + DAY < entry.historyDate` and :279 `lastTime = entry.historyDate`; position proven by pricehistorychart.py:114 FmtDate(rec[0]).';


--
-- Name: COLUMN market_history."lowPrice"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history."lowPrice" IS 'Position 1, rendered with FmtISK (pricehistorychart.py:114 rec[1], header "low"). NAME INFERRED.';


--
-- Name: COLUMN market_history."highPrice"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history."highPrice" IS 'Position 2, rendered with FmtISK (pricehistorychart.py:114 rec[2], header "high"). NAME INFERRED.';


--
-- Name: COLUMN market_history."avgPrice"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history."avgPrice" IS 'Position 3. NAME PROVEN: marketsvc.py:280 `lastPrice = entry.avgPrice`; position proven by pricehistorychart.py:114 rec[3], header "avg.".';


--
-- Name: COLUMN market_history.volume; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history.volume IS 'Units traded. Position 4, rendered with FmtAmt (pricehistorychart.py:114 rec[4], header "volume"). NAME INFERRED. bigint because a day of trimark volume overflows int32.';


--
-- Name: COLUMN market_history.orders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_history.orders IS 'Number of orders that day. Position 5, rendered with FmtAmt (pricehistorychart.py:114 rec[5], header "orders"). NAME INFERRED. The client''s synthetic gap-filler rows put 0 here (marketsvc.py:275).';


--
-- Data for Name: market_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.market_history ("regionID", "typeID", "historyDate", "lowPrice", "highPrice", "avgPrice", volume, orders) FROM stdin;
\.


--
-- Name: market_history market_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_history
    ADD CONSTRAINT market_history_pkey PRIMARY KEY ("regionID", "typeID", "historyDate");


--
-- Name: market_history_scan_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_history_scan_ix ON public.market_history USING btree ("typeID", "regionID", "historyDate");


--
-- PostgreSQL database dump complete
--

\unrestrict enaXskGoRFO2hrKtUpygaStCRkkEyYgrKf2Q7JBUg8va6HLvG6VK4OlC1UhLVff

