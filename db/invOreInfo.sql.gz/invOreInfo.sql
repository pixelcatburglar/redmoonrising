--
-- PostgreSQL database dump
--

\restrict aD73BVtASoknHgKgyndzhic6FoWqkeWwuvyCAj5Z6NtDxUcgms6DtRM7CHsLg1b

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invOreInfo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invOreInfo" (
    "typeID" integer DEFAULT 0 NOT NULL,
    "yieldBonus" integer DEFAULT 0 NOT NULL,
    "minToRefine" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: invOreInfo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invOreInfo" ("typeID", "yieldBonus", "minToRefine") FROM stdin;
\.


--
-- Name: invOreInfo invOreInfo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invOreInfo"
    ADD CONSTRAINT "invOreInfo_pkey" PRIMARY KEY ("typeID");


--
-- PostgreSQL database dump complete
--

\unrestrict aD73BVtASoknHgKgyndzhic6FoWqkeWwuvyCAj5Z6NtDxUcgms6DtRM7CHsLg1b

