--
-- PostgreSQL database dump
--

\restrict yw97DyKUYZtav4Q22N4ES0YIMxRHWl4Supz4ggcpYr9mDrkTsH6gbtZJdAijMiL

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: posStructures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."posStructures" (
    "itemID" integer NOT NULL,
    state smallint DEFAULT 0 NOT NULL,
    "stateTimestamp" bigint,
    "controlTowerID" integer,
    "moonID" integer,
    "lastFuel" bigint,
    claim smallint DEFAULT 0 NOT NULL,
    "claimSince" bigint,
    password text DEFAULT ''::text NOT NULL,
    "allowCorp" smallint DEFAULT 1 NOT NULL,
    "allowAlliance" smallint DEFAULT 0 NOT NULL,
    "sentryStanding" double precision,
    "sentryStatus" double precision,
    "sentryStandingDrop" smallint DEFAULT 0 NOT NULL,
    "sentryStatusDrop" smallint DEFAULT 0 NOT NULL,
    "sentryAggression" smallint DEFAULT 0 NOT NULL,
    "sentryWar" smallint DEFAULT 1 NOT NULL,
    "deployAnchor" smallint DEFAULT 0 NOT NULL,
    "deployUnanchor" smallint DEFAULT 0 NOT NULL,
    "deployOnline" smallint DEFAULT 0 NOT NULL,
    "deployOffline" smallint DEFAULT 0 NOT NULL,
    "useViewPut" smallint DEFAULT 0 NOT NULL,
    "useViewPutTake" smallint DEFAULT 0 NOT NULL,
    "useUse" smallint DEFAULT 0 NOT NULL,
    "shieldCharge" double precision,
    "armorDamage" double precision DEFAULT 0 NOT NULL,
    "hullDamage" double precision DEFAULT 0 NOT NULL,
    "provisionType" integer
);


--
-- Name: TABLE "posStructures"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."posStructures" IS 'Starbase structures in space: anchoring/online state (playerOwned.py STRUCTURE_*), the tower each belongs to, and the tower''s fuel, claim, force field, sentry and access settings.';


--
-- Name: COLUMN "posStructures"."provisionType"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."posStructures"."provisionType" IS 'What a moon harvester mines, or a silo holds (posMgr.ChangeStructureProvisionType).';


--
-- Data for Name: posStructures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."posStructures" ("itemID", state, "stateTimestamp", "controlTowerID", "moonID", "lastFuel", claim, "claimSince", password, "allowCorp", "allowAlliance", "sentryStanding", "sentryStatus", "sentryStandingDrop", "sentryStatusDrop", "sentryAggression", "sentryWar", "deployAnchor", "deployUnanchor", "deployOnline", "deployOffline", "useViewPut", "useViewPutTake", "useUse", "shieldCharge", "armorDamage", "hullDamage", "provisionType") FROM stdin;
\.


--
-- Name: posStructures posStructures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."posStructures"
    ADD CONSTRAINT "posStructures_pkey" PRIMARY KEY ("itemID");


--
-- PostgreSQL database dump complete
--

\unrestrict yw97DyKUYZtav4Q22N4ES0YIMxRHWl4Supz4ggcpYr9mDrkTsH6gbtZJdAijMiL

