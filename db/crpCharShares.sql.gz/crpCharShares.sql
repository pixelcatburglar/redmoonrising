--
-- PostgreSQL database dump
--

\restrict jWfoKMXplvc9cKIQdNGA6eeIqeuWVQxYdR02HO0lL99dlKrxbMlor4gPbY170vB

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpCharShares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpCharShares" (
    "characterID" integer DEFAULT 0 NOT NULL,
    "corporationID" integer DEFAULT 0 NOT NULL,
    shares integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: crpCharShares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpCharShares" ("characterID", "corporationID", shares) FROM stdin;
\.


--
-- Name: crpCharShares crpCharShares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpCharShares"
    ADD CONSTRAINT "crpCharShares_pkey" PRIMARY KEY ("characterID", "corporationID");


--
-- Name: crpcharshares_corp_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crpcharshares_corp_ix ON public."crpCharShares" USING btree ("corporationID");


--
-- Name: INDEX crpcharshares_corp_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.crpcharshares_corp_ix IS 'GetMemberIDsWithMoreThanAvgShares and PayoutDividend need every shareholder of a corp; the shipped PK is (characterID, corporationID), the wrong way round for that.';


--
-- PostgreSQL database dump complete
--

\unrestrict jWfoKMXplvc9cKIQdNGA6eeIqeuWVQxYdR02HO0lL99dlKrxbMlor4gPbY170vB

