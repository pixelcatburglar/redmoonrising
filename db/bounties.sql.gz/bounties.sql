--
-- PostgreSQL database dump
--

\restrict ki1GMOCJE2bSzmK5nCmEbtmELcplbVJU8vSRCauHStapEodBp5tEwFrtrykYJQY

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bounties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bounties (
    "characterID" integer NOT NULL,
    "ownerID" integer NOT NULL,
    bounty double precision DEFAULT 0 NOT NULL,
    "placedAt" bigint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE bounties; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.bounties IS 'Per-contributor bounty ledger behind charmgr.AddToBounty(charID, amount) (base_missions.py:701) and charmgr.GetTopBounties() (base_missions.py:711). GetTopBounties is served by summing this table (or by reading character_."bounty") joined to the owner name and online flag.';


--
-- Name: COLUMN bounties."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bounties."characterID" IS 'PROVEN: read as bounty.characterID off a GetTopBounties row (base_missions.py:718, billboardMgr.py:164) and it is AddToBounty''s 1st argument. The WANTED character.';


--
-- Name: COLUMN bounties."ownerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bounties."ownerID" IS 'INFERRED. Who put the money up; needed to refund or audit. Not on the wire.';


--
-- Name: COLUMN bounties.bounty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bounties.bounty IS 'PROVEN as a wire field: billboardMgr.py:164 m.bounty and userentry.py:57 util.FmtISK(data.bounty.bounty). ISK. AddToBounty''s 2nd argument; the UI floors a single contribution at 5000 (base_missions.py:676).';


--
-- Name: COLUMN bounties."placedAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bounties."placedAt" IS 'INFERRED. Windows FILETIME.';


--
-- Data for Name: bounties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bounties ("characterID", "ownerID", bounty, "placedAt") FROM stdin;
\.


--
-- Name: bounties bounties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bounties
    ADD CONSTRAINT bounties_pkey PRIMARY KEY ("characterID", "ownerID");


--
-- PostgreSQL database dump complete
--

\unrestrict ki1GMOCJE2bSzmK5nCmEbtmELcplbVJU8vSRCauHStapEodBp5tEwFrtrykYJQY

