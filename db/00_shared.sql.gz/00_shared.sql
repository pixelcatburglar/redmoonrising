--
-- PostgreSQL database dump
--

\restrict NXb4YnjWuvcx1KSpaQpvFKrrRDskHLgeNpvtIXStNlUyAhV9kLGiKpSmOfaf3tv

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dyn_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dyn_id_seq
    AS integer
    START WITH 140000000
    INCREMENT BY 1
    MINVALUE 100000000
    MAXVALUE 1999999999
    CACHE 1;


--
-- Name: SEQUENCE dyn_id_seq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public.dyn_id_seq IS 'Shared allocator for every dynamic ownerID/locationID: entity.itemID, corporation.corporationID, alliances.allianceID. Floor 100000000 because cfg.py:1419/1431/1459 only resolve IDs >= 100000000 through cfg.eveowners; start 140000000 matches prime_db.sql:36.';


--
-- Name: factory_folder_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.factory_folder_seq
    AS integer
    START WITH 68000001
    INCREMENT BY 1
    MINVALUE 68000000
    MAXVALUE 69999999
    CACHE 1;


--
-- Name: SEQUENCE factory_folder_seq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public.factory_folder_seq IS 'Virtual factory-folder container IDs. Range forced by cfg.IsFactoryFolder (cfg.py:1509). const.typeFactoryFolder = invTypes 28 (group 16).';


--
-- Name: office_folder_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.office_folder_seq
    AS integer
    START WITH 66000001
    INCREMENT BY 1
    MINVALUE 66000000
    MAXVALUE 67999999
    CACHE 1;


--
-- Name: SEQUENCE office_folder_seq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public.office_folder_seq IS 'crpOffices."officeFolderID". Range forced by cfg.IsOfficeFolder (cfg.py:1504). Only 2 000 000 IDs exist -- recycle on office cancellation (open question 5 in docs/data/02-dynamic-schema.md).';


--
-- Name: player_channel_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.player_channel_seq
    AS integer
    START WITH 2000000000
    INCREMENT BY 1
    MINVALUE 2000000000
    NO MAXVALUE
    CACHE 1;


--
-- Name: SEQUENCE player_channel_seq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public.player_channel_seq IS 'channels."channelID" for player-created / ad-hoc channels only. Owned channels keep channelID = ownerID (lscengine.py:1586 and :1683 test channel.channelID == channel.info.ownerID; lscengine.py:694 and :1523 test channel.channelID == eve.session.charid). The shipped auto-increment was unfloored and would hand out 30001408, colliding with solar system 30001408 local channel.';


--
-- Name: trade_session_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trade_session_seq
    AS integer
    START WITH 64000001
    INCREMENT BY 1
    MINVALUE 64000000
    MAXVALUE 65999999
    CACHE 1;


--
-- Name: SEQUENCE trade_session_seq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public.trade_session_seq IS 'Trade-session container IDs. Range forced by cfg.IsTrading (cfg.py:1499). locationTradeSessionJunkyard = 1008 is where their contents go when the session dies.';


--
-- Name: dyn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dyn_id_seq', 140000000, false);


--
-- Name: factory_folder_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.factory_folder_seq', 68000001, false);


--
-- Name: office_folder_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.office_folder_seq', 66000001, false);


--
-- Name: player_channel_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.player_channel_seq', 2000000000, false);


--
-- Name: trade_session_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trade_session_seq', 64000001, false);


--
-- PostgreSQL database dump complete
--

\unrestrict NXb4YnjWuvcx1KSpaQpvFKrrRDskHLgeNpvtIXStNlUyAhV9kLGiKpSmOfaf3tv


-- Trigger function used by alliances.sql (trg_sync_alliance_shortnames).
CREATE OR REPLACE FUNCTION public.sync_alliance_shortnames()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        DELETE FROM alliance_shortnames WHERE "allianceID" = OLD."allianceID";
        RETURN OLD;
    END IF;
    INSERT INTO alliance_shortnames ("allianceID", "shortName")
         VALUES (NEW."allianceID", NEW."shortName")
    ON CONFLICT ("allianceID") DO UPDATE SET "shortName" = EXCLUDED."shortName";
    RETURN NEW;
END
$function$
;
