--
-- PostgreSQL database dump
--

\restrict bWanGrz8L7ipobwGYQbmMG91HOwgjO5lZW47KhinnNVdU5XZjOPXGoXyUB9Qvmx

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrEyes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrEyes" (
    "eyesID" integer DEFAULT 0 NOT NULL,
    "eyesName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrEyes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrEyes" ("eyesID", "eyesName") FROM stdin;
1	BlueV2
2	Brightgrey
3	BrownV2
4	Darkgreen
5	Darkgrey
6	Deep brown
7	Deep ocean
8	GoldenV2
9	Greengraybright
10	Moss
11	Redbrown
12	Reptile
13	Stinging blue
14	Stinging green
15	Stinging grey
16	Stinging greyblue
17	Natural green
18	Gold
19	Grey
20	Greyblue
21	Orange
22	Yellow
23	Moss brown
24	Friendly deep brown
25	Dark grey
26	Stinging beige
27	Moss friendly
28	Lightbrown
29	Deepbrown
30	Browngreen
31	Very dark hirefract 2
32	Very dark hirefract
33	Light grey hirefract
34	Greyish
35	Grey brown
36	Golden grey
37	Brownred hirefract
38	Brown
39	Bright yellow
40	Bright grey
41	Standard
42	Small pupil brown
43	Serpent
44	Orange brown
45	Dark brown
\.


--
-- Name: chrEyes chrEyes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrEyes"
    ADD CONSTRAINT "chrEyes_pkey" PRIMARY KEY ("eyesID");


--
-- PostgreSQL database dump complete
--

\unrestrict bWanGrz8L7ipobwGYQbmMG91HOwgjO5lZW47KhinnNVdU5XZjOPXGoXyUB9Qvmx

