--
-- PostgreSQL database dump
--

\restrict hP3Ovhl3oVIgRlwzxJwfZxr4DAiznPg8H9DBEiRWdaYdzu2AHWkEkWLr35YWBmP

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrSpecialities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrSpecialities" (
    "fieldID" integer DEFAULT 0 NOT NULL,
    "specialityID" integer DEFAULT 0 NOT NULL,
    "specialityName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "skillTypeID1" integer DEFAULT 0 NOT NULL,
    "skillTypeID2" integer,
    "typeID" integer,
    "typeQuantity" integer DEFAULT 0 NOT NULL,
    "typeID2" text,
    "typeQuantity2" integer DEFAULT 0 NOT NULL,
    "graphicID" integer
);


--
-- Data for Name: chrSpecialities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrSpecialities" ("fieldID", "specialityID", "specialityName", description, "skillTypeID1", "skillTypeID2", "typeID", "typeQuantity", "typeID2", "typeQuantity2", "graphicID") FROM stdin;
1	1	Gunsmith	Teaches the basics of gunsmithing and weapon modifications.	3318	3392	\N	0	\N	0	\N
1	2	Master Gunnery	Expert training in weapon handling.	3300	3429	\N	0	\N	0	\N
1	3	Close Quarter Combat	Improves weapon accuracy and targeting.	3312	3300	\N	0	\N	0	\N
2	4	Projectile Weapons	Teaches the basics for using these types of weapons.	3302	3300	\N	0	\N	0	\N
2	5	Hybrid Weapons	Teaches the basics for using these types of weapons.	3301	3300	\N	0	\N	0	\N
2	6	Advanced Laser Weapons	Teaches advanced laser combat techniques 	3303	3300	\N	0	\N	0	\N
3	7	Improved Rocketry	Teaches the basics of using rockets.	3320	3319	\N	0	\N	0	\N
3	8	Standard Missiles	Teaches the basics of using missiles.	3321	3319	\N	0	\N	0	\N
3	9	Defender Missiles	Teaches the basics of using anti-missile missiles and other defensive missiles.	3323	3319	\N	0	\N	0	\N
4	10	Captain Training	Basic training in using same-race frigates.	3331	3327	\N	0	\N	0	\N
4	11	Advanced Command	Teaches the fundamentals of leadership.	3348	3349	\N	0	\N	0	\N
4	12	Group Tactics	Instructs in forming and joining basic group formations.	3350	3349	\N	0	\N	0	\N
5	13	Advanced Navigation	Teaches the fundamentals of long-trek navigation.	3449	3455	\N	0	\N	0	\N
5	14	Advanced Piloting	Teaches the fundamentals of close-range maneuvering.	3449	3450	\N	0	\N	0	\N
5	15	Combat Maneuvering	Teaches combat related maneuvering and evasive actions.	3449	3453	\N	0	\N	0	\N
6	16	Advanced Recon	Teaches the fundamentals of long-range detection and targeting.	3426	3431	\N	0	\N	0	\N
6	17	Electronic Warfare	Teaches the basics of employing ECM and ECCM tactics.	3426	3427	\N	0	\N	0	\N
6	18	Scout Drones	Basic drone operation tutoring.	3436	3437	\N	0	\N	0	\N
7	19	High Energy Physics	Teaches the basics of energy management.	3413	3417	\N	0	\N	0	\N
7	20	FTL Physics	Teaches the fundamentals of faster-than-light travel.	3455	3449	\N	0	\N	0	\N
7	21	Astrometrics	Teaches the fundamentals of deep space scanning.	3412	3426	\N	0	\N	0	\N
8	22	Astrogeology	Teaches stellar body physics and geo-surveying.	3410	3386	\N	0	\N	0	\N
8	23	Metallurgy	Instructions on ore composition and refining techniques.	3409	3385	\N	0	\N	0	\N
8	24	CSO	Comprehensive tutoring for science officers.	3402	3403	\N	0	\N	0	\N
9	25	Mnemonics	Instructs on duplicating knowledge and creating memory files.	3402	3407	\N	0	\N	0	\N
9	26	Genetics	Teaches the basics of human physiology and cloning.	3404	3405	\N	0	\N	0	\N
9	27	Cybernetics	Teaches the basics of cyber implants.	3402	3411	\N	0	\N	0	\N
10	28	Broker Relations	Teaches the fundamental of employing market brokers.	3446	3444	\N	0	\N	0	\N
10	29	Underhand Trade Practices	Teaches unscrupulous business principles.	3444	3445	\N	0	\N	0	\N
10	30	Advanced Trade	Courses on trading and market fundamentals.	3443	3444	\N	0	\N	0	\N
11	31	CFO	Teaches the basics of corporation financial management.	3363	3443	\N	0	\N	0	\N
11	32	Millitary Strategy	Teaches basic skills at managing a corporations millitary. 	3348	3303	\N	0	\N	0	\N
11	33	CEO	Teaches the fundamentals of managing a corporation.	3348	3363	\N	0	\N	0	\N
12	34	Diplomacy	Teaches the basics of negotiating with hostile parties.	3357	3348	\N	0	\N	0	\N
12	35	Networking	Instructs on social interaction and negotiations.	3356	3359	\N	0	\N	0	\N
12	36	Underworld Politics	Knowledge of the powerstructure of the criminal underworld.	3361	3356	\N	0	\N	0	\N
13	37	Advanced Force Field Technology	Teaches general shield operation for space ships.	3413	3416	\N	0	\N	0	\N
13	38	Shield Emission Technology	Courses on transmitting shield strength between ships.	3413	3422	\N	0	\N	0	\N
13	39	Shield Grid Upgrades	Teaches shield defensive augmentations.	3413	3425	\N	0	\N	0	\N
14	40	Advanced Energy Manipulation	Teaches general power core operation and energy fundamentals.	3422	3417	\N	0	\N	0	\N
14	41	Energy Pulse Technology	Courses on offensive energy techniques.	3421	3417	\N	0	\N	0	\N
14	42	Power Grid Upgrades	Teaches energy augmentation techniques.	3413	3424	\N	0	\N	0	\N
15	43	Sensor Modifications	General courses on the sensor technology.	3413	3432	\N	0	\N	0	\N
15	44	Electronic Warfare	Teaches offensive and defensive usage of the sensor systems.	3427	3426	\N	0	\N	0	\N
15	45	Advanced Sensor Operation	Courses on sensor augmentation.	3426	3431	\N	0	\N	0	\N
16	46	Remote Mining	Teaches mining drone operation.	3436	3438	\N	0	\N	0	\N
16	47	Advanced Refining	Advanced study of mineral refining techniques.	3380	3385	\N	0	\N	0	\N
16	48	Surveying	Teaches the basics of asteroid surveying.	3426	3551	\N	0	\N	0	\N
17	49	Ship Construction	Teaches the basics of frigate construction.	3392	3395	\N	0	\N	0	\N
17	50	Faster Production	Teaches more efficient, less costly, item production.	3380	3388	\N	0	\N	0	\N
17	51	Mass Manufacturing	Teaches techniques for speeding up item production.	3387	3386	\N	0	\N	0	\N
18	52	Advanced Ship Repair	Teaches basic mechanical and ship repair skills.	3392	3393	\N	0	\N	0	\N
18	53	Remote Repair	Instructs on repair drone operation.	3436	3439	\N	0	\N	0	\N
18	54	Hull Modifications	Courses in modifying the interior of space ships, to give room for special modules.	3394	3393	\N	0	\N	0	\N
19	55	Gunsmith	Teaches the basics of gunsmithing and weapon modifications.	3318	3392	\N	0	\N	0	\N
19	56	Master Gunnery	Expert training in weapon handling.	3300	\N	\N	0	\N	0	\N
19	57	Close Quarter Combat	Improves weapon accuracy and targeting.	3312	3379	\N	0	\N	0	\N
20	58	Laser Weapons	Teaches the basics for using these types of weapons.	3303	3300	\N	0	\N	0	\N
20	59	Hybrid Weapons	Teaches the basics for using these types of weapons.	3301	3300	\N	0	\N	0	\N
20	60	Advanced Projectile Weapons	Teaches the fundamentals for using these types of weapons.	3302	3300	\N	0	\N	0	\N
21	61	Improved Rocketry	Teaches the basics of using rockets.	3320	3319	\N	0	\N	0	\N
21	62	Standard Missiles	Teaches the basics of using missiles.	3321	3319	\N	0	\N	0	\N
21	63	Defender Missiles	Teaches the basics of using anti-missile missiles and other defensive missiles.	3323	3319	\N	0	\N	0	\N
22	64	Captain Training	Basic training in using same-race frigates.	3329	3327	\N	0	\N	0	\N
22	65	Advanced Command	Teaches the fundamentals of leadership.	3348	\N	\N	0	\N	0	\N
22	66	Group Tactics	Instructs in forming and joining basic group formations.	3350	3349	\N	0	\N	0	\N
23	67	Advanced Navigation	Teaches the fundamentals of long-trek navigation.	3449	3455	\N	0	\N	0	\N
23	68	Advanced Piloting	Teaches the fundamentals of close-range maneuvering.	3449	3450	\N	0	\N	0	\N
23	69	Combat Maneuvering	Teaches combat related maneuvering and evasive actions.	3449	3453	\N	0	\N	0	\N
24	70	Advanced Recon	Teaches the fundamentals of long-range detection and targeting.	3426	3431	\N	0	\N	0	\N
24	71	Electronic Warfare	Teaches the basics of employing ECM and ECCM tactics.	3426	3427	\N	0	\N	0	\N
24	72	Scout Drones	Basic drone operation tutoring.	3436	3437	\N	0	\N	0	\N
25	73	High Energy Physics	Teaches the basics of energy management.	3413	3417	\N	0	\N	0	\N
25	74	FTL Physics	Teaches the fundamentals of faster-than-light travel.	3455	3449	\N	0	\N	0	\N
25	75	Astrometrics	Teaches the fundamentals of deep space scanning.	3412	3426	\N	0	\N	0	\N
26	76	Astrogeology	Teaches stellar body physics and geo-surveying.	3410	3386	\N	0	\N	0	\N
26	77	Metallurgy	Instructions on ore composition and refining techniques.	3409	3385	\N	0	\N	0	\N
26	78	CSO	Comprehensive tutoring for science officers.	3402	3403	\N	0	\N	0	\N
27	79	Mnemonics	Instructs on duplicating knowledge and creating memory files.	3402	3407	\N	0	\N	0	\N
27	80	Genetics	Teaches the basics of human physiology and cloning.	3404	3405	\N	0	\N	0	\N
27	81	Cybernetics	Teaches the basics of cyber implants.	3402	3411	\N	0	\N	0	\N
28	82	Broker Relations	Teaches the fundamental of employing market brokers.	3446	3444	\N	0	\N	0	\N
28	83	Underhand Trade Practices	Teaches unscrupulous business principles.	3444	3445	\N	0	\N	0	\N
28	84	Advanced Trade	Courses on trading and market fundamentals.	3443	\N	\N	0	\N	0	\N
29	85	CFO	Teaches the basics of corporation financial management.	3363	3444	\N	0	\N	0	\N
29	86	CEO	Teaches the fundamentals of managing a corporation.	3348	3363	\N	0	\N	0	\N
29	87	Millitary Strategy	Teaches basic skills at managing a corporations millitary assets.	3302	3348	\N	0	\N	0	\N
30	88	Diplomacy	Teaches the basics of negotiating with hostile parties.	3357	3348	\N	0	\N	0	\N
30	89	Networking	Instructs on social interaction and negotiations.	3356	3359	\N	0	\N	0	\N
30	90	Underworld Politics	Knowledge of the powerstructure of the criminal underworld. 	3355	3361	\N	0	\N	0	\N
31	91	Advanced Force Field Technology	Teaches general shield operation for space ships.	3413	3416	\N	0	\N	0	\N
31	92	Shield Emission Technology	Courses on transmitting shield strength between ships.	3413	3422	\N	0	\N	0	\N
31	93	Shield Grid Upgrades	Teaches shield defensive augmentations.	3413	3425	\N	0	\N	0	\N
32	94	Advanced Energy Manipulation	Teaches general power core operation and energy fundamentals.	3422	3417	\N	0	\N	0	\N
32	95	Energy Pulse Technology	Courses on offensive energy techniques.	3421	3417	\N	0	\N	0	\N
32	96	Power Grid Upgrades	Teaches energy augmentation techniques.	3413	3424	\N	0	\N	0	\N
33	97	Sensor Modifications	General courses on the sensor technology.	3413	3432	\N	0	\N	0	\N
33	98	Electronic Warfare	Teaches offensive and defensive usage of the sensor systems.	3427	3426	\N	0	\N	0	\N
33	99	Advanced Sensor Operation	Courses on sensor augmentation.	3426	3431	\N	0	\N	0	\N
34	100	Remote Mining	Teaches mining drone operation.	3436	3438	\N	0	\N	0	\N
34	101	Advanced Refining	Teaches the fundamentals of mineral refinery techniques.	3380	3385	\N	0	\N	0	\N
34	102	Surveying	Teaches the basics of asteroid surveying.	3426	3551	\N	0	\N	0	\N
35	103	Ship Construction	Teaches the basics of frigate construction.	3392	3395	\N	0	\N	0	\N
35	104	Faster Production	Teaches more efficient, less costly, item production.	3380	3388	\N	0	\N	0	\N
35	105	Mass Manufacturing	Teaches techniques for speeding up item production.	3387	\N	\N	0	\N	0	\N
36	106	Advanced Ship Repair	Teaches basic mechanical and ship repair skills.	3392	3393	\N	0	\N	0	\N
36	107	Remote Repair	Instructs on repair drone operation.	3436	3439	\N	0	\N	0	\N
36	108	Hull Modifications	Courses in modifying the interior of space ships, to give room for special modules.	3394	3393	\N	0	\N	0	\N
37	109	Gunsmith	Teaches the basics of gunsmithing and weapon modifications.	3318	3392	\N	0	\N	0	\N
37	110	Master Gunnery	Expert training in weapon handling.	3300	3429	\N	0	\N	0	\N
37	111	Close Quarter Combat	Improves weapon accuracy and targeting.	3312	3379	\N	0	\N	0	\N
38	112	Laser Weapons	Teaches the basics for using these types of weapons.	3303	3300	\N	0	\N	0	\N
38	113	Master Hybrid Weapons	Teaches the fundamentals for using these types of weapons.	3301	3300	\N	0	\N	0	\N
38	114	Projectile Weapons	Teaches the basics for using these types of weapons.	3302	3300	\N	0	\N	0	\N
39	115	Improved Rocketry	Teaches the basics of using rockets.	3320	3319	\N	0	\N	0	\N
39	116	Standard Missiles	Teaches the basics of using missiles.	3321	3319	\N	0	\N	0	\N
39	117	Defender Missiles	Teaches the basics of using anti-missile missiles and other defensive missiles.	3323	3319	\N	0	\N	0	\N
40	118	Captain Training	Basic training in using same-race frigates.	3330	3327	\N	0	\N	0	\N
40	119	Advanced Command	Teaches the fundamentals of leadership.	3348	\N	\N	0	\N	0	\N
40	120	Group Tactics	Instructs in forming and joining basic group formations.	3350	3349	\N	0	\N	0	\N
41	121	Advanced Navigation	Teaches the fundamentals of long-trek navigation.	3449	3455	\N	0	\N	0	\N
41	122	Advanced Piloting	Teaches the fundamentals of close-range maneuvering.	3449	3450	\N	0	\N	0	\N
41	123	Combat Maneuvering	Teaches combat related maneuvering and evasive actions.	3449	3453	\N	0	\N	0	\N
42	124	Advanced Recon	Teaches the fundamentals of long-range detection and targeting.	3426	3431	\N	0	\N	0	\N
42	125	Electronic Warfare	Teaches the basics of employing ECM and ECCM tactics.	3426	3427	\N	0	\N	0	\N
42	126	Scout Drones	Basic drone operation tutoring.	3436	3437	\N	0	\N	0	\N
43	127	High Energy Physics	Teaches the basics of energy management.	3413	3417	\N	0	\N	0	\N
43	128	FTL Physics	Teaches the fundamentals of faster-than-light travel.	3455	3449	\N	0	\N	0	\N
43	129	Astrometrics	Teaches the fundamentals of deep space scanning.	3412	3426	\N	0	\N	0	\N
44	130	Astrogeology	Teaches stellar body physics and geo-surveying.	3410	3386	\N	0	\N	0	\N
44	131	Metallurgy	Instructions on ore composition and refining techniques.	3409	3385	\N	0	\N	0	\N
44	132	CSO	Comprehensive tutoring for science officers.	3402	3403	\N	0	\N	0	\N
45	133	Mnemonics	Instructs on duplicating knowledge and creating memory files.	3402	3407	\N	0	\N	0	\N
45	134	Genetics	Teaches the basics of human physiology and cloning.	3404	3405	\N	0	\N	0	\N
45	135	Cybernetics	Teaches the basics of cyber implants.	3402	3411	\N	0	\N	0	\N
46	136	Broker Relations	Teaches the fundamental of employing market brokers.	3446	3444	\N	0	\N	0	\N
46	137	Underhand Trade Practices	Teaches unscrupulous business principles.	3444	3445	\N	0	\N	0	\N
46	138	Advanced Trade	Courses on trading and market fundamentals.	3443	\N	\N	0	\N	0	\N
47	139	CFO	Teaches the basics of corporation financial management.	3363	3443	\N	0	\N	0	\N
47	140	CEO	Teaches the fundamentals of managing a corporation.	3348	3363	\N	0	\N	0	\N
47	141	Millitary Strategy	Teaches basic skills at managing a corporations millitary.  	3301	3363	\N	0	\N	0	\N
48	142	Diplomacy	Teaches the basics of negotiating with hostile parties.	3357	3348	\N	0	\N	0	\N
48	143	Networking	Instructs on social interaction and negotiations.	3356	3359	\N	0	\N	0	\N
48	144	Underworld Politics	Knowledge of the powerstructure of the criminal underworld 	3355	3361	\N	0	\N	0	\N
49	145	Advanced Force Field Technology	Teaches general shield operation for space ships.	3413	3416	\N	0	\N	0	\N
49	146	Shield Emission Technology	Courses on transmitting shield strength between ships.	3413	3422	\N	0	\N	0	\N
49	147	Shield Grid Upgrades	Teaches shield defensive augmentations.	3413	3425	\N	0	\N	0	\N
50	148	Advanced Energy Manipulation	Teaches general power core operation and energy fundamentals.	3422	3417	\N	0	\N	0	\N
50	149	Energy Pulse Technology	Courses on offensive energy techniques.	3421	3417	\N	0	\N	0	\N
50	150	Power Grid Upgrades	Teaches energy augmentation techniques.	3413	3424	\N	0	\N	0	\N
51	151	Sensor Modifications	General courses on the sensor technology.	3413	3432	\N	0	\N	0	\N
51	152	Electronic Warfare	Teaches offensive and defensive usage of the sensor systems.	3427	3426	\N	0	\N	0	\N
51	153	Advanced Sensor Operation	Courses on sensor augmentation.	3426	3431	\N	0	\N	0	\N
52	154	Remote Mining	Teaches mining drone operation.	3436	3438	\N	0	\N	0	\N
52	155	Advanced Refining	Teaches the fundamentals of mineral refinery techniques.	3380	3385	\N	0	\N	0	\N
52	156	Surveying	Teaches the basics of asteroid surveying.	3426	3551	\N	0	\N	0	\N
53	157	Ship Construction	Teaches the basics of frigate construction.	3392	3395	\N	0	\N	0	\N
53	158	Faster Production	Teaches more efficient, less costly, item production.	3380	3388	\N	0	\N	0	\N
53	159	Mass Manufacturing	Teaches techniques for speeding up item production.	3387	\N	\N	0	\N	0	\N
54	160	Advanced Ship Repair	Teaches basic mechanical and ship repair skills.	3392	3393	\N	0	\N	0	\N
54	161	Remote Repair	Instructs on repair drone operation.	3436	3439	\N	0	\N	0	\N
54	162	Hull Modifications	Courses in modifying the interior of space ships, to give room for special modules.	3394	3393	\N	0	\N	0	\N
55	163	Gunsmith	Teaches the basics of gunsmithing and weapon modifications.	3318	3392	\N	0	\N	0	\N
55	164	Master Gunnery	Expert training in weapon handling.	3300	\N	\N	0	\N	0	\N
55	165	Close Quarter Combat	Improves weapon accuracy and targeting.	3312	3379	\N	0	\N	0	\N
56	166	Laser Weapons	Teaches the basics for using these types of weapons.	3303	3300	\N	0	\N	0	\N
56	167	Master Hybrid Weapons	Teaches the fundamentals for using these types of weapons.	3301	3300	\N	0	\N	0	\N
56	168	Projectile Weapons	Teaches the basics for using these types of weapons.	3302	3300	\N	0	\N	0	\N
57	169	Improved Rocketry	Teaches the basics of using rockets.	3320	3319	\N	0	\N	0	\N
57	170	Standard Missiles	Teaches the basics of using missiles.	3321	3319	\N	0	\N	0	\N
57	171	Defender Missiles	Teaches the basics of using anti-missile missiles and other defensive missiles.	3323	3319	\N	0	\N	0	\N
58	172	Captain Training	Basic training in using same-race frigates.	3328	3327	\N	0	\N	0	\N
58	173	Advanced Command	Teaches the fundamentals of leadership.	3348	\N	\N	0	\N	0	\N
58	174	Group Tactics	Instructs in forming and joining basic group formations.	3350	3349	\N	0	\N	0	\N
59	175	Advanced Navigation	Teaches the fundamentals of long-trek navigation.	3449	3455	\N	0	\N	0	\N
59	176	Advanced Piloting	Teaches the fundamentals of close-range maneuvering.	3449	3450	\N	0	\N	0	\N
59	177	Combat Maneuvering	Teaches combat related maneuvering and evasive actions.	3449	3453	\N	0	\N	0	\N
60	178	Advanced Recon	Teaches the fundamentals of long-range detection and targeting.	3426	3431	\N	0	\N	0	\N
60	179	Electronic Warfare	Teaches the basics of employing ECM and ECCM tactics.	3426	3427	\N	0	\N	0	\N
60	180	Scout Drones	Basic drone operation tutoring.	3436	3437	\N	0	\N	0	\N
61	181	High Energy Physics	Teaches the basics of energy management.	3413	3417	\N	0	\N	0	\N
61	182	FTL Physics	Teaches the fundamentals of faster-than-light travel.	3455	3449	\N	0	\N	0	\N
61	183	Astrometrics	Teaches the fundamentals of deep space scanning.	3412	3426	\N	0	\N	0	\N
62	184	Astrogeology	Teaches stellar body physics and geo-surveying.	3410	3386	\N	0	\N	0	\N
62	185	Metallurgy	Instructions on ore composition and refining techniques.	3409	3385	\N	0	\N	0	\N
62	186	CSO	Comprehensive tutoring for science officers.	3402	3403	\N	0	\N	0	\N
63	187	Mnemonics	Instructs on duplicating knowledge and creating memory files.	3402	3407	\N	0	\N	0	\N
63	188	Genetics	Teaches the basics of human physiology and cloning.	3404	3405	\N	0	\N	0	\N
63	189	Cybernetics	Teaches the basics of cyber implants.	3402	3411	\N	0	\N	0	\N
64	190	Broker Relations	Teaches the fundamental of employing market brokers.	3446	3444	\N	0	\N	0	\N
64	191	Underhand Trade Practices	Teaches unscrupulous business principles.	3444	3445	\N	0	\N	0	\N
64	192	Advanced Trade	Courses on trading and market fundamentals.	3443	\N	\N	0	\N	0	\N
65	193	CFO	Teaches the basics of corporation financial management.	3363	3444	\N	0	\N	0	\N
65	194	CEO	Teaches the fundamentals of managing a corporation.	3348	3363	\N	0	\N	0	\N
65	195	Millitary Strategy	Teaches basic skills at managing a corporations millitary. 	3348	3436	\N	0	\N	0	\N
66	196	Diplomacy	Teaches the basics of negotiating with hostile parties.	3357	3348	\N	0	\N	0	\N
66	197	Networking	Instructs on social interaction and negotiations.	3356	3359	\N	0	\N	0	\N
66	198	Underworld Politics	Knowledge of the powerstructure of the criminal underworld.  	3355	3361	\N	0	\N	0	\N
67	199	Advanced Force Field Technology	Teaches general shield operation for space ships.	3413	3416	\N	0	\N	0	\N
67	200	Shield Emission Technology	Courses on transmitting shield strength between ships.	3413	3422	\N	0	\N	0	\N
67	201	Shield Grid Upgrades	Teaches shield defensive augmentations.	3413	3425	\N	0	\N	0	\N
68	202	Advanced Energy Manipulation	Teaches general power core operation and energy fundamentals.	3422	3417	\N	0	\N	0	\N
68	203	Energy Pulse Technology	Courses on offensive energy techniques.	3421	3417	\N	0	\N	0	\N
68	204	Power Grid Upgrades	Teaches energy augmentation techniques.	3413	3424	\N	0	\N	0	\N
69	205	Sensor Modifications	General courses on the sensor technology.	3413	3432	\N	0	\N	0	\N
69	206	Electronic Warfare	Teaches offensive and defensive usage of the sensor systems.	3427	3426	\N	0	\N	0	\N
69	207	Advanced Sensor Operation	Courses on sensor augmentation.	3426	3431	\N	0	\N	0	\N
70	208	Remote Mining	Teaches mining drone operation.	3436	3438	\N	0	\N	0	\N
70	209	Advanced Refining	Teaches the fundamentals of mineral refinery techniques.	3380	3385	\N	0	\N	0	\N
70	210	Surveying	Teaches the basics of asteroid surveying.	3426	3551	\N	0	\N	0	\N
71	211	Ship Construction	Teaches the basics of frigate construction.	3392	3395	\N	0	\N	0	\N
71	212	Faster Production	Teaches more efficient, less costly, item production.	3380	3388	\N	0	\N	0	\N
71	213	Mass Manufacturing	Teaches techniques for speeding up item production.	3387	\N	\N	0	\N	0	\N
72	214	Advanced Ship Repair	Teaches basic mechanical and ship repair skills.	3392	3393	\N	0	\N	0	\N
72	215	Remote Repair	Instructs on repair drone operation.	3436	3439	\N	0	\N	0	\N
72	216	Hull Modifications	Courses in modifying the interior of space ships, to give room for special modules.	3394	3393	\N	0	\N	0	\N
73	217	Gunsmith	Teaches the basics of gunsmithing and weapon modifications.	3318	3392	\N	0	\N	0	\N
73	218	Master Gunnery	Expert training in weapon handling.	3300	3429	\N	0	\N	0	\N
73	219	Close Quarter Combat	Improves weapon accuracy and targeting.	3312	3379	\N	0	\N	0	\N
74	220	Laser Weapons	Teaches the basics for using these types of weapons.	3303	3300	\N	0	\N	0	\N
74	221	Master Hybrid Weapons	Teaches the fundamentals for using these types of weapons.	3301	3300	\N	0	\N	0	\N
74	222	Projectile Weapons	Teaches the basics for using these types of weapons.	3302	3300	\N	0	\N	0	\N
75	223	Improved Rocketry	Teaches the basics of using rockets.	3320	3319	\N	0	\N	0	\N
75	224	Standard Missiles	Teaches the basics of using missiles.	3321	3319	\N	0	\N	0	\N
75	225	Defender Missiles	Teaches the basics of using anti-missile missiles and other defensive missiles.	3323	3319	\N	0	\N	0	\N
76	226	Captain Training	Basic training in using same-race frigates.	3330	3327	\N	0	\N	0	\N
76	227	Advanced Command	Teaches the fundamentals of leadership.	3348	\N	\N	0	\N	0	\N
76	228	Group Tactics	Instructs in forming and joining basic group formations.	3350	3349	\N	0	\N	0	\N
77	229	Advanced Navigation	Teaches the fundamentals of long-trek navigation.	3449	3455	\N	0	\N	0	\N
77	230	Advanced Piloting	Teaches the fundamentals of close-range maneuvering.	3449	3450	\N	0	\N	0	\N
77	231	Combat Maneuvering	Teaches combat related maneuvering and evasive actions.	3449	3453	\N	0	\N	0	\N
78	232	Advanced Recon	Teaches the fundamentals of long-range detection and targeting.	3426	3431	\N	0	\N	0	\N
78	233	Electronic Warfare	Teaches the basics of employing ECM and ECCM tactics.	3426	3427	\N	0	\N	0	\N
78	234	Scout Drones	Basic drone operation tutoring.	3436	3437	\N	0	\N	0	\N
79	235	High Energy Physics	Teaches the basics of energy management.	3413	3417	\N	0	\N	0	\N
79	236	FTL Physics	Teaches the fundamentals of faster-than-light travel.	3455	3449	\N	0	\N	0	\N
79	237	Astrometrics	Teaches the fundamentals of deep space scanning.	3412	3426	\N	0	\N	0	\N
80	238	Astrogeology	Teaches stellar body physics and geo-surveying.	3410	3386	\N	0	\N	0	\N
80	239	Metallurgy	Instructions on ore composition and refining techniques.	3409	3385	\N	0	\N	0	\N
80	240	CSO	Comprehensive tutoring for science officers.	3402	3403	\N	0	\N	0	\N
81	241	Mnemonics	Instructs on duplicating knowledge and creating memory files.	3402	3407	\N	0	\N	0	\N
81	242	Genetics	Teaches the basics of human physiology and cloning.	3404	3405	\N	0	\N	0	\N
81	243	Cybernetics	Teaches the basics of cyber implants.	3402	3411	\N	0	\N	0	\N
82	244	Broker Relations	Teaches the fundamental of employing market brokers.	3446	3444	\N	0	\N	0	\N
82	245	Underhand Trade Practices	Teaches unscrupulous business principles.	3444	3445	\N	0	\N	0	\N
82	246	Advanced Trade	Courses on trading and market fundamentals.	3443	\N	\N	0	\N	0	\N
83	247	CFO	Teaches the basics of corporation financial management.	3363	3443	\N	0	\N	0	\N
83	248	CEO	Teaches the fundamentals of managing a corporation.	3348	3363	\N	0	\N	0	\N
83	249	Millitary Strategy	Teaches basic skills at managing a corporations millitary.  	3301	3363	\N	0	\N	0	\N
84	250	Diplomacy	Teaches the basics of negotiating with hostile parties.	3357	3348	\N	0	\N	0	\N
84	251	Networking	Instructs on social interaction and negotiations.	3356	3359	\N	0	\N	0	\N
84	252	Underworld Politics	Knowledge of the powerstructure of the criminal underworld 	3355	3361	\N	0	\N	0	\N
85	253	Advanced Force Field Technology	Teaches general shield operation for space ships.	3413	3416	\N	0	\N	0	\N
85	254	Shield Emission Technology	Courses on transmitting shield strength between ships.	3413	3422	\N	0	\N	0	\N
85	255	Shield Grid Upgrades	Teaches shield defensive augmentations.	3413	3425	\N	0	\N	0	\N
86	256	Advanced Energy Manipulation	Teaches general power core operation and energy fundamentals.	3422	3417	\N	0	\N	0	\N
86	257	Energy Pulse Technology	Courses on offensive energy techniques.	3421	3417	\N	0	\N	0	\N
86	258	Power Grid Upgrades	Teaches energy augmentation techniques.	3413	3424	\N	0	\N	0	\N
87	259	Sensor Modifications	General courses on the sensor technology.	3413	3432	\N	0	\N	0	\N
87	260	Electronic Warfare	Teaches offensive and defensive usage of the sensor systems.	3427	3426	\N	0	\N	0	\N
87	261	Advanced Sensor Operation	Courses on sensor augmentation.	3426	3431	\N	0	\N	0	\N
88	262	Remote Mining	Teaches mining drone operation.	3386	3438	\N	0	\N	0	\N
88	263	Advanced Refining	Teaches the fundamentals of mineral refinery techniques.	3380	3385	\N	0	\N	0	\N
88	264	Surveying	Teaches the basics of asteroid surveying.	3426	3551	\N	0	\N	0	\N
89	265	Ship Construction	Teaches the basics of frigate construction.	3392	3395	\N	0	\N	0	\N
89	266	Faster Production	Teaches more efficient, less costly, item production.	3380	3388	\N	0	\N	0	\N
89	267	Mass Manufacturing	Teaches techniques for speeding up item production.	3387	\N	\N	0	\N	0	\N
90	268	Advanced Ship Repair	Teaches basic mechanical and ship repair skills.	3392	3393	\N	0	\N	0	\N
90	269	Remote Repair	Instructs on repair drone operation.	3436	3439	\N	0	\N	0	\N
90	270	Hull Modifications	Courses in modifying the interior of space ships, to give room for special modules.	3394	3393	\N	0	\N	0	\N
\.


--
-- Name: chrSpecialities chrSpecialities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrSpecialities"
    ADD CONSTRAINT "chrSpecialities_pkey" PRIMARY KEY ("specialityID");


--
-- PostgreSQL database dump complete
--

\unrestrict hP3Ovhl3oVIgRlwzxJwfZxr4DAiznPg8H9DBEiRWdaYdzu2AHWkEkWLr35YWBmP

