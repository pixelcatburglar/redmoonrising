--
-- PostgreSQL database dump
--

\restrict d7TVwVXycIcTv9KAkIN7CmP2cx52vtcxs7NftwNoJks97tGIXMjOkvp2pGVxVFb

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.petitions (
    "petitionID" integer NOT NULL,
    "petitionerID" integer,
    "accountID" integer,
    "categoryID" integer NOT NULL,
    "queueID" integer,
    subject text DEFAULT ''::text NOT NULL,
    petition text DEFAULT ''::text NOT NULL,
    "createdAt" bigint DEFAULT 0 NOT NULL,
    claimed smallint DEFAULT 0 NOT NULL,
    "claimedBy" integer,
    closed smallint DEFAULT 0 NOT NULL,
    "closedAt" bigint,
    deleted smallint DEFAULT 0 NOT NULL,
    "escalatesTo" integer,
    "combatLog" text,
    "chatLog" text
);


--
-- Name: TABLE petitions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.petitions IS 'Support petitions. Serves petitioner.CreatePetition / GetPetition / GetMyPetitions / GetClaimedPetitions / GetPetitionQueue / Claim / UnClaim / Escalate / Close / Cancel / Delete. Stubbing MayPetition -> False disables the whole feature cleanly (petition.py:385-390).';


--
-- Name: COLUMN petitions."petitionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."petitionID" IS 'PROVEN: petition.py:488-500 pass p.petitionID to every action, and :91 GetPetition(petitionID).';


--
-- Name: COLUMN petitions."petitionerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."petitionerID" IS 'PROVEN and NULLABLE: petition.py:261 owners.append(p.petitionerID) and :495 `if p.petitionerID != session.charid`. NULL is possible because a petition can be filed with no character in session (petition.py:457-460, and the OocCharacterID argument at :431).';


--
-- Name: COLUMN petitions."accountID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."accountID" IS 'INFERRED. The filing account, needed exactly because petitionerID can be NULL.';


--
-- Name: COLUMN petitions."categoryID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."categoryID" IS 'PROVEN: petition.py:505 self.GetC_String(p.categoryID); 3rd argument of CreatePetition.';


--
-- Name: COLUMN petitions."queueID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."queueID" IS 'INFERRED. Which GM queue the petition sits in; GetPetitionQueue(queueID) (petition.py:259) must filter on something.';


--
-- Name: COLUMN petitions.subject; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions.subject IS 'PROVEN: petition.py:505 ''label'': ''Subject'', ''text'': (p.subject); 1st argument of CreatePetition. Also the 3rd argument of the OnNewPetition notification (petition.py:35).';


--
-- Name: COLUMN petitions.petition; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions.petition IS 'PROVEN, AND THE NAME MATTERS: petition.py:505 renders p.petition into the read-only body textedit -- the column is `petition`, not `body` or `description`. 2nd argument of CreatePetition; the form limits it to 1000 chars (petition.py:411).';


--
-- Name: COLUMN petitions."createdAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."createdAt" IS 'INFERRED. Windows FILETIME.';


--
-- Name: COLUMN petitions.claimed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions.claimed IS 'PROVEN 0/1: petition.py:486 `if p.claimed:` shows the GM buttons, :497 `if not p.claimed:` allows Cancel, :327-328 makes the status "In Action".';


--
-- Name: COLUMN petitions."claimedBy"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."claimedBy" IS 'INFERRED. Which GM claimed it (ClaimPetition / UnClaimPetition, petition.py:489, :494); GetClaimedPetitions must filter on it.';


--
-- Name: COLUMN petitions.closed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions.closed IS 'PROVEN 0/1: petition.py:492 `elif not p.closed and not p.deleted:`, :499 `if p.closed:` enables Delete, :325-330 GetStatusName maps closed==0 to Open and anything else to Closed.';


--
-- Name: COLUMN petitions."closedAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."closedAt" IS 'INFERRED. Windows FILETIME.';


--
-- Name: COLUMN petitions.deleted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions.deleted IS 'PROVEN 0/1: petition.py:492 tests it alongside closed.';


--
-- Name: COLUMN petitions."escalatesTo"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."escalatesTo" IS 'PROVEN: petition.py:490 EscalatePetition(p.petitionID, p.escalatesTo) -- the row carries its own escalation target.';


--
-- Name: COLUMN petitions."combatLog"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."combatLog" IS 'PROVEN as an argument: CreatePetition(..., combatLog=combatLog) (petition.py:453); filled from eve.LocalSvc(''logger'').GetLog() for every category except 7 (petition.py:447) and truncated client-side to const.petitionMaxCombatLogSize (:452).';


--
-- Name: COLUMN petitions."chatLog"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.petitions."chatLog" IS 'PROVEN as an argument: CreatePetition(..., chatLog=chatLog) (petition.py:453); filled from LSC.GetChannelMessages() for categories 4 and 5 only (petition.py:435-445) and truncated to const.petitionMaxChatLogSize (:450).';


--
-- Name: petitions_petitionID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.petitions ALTER COLUMN "petitionID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."petitions_petitionID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: petitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.petitions ("petitionID", "petitionerID", "accountID", "categoryID", "queueID", subject, petition, "createdAt", claimed, "claimedBy", closed, "closedAt", deleted, "escalatesTo", "combatLog", "chatLog") FROM stdin;
\.


--
-- Name: petitions_petitionID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."petitions_petitionID_seq"', 1, false);


--
-- Name: petitions petitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.petitions
    ADD CONSTRAINT petitions_pkey PRIMARY KEY ("petitionID");


--
-- Name: petitions_claimed_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX petitions_claimed_ix ON public.petitions USING btree ("claimedBy") WHERE (claimed = 1);


--
-- Name: INDEX petitions_claimed_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.petitions_claimed_ix IS 'petitioner.GetClaimedPetitions.';


--
-- Name: petitions_petitioner_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX petitions_petitioner_ix ON public.petitions USING btree ("petitionerID");


--
-- Name: INDEX petitions_petitioner_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.petitions_petitioner_ix IS 'petitioner.GetMyPetitions.';


--
-- Name: petitions_queue_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX petitions_queue_ix ON public.petitions USING btree ("queueID", closed);


--
-- Name: INDEX petitions_queue_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.petitions_queue_ix IS 'petitioner.GetPetitionQueue(queueID) (petition.py:259).';


--
-- PostgreSQL database dump complete
--

\unrestrict d7TVwVXycIcTv9KAkIN7CmP2cx52vtcxs7NftwNoJks97tGIXMjOkvp2pGVxVFb

