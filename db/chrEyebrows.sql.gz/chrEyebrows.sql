--
-- PostgreSQL database dump
--

\restrict aSDmkQTKNfgsdL22p0snec3z8yaz2JsThkh5wdoQk7mrNIwVrnqzbNqvkevihS3

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrEyebrows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrEyebrows" (
    "eyebrowsID" integer DEFAULT 0 NOT NULL,
    "eyebrowsName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrEyebrows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrEyebrows" ("eyebrowsID", "eyebrowsName") FROM stdin;
1	1
2	10
3	11
4	2
5	3
6	4
7	5
8	6
9	7
10	8
11	9
12	Normal
13	Strong
14	13
15	14
16	12
17	Light
18	None
19	Blonde Thin
20	Delicate brown
21	Evil
22	Evil brown
23	Small black curve
24	Thin black curve
25	Thin white
26	Wicked blond
27	Hairy
28	Heavy
29	07
30	08
31	09
32	Black heavy
33	Normal heavy
34	Thin
35	Thin black
36	15
37	16
38	Med black
39	Black straight
40	Thin straight 2
41	Thin black 2
42	Med curve
43	Thin straight
44	Thin dark
45	Thin black2
46	Med curve 2
47	Pearl strong
48	Pearl medium
49	Pearl
50	none
51	Grey Ruffled
52	Grey Medium
53	Dark Thin Stern
54	Dark Thin Long
55	Dark Thin
56	Dark Thick
57	Dark Stern
58	Dark Small Thin
59	Dark Short Thick
60	Dark Ruffled
61	Dark Medium 2
62	Dark Medium
63	Dark Grey Thick
64	Brown Medium
65	Thin Grey
66	Thin Dark
67	Thin Brown
68	Thick Dark
69	Thick Brown
70	Short Dark
71	Ruffled Grey
72	Ruffled Dark
73	Medium Dark
74	Arched Dark
75	Arched Brown
76	Angled Dark
77	Grey Thin
78	Dark Very Thin
79	Dark Thin Cunning
80	Dark Fuzzy
81	Brown Thin
82	Brown Thick
\.


--
-- Name: chrEyebrows chrEyebrows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrEyebrows"
    ADD CONSTRAINT "chrEyebrows_pkey" PRIMARY KEY ("eyebrowsID");


--
-- PostgreSQL database dump complete
--

\unrestrict aSDmkQTKNfgsdL22p0snec3z8yaz2JsThkh5wdoQk7mrNIwVrnqzbNqvkevihS3

