--
-- PostgreSQL database dump
--

\restrict oUyDLgqPE5L4vl0TmpzTxIDinazRTM9NTspSdiRz7VWblzkcuFBKAY8BBivJz1g

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_transactions (
    "transactionID" integer NOT NULL,
    "transactionDateTime" bigint DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    "transactionType" integer DEFAULT 0 NOT NULL,
    "clientID" integer DEFAULT 0 NOT NULL,
    "regionID" integer DEFAULT 0 NOT NULL,
    "stationID" integer DEFAULT 0 NOT NULL,
    "characterID" integer,
    "corporationID" integer,
    "isCorp" smallint DEFAULT 0 NOT NULL,
    "accountKey" integer DEFAULT 1000 NOT NULL,
    "journalRefID" integer
);


--
-- Name: COLUMN market_transactions."clientID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_transactions."clientID" IS 'The COUNTERPARTY, not the owner: wallet.py:1046 does cfg.eveowners.Get(tr.clientID).name and labels the column "client".';


--
-- Name: COLUMN market_transactions."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_transactions."characterID" IS 'The character whose wallet this side of the trade belongs to. INFERRED: no such column exists in the 2005 DDL, but wallet.py:1028 scopes CharGetTransactions to the caller and there is no other way to do it.';


--
-- Name: COLUMN market_transactions."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_transactions."corporationID" IS 'Set when the trade was made on the corporation wallet (isCorp=1). INFERRED, same basis.';


--
-- Name: COLUMN market_transactions."isCorp"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_transactions."isCorp" IS 'INFERRED 0/1. Mirrors market_orders."isCorp"; distinguishes a corp transaction from a personal one for the same character.';


--
-- Name: COLUMN market_transactions."accountKey"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_transactions."accountKey" IS 'Which of the market_keyMap accounts; 1000 is the personal wallet. Journal filter only in RMR.';


--
-- Name: COLUMN market_transactions."journalRefID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_transactions."journalRefID" IS 'The market_journal row this transaction produced. INFERRED; nothing in the client reads it, but the two have to be reconcilable.';


--
-- Name: market_transactions_transactionID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."market_transactions_transactionID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: market_transactions_transactionID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."market_transactions_transactionID_seq" OWNED BY public.market_transactions."transactionID";


--
-- Name: market_transactions transactionID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_transactions ALTER COLUMN "transactionID" SET DEFAULT nextval('public."market_transactions_transactionID_seq"'::regclass);


--
-- Data for Name: market_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.market_transactions ("transactionID", "transactionDateTime", "typeID", quantity, price, "transactionType", "clientID", "regionID", "stationID", "characterID", "corporationID", "isCorp", "accountKey", "journalRefID") FROM stdin;
\.


--
-- Name: market_transactions_transactionID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."market_transactions_transactionID_seq"', 1, false);


--
-- Name: market_transactions market_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_transactions
    ADD CONSTRAINT market_transactions_pkey PRIMARY KEY ("transactionID");


--
-- Name: market_transactions_regionID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "market_transactions_regionID_idx" ON public.market_transactions USING btree ("regionID");


--
-- Name: market_tx_char_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_tx_char_ix ON public.market_transactions USING btree ("characterID", "transactionID" DESC);


--
-- Name: INDEX market_tx_char_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_tx_char_ix IS 'marketProxy.CharGetNewTransactions and CharGetTransactions(fromTransactionID) page backwards on transactionID (wallet.py:1027-1028), so DESC on the id is exactly the access path.';


--
-- Name: market_tx_corp_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_tx_corp_ix ON public.market_transactions USING btree ("corporationID", "transactionID" DESC) WHERE ("corporationID" IS NOT NULL);


--
-- Name: INDEX market_tx_corp_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_tx_corp_ix IS 'The corporate transaction list (corp_ui_accounts).';


--
-- Name: market_tx_station_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_tx_station_ix ON public.market_transactions USING btree ("stationID");


--
-- Name: INDEX market_tx_station_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_tx_station_ix IS 'Station trade volume; also the "Market Activity" info tab.';


--
-- Name: market_tx_type_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_tx_type_ix ON public.market_transactions USING btree ("typeID", "transactionDateTime" DESC);


--
-- Name: INDEX market_tx_type_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_tx_type_ix IS 'Feeds the nightly market_history aggregation.';


--
-- PostgreSQL database dump complete
--

\unrestrict oUyDLgqPE5L4vl0TmpzTxIDinazRTM9NTspSdiRz7VWblzkcuFBKAY8BBivJz1g

