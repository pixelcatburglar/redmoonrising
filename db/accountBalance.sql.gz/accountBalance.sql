--
-- PostgreSQL database dump
--

\restrict dg4mymnslPf6H0OWoqaTPjB6Hp3rjvxpxELoRcftwObsyvOfqSQugyF5c9feAbH

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accountBalance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."accountBalance" (
    "ownerID" integer NOT NULL,
    "accountKey" integer NOT NULL,
    balance double precision DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "accountBalance"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."accountBalance" IS 'Per-owner, per-accountKey ISK balance. Needed because OnAccountChange(accountKey, ownerID, balance) (wallet.py:239) pushes a balance per key and corp_ui_accounts.py:190-203 asks for a journal per market_keyMap row.';


--
-- Name: COLUMN "accountBalance"."ownerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."accountBalance"."ownerID" IS 'Character or corporation ID. Polymorphic on purpose -- wallet.py:240 tests ownerID == eve.session.charid and :246 ownerID == eve.session.corpid.';


--
-- Name: COLUMN "accountBalance"."accountKey"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."accountBalance"."accountKey" IS 'market_keyMap."accountKey": 1000,1100,1500,1800,2000,2010,2900,3000,4000. The notification sends the matching market_keyMap."accountName" string instead (wallet.py:240 compares to ''cash'').';


--
-- Name: COLUMN "accountBalance".balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."accountBalance".balance IS 'ISK. double precision: blue.marshal sends an IEEE double and util.FmtISK does the rounding client-side (wallet.py:245 SetMoney(self.wealth)).';


--
-- Data for Name: accountBalance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."accountBalance" ("ownerID", "accountKey", balance) FROM stdin;
\.


--
-- Name: accountBalance accountBalance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."accountBalance"
    ADD CONSTRAINT "accountBalance_pkey" PRIMARY KEY ("ownerID", "accountKey");


--
-- PostgreSQL database dump complete
--

\unrestrict dg4mymnslPf6H0OWoqaTPjB6Hp3rjvxpxELoRcftwObsyvOfqSQugyF5c9feAbH

