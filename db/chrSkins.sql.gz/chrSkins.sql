--
-- PostgreSQL database dump
--

\restrict qKtJ9jmu33f7RIMiWWn43aU6KPBaAYekWFcTyRU6rhGYjmpeeR5OoVVnC4pwwMo

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrSkins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrSkins" (
    "skinID" integer DEFAULT 0 NOT NULL,
    "skinName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrSkins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrSkins" ("skinID", "skinName") FROM stdin;
1	1
2	2
3	3
4	4
5	5
6	6
7	7
8	8
9	10
10	11
11	9
12	Normal
13	Bright
14	Pale
15	Smooth
16	Tan
17	Ancient
18	Contrasted
19	Old
20	Golden
21	regular
22	Sick
23	Dark
24	Caldari
25	12
26	glossy
27	oily
28	veins
29	redveins
30	Asian 1
31	Brown smooth
32	Brown
33	Fair asian
34	Fair
35	Fairest
36	Normal shiny
37	Very bright
38	Smooth pale
39	Smooth asian
40	Fair shiny 2
41	Fair shiny
42	Brown shiny
43	Asian 3
44	Asian 2
45	Soft pale
46	Soft dark asian
47	Soft asian
48	Reynir
49	Japanes
50	Normal smooth
51	Normal glossy
52	Glossy asian
53	Asian glossy 2
54	Smooth lowgloss
55	Smooth glossy
56	Lowgloss
57	Hi contrast gloss
58	Glossy
59	Dark tone
60	Smooth contrast
61	Middle east dark
62	Glossy 2
63	Asian light
64	Asian dark
65	Asian
66	Hicontrast
67	Tanned
68	Nocturnal
69	Light asian
70	Dark asian
71	Casual
\.


--
-- Name: chrSkins chrSkins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrSkins"
    ADD CONSTRAINT "chrSkins_pkey" PRIMARY KEY ("skinID");


--
-- PostgreSQL database dump complete
--

\unrestrict qKtJ9jmu33f7RIMiWWn43aU6KPBaAYekWFcTyRU6rhGYjmpeeR5OoVVnC4pwwMo

