--
-- PostgreSQL database dump
--

\restrict Cfo99IyQLrst7dcQCAlakwlZbb6vSgVrfU9goD0GT2ZOxmOwA0XKEffTbIr3Vxi

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLBeards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLBeards" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "beardID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLBeards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLBeards" ("bloodlineID", gender, "beardID", npc) FROM stdin;
1	1	2	0
1	1	3	0
1	1	10	0
1	1	12	0
1	1	13	0
1	1	14	0
1	1	15	0
1	1	16	0
1	1	19	0
1	1	20	0
1	1	21	0
1	1	22	0
1	1	23	0
2	1	1	0
2	1	2	0
2	1	3	0
2	1	4	0
2	1	5	0
2	1	6	0
2	1	7	0
2	1	8	0
2	1	9	0
2	1	10	0
2	1	12	0
2	1	13	0
2	1	14	0
2	1	15	0
2	1	16	0
2	1	17	0
2	1	18	0
2	1	19	0
2	1	20	0
4	1	1	0
4	1	2	0
4	1	3	0
4	1	4	0
4	1	5	0
4	1	6	0
4	1	7	0
4	1	8	0
4	1	9	0
4	1	10	0
4	1	11	0
4	1	12	0
4	1	13	0
4	1	14	0
4	1	15	0
4	1	16	0
7	1	1	0
7	1	3	0
7	1	6	0
7	1	8	0
7	1	9	0
7	1	10	0
7	1	11	0
7	1	12	0
7	1	13	0
7	1	14	0
7	1	15	0
7	1	16	0
7	1	18	0
7	1	19	0
7	1	20	0
7	1	24	0
7	1	25	0
7	1	26	0
7	1	27	0
7	1	28	0
7	1	29	0
8	1	1	0
8	1	2	0
8	1	6	0
8	1	7	0
8	1	8	0
8	1	9	0
8	1	10	0
8	1	12	0
8	1	15	0
8	1	16	0
8	1	18	0
8	1	26	0
8	1	30	0
11	1	16	0
11	1	31	0
12	1	16	0
12	1	33	0
12	1	34	0
13	1	31	0
13	1	35	0
13	1	36	0
13	1	37	0
14	1	16	0
14	1	31	0
14	1	32	0
\.


--
-- Name: chrBLBeards chrBLBeards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLBeards"
    ADD CONSTRAINT "chrBLBeards_pkey" PRIMARY KEY ("bloodlineID", gender, "beardID");


--
-- PostgreSQL database dump complete
--

\unrestrict Cfo99IyQLrst7dcQCAlakwlZbb6vSgVrfU9goD0GT2ZOxmOwA0XKEffTbIr3Vxi

