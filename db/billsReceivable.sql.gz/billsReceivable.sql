--
-- PostgreSQL database dump
--

\restrict ByMpHYMJJ8nxMDCnGKCfOzWxprWqewfmQKAsrcfkhR08V3uzBK10yXIxsE7QEDQ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billsReceivable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."billsReceivable" (
    "billID" integer NOT NULL,
    "billTypeID" integer,
    "debtorID" integer,
    "creditorID" integer,
    amount double precision DEFAULT 0 NOT NULL,
    "dueDateTime" bigint DEFAULT 0 NOT NULL,
    interest double precision DEFAULT 0 NOT NULL,
    "externalID" integer,
    paid smallint DEFAULT 0 NOT NULL,
    "externalID2" integer DEFAULT '-1'::integer NOT NULL
);


--
-- Name: COLUMN "billsReceivable".amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."billsReceivable".amount IS 'ISK owed. double precision: wallet.py:799 util.FmtISK(bill.amount), and :802 data.sort_amount = bill.amount.';


--
-- Name: COLUMN "billsReceivable"."dueDateTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."billsReceivable"."dueDateTime" IS 'Windows FILETIME. bigint: wallet.py:799 formats it twice, util.FmtDate(bill.dueDateTime,''ln'') for the date column and ''ns'' for the time column.';


--
-- Name: COLUMN "billsReceivable".interest; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."billsReceivable".interest IS 'Interest as a percentage. double precision: wallet.py:799 renders it with a trailing %% and :803 sorts on it (data.sort_interest = bill.interest).';


--
-- Name: COLUMN "billsReceivable"."externalID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."billsReceivable"."externalID" IS 'Signed, POLYMORPHIC by billTypeID. wallet.py:805-806 (billTypeMarketFine) tests `!= -1` then cfg.invtypes.Get(bill.externalID).name -- a typeID; wallet.py:813 (billTypeRentalBill) the same; wallet.py:827 (billTypeBrokerBill) prints it raw as an order id. -1 means unset.';


--
-- Name: COLUMN "billsReceivable".paid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."billsReceivable".paid IS 'INFERRED 0/1. The client NEVER reads it -- the payable/receivable split is by CALL (billMgr.CharGetBills vs CharGetBillsReceivable, wallet.py:695-697) and a paid bill simply stops being returned. smallint rather than boolean so that if it ever does go on the wire, marshal emits an integer.';


--
-- Name: COLUMN "billsReceivable"."externalID2"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."billsReceivable"."externalID2" IS 'Signed. wallet.py:807, :814 and :828 all do cfg.evelocations.Get(bill.externalID2).name after testing `!= -1` -- a locationID, with -1 meaning unset.';


--
-- Name: billsReceivable_billID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."billsReceivable_billID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billsReceivable_billID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."billsReceivable_billID_seq" OWNED BY public."billsReceivable"."billID";


--
-- Name: billsReceivable billID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."billsReceivable" ALTER COLUMN "billID" SET DEFAULT nextval('public."billsReceivable_billID_seq"'::regclass);


--
-- Data for Name: billsReceivable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."billsReceivable" ("billID", "billTypeID", "debtorID", "creditorID", amount, "dueDateTime", interest, "externalID", paid, "externalID2") FROM stdin;
\.


--
-- Name: billsReceivable_billID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."billsReceivable_billID_seq"', 1, false);


--
-- Name: billsReceivable billsReceivable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."billsReceivable"
    ADD CONSTRAINT "billsReceivable_pkey" PRIMARY KEY ("billID");


--
-- Name: billsreceivable_creditor_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX billsreceivable_creditor_ix ON public."billsReceivable" USING btree ("creditorID", paid);


--
-- Name: INDEX billsreceivable_creditor_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.billsreceivable_creditor_ix IS 'billMgr.CharGetBillsReceivable / GetCorporationBillsReceivable -- "what am I owed" (wallet.py:697).';


--
-- Name: billsreceivable_debtor_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX billsreceivable_debtor_ix ON public."billsReceivable" USING btree ("debtorID", paid);


--
-- Name: INDEX billsreceivable_debtor_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.billsreceivable_debtor_ix IS 'billMgr.CharGetBills / GetCorporationBills -- "what do I owe" (wallet.py:695).';


--
-- PostgreSQL database dump complete
--

\unrestrict ByMpHYMJJ8nxMDCnGKCfOzWxprWqewfmQKAsrcfkhR08V3uzBK10yXIxsE7QEDQ

