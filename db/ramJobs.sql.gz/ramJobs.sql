--
-- PostgreSQL database dump
--

\restrict ZXLTSd2t2TitylCQhu5g5QvbkiBmWHXJqjwtMwilxTEE13bNFhrRGf821Htd7kO

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramJobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramJobs" (
    "jobID" integer NOT NULL,
    "assemblyLineID" integer NOT NULL,
    "installerID" integer NOT NULL,
    creator integer,
    "installedItemID" integer,
    "installedItemTypeID" integer NOT NULL,
    "installedItemOwnerID" integer NOT NULL,
    "installedItemQuantity" integer DEFAULT 1 NOT NULL,
    "installedItemProductivityLevel" integer,
    "installedItemMaterialLevel" integer,
    "installedItemLicensedProductionRunsRemaining" integer,
    "containerID" integer NOT NULL,
    "containerTypeID" integer NOT NULL,
    "containerLocationID" integer NOT NULL,
    "installedInSolarSystemID" integer NOT NULL,
    "activityID" integer NOT NULL,
    "outputTypeID" integer NOT NULL,
    "outputFlag" integer DEFAULT 4 NOT NULL,
    "outputLocationID" integer,
    runs integer DEFAULT 1 NOT NULL,
    "licensedProductionRuns" integer DEFAULT 0 NOT NULL,
    "installTime" bigint NOT NULL,
    "beginProductionTime" bigint NOT NULL,
    "endProductionTime" bigint NOT NULL,
    completed smallint DEFAULT 0 NOT NULL,
    "completedStatus" smallint,
    "charAddedCost" double precision DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "ramJobs"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."ramJobs" IS 'Installed manufacturing / research / copying jobs. Serves ramProxy.InstallJob (manufacturing.py:1672 quote, :1692 commit), ramProxy.CompleteJob (manufacturing.py:131) and ramProxy.GetJobs2 (manufacturing.py:665). Job state is derived from the three timestamps plus "completed" -- see manufacturing.py:728-740.';


--
-- Name: COLUMN "ramJobs"."jobID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."jobID" IS 'PROVEN: manufacturing.py:131 passes jobdata.jobID to ramProxy.CompleteJob(installationLocationData, jobdata.jobID, cancel). A private handle, so a plain identity column -- it is never an ownerID or a locationID.';


--
-- Name: COLUMN "ramJobs"."assemblyLineID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."assemblyLineID" IS 'INFERRED. ramAssemblyLines."assemblyLineID" the job occupies. manufacturing.py:1663 appends self.sr.assemblyLine.assemblyLineID into installationLocationData[2] before InstallJob, and manufacturing.py:1375 shows assemblyLineID is a column of the assembly-line rowset. The job row must remember it so ramAssemblyLines."nextFreeTime" can be recomputed on completion.';


--
-- Name: COLUMN "ramJobs"."installerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installerID" IS 'PROVEN: manufacturing.py:678 j_creator = j.installerID and :686 cfg.eveowners.Get(j.installerID).name (column header "installer").';


--
-- Name: COLUMN "ramJobs".creator; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs".creator IS 'PROVEN and OPTIONAL: manufacturing.py:679-680 `if hasattr(j, ''creator''): j_creator = j.creator`. The client tolerates the column being absent from the header entirely, so NULL is safe.';


--
-- Name: COLUMN "ramJobs"."installedItemID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemID" IS 'INFERRED. entity.itemID of the blueprint/item installed. Not read off the job row by this client, but InstallJob receives installedItem (manufacturing.py:1672 `installedItem=self.sr.bluePrint`) and facility.py:472 reads info.installedItem.itemID from the quote, so the identity exists and CompleteJob must return that exact item.';


--
-- Name: COLUMN "ramJobs"."installedItemTypeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemTypeID" IS 'PROVEN: manufacturing.py:686 cfg.invtypes.Get(j.installedItemTypeID).name (column header "type").';


--
-- Name: COLUMN "ramJobs"."installedItemOwnerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemOwnerID" IS 'PROVEN: manufacturing.py:686 cfg.eveowners.Get(j.installedItemOwnerID).name (column header "owner"). Also the natural filter for GetJobs2''s `owner` argument.';


--
-- Name: COLUMN "ramJobs"."installedItemQuantity"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemQuantity" IS 'INFERRED. No client read. Needed so a stacked input is accounted for.';


--
-- Name: COLUMN "ramJobs"."installedItemProductivityLevel"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemProductivityLevel" IS 'PROVEN: manufacturing.py:769-770 renders "Install P.E." = jobdata.installedItemProductivityLevel and "End P.E." = installedItemProductivityLevel + runs for activityID 3 (ramActivityResearchingTimeProductivity).';


--
-- Name: COLUMN "ramJobs"."installedItemMaterialLevel"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemMaterialLevel" IS 'PROVEN: manufacturing.py:772-773 renders "Install M.E." = jobdata.installedItemMaterialLevel and "End. M.E." = installedItemMaterialLevel + runs for activityID 4 (ramActivityResearchingMaterialProductivity).';


--
-- Name: COLUMN "ramJobs"."installedItemLicensedProductionRunsRemaining"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedItemLicensedProductionRunsRemaining" IS 'INFERRED name; the CONCEPT is proven -- a BPO carries -1 here (corp_ui_votes.py:364 tests != -1) and blueprint runs live in entity_attributes. Snapshot of the input blueprint''s remaining runs at install time so CompleteJob can decrement correctly.';


--
-- Name: COLUMN "ramJobs"."containerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."containerID" IS 'PROVEN: manufacturing.py:686 and :707 -- GetJobLocationName(j.containerID, j.containerTypeID, j.containerLocationID); manufacturing.py:704 also uses it for the celestial menu. The station or assembly-array item the line lives in.';


--
-- Name: COLUMN "ramJobs"."containerTypeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."containerTypeID" IS 'PROVEN: manufacturing.py:686, :707, :704 (menu typeID). Used to tell a station from a groupAssemblyArray / groupMobileLaboratory (manufacturing.py:711-717).';


--
-- Name: COLUMN "ramJobs"."containerLocationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."containerLocationID" IS 'PROVEN: manufacturing.py:686, :711 -- third argument of GetJobLocationName.';


--
-- Name: COLUMN "ramJobs"."installedInSolarSystemID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installedInSolarSystemID" IS 'PROVEN: manufacturing.py:686 GetJumpCountFromCurrent(j.installedInSolarSystemID) (column header "jumps") and :702 compares it to eve.session.solarsystemid.';


--
-- Name: COLUMN "ramJobs"."activityID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."activityID" IS 'PROVEN: manufacturing.py:676 filters on j.activityID, :686 GetActivityName(j.activityID), :767-774 branches on ramActivityResearchingTimeProductivity/MaterialProductivity/Copying. FK values are static ramActivities.activityID (0 None, 1 Manufacturing, 2 Researching Technology, 3 Res. Time Productivity, 4 Res. Material Productivity, 5 Copying, 6 Duplicating, 7 Reverse Engineering, 8 Invention).';


--
-- Name: COLUMN "ramJobs"."outputTypeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."outputTypeID" IS 'PROVEN: manufacturing.py:757 outputType = cfg.invtypes.Get(jobdata.outputTypeID), then portionSize * runs.';


--
-- Name: COLUMN "ramJobs"."outputFlag"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."outputFlag" IS 'INFERRED name. The VALUE is proven: InstallJob''s 4th positional argument is flagOutput (manufacturing.py:1672/1692). An eveFlags.flagID -- 4 Hangar, or 116..121 for corp divisions 2..7.';


--
-- Name: COLUMN "ramJobs"."outputLocationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."outputLocationID" IS 'INFERRED. No client read. Where CompleteJob delivers the product; NULL means "same container".';


--
-- Name: COLUMN "ramJobs".runs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs".runs IS 'PROVEN: manufacturing.py:757 portionSize * jobdata.runs, :770 installedItemProductivityLevel + jobdata.runs, :776 "Copies". Comes in as InstallJob''s buildRuns argument (manufacturing.py:1672).';


--
-- Name: COLUMN "ramJobs"."licensedProductionRuns"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."licensedProductionRuns" IS 'PROVEN: manufacturing.py:777 renders "Production Runs" = jobdata.licensedProductionRuns for activityID 5 (Copying). Also an explicit InstallJob argument (manufacturing.py:1672).';


--
-- Name: COLUMN "ramJobs"."installTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."installTime" IS 'PROVEN: manufacturing.py:686 util.FmtDate(j.installTime, ''ss'') (column header "installdate"). Windows FILETIME.';


--
-- Name: COLUMN "ramJobs"."beginProductionTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."beginProductionTime" IS 'PROVEN: manufacturing.py:733 and :735 compare it to blue.os.GetTime() to derive Pending/InProgress. Windows FILETIME. InstallJob receives maxJobStartTime = assemblyLine.nextFreeTime + 1*MIN (manufacturing.py:1672) as the ceiling for it.';


--
-- Name: COLUMN "ramJobs"."endProductionTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."endProductionTime" IS 'PROVEN: manufacturing.py:686 util.FmtDate(j.endProductionTime,''ss'') (header "enddate") and :730 the Ready/Delivered test. Windows FILETIME.';


--
-- Name: COLUMN "ramJobs".completed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs".completed IS 'PROVEN 0/1: manufacturing.py:731 `if jobdata.completed == 1` -> Delivered, :734 `== 0` -> Ready. Also GetJobs2''s `completed` filter argument (manufacturing.py:665). smallint so marshal emits an integer.';


--
-- Name: COLUMN "ramJobs"."completedStatus"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."completedStatus" IS 'PROVEN: manufacturing.py:732 cfg.ramcompletedstatuses.Get(jobdata.completedStatus).completedStatusName. Static ramCompletedStatuses: 0 Failed, 1 Delivered, 2 Aborted, 3 GM aborted, 4 Unanchored, 5 Destroyed. NULL while the job is not completed.';


--
-- Name: COLUMN "ramJobs"."charAddedCost"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."ramJobs"."charAddedCost" IS 'INFERRED name. The VALUE is proven: InstallJob is called with authorizedCost=... on the commit pass (manufacturing.py:1692) after a quoteOnly=1 pass returned the quote (:1672). ISK the installer agreed to pay.';


--
-- Name: ramJobs_jobID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."ramJobs" ALTER COLUMN "jobID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."ramJobs_jobID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: ramJobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramJobs" ("jobID", "assemblyLineID", "installerID", creator, "installedItemID", "installedItemTypeID", "installedItemOwnerID", "installedItemQuantity", "installedItemProductivityLevel", "installedItemMaterialLevel", "installedItemLicensedProductionRunsRemaining", "containerID", "containerTypeID", "containerLocationID", "installedInSolarSystemID", "activityID", "outputTypeID", "outputFlag", "outputLocationID", runs, "licensedProductionRuns", "installTime", "beginProductionTime", "endProductionTime", completed, "completedStatus", "charAddedCost") FROM stdin;
\.


--
-- Name: ramJobs_jobID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ramJobs_jobID_seq"', 1, false);


--
-- Name: ramJobs ramJobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramJobs"
    ADD CONSTRAINT "ramJobs_pkey" PRIMARY KEY ("jobID");


--
-- Name: ramjobs_container_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ramjobs_container_ix ON public."ramJobs" USING btree ("containerID");


--
-- Name: INDEX ramjobs_container_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ramjobs_container_ix IS 'Jobs at one installation -- the facility window (facility.py) lists per container.';


--
-- Name: ramjobs_installer_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ramjobs_installer_ix ON public."ramJobs" USING btree ("installerID", completed);


--
-- Name: INDEX ramjobs_installer_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ramjobs_installer_ix IS 'The client also filters by installer/creator client-side (manufacturing.py:678-681); serving it in SQL is cheaper.';


--
-- Name: ramjobs_line_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ramjobs_line_ix ON public."ramJobs" USING btree ("assemblyLineID");


--
-- Name: INDEX ramjobs_line_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ramjobs_line_ix IS 'Recomputing ramAssemblyLines."nextFreeTime" when a job finishes.';


--
-- Name: ramjobs_owner_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ramjobs_owner_ix ON public."ramJobs" USING btree ("installedItemOwnerID", completed);


--
-- Name: INDEX ramjobs_owner_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ramjobs_owner_ix IS 'ramProxy.GetJobs2(owner, completed, fromDate, toDate) (manufacturing.py:665) -- both of its first two arguments, in order.';


--
-- Name: ramjobs_pending_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ramjobs_pending_ix ON public."ramJobs" USING btree ("endProductionTime") WHERE (completed = 0);


--
-- Name: INDEX ramjobs_pending_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ramjobs_pending_ix IS 'The delivery sweep: jobs whose endProductionTime has passed and completed = 0 are "Ready" (manufacturing.py:730-734).';


--
-- PostgreSQL database dump complete
--

\unrestrict ZXLTSd2t2TitylCQhu5g5QvbkiBmWHXJqjwtMwilxTEE13bNFhrRGf821Htd7kO

