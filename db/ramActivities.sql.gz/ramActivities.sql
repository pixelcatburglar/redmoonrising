--
-- PostgreSQL database dump
--

\restrict vrHbQn4g2nUxIicEwj1VrdUXoILQlfVyH4dUO1q6KiUiiT5pcCRjQoPp26k9hEb

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramActivities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramActivities" (
    "activityID" integer DEFAULT 0 NOT NULL,
    "activityName" text DEFAULT ''::text NOT NULL,
    "iconNo" text,
    description text DEFAULT ''::text NOT NULL,
    published integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: ramActivities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramActivities" ("activityID", "activityName", "iconNo", description, published) FROM stdin;
0	None	\N	No activity	1
1	Manufacturing	18_02	Manufacturing	1
2	Researching Technology	33_02	Technological research	0
3	Researching Time Productivity	33_02	Researching productivity time	1
4	Researching Material Productivity	33_02	Researching material productivity	1
5	Copying	33_02	Copying	1
6	Duplicating	\N	The process of creating an item, by studying an already existing item.	0
7	Reverse Engineering	\N	The process of creating a blueprint from an item.	0
8	Invention	33_02	The process of creating a more advanced item based on an existing item	1
\.


--
-- Name: ramActivities ramActivities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramActivities"
    ADD CONSTRAINT "ramActivities_pkey" PRIMARY KEY ("activityID");


--
-- PostgreSQL database dump complete
--

\unrestrict vrHbQn4g2nUxIicEwj1VrdUXoILQlfVyH4dUO1q6KiUiiT5pcCRjQoPp26k9hEb

