--
-- PostgreSQL database dump
--

\restrict XDOWar6wqss2P8KfR1ejIxQhaVbAt9Xb2dh3oltNGwYa9QQdmQtUpigPK0GdznY

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitionCategoryProperties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."petitionCategoryProperties" (
    "categoryID" integer NOT NULL,
    k text NOT NULL,
    "orderID" integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "petitionCategoryProperties"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."petitionCategoryProperties" IS 'CONFIG. Extra required fields per petition category, returned by petitioner.GetCategoryProperties(categoryID) (petition.py:403). The answers arrive back as CreatePetition''s retval argument (petition.py:453).';


--
-- Name: COLUMN "petitionCategoryProperties"."categoryID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategoryProperties"."categoryID" IS 'PROVEN: the argument of GetCategoryProperties (petition.py:403).';


--
-- Name: COLUMN "petitionCategoryProperties".k; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategoryProperties".k IS 'PROVEN, AND THE NAME IS LITERALLY `k`: petition.py:405 uses r.k as both the form label and the form key. Same one-letter convention as the static agtConfig(agentID, k, v) table.';


--
-- Name: COLUMN "petitionCategoryProperties"."orderID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionCategoryProperties"."orderID" IS 'INFERRED. Presentation order; the client renders them in the order returned.';


--
-- Data for Name: petitionCategoryProperties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."petitionCategoryProperties" ("categoryID", k, "orderID") FROM stdin;
2	Solar system	1
3	What was lost	1
3	Where and when	2
4	Pilot name	1
5	Pilot name	1
\.


--
-- Name: petitionCategoryProperties petitionCategoryProperties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."petitionCategoryProperties"
    ADD CONSTRAINT "petitionCategoryProperties_pkey" PRIMARY KEY ("categoryID", k);


--
-- PostgreSQL database dump complete
--

\unrestrict XDOWar6wqss2P8KfR1ejIxQhaVbAt9Xb2dh3oltNGwYa9QQdmQtUpigPK0GdznY

