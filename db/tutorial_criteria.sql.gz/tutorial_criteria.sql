--
-- PostgreSQL database dump
--

\restrict oEL9UnW8L0QwEnHkP1xQbcGs4uc6iJexvoI6oTOs2v57FteJOY7I9P22KSfCtlW

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tutorial_criteria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tutorial_criteria (
    "criteriaID" integer DEFAULT 0 NOT NULL,
    "criteriaName" text DEFAULT ''::text NOT NULL,
    "messageText" text DEFAULT ''::text NOT NULL,
    "audioPath" text
);


--
-- Data for Name: tutorial_criteria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tutorial_criteria ("criteriaID", "criteriaName", "messageText", "audioPath") FROM stdin;
1	session.station	The ship must be docked in a station before continuing.	res:/Tutorial2/_criterias/SessionStation.ogg
2	session.inflight	The ship must be in space before continuing.	res:/Tutorial2/_criterias/SessionInflight.ogg
3	session.station_inflight	The ship must either be docked in a station or in flight before continuing.	res:/Tutorial2/_criterias/SessionStationInflight.ogg
5	stationsvc.fitting	The Fitting station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceFitting.ogg
6	wndopen.wallet	The Wallet must be open before continuing.	res:/Tutorial2/_criterias/WndopenWallet.ogg
7	neocombtnblink.wallet		\N
8	neocombtnblink.charactersheet		\N
9	neocombtnblink.addressbook		\N
10	neocombtnblink.inbox		\N
11	neocombtnblink.notepad		\N
12	neocombtnblink.market		\N
13	neocombtnblink.corporation		\N
14	neocombtnblink.map		\N
15	neocombtnblink.assets		\N
16	neocombtnblink.calculator		\N
17	neocombtnblink.help		\N
18	neocombtnblink.channels		\N
19	neocombtnblink.browser		\N
20	neocombtnblink.journal		\N
21	neocombtnblink.jukebox		\N
22	neocombtnblink.log		\N
23	neocombtnblink.ships		\N
24	neocombtnblink.items		\N
25	stationsvc.medical	The Medical station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceMedical.ogg
26	stationsvc.repairshop	The Repair station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceRepairshop.ogg
27	stationsvc.reprocessingplant	The Reprocessing station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceReprocess.ogg
28	stationsvc.factories	The Factory station service must be open before continuing.	res:/Tutorial2/_criterias/StationServicesFactories.ogg
29	stationsvc.researchfacility	The Research station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceResearch.ogg
30	stationsvc.missions	The Missions station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceMissions.ogg
31	stationsvc.insurance	The Insurance station service must be open before continuing.	res:/Tutorial2/_criterias/StationServiceInsurance.ogg
32	wndopen.charactersheet	The Character Sheet must be open before continuing.	res:/Tutorial2/_criterias/WndOpenCharactersheet.ogg
33	wndopen.addressbook	The People and Places window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenAddressbook.ogg
34	wndopen.inbox	The Inbox needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenInbox.ogg
35	wndopen.notepad	The Notepad needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenNotepad.ogg
36	wndopen.market	The Market window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenMarket.ogg
37	wndopen.corporation	The Corporation window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenCorporation.ogg
38	wndopen.map	The Map window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenMap.ogg
39	wndopen.mapbrowser	The Map Browser window (F11) needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenMapbrowser.ogg
40	wndopen.assets	The Assets window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenAssets.ogg
41	wndopen.calculator	The Calculator window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenCalculator.ogg
42	wndopen.help	The Help window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenHelp.ogg
43	wndopen.channels	The Channels window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenChannels.ogg
44	wndopen.browser	The Browser needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenBrowser.ogg
45	wndopen.journal	The Journal needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenJournal.ogg
46	wndopen.jukebox	The Jukebox needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenJukebox.ogg
47	wndopen.log	The Log window needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenLog.ogg
48	wndopen.ships	The Ship Hangar needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenShips.ogg
49	wndopen.items	The Items Hangar needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenItems.ogg
50	wndopen.cargo	The ship's cargo hold needs to be open before continuing.	res:/Tutorial2/_criterias/WndOpenCargo.ogg
52	stationbtnblink.fitting		\N
53	stationbtnblink.medical		\N
54	stationbtnblink.repairshop		\N
55	stationbtnblink.reprocessingplant		\N
56	stationbtnblink.market		\N
57	stationbtnblink.factories		\N
58	stationbtnblink.researchfacility		\N
59	stationbtnblink.missions		\N
60	stationbtnblink.insurance		\N
61	tutorialbtnblink.OK		\N
62	neocombtnblink.undock		\N
63	rookieState.1		\N
64	rookieState.2		\N
65	rookieState.3		\N
66	rookieState.4		\N
67	rookieState.5		\N
68	rookieState.6		\N
69	rookieState.7		\N
70	rookieState.8		\N
71	rookieState.9		\N
72	rookieState.10		\N
73	rookieState.11		\N
74	rookieState.12		\N
75	rookieState.13		\N
76	rookieState.14		\N
77	rookieState.15		\N
78	rookieState.16		\N
79	rookieState.17		\N
80	rookieState.18		\N
81	rookieState.19		\N
82	rookieState.20		\N
83	shipuibtnblink.ResetCamera		\N
84	shipuibtnblink.ZoomIn		\N
85	shipuibtnblink.ZoomOut		\N
86	shipuibtnblink.Cargo		\N
87	shipuibtnblink.Tactical		\N
88	shipuibtnblink.Scanner		\N
89	shipuibtnblink.Autopilot		\N
90	shipuibtnblink.HiSlot0		\N
91	shipuibtnblink.HiSlot1		\N
92	headerblink.overview		\N
93	headerblink.activeitem		\N
94	shipuibtnblink.expandBtnLeft		\N
95	shipuibtnblink.expandBtnRight		\N
96	activeitembtnblink.approach		\N
97	activeitembtnblink.orbit		\N
98	activeitembtnblink.keepatrange		\N
99	activeitembtnblink.locktarget		\N
100	activeitembtnblink.lookat		\N
101	wndopen.tacticaloverlay	The Tactical Overlay needs to be active before continuing.	res:/Tutorial2/_criterias/WndOpenTacticalOverlay.ogg
102	expanded.overview	The Overview must be open before continuing.	res:/Tutorial2/_criterias/ExpandedOverview.ogg
103	expanded.activeitem	The Selected Items window must be open before continuing.	res:/Tutorial2/_criterias/ExpandedActiveItem.ogg
104	checklocktarget.*	The targeting systems must have locked on to a target before continuing.	res:/Tutorial2/_criterias/CheckLockTarget.ogg
105	checklocktarget.DeadspaceFrigate	The targeting systems must have locked on to an enemy frigate before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtDdSpcFrigate.ogg
106	checklocktarget.DeadspaceCruiser	The targeting systems must have locked on to an enemy cruiser before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtDdSpcCruiser.ogg
107	checklocktarget.Veldspar	The targeting systems must have locked on to a veldspar asteroid before continuing (you might be too far away, APPPROACH it before trying again).	res:/Tutorial2/_criterias/ChkLckTrgtVeldspar.ogg
108	checklocktarget.Station	The targeting systems must have locked on to a large, stationary object in space before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtLrgStatnryObjct.ogg
109	checklocktarget.ConcordDrone	The targeting systems must have locked on to a Concord drone before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtConcordDrone.ogg
110	checklocktarget.CustomsOfficial	The targeting systems must have locked on to a customs official before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtCustomOfficials.ogg
112	checklocktarget.PoliceDrone	The targeting systems must have locked on to a police vessel before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtPoliceDrone.ogg
113	checklocktarget.SentryGun	The targeting systems must have locked on to a sentry gun before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtSentryGun.ogg
114	rookieState.21		\N
115	rookieState.22		\N
116	rookieState.23		\N
117	rookieState.24		\N
118	rookieState.25		\N
119	rookieState.26		\N
120	rookieState.26		\N
121	rookieState.27		\N
122	rookieState.28		\N
123	rookieState.29		\N
124	rookieState.30		\N
125	rookieState.31		\N
126	rookieState.32		\N
127	rookieState.33		\N
128	rookieState.34		\N
129	checkBallpark.typeCelestialBeaconII	We need to warp to the Deadspace Complex before continuing	res:/Tutorial2/_criterias/ChkBllPrkTpCelstlBeacnII.ogg
130	checkBallpark.Beacon	We need to warp to the Deadspace Complex before continuing	res:/Tutorial2/_criterias/ChkNmBllPrkAstrdPrPrcssng.ogg
131	checkBallpark.Veldspar	There must be some veldspar in vicinity before continuing.	res:/Tutorial2/_criterias/ChkBllPrkVeldspar.ogg
132	checkComplex.Room0		\N
133	checkComplex.Room1	The Acceleration gate needs to be activated before continuing	\N
134	checkComplex.Room2	The Acceleration gate needs to be activated before continuing	\N
135	checkComplex.Room3	The Acceleration gate needs to be activated before continuing	\N
136	checkComplex.Room4	The Acceleration gate needs to be activated before continuing	\N
137	checkComplex.Room5	The Acceleration gate needs to be activated before continuing	\N
138	checkActiveModule.F1	Activate the first module (F1) before continuing.	res:/Tutorial2/_criterias/ChkActvtModuleF1.ogg
139	checkActiveModule.F2	Activate the the second module (F2) before continuing.	res:/Tutorial2/_criterias/ChkActvtModuleF2.ogg
140	checkActiveModule.F3		\N
141	checkActiveModule.F4		\N
142	checkActiveModule.F5		\N
143	checklocktarget.None	The targeting systems need to be unlocked or the target eliminated before continuing.	res:/Tutorial2/_criterias/CheckLockTargetNone.ogg
144	checkcargo.groupAccelerationGateKeys	The Training Complex Passkey must be located in the ship's cargo before continuing.	res:/Tutorial2/_criterias/ChkCmplxGrpAcclrtnGateKey.ogg
145	checkcargo.groupVeldspar	There must be some veldspar in the cargo hold before continuing.	res:/Tutorial2/_criterias/ChkCrgGrpVeldspar.ogg
146	checkcargo.groupOverseerPersonalEffects	The Overseer's Personal Belongings from the Prize Container must be in the cargo hold before continuing.	res:/Tutorial2/_criterias/ChkCrgOvrsrPrsonalEffects.ogg
147	checklocktarget.DeadspaceOverseersBelongings	The targeting systems must have locked on to the Prize Container before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtDdSpcOvrsrsBlng.ogg
148	checkHangar.typeTritanium	There must be some tritanium in the hangar before continuing.	res:/Tutorial2/_criterias/ChkHngrTypeTritanium.ogg
149	checkHangar.groupVeldspar	There must be some veldspar in the hangar before continuing.	res:/Tutorial2/_criterias/ChkHngrGrpVeldspar.ogg
150	checkNotInHangar.typeTritanium	All tritanium must be sold or removed from the hangar before continuing.	res:/Tutorial2/_criterias/ChkNtInHngrTpTritanium.ogg
151	rookieState.35		\N
152	rookieState.36		\N
153	rookieState.37		\N
154	checkNotInCargo.typeTritanium	All tritanium must be removed from the cargo hold before continuing.	res:/Tutorial2/_criterias/ChkNtInCrgTpTritanium.ogg
155	checkNotInCargo.groupVeldspar	All veldspar must be removed from the cargo hold before continuing.	res:/Tutorial2/_criterias/ChkNtInCrgGrpVeldspar.ogg
156	checkNotInShip.groupCapsule	The pod needs to be inserted into a ship (e.g. from ship hangar) before continuing.	res:/Tutorial2/_criterias/ChkNtInShpGrpCapsule.ogg
157	checkNotInShip.groupRookieship	A ship, other than a rookie ship, must be active before continuing.	res:/Tutorial2/_criterias/ChkNtInShpGrpRookieShip.ogg
158	rookieState.38		\N
159	rookieState.39		\N
160	rookieState.40		\N
161	checkHangar.groupShieldBooster	There must be a shield booster located in the Items Hangar in the current station before continuing.	res:/Tutorial2/_criterias/ChkHngrGrpShieldBooster.ogg
162	checkfitted.groupShieldBooster	The ship must be fitted with a Civilian Shield Booster before continuing (buy one on the Market, dock the ship and use the Fittings station service to fit it).	res:/Tutorial2/_criterias/ChkFttdGrpShieldBooster.ogg
163	checkNotInHangar.typeDamageControlI	The Damage Control must have been sold or removed from the Items Hangar before continuing.	res:/Tutorial2/_criterias/ChkNtInHngrTpBscDmgCntrl.ogg
164	activeitembtnblink.Opencargo		\N
165	checknameinballpark.AncientAccelerationGateleadingintoDeadspace	The ship must have warped to the Deadspace Training Complex before continuing.	res:/Tutorial2/_criterias/ChkNmBllPrkAstrdPrPrcssng.ogg
166	checknameinballpark.GateBeaconI	The ship must be inside the first pocket of the deadspace complex (past the first acceleration gate) before continuing.	res:/Tutorial2/_criterias/ChkNmBllPrkGateBeaconI.ogg
167	checknameinballpark.GateBeaconII	The ship must be inside the second pocket of the deadspace complex before continuing.	res:/Tutorial2/_criterias/ChkNmBllPrkGateBeaconII.ogg
168	checknameinballpark.GateBeaconIII	The ship must be inside the third pocket of the deadspace complex before continuing.	res:/Tutorial2/_criterias/ChkNmBllPrkGateBeaconIII.ogg
169	rookieState.1000		\N
170	checkNotInCargo.typeBasicDamageControl	The Damage Control must not be in the ship's cargo, but in the hangar before continuing.	res:/Tutorial2/_criterias/ChkNtInCrgTpBscDmgCntrl.ogg
171	checklocktarget.Station	The targeting systems must have locked on to the station before continuing.	res:/Tutorial2/_criterias/ChkLckTrgtStation2.ogg
172	checkSkilltraining.*	There must be a skill in training before continuing.	res:/Tutorial2/_criterias/CheckSkillTraining.ogg
173	rookieState.28_5		\N
174	wndclosed.map	The map needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedMap.ogg
178	checkNotInHangar.groupVeldspar	The veldspar needs to have been reprocessed or sold from the hangar before continuing.	res:/Tutorial2/_criterias/ChkNtInHngrTpVeldspar.ogg
179	wndclosed.items	The items hangar needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedItems.ogg
180	wndclosed.cargo	The cargo needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedCargo.ogg
181	wndclosed.charactersheet	The character sheet needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedCharactersheet.ogg
182	wndclosed.wallet	The wallet needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedWallet.ogg
183	wndclosed.reprocessingplant	The reprocessing station service needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedReprocessing.ogg
184	wndclosed.market	The market needs to be closed before continuing (left-click the [x] in its upper right corner).	res:/Tutorial2/_criterias/WndClosedMarket.ogg
185	wndclosed.fitting	The fitting station service needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedFitting.ogg
186	wndclosed.mapbrowser	The map browser needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedMapbrowser.ogg
187	checkNotInHangar.groupVeldspar	All veldspar must be sold or removed from the hangar before continuing.	res:/Tutorial2/_criterias/ChkNtHngrGrpVeldspar.ogg
188	checknamenotinballpark.PirateKeyholder	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
189	checknamenotinballpark.AutomatedCentiiTrainingVessel	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
190	checknamenotinballpark.PirateCaptainAutomaton	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
191	wndclosed.addressbook	The People and Places window needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedAddressbook.ogg
192	checkTutorialAgent.all	The ship must be docked in our home station before continuing.	res:/Tutorial2/_criterias/CheckTutorialAgent.ogg
193	tutorialDone.02		\N
194	wndclosed.assets	The assets window needs to be closed before continuing.	res:/Tutorial2/_criterias/WndClosedAssets.ogg
195	deadspace.accelgatefromlastpage	Please continue the tutorial before activating the gate.	\N
196	IfNameInBallparkThenNoGateActivation.DeadspaceTrainingComplex	You must proceed further in the tutorial before activating this gate.	\N
197	IfNameInBallparkThenNoGateActivation.GateBeaconI	You must proceed further in the tutorial before activating this gate.	\N
198	IfNameInBallparkThenNoGateActivation.GateBeaconII	You must proceed further in the tutorial before activating this gate.	\N
199	IfNameInBallparkThenNoGateActivation.GateBeaconIII	You must proceed further in the tutorial before activating this gate.	\N
200	checknamenotinballpark.AutomatedCoreliTrainingVessel	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
201	checknamenotinballpark.AutomatedCorpiiTrainingVessel	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
202	checknamenotinballpark.AutomatedGistiTrainingVessel	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
203	checknamenotinballpark.AutomatedPithiTrainingVessel	The targets must be eliminated before continuing.	res:/Tutorial2/_criterias/CheckAutomatonsEliminated.ogg
\.


--
-- Name: tutorial_criteria tutorial_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tutorial_criteria
    ADD CONSTRAINT tutorial_criteria_pkey PRIMARY KEY ("criteriaID");


--
-- PostgreSQL database dump complete
--

\unrestrict oEL9UnW8L0QwEnHkP1xQbcGs4uc6iJexvoI6oTOs2v57FteJOY7I9P22KSfCtlW

