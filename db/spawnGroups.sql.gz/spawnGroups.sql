--
-- PostgreSQL database dump
--

\restrict qu2xZCjz2gOyRUh1GWTCMBjUT78AJfu9wYVijKTauTTNBO8qijprvdJKfeOr95d

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: spawnGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."spawnGroups" (
    "spawnGroupID" integer NOT NULL,
    "spawnGroupName" text DEFAULT ''::text NOT NULL,
    formation integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: spawnGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."spawnGroups" ("spawnGroupID", "spawnGroupName", formation) FROM stdin;
1	Caldari Sentry	0
\.


--
-- Name: spawnGroups spawnGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."spawnGroups"
    ADD CONSTRAINT "spawnGroups_pkey" PRIMARY KEY ("spawnGroupID");


--
-- PostgreSQL database dump complete
--

\unrestrict qu2xZCjz2gOyRUh1GWTCMBjUT78AJfu9wYVijKTauTTNBO8qijprvdJKfeOr95d

