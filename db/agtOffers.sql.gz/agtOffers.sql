--
-- PostgreSQL database dump
--

\restrict dcDUsAwXW1eQO1Ba4kvLuJUbAcF2n8F17C1cbH1vRdWxUCFWv9JQbBhVQSYCtQZ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtOffers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtOffers" (
    "offerID" integer NOT NULL,
    "offerName" text DEFAULT ''::text NOT NULL,
    "offerLevel" smallint DEFAULT 0 NOT NULL,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL,
    "requiredISK" integer DEFAULT 0 NOT NULL,
    "rewardISK" integer DEFAULT 0 NOT NULL,
    "offerText" text DEFAULT ''::text NOT NULL,
    "offerAcceptedText" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: agtOffers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtOffers" ("offerID", "offerName", "offerLevel", "loyaltyPoints", "requiredISK", "rewardISK", "offerText", "offerAcceptedText") FROM stdin;
\.


--
-- Name: agtOffers agtOffers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtOffers"
    ADD CONSTRAINT "agtOffers_pkey" PRIMARY KEY ("offerID");


--
-- Name: agtOffers_offerLevel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtOffers_offerLevel_idx" ON public."agtOffers" USING btree ("offerLevel");


--
-- PostgreSQL database dump complete
--

\unrestrict dcDUsAwXW1eQO1Ba4kvLuJUbAcF2n8F17C1cbH1vRdWxUCFWv9JQbBhVQSYCtQZ

