--
-- PostgreSQL database dump
--

\restrict XEfgbgUYGxsyLsoozeKesgifrjXKQDFZJmmr74TglQMubsPHQfe22BZRxwIzfj6

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrDepartments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrDepartments" (
    "schoolID" integer DEFAULT 0 NOT NULL,
    "departmentID" integer DEFAULT 0 NOT NULL,
    "departmentName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "skillTypeID1" integer DEFAULT 0 NOT NULL,
    "skillTypeID2" integer DEFAULT 0 NOT NULL,
    "skillTypeID3" integer DEFAULT 0 NOT NULL,
    "graphicID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrDepartments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrDepartments" ("schoolID", "departmentID", "departmentName", description, "skillTypeID1", "skillTypeID2", "skillTypeID3", "graphicID") FROM stdin;
11	1	Gunnery	(Buffer)	3429	3300	3426	1432
11	2	Operations	(Buffer)	3331	3348	3375	1433
12	3	Science	(Buffer)	3402	3377	3403	1434
12	4	Business	Might makes right and in this day and age money is where the might lies. Acute businessmen abound and the only way to beat them is at their own game. Once you understand what drives the market you're halfway home to earning your first million.	3443	3376	3355	1435
13	5	Engineering	(Buffer)	3413	3426	3402	1436
13	6	Industry	(Buffer)	3380	3378	3385	1437
14	7	Gunnery	(Buffer)	3300	3426	3429	1432
14	8	Operations	(Buffer)	3329	3348	3327	1433
15	9	Science	(Buffer)	3402	3377	3403	1434
15	10	Business	Might makes right and in this day and age money is where the might lies. Acute businessmen abound and the only way to beat them is at their own game. Once you understand what drives the market you're halfway home to earning your first million.	3443	3376	3355	1435
16	11	Engineering	(Buffer)	3413	3378	3402	1436
16	12	Industry	(Buffer)	3380	3392	3386	1437
17	13	Gunnery	(Buffer)	3300	3429	3426	1432
17	14	Operations	(Buffer)	3330	3348	3375	1433
18	15	Science	(Buffer)	3402	3377	3403	1434
18	16	Business	Might makes right and in this day and age money is where the might lies. Acute businessmen abound and the only way to beat them is at their own game. Once you understand what drives the market you're halfway home to earning your first million.	3443	3355	3376	1435
19	17	Engineering	(Buffer)	3413	3402	3426	1436
19	18	Industry	(Buffer)	3386	3392	3380	1437
20	19	Gunnery	(Buffer)	3300	3429	3426	1432
20	20	Operations	(Buffer)	3328	3348	3375	1433
21	21	Science	(Buffer)	3402	3403	3377	1434
21	22	Business	Might makes right and in this day and age money is where the might lies. Acute businessmen abound and the only way to beat them is at their own game. Once you understand what drives the market you're halfway home to earning your first million.	3443	3376	3355	1435
22	23	Engineering	(Buffer)	3413	3402	3426	1436
22	24	Industry	(Buffer)	3380	3392	3386	1437
23	25	Business	Might makes right and in this day and age money is where the might lies. Acute businessmen abound and the only way to beat them is at their own game. Once you understand what drives the market you're halfway home to earning your first million.	3443	3355	3376	1435
23	26	Science	(Buffer)	3377	3402	3403	1434
24	27	Engineering	(Buffer)	3413	3426	3402	1436
24	28	Industry	(Buffer)	3380	3385	3378	1437
25	29	Gunnery	(Buffer)	3300	3429	3426	1432
25	30	Operations	(Buffer)	3755	3348	3375	1433
\.


--
-- Name: chrDepartments chrDepartments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrDepartments"
    ADD CONSTRAINT "chrDepartments_pkey" PRIMARY KEY ("departmentID");


--
-- PostgreSQL database dump complete
--

\unrestrict XEfgbgUYGxsyLsoozeKesgifrjXKQDFZJmmr74TglQMubsPHQfe22BZRxwIzfj6

