--
-- PostgreSQL database dump
--

\restrict giMpWdzqF8szwh6BbH2pbbRNDaC71T0Emd3ogtKGFSkumJEJmvcTdoiQG17LpYh

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tutorials_criterias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tutorials_criterias (
    "tutorialID" integer DEFAULT 0 NOT NULL,
    "criteriaID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: tutorials_criterias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tutorials_criterias ("tutorialID", "criteriaID") FROM stdin;
5	1
6	1
7	1
8	1
9	1
11	1
12	1
13	1
14	1
16	1
15	2
17	2
18	2
19	2
21	2
23	2
24	2
28	2
37	2
38	2
\.


--
-- Name: tutorials_criterias tutorials_criterias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tutorials_criterias
    ADD CONSTRAINT tutorials_criterias_pkey PRIMARY KEY ("tutorialID", "criteriaID");


--
-- Name: tutorials_criterias_criteriaID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tutorials_criterias_criteriaID_idx" ON public.tutorials_criterias USING btree ("criteriaID");


--
-- PostgreSQL database dump complete
--

\unrestrict giMpWdzqF8szwh6BbH2pbbRNDaC71T0Emd3ogtKGFSkumJEJmvcTdoiQG17LpYh

