--
-- PostgreSQL database dump
--

\restrict 7y0CSiH9QeXcGBmHVDZ7XG6nHzC7W3SyUSCF1hdEkNk4jRuUgt8qdtE016R0yE1

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpItemLocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpItemLocks" (
    "corporationID" integer NOT NULL,
    "itemID" integer NOT NULL,
    "locationID" integer NOT NULL,
    "typeID" integer NOT NULL,
    "lockedAt" bigint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "crpItemLocks"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."crpItemLocks" IS 'Corp-locked items. Serves corpRegistry.GetLockedItemsByLocation / GetLockedItemLocations (bco_itemLocking.py:49,62). Push: OnLockedItemChange(itemID, ownerID, locationID, change) (bco_itemLocking.py:18).';


--
-- Name: COLUMN "crpItemLocks"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpItemLocks"."corporationID" IS 'INFERRED as a column: bco_itemLocking.py:14-16 flushes the whole cache when session corpid changes, and IsItemLocked (:68-70) returns 0 unless util.IsCorporation(item.ownerID).';


--
-- Name: COLUMN "crpItemLocks"."itemID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpItemLocks"."itemID" IS 'PROVEN: the index key of the returned rowset -- bco_itemLocking.py:107 GetLockedItemsByLocation(stationID).has_key(itemID) -- and the 1st argument of the OnLockedItemChange notification.';


--
-- Name: COLUMN "crpItemLocks"."locationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpItemLocks"."locationID" IS 'PROVEN: the argument of GetLockedItemsByLocation and the 3rd argument of OnLockedItemChange. A STATION or SOLAR SYSTEM id, not the immediate container -- bco_itemLocking.py:82-104 resolves offices up to their station before querying.';


--
-- Name: COLUMN "crpItemLocks"."typeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpItemLocks"."typeID" IS 'INFERRED. IsItemIDLocked(itemID, locationID, typeID) (bco_itemLocking.py:80) takes a typeID to decide whether the location IS the station (categoryStation test at :96-97), so the row is expected to carry enough to rebuild that.';


--
-- Name: COLUMN "crpItemLocks"."lockedAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpItemLocks"."lockedAt" IS 'INFERRED. Windows FILETIME. No client read; useful because a lockdown is the product of a vote (voteItemLockdown) and the audit trail matters.';


--
-- Data for Name: crpItemLocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpItemLocks" ("corporationID", "itemID", "locationID", "typeID", "lockedAt") FROM stdin;
\.


--
-- Name: crpItemLocks crpItemLocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpItemLocks"
    ADD CONSTRAINT "crpItemLocks_pkey" PRIMARY KEY ("corporationID", "itemID");


--
-- Name: crpitemlocks_location_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crpitemlocks_location_ix ON public."crpItemLocks" USING btree ("locationID");


--
-- Name: INDEX crpitemlocks_location_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.crpitemlocks_location_ix IS 'GetLockedItemsByLocation(locationID) and GetLockedItemLocations() (bco_itemLocking.py:49, :62).';


--
-- PostgreSQL database dump complete
--

\unrestrict 7y0CSiH9QeXcGBmHVDZ7XG6nHzC7W3SyUSCF1hdEkNk4jRuUgt8qdtE016R0yE1

