--
-- PostgreSQL database dump
--

\restrict if22TlEeJC71tLZRKfiSO1HsV0js6O8DMrSsGxb4vYIx2XCUmyHl4uu7X6zG2GF

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtOfferRequired; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtOfferRequired" (
    "offerID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    quantity integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: agtOfferRequired; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtOfferRequired" ("offerID", "typeID", quantity) FROM stdin;
\.


--
-- Name: agtOfferRequired agtOfferRequired_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtOfferRequired"
    ADD CONSTRAINT "agtOfferRequired_pkey" PRIMARY KEY ("offerID", "typeID");


--
-- Name: agtOfferRequired_typeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtOfferRequired_typeID_idx" ON public."agtOfferRequired" USING btree ("typeID");


--
-- PostgreSQL database dump complete
--

\unrestrict if22TlEeJC71tLZRKfiSO1HsV0js6O8DMrSsGxb4vYIx2XCUmyHl4uu7X6zG2GF

