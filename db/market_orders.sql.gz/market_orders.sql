--
-- PostgreSQL database dump
--

\restrict 51P9vlMn5oKkIahfuWhEW4nVf88fmb9vLsi7SmM33bUiy9i9tc24dxteriZObjZ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.market_orders (
    "orderID" integer NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    "charID" integer DEFAULT 0 NOT NULL,
    "regionID" integer DEFAULT 0 NOT NULL,
    "stationID" integer DEFAULT 0 NOT NULL,
    range integer NOT NULL,
    bid smallint DEFAULT 0 NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    "volEntered" integer DEFAULT 0 NOT NULL,
    "volRemaining" integer DEFAULT 0 NOT NULL,
    issued bigint DEFAULT 0 NOT NULL,
    "orderState" integer DEFAULT 0 NOT NULL,
    "minVolume" integer DEFAULT 0 NOT NULL,
    contraband smallint DEFAULT 0 NOT NULL,
    "accountID" integer DEFAULT 0 NOT NULL,
    duration integer DEFAULT 0 NOT NULL,
    "isCorp" smallint DEFAULT 0 NOT NULL,
    "solarSystemID" integer DEFAULT 0 NOT NULL,
    escrow double precision DEFAULT 0 NOT NULL,
    jumps integer DEFAULT 1 NOT NULL
);


--
-- Name: COLUMN market_orders.escrow; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.market_orders.escrow IS 'ISK held in escrow for a buy order. double precision, not the shipped tinyint: orders.py:199-200 sums it against volRemaining*price.';


--
-- Name: market_orders_orderID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."market_orders_orderID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: market_orders_orderID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."market_orders_orderID_seq" OWNED BY public.market_orders."orderID";


--
-- Name: market_orders orderID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_orders ALTER COLUMN "orderID" SET DEFAULT nextval('public."market_orders_orderID_seq"'::regclass);


--
-- Data for Name: market_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.market_orders ("orderID", "typeID", "charID", "regionID", "stationID", range, bid, price, "volEntered", "volRemaining", issued, "orderState", "minVolume", contraband, "accountID", duration, "isCorp", "solarSystemID", escrow, jumps) FROM stdin;
\.


--
-- Name: market_orders_orderID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."market_orders_orderID_seq"', 1, false);


--
-- Name: market_orders market_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.market_orders
    ADD CONSTRAINT market_orders_pkey PRIMARY KEY ("orderID");


--
-- Name: market_orders_char_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_orders_char_ix ON public.market_orders USING btree ("charID") WHERE ("orderState" = 0);


--
-- Name: INDEX market_orders_char_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_orders_char_ix IS 'marketProxy.GetCharOrders (invalidated at marketsvc.py:90). Partial on orderState = 0 -- only live orders are listed.';


--
-- Name: market_orders_hot_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_orders_hot_ix ON public.market_orders USING btree ("typeID", "regionID", bid, price);


--
-- Name: market_orders_regionID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "market_orders_regionID_idx" ON public.market_orders USING btree ("regionID");


--
-- Name: market_orders_solarSystemID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "market_orders_solarSystemID_idx" ON public.market_orders USING btree ("solarSystemID");


--
-- Name: market_orders_stationID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "market_orders_stationID_idx" ON public.market_orders USING btree ("stationID");


--
-- Name: market_orders_station_type_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_orders_station_type_ix ON public.market_orders USING btree ("stationID", "typeID");


--
-- Name: INDEX market_orders_station_type_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_orders_station_type_ix IS 'marketProxy.GetStationAsks (marketsvc.py:255).';


--
-- Name: market_orders_system_type_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_orders_system_type_ix ON public.market_orders USING btree ("solarSystemID", "typeID");


--
-- Name: INDEX market_orders_system_type_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_orders_system_type_ix IS 'marketProxy.GetSystemAsks (marketsvc.py:262).';


--
-- Name: market_orders_typeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "market_orders_typeID_idx" ON public.market_orders USING btree ("typeID");


--
-- Name: market_orders_type_region_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX market_orders_type_region_ix ON public.market_orders USING btree ("typeID", "regionID", bid, price);


--
-- Name: INDEX market_orders_type_region_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.market_orders_type_region_ix IS 'THE hot query: marketProxy.GetOrders(typeID) scoped to the session region -- marketsvc.py:103-105 clears the client cache when regionid changes, and objectCaching invalidates per typeID (marketsvc.py:91). bid and price ride along so the buy/sell split and the sort are index-only.';


--
-- PostgreSQL database dump complete
--

\unrestrict 51P9vlMn5oKkIahfuWhEW4nVf88fmb9vLsi7SmM33bUiy9i9tc24dxteriZObjZ

