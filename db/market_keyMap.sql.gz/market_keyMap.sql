--
-- PostgreSQL database dump
--

\restrict lP9yG9garzzKbAqFI37xjoSucb2uzMOhQSRDdJ6eII01RadYcty9oDJUsvVcj8i

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_keyMap; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."market_keyMap" (
    "accountKey" integer DEFAULT 0 NOT NULL,
    "accountType" text DEFAULT ''::text NOT NULL,
    "accountName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: market_keyMap; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."market_keyMap" ("accountKey", "accountType", "accountName", description) FROM stdin;
1000	A	cash	
1100	A	property	
1500	A	escrow	
1800	A	receivables	
2000	L	payables	
2010	L	gold	
2900	L	equity	
3000	R	sales	
4000	C	purchases	
\.


--
-- Name: market_keyMap market_keyMap_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."market_keyMap"
    ADD CONSTRAINT "market_keyMap_pkey" PRIMARY KEY ("accountKey");


--
-- PostgreSQL database dump complete
--

\unrestrict lP9yG9garzzKbAqFI37xjoSucb2uzMOhQSRDdJ6eII01RadYcty9oDJUsvVcj8i

