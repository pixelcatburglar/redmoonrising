--
-- PostgreSQL database dump
--

\restrict GrKqc2YhI3uGzmOZwTNErvU4ZJihMddnVHv2BLkTa6bXIxSf0vkPWIlIRndbRCW

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLDecos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLDecos" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "decoID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLDecos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLDecos" ("bloodlineID", gender, "decoID", npc) FROM stdin;
1	0	1	0
1	0	2	0
1	0	4	0
1	0	7	0
1	0	8	0
1	0	9	0
1	0	10	0
1	0	11	0
1	0	12	0
1	0	13	0
1	0	14	0
1	0	18	0
1	0	22	0
1	0	23	0
1	0	24	0
1	0	26	0
1	0	27	0
1	0	28	0
1	0	45	0
1	0	77	0
1	0	78	0
1	0	79	0
1	0	80	0
1	0	81	0
1	0	82	0
1	1	1	0
1	1	2	0
1	1	3	0
1	1	4	0
1	1	5	0
1	1	6	0
1	1	7	0
1	1	9	0
1	1	10	0
1	1	12	0
1	1	13	0
1	1	14	0
1	1	18	0
1	1	23	0
1	1	24	0
1	1	25	0
2	0	1	0
2	0	2	0
2	0	4	0
2	0	5	0
2	0	6	0
2	0	7	0
2	0	8	0
2	0	9	0
2	0	10	0
2	0	11	0
2	0	12	0
2	0	13	0
2	0	14	0
2	0	18	0
2	0	24	0
2	0	25	0
2	0	26	0
2	0	27	0
2	0	28	0
2	0	76	0
2	0	77	0
2	0	78	0
2	0	79	0
2	0	80	0
2	0	81	0
2	0	82	0
2	1	1	0
2	1	2	0
2	1	3	0
2	1	4	0
2	1	5	0
2	1	6	0
2	1	7	0
2	1	9	0
2	1	10	0
2	1	12	0
2	1	13	0
2	1	14	0
2	1	18	0
2	1	23	0
2	1	24	0
2	1	25	0
3	0	1	0
3	0	2	0
3	0	3	0
3	0	4	0
3	0	6	0
3	0	8	0
3	0	9	0
3	0	10	0
3	0	11	0
3	0	12	0
3	0	13	0
3	0	14	0
3	0	18	0
3	0	23	0
3	0	24	0
3	0	25	0
3	0	26	0
3	0	27	0
3	0	28	0
3	0	32	0
3	0	33	0
3	0	34	0
3	0	35	0
3	0	36	0
3	0	37	0
3	1	1	0
3	1	2	0
3	1	3	0
3	1	4	0
3	1	5	0
3	1	6	0
3	1	7	0
3	1	8	0
3	1	9	0
3	1	10	0
3	1	11	0
3	1	12	0
3	1	13	0
3	1	14	0
3	1	18	0
3	1	22	0
3	1	23	0
3	1	24	0
3	1	25	0
3	1	26	0
3	1	27	0
3	1	38	0
3	1	39	0
3	1	40	0
3	1	41	0
3	1	42	0
3	1	43	0
3	1	44	0
3	1	45	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	0	9	0
4	0	10	0
4	0	11	0
4	0	12	0
4	0	13	0
4	0	14	0
4	0	15	0
4	0	16	0
4	0	17	0
4	0	18	0
4	0	19	0
4	0	20	0
4	0	21	0
4	1	1	0
4	1	2	0
4	1	3	0
4	1	4	0
4	1	5	0
4	1	6	0
4	1	7	0
4	1	8	0
4	1	9	0
4	1	10	0
4	1	11	0
4	1	12	0
4	1	13	0
4	1	14	0
4	1	18	0
4	1	22	0
4	1	23	0
4	1	24	0
4	1	25	0
4	1	26	0
4	1	27	0
4	1	28	0
4	1	29	0
4	1	30	0
4	1	31	0
5	0	18	0
5	0	46	0
5	0	47	0
5	0	48	0
5	0	49	0
5	0	50	0
5	0	51	0
5	0	52	0
5	0	53	0
5	0	54	0
5	0	55	0
5	1	18	0
5	1	56	0
5	1	57	0
5	1	58	0
5	1	59	0
5	1	60	0
5	1	61	0
5	1	62	0
5	1	63	0
6	0	64	0
6	0	65	0
6	0	66	0
6	0	67	0
6	0	68	0
6	0	69	0
6	0	70	0
6	1	18	0
6	1	71	0
6	1	72	0
6	1	73	0
6	1	74	0
6	1	75	0
7	0	1	0
7	0	2	0
7	0	3	0
7	0	4	0
7	0	5	0
7	0	6	0
7	0	7	0
7	0	8	0
7	0	9	0
7	0	10	0
7	0	11	0
7	0	12	0
7	0	13	0
7	0	14	0
7	0	18	0
7	0	22	0
7	0	23	0
7	0	24	0
7	0	25	0
7	0	26	0
7	0	27	0
7	0	28	0
7	0	29	0
7	0	30	0
7	0	83	0
7	0	84	0
7	0	85	0
7	0	86	0
7	0	87	0
7	0	88	0
7	0	89	0
7	0	90	0
7	0	91	0
7	0	92	0
7	0	93	0
7	0	94	0
7	0	95	0
7	0	96	0
7	0	97	0
7	0	98	0
7	0	99	0
7	1	1	0
7	1	2	0
7	1	3	0
7	1	4	0
7	1	5	0
7	1	6	0
7	1	7	0
7	1	8	0
7	1	9	0
7	1	10	0
7	1	11	0
7	1	12	0
7	1	13	0
7	1	14	0
7	1	22	0
7	1	23	0
7	1	24	0
7	1	25	0
7	1	26	0
7	1	27	0
7	1	28	0
7	1	29	0
7	1	30	0
7	1	83	0
7	1	84	0
7	1	85	0
8	0	1	0
8	0	4	0
8	0	5	0
8	0	6	0
8	0	7	0
8	0	8	0
8	0	9	0
8	0	10	0
8	0	12	0
8	0	13	0
8	0	22	0
8	0	23	0
8	0	24	0
8	0	25	0
8	0	26	0
8	0	27	0
8	0	28	0
8	0	29	0
8	0	83	0
8	0	84	0
8	1	1	0
8	1	2	0
8	1	3	0
8	1	4	0
8	1	5	0
8	1	7	0
8	1	8	0
8	1	9	0
8	1	10	0
8	1	12	0
8	1	13	0
8	1	14	0
8	1	18	0
8	1	22	0
8	1	24	0
8	1	25	0
8	1	100	0
8	1	101	0
11	1	102	0
11	1	103	0
11	1	104	0
11	1	105	0
11	1	106	0
11	1	107	0
11	1	108	0
12	1	106	0
12	1	124	0
12	1	125	0
12	1	126	0
12	1	127	0
13	1	106	0
13	1	112	0
13	1	128	0
13	1	129	0
13	1	130	0
13	1	131	0
13	1	132	0
13	1	133	0
13	1	134	0
13	1	135	0
13	1	136	0
14	1	106	0
14	1	109	0
14	1	110	0
14	1	111	0
14	1	112	0
14	1	113	0
14	1	114	0
14	1	115	0
14	1	116	0
14	1	117	0
14	1	118	0
14	1	119	0
14	1	120	0
14	1	121	0
14	1	122	0
14	1	123	0
\.


--
-- Name: chrBLDecos chrBLDecos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLDecos"
    ADD CONSTRAINT "chrBLDecos_pkey" PRIMARY KEY ("bloodlineID", gender, "decoID");


--
-- PostgreSQL database dump complete
--

\unrestrict GrKqc2YhI3uGzmOZwTNErvU4ZJihMddnVHv2BLkTa6bXIxSf0vkPWIlIRndbRCW

