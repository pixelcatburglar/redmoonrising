--
-- PostgreSQL database dump
--

\restrict oh4bdnrUYOyJzWPQAlQsacefv8owVECgnSCdqYwGJrUcAEyQ1ILjULRjwq2RAVx

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLLipsticks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLLipsticks" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "lipstickID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLLipsticks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLLipsticks" ("bloodlineID", gender, "lipstickID", npc) FROM stdin;
1	0	1	0
1	0	2	0
1	0	3	0
1	0	4	0
1	0	5	0
1	0	6	0
1	0	9	0
1	0	12	0
1	0	14	0
1	0	17	0
1	0	24	0
1	0	25	0
1	0	26	0
1	0	37	0
1	0	38	0
1	0	40	0
1	0	41	0
2	0	1	0
2	0	2	0
2	0	3	0
2	0	4	0
2	0	5	0
2	0	6	0
2	0	9	0
2	0	12	0
2	0	14	0
2	0	17	0
2	0	24	0
2	0	25	0
2	0	26	0
2	0	37	0
2	0	38	0
2	0	39	0
2	0	40	0
2	0	41	0
3	0	7	0
3	0	8	0
3	0	9	0
3	0	10	0
3	0	11	0
3	0	12	0
3	0	13	0
3	0	14	0
3	0	15	0
3	0	16	0
3	0	17	0
3	0	18	0
3	0	20	0
3	0	21	0
3	0	22	0
3	0	23	0
3	0	24	0
3	0	25	0
3	0	26	0
3	0	27	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	0	9	0
4	0	10	0
4	0	11	0
4	0	12	0
4	0	13	0
4	0	14	0
4	0	15	0
4	0	16	0
4	0	17	0
4	0	18	0
4	0	19	0
4	0	20	0
4	0	21	0
5	0	17	0
5	0	18	0
5	0	28	0
5	0	29	0
5	0	30	0
5	0	31	0
5	0	32	0
5	0	33	0
5	0	34	0
5	0	35	0
5	0	36	0
6	0	1	0
6	0	2	0
6	0	4	0
6	0	5	0
6	0	24	0
6	0	25	0
6	0	26	0
6	0	37	0
6	0	38	0
7	0	1	0
7	0	2	0
7	0	3	0
7	0	4	0
7	0	5	0
7	0	6	0
7	0	7	0
7	0	9	0
7	0	12	0
7	0	14	0
7	0	17	0
7	0	18	0
7	0	22	0
7	0	23	0
7	0	24	0
7	0	25	0
7	0	26	0
7	0	27	0
7	0	37	0
7	0	38	0
7	0	42	0
7	0	43	0
7	0	44	0
7	0	45	0
7	0	46	0
7	0	47	0
8	0	1	0
8	0	2	0
8	0	3	0
8	0	4	0
8	0	5	0
8	0	6	0
8	0	7	0
8	0	9	0
8	0	12	0
8	0	14	0
8	0	17	0
8	0	18	0
8	0	22	0
8	0	23	0
8	0	24	0
8	0	25	0
8	0	26	0
8	0	27	0
8	0	37	0
8	0	38	0
8	0	42	0
8	0	43	0
8	0	44	0
8	0	45	0
8	0	46	0
8	0	47	0
11	0	55	0
11	0	56	0
11	0	57	0
11	0	58	0
11	0	59	0
11	0	60	0
12	0	12	0
12	0	17	0
12	0	48	0
12	0	49	0
12	0	50	0
12	0	51	0
12	0	52	0
12	0	53	0
12	0	54	0
13	0	17	0
13	0	55	0
13	0	61	0
13	0	62	0
13	0	63	0
13	0	64	0
13	0	65	0
13	0	66	0
13	0	67	0
13	0	68	0
14	0	17	0
14	0	18	0
14	0	28	0
14	0	29	0
14	0	30	0
14	0	31	0
14	0	32	0
14	0	33	0
14	0	34	0
14	0	36	0
\.


--
-- Name: chrBLLipsticks chrBLLipsticks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLLipsticks"
    ADD CONSTRAINT "chrBLLipsticks_pkey" PRIMARY KEY ("bloodlineID", gender, "lipstickID");


--
-- PostgreSQL database dump complete
--

\unrestrict oh4bdnrUYOyJzWPQAlQsacefv8owVECgnSCdqYwGJrUcAEyQ1ILjULRjwq2RAVx

