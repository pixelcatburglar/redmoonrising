--
-- PostgreSQL database dump
--

\restrict f1oJkkVCcGcMPkzNs1uVuIgQGjwfrGVpHBjhondzYmUfP67f2CmiYaSjDkB5TLf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLEyes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLEyes" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "eyesID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLEyes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLEyes" ("bloodlineID", gender, "eyesID", npc) FROM stdin;
1	0	1	0
1	0	3	0
1	0	4	0
1	0	5	0
1	0	6	0
1	0	7	0
1	0	8	0
1	0	10	0
1	0	11	0
1	0	13	0
1	0	14	0
1	0	15	0
1	0	16	0
1	0	17	0
1	1	1	0
1	1	3	0
1	1	4	0
1	1	5	0
1	1	6	0
1	1	7	0
1	1	8	0
1	1	10	0
1	1	11	0
1	1	13	0
1	1	14	0
1	1	15	0
1	1	16	0
1	1	17	0
1	1	19	0
2	0	1	0
2	0	3	0
2	0	4	0
2	0	5	0
2	0	6	0
2	0	7	0
2	0	8	0
2	0	10	0
2	0	11	0
2	0	13	0
2	0	14	0
2	0	15	0
2	0	16	0
2	1	1	0
2	1	3	0
2	1	4	0
2	1	5	0
2	1	6	0
2	1	7	0
2	1	8	0
2	1	10	0
2	1	11	0
2	1	13	0
2	1	14	0
2	1	15	0
2	1	16	0
2	1	17	0
3	0	1	0
3	0	2	0
3	0	3	0
3	0	4	0
3	0	5	0
3	0	6	0
3	0	7	0
3	0	8	0
3	0	10	0
3	0	11	0
3	0	13	0
3	0	14	0
3	0	15	0
3	0	16	0
3	1	1	0
3	1	2	0
3	1	3	0
3	1	4	0
3	1	5	0
3	1	6	0
3	1	7	0
3	1	8	0
3	1	10	0
3	1	11	0
3	1	13	0
3	1	14	0
3	1	15	0
3	1	16	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	0	9	0
4	0	10	0
4	0	11	0
4	0	12	0
4	0	13	0
4	0	14	0
4	0	15	0
4	0	16	0
4	1	1	0
4	1	3	0
4	1	4	0
4	1	5	0
4	1	6	0
4	1	7	0
4	1	8	0
4	1	10	0
4	1	11	0
4	1	13	0
4	1	14	0
4	1	15	0
4	1	16	0
4	1	17	0
5	0	1	0
5	0	2	0
5	0	3	0
5	0	4	0
5	0	5	0
5	0	6	0
5	0	7	0
5	0	8	0
5	0	10	0
5	0	11	0
5	0	13	0
5	0	14	0
5	0	15	0
5	0	16	0
5	1	2	0
5	1	18	0
5	1	19	0
5	1	20	0
5	1	21	0
5	1	22	0
6	0	1	0
6	0	2	0
6	0	3	0
6	0	4	0
6	0	5	0
6	0	6	0
6	0	7	0
6	0	8	0
6	0	10	0
6	0	11	0
6	0	13	0
6	0	14	0
6	0	15	0
6	0	16	0
6	1	1	0
6	1	2	0
6	1	3	0
6	1	4	0
6	1	5	0
6	1	6	0
6	1	7	0
6	1	8	0
6	1	10	0
6	1	11	0
6	1	13	0
6	1	14	0
6	1	15	0
6	1	16	0
7	0	1	0
7	0	3	0
7	0	4	0
7	0	5	0
7	0	6	0
7	0	7	0
7	0	8	0
7	0	10	0
7	0	11	0
7	0	13	0
7	0	14	0
7	0	15	0
7	0	16	0
7	0	17	0
7	1	1	0
7	1	3	0
7	1	4	0
7	1	5	0
7	1	6	0
7	1	7	0
7	1	8	0
7	1	10	0
7	1	13	0
7	1	14	0
7	1	15	0
7	1	16	0
7	1	17	0
8	0	1	0
8	0	3	0
8	0	4	0
8	0	5	0
8	0	6	0
8	0	7	0
8	0	8	0
8	0	10	0
8	0	11	0
8	0	13	0
8	0	14	0
8	0	15	0
8	0	16	0
8	0	17	0
8	1	1	0
8	1	3	0
8	1	4	0
8	1	5	0
8	1	6	0
8	1	7	0
8	1	8	0
8	1	10	0
8	1	13	0
8	1	14	0
8	1	15	0
8	1	16	0
8	1	17	0
11	0	2	0
11	0	3	0
11	0	4	0
11	0	5	0
11	0	6	0
11	0	8	0
11	0	10	0
11	0	11	0
11	0	15	0
11	1	31	0
11	1	32	0
11	1	33	0
11	1	34	0
11	1	35	0
11	1	36	0
11	1	37	0
11	1	38	0
11	1	39	0
11	1	40	0
12	0	6	0
12	0	23	0
12	0	24	0
12	0	25	0
12	1	31	0
12	1	32	0
12	1	33	0
12	1	35	0
12	1	36	0
12	1	37	0
12	1	38	0
12	1	39	0
13	0	24	0
13	0	26	0
13	0	27	0
13	0	28	0
13	0	29	0
13	0	30	0
13	1	31	0
13	1	32	0
13	1	33	0
13	1	35	0
13	1	36	0
13	1	37	0
13	1	38	0
13	1	39	0
14	0	2	0
14	0	3	0
14	0	4	0
14	0	5	0
14	0	6	0
14	0	8	0
14	0	10	0
14	0	11	0
14	0	15	0
14	1	6	0
14	1	41	0
14	1	42	0
14	1	43	0
14	1	44	0
14	1	45	0
\.


--
-- Name: chrBLEyes chrBLEyes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLEyes"
    ADD CONSTRAINT "chrBLEyes_pkey" PRIMARY KEY ("bloodlineID", gender, "eyesID");


--
-- PostgreSQL database dump complete
--

\unrestrict f1oJkkVCcGcMPkzNs1uVuIgQGjwfrGVpHBjhondzYmUfP67f2CmiYaSjDkB5TLf

