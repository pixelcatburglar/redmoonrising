--
-- PostgreSQL database dump
--

\restrict FIiVDto907YeZNyks2NMhwce1eQF0Un6FvhpyTApZ4zOswuv22PM8JlptBFzku5

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: petitionQueues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."petitionQueues" (
    "queueID" integer NOT NULL,
    "queueName" text NOT NULL
);


--
-- Name: TABLE "petitionQueues"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."petitionQueues" IS 'CONFIG. GM petition queues; one window tab each (petition.py:126-127). Only requested for petitionees (petition.py:284-286), so returning an empty rowset is correct for players.';


--
-- Name: COLUMN "petitionQueues"."queueID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionQueues"."queueID" IS 'PROVEN: petition.py:127 uses each.queueID as the tab key and :259 passes it to GetPetitionQueue.';


--
-- Name: COLUMN "petitionQueues"."queueName"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."petitionQueues"."queueName" IS 'PROVEN: petition.py:127 uses each.queueName as the tab caption.';


--
-- Data for Name: petitionQueues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."petitionQueues" ("queueID", "queueName") FROM stdin;
1	General
2	Senior GMs
\.


--
-- Name: petitionQueues petitionQueues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."petitionQueues"
    ADD CONSTRAINT "petitionQueues_pkey" PRIMARY KEY ("queueID");


--
-- PostgreSQL database dump complete
--

\unrestrict FIiVDto907YeZNyks2NMhwce1eQF0Un6FvhpyTApZ4zOswuv22PM8JlptBFzku5

