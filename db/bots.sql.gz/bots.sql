--
-- PostgreSQL database dump
--

\restrict 0cwXUyq6r3emaGRuWpFxnkThlyceMsB3GcbuBgZeO6RWeCCZjtjWqamVeV6Chll

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bots (
    "characterID" integer NOT NULL,
    role smallint NOT NULL,
    "homeStationID" integer NOT NULL,
    share real NOT NULL,
    turf integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE bots; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.bots IS 'MADE: the characters the bot simulation plays (RMR_BOTS), on the account rmr-bots. Where each one is lives on its character_ row; this holds what it is.';


--
-- Name: COLUMN bots.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bots.role IS 'MADE: 1 miner, 2 hauler, 3 trader, 4 ratter, 5 explorer, 6 pirate (bots::behaviour::Role).';


--
-- Name: COLUMN bots."homeStationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bots."homeStationID" IS 'MADE: the station it goes back to; traders and explorers move home.';


--
-- Name: COLUMN bots.share; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bots.share IS 'MADE: the share of the day it plays, 0 to 1.';


--
-- Name: COLUMN bots.turf; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bots.turf IS 'MADE: the system it mines or rats in, its alliance''s space; 0 for wherever is near.';


--
-- Name: bots bots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bots
    ADD CONSTRAINT bots_pkey PRIMARY KEY ("characterID");


--
-- PostgreSQL database dump complete
--

\unrestrict 0cwXUyq6r3emaGRuWpFxnkThlyceMsB3GcbuBgZeO6RWeCCZjtjWqamVeV6Chll

