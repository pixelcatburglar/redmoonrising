--
-- PostgreSQL database dump
--

\restrict N8xMpNlic3RehckErnOs5HCvkoQsbufR8bOlOoaP4zKGN8q8aaVwTFA6YGJngYu

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBackgrounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBackgrounds" (
    "backgroundID" integer DEFAULT 0 NOT NULL,
    "backgroundName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrBackgrounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBackgrounds" ("backgroundID", "backgroundName") FROM stdin;
1	AthleticFIST
2	Banner
3	Boilerroom
4	Bones
5	Brickwall
6	Caution
7	City
8	Cloudy halo
9	Concord
10	Darkmetal
11	Dirty iron
12	Graffiti
13	Hallway
14	Hangardoor
15	Interbus
16	Pirate
17	Rabbitskull
18	Refraction
19	Rocky halo
20	Rustball
21	Ruststripe
22	RustyMech
23	Statues
24	Tribal
25	Tribaltech
26	Whirlpool
27	Zoom
28	aliens
29	amarrchapel
30	amarrdoors
31	amarrmec
32	boilerroombackdrop
33	breasts
34	cell-298
35	crazyface
36	dirt
37	door
38	doorbackrop
39	doorish
40	doorstraight
41	doublefist
42	factory
43	fistpower
44	garagedoor
45	garbagedoor
46	gigerbackdrop
47	hangar
48	jovemech
49	lights
50	lightsnowindow
51	mec
52	mechyhall
53	metalplate
54	neon01
55	neon02
56	neon3
57	neon4
58	neon5
59	rusty_metalheads
60	sheetmetal_blue
61	sheetmetal_green
62	ship
63	skins_n_metal
64	sphinx
65	sphinx_deco
66	sphinxsofthe6threich
67	steel
68	tech_tribal
69	tiles_green
70	tiles_yellow
71	tunnel
72	window
73	wood
74	Asian Metal Ornament
75	Asian Pattern Plate
76	Asian Royal Glass
77	Asian Space Window
78	Asian Tiger Painting
79	Asian Wood Ornament
80	Asian wood ornaments
81	AsianDragons
\.


--
-- Name: chrBackgrounds chrBackgrounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBackgrounds"
    ADD CONSTRAINT "chrBackgrounds_pkey" PRIMARY KEY ("backgroundID");


--
-- PostgreSQL database dump complete
--

\unrestrict N8xMpNlic3RehckErnOs5HCvkoQsbufR8bOlOoaP4zKGN8q8aaVwTFA6YGJngYu

