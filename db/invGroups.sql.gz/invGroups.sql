--
-- PostgreSQL database dump
--

\restrict xYW2GyerCgwi8lOFesdbsGdXRheXHOl5fGAyUEDsvwJeRzWiytnw5OxGiip4jLj

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invGroups" (
    "groupID" integer NOT NULL,
    "categoryID" integer,
    "groupName" text,
    description text,
    "graphicID" integer,
    "useBasePrice" integer,
    "allowManufacture" integer,
    "allowRecycler" integer,
    anchored integer,
    anchorable integer,
    "fittableNonSingleton" integer
);


--
-- Data for Name: invGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invGroups" ("groupID", "categoryID", "groupName", description, "graphicID", "useBasePrice", "allowManufacture", "allowRecycler", anchored, anchorable, "fittableNonSingleton") FROM stdin;
0	0	#System		\N	0	1	1	0	0	0
1	1	Character		1	0	1	1	0	0	0
2	1	Corporation		2	0	1	1	0	0	0
3	2	Region		4	0	1	1	0	0	0
4	2	Constellation		5	0	1	1	0	0	0
5	2	Solar System		6	0	1	1	0	0	0
6	2	Sun		8	0	1	1	0	0	0
7	2	Planet		9	0	1	1	0	0	0
8	2	Moon		10	0	1	1	0	0	0
9	2	Asteroid Belt		11	0	1	1	0	0	0
10	2	Stargate		12	0	1	1	0	0	0
11	2	Asteroid OLD		15	0	1	1	1	0	0
12	2	Cargo Container		16	0	1	1	0	0	0
13	2	Ring		0	0	1	1	0	0	0
14	2	Biomass	Corpse of human. Can be sold for clone production.	0	0	1	1	0	0	0
15	3	Station		17	0	1	1	1	0	0
16	3	Station Services		18	0	1	1	0	0	0
17	4	Money		21	0	1	1	0	0	0
18	4	Mineral		399	1	1	1	0	0	0
19	1	Faction		\N	0	1	1	0	0	0
20	4	Drug	Drug	32	0	1	1	0	0	0
23	5	Clone		34	0	1	1	0	0	0
24	5	Voucher		37	0	1	1	0	0	0
25	6	Frigate		38	0	1	1	0	0	0
26	6	Cruiser		41	0	1	1	0	0	0
27	6	Battleship		43	0	1	1	0	0	0
28	6	Industrial		51	0	1	1	0	0	0
29	6	Capsule		73	0	1	1	0	0	0
30	6	Titan	The collective name for these behemoths is Titans, the largest spacefaring vessels ever constructed. The sheer cost in resources, manpower and time, as well as the necessary technological knowledge, makes construction of a Titan-class vessel a venture only empires can usually fathom. Some of these mammoth vessels have taken decades to assemble. Many are over a century old themselves, and the three mammoth Jovian motherships, the first Titans, have origins pre-dating modern space travel. They are	64	0	1	1	0	0	0
31	6	Shuttle		0	0	1	1	0	0	0
32	1	Alliance		2	0	1	1	0	0	0
38	7	Shield Extender		82	0	1	1	0	0	0
39	7	Shield Recharger		83	0	1	1	0	0	0
40	7	Shield Booster		84	0	1	1	0	0	0
41	7	Shield Transporter		86	0	1	1	0	0	0
43	7	Capacitor Recharger		90	0	1	1	0	0	0
46	7	Afterburner		96	0	1	1	0	0	0
47	7	Cargo Scanner		106	0	1	1	0	0	0
48	7	Ship Scanner		107	0	1	1	0	0	0
49	7	Survey Scanner		108	0	1	1	0	0	0
52	7	Jump Scrambler		111	0	1	1	0	0	0
53	7	Energy Weapon		113	0	1	1	0	0	0
54	7	Mining Laser	Mining Laser	138	0	1	1	0	0	0
55	7	Projectile Weapon		156	0	1	1	0	0	0
56	7	Missile Launcher		168	0	1	1	0	0	0
57	7	Power Manager	These module usually act on the power and/or capacitor requirements of modules.	0	0	1	1	0	0	0
59	7	Gyrostabilizer	Uses gyroscopes and inertial dampeners to reduce recoil and stabilize the weapon while firing	0	0	1	1	0	0	0
60	7	Damage Control	Reinforcement are modules that increase the "armorHP" of some module group or specific module type. It typically only defines a passive effect.	0	0	1	1	0	0	0
61	7	Capacitor Battery	Supplement the ships builtin power battery.	0	0	1	1	0	0	0
62	7	Armor Repair Unit		0	0	1	1	0	0	0
63	7	Hull Repair Unit		0	0	1	1	0	0	0
65	7	Stasis Web	Reduces max speed of a target ship.	0	0	1	1	0	0	0
67	7	Energy Transfer Array	Transfers some of our energy to the target ships.	0	0	1	1	0	0	0
68	7	Energy Vampire		0	0	1	1	0	0	0
71	7	Energy Destabilizer	Target ship loses power.	0	0	1	1	0	0	0
72	7	Smart Bomb	Smart Bomb	0	0	1	1	0	0	0
74	7	Hybrid Weapon	Hybrid	0	0	1	1	0	0	0
76	7	Capacitor Booster	In times of danger and need, being able to boost your power supply can save your skin.  Don't leave home without one of these.  And don't forget to feed it.	0	0	1	1	0	0	0
77	7	Shield Hardener	Increases the resistance of the shield to damages of specified types.	0	0	1	1	0	0	0
78	7	Hull Mods		0	0	1	1	0	0	0
80	7	ECM Burst	Clears all targets on all ships(excluding self) wihin range.	0	0	1	1	0	0	0
82	7	Passive Targeting System	Targets ship quietly (as in does not alert other ship to the fact rhat its been targeted).	0	0	1	1	0	0	0
83	8	Ammo	Ammo	171	0	1	1	0	0	1
84	8	Missile		182	0	1	1	0	0	1
85	8	Hybrid Ammo	Raw minerals	1325	0	1	1	0	0	1
86	8	Frequency Crystal	the frequency of Laser weapon	0	0	1	1	0	0	1
87	8	Capacitor Booster Charge	Capacitor Booster Charge	0	0	1	1	0	0	1
88	8	Defender Missile		0	0	1	1	0	0	1
89	8	Torpedo	Torrpedo	0	0	1	1	0	0	1
90	8	Bomb	Remote triggered. Have no internal Thrust or Guidance. Are dropped at 80% of ship current speed	0	0	1	1	0	0	1
92	8	Mine		0	0	1	1	0	0	0
94	10	Trading		195	0	1	1	0	0	0
95	10	Trade Session		196	0	1	1	0	0	0
96	7	Automated Targeting System	Targets all hostile ships within range.	0	0	1	1	0	0	0
97	18	Proximity Drone	ProximityDrone	0	0	1	1	0	0	0
98	7	Armor Coating		0	0	1	1	0	0	0
99	11	Sentry Gun	Protecting the weak and upholding the law, these shining examples of fabrication maintain the peace.	0	0	1	1	1	0	0
100	18	Combat Drone		0	0	1	1	0	0	0
101	18	Mining Drone	Mines.	0	0	1	1	0	0	0
104	9	Clone Blueprint		34	1	1	1	0	0	0
105	9	Frigate Blueprint		38	1	1	1	0	0	0
106	9	Cruiser Blueprint		41	1	1	1	0	0	0
107	9	Battleship Blueprint		43	1	1	1	0	0	0
108	9	Industrial Blueprint		51	1	1	1	0	0	0
109	9	Capsule Blueprint		73	1	1	1	0	0	0
110	9	Titan Blueprint		64	1	1	1	0	0	0
111	9	Shuttle Blueprint		0	1	1	1	0	0	0
118	9	Shield Extender Blueprint		82	1	1	1	0	0	0
119	9	Shield Recharger Blueprint		83	1	1	1	0	0	0
120	9	Shield Booster Blueprint		84	1	1	1	0	0	0
121	9	Shield Transporter Blueprint		86	1	1	1	0	0	0
123	9	Capacitor Recharger Blueprint		90	1	1	1	0	0	0
126	9	Afterburner Blueprint		96	1	1	1	0	0	0
127	9	Cargo Scanner Blueprint		106	1	1	1	0	0	0
128	9	Ship Scanner Blueprint		107	1	1	1	0	0	0
129	9	Survey Scanner Blueprint		108	1	1	1	0	0	0
130	9	ECM Blueprint		109	1	1	1	0	0	0
131	9	ECCM Blueprint		110	1	1	1	0	0	0
132	9	Jump Scrambler Blueprint		111	1	1	1	0	0	0
133	9	Energy Weapon Blueprint		113	1	1	1	0	0	0
134	9	Mining Laser Blueprint		138	1	1	1	0	0	0
135	9	Projectile Weapon Blueprint		156	1	1	1	0	0	0
136	9	Missile Launcher Blueprint		168	1	1	1	0	0	0
137	9	Power Manager Blueprint		0	1	1	1	0	0	0
139	9	Fast Loader Blueprint		0	1	1	1	0	0	0
140	9	Damage Control Blueprint		0	1	1	1	0	0	0
141	9	Capacitor Battery Blueprint		0	1	1	1	0	0	0
142	9	Armor Repair Unit Blueprint		0	1	1	1	0	0	0
143	9	Hull Repair Unit Blueprint		0	1	1	1	0	0	0
145	9	Stasis Web Blueprint		0	1	1	1	0	0	0
147	9	Energy Transfer Array Blueprint		0	1	1	1	0	0	0
148	9	Energy Vampire Blueprint		0	1	1	1	0	0	0
151	9	Energy Destabilizer Blueprint		0	1	1	1	0	0	0
152	9	Smart Bomb Blueprint		0	1	1	1	0	0	0
154	9	Hybrid Weapon Blueprint		0	1	1	1	0	0	0
156	9	Capacitor Booster Blueprint		0	1	1	1	0	0	0
157	9	Shield Hardener Blueprint		0	1	1	1	0	0	0
158	9	Hull Mods Blueprint		0	1	1	1	0	0	0
160	9	ECM Burst Blueprint		0	1	1	1	0	0	0
161	9	Passive Targeting System Blueprint		0	1	1	1	0	0	0
162	9	Automated Targeting System Blueprint		0	1	1	1	0	0	0
163	9	Armor Coating Blueprint		0	1	1	1	0	0	0
165	9	Ammo Blueprint		171	1	1	1	0	0	0
166	9	Missile Blueprint		182	1	1	1	0	0	0
167	9	Hybrid Ammo Blueprint		179	1	1	1	0	0	0
168	9	Frequency Crystal Blueprint		0	1	1	1	0	0	0
169	9	Capacitor Booster Charge Blueprint		0	1	1	1	0	0	0
170	9	Defender Missile Blueprint		0	1	1	1	0	0	0
172	9	Bomb Blueprint		0	1	1	1	0	0	0
174	9	Mine Blueprint		0	1	1	1	0	0	0
175	9	Proximity Drone Blueprint		0	1	1	1	0	0	0
176	9	Combat Drone Blueprint		0	1	1	1	0	0	0
177	9	Mining Drone Blueprint		0	1	1	1	0	0	0
178	9	Drug Blueprint		194	1	1	1	0	0	0
180	11	Protective Sentry Gun	Defends all within its observation range who get attacked.	\N	0	1	1	0	0	0
182	11	Police Drone	Ho hum.	\N	0	1	1	0	0	0
185	11	Pirate Drone		0	0	1	1	0	0	0
186	11	Wreck	Shipwrecks and stuff like that	0	0	1	1	0	0	0
190	14	Bloodline Bonus	Bonuses for the given bloodlines.	0	0	1	1	0	0	0
191	14	Physical Benefit	Physical Benefit	0	0	1	1	0	0	0
192	14	Physical Handicap	Physical Handicap.	0	0	1	1	0	0	0
193	14	Phobia Handicap	Phobia handicap	0	0	1	1	0	0	0
194	14	Social Handicap	Social handicap.	0	0	1	1	0	0	0
195	14	Amarr Education	Bonuses for having various Amarr educations.	0	0	1	1	0	0	0
196	14	Caldari Education	Bonuses for having various Caldari educations.	0	0	1	1	0	0	0
197	14	Gallente Education	Bonuses for having a variety of Gallente educations.	0	0	1	1	0	0	0
198	14	Minmatar Education	A variety of bonuses for having a Minmatar education.	0	0	1	1	0	0	0
199	14	Career Bonus	Bonus for taking a career or some sh1t.	0	0	1	1	0	0	0
201	7	ECM	Electronic Countermeasure	0	0	1	1	0	0	0
202	7	ECCM		0	0	1	1	0	0	0
203	7	Sensor Backup Array	An upgrade to the electronics capacilities of the ship 1.	0	0	1	1	0	0	0
205	7	Heat Sink		0	0	1	1	0	0	0
208	7	Remote Sensor Damper	Electronic Warfare System 2	0	0	1	1	0	0	0
209	7	Tracking Link	Tracking Link	0	0	1	1	0	0	0
210	7	Signal Amplifier		0	0	1	1	0	0	0
211	7	Tracking Enhancer		0	0	1	1	0	0	0
212	7	EB2 - Sensor Booster	Boosts the Range, Speed and Max targets of electronics module	0	0	1	1	0	0	0
213	7	EB3 - Tracking Computer	On command adjust the effectiveness of the sensor functions of the electronics of the users ship.	0	0	1	1	0	0	0
218	9	Heat Sink Blueprint		0	1	1	1	0	0	0
223	9	EB2 - Sensor Booster Blueprint		0	1	1	1	0	0	0
224	9	EB3 - Tracking Computer Blueprint		0	1	1	1	0	0	0
225	7	Cheat Module Group	For limited distribution.  Speed up testing.	0	0	1	1	0	0	0
226	2	Large Collidable Object		\N	0	1	1	1	0	0
227	2	Cloud		0	0	1	1	0	0	0
237	6	Rookie ship	These are the rookie frigates, read: n00be ships yo!	0	0	1	1	0	0	0
255	16	Gunnery		\N	1	1	1	0	0	0
256	16	Missile Launcher Operation		\N	1	1	1	0	0	0
257	16	Spaceship Command		\N	1	1	1	0	0	0
258	16	Leadership		\N	1	1	1	0	0	0
266	16	Corporation Management		\N	1	1	1	0	0	0
267	16	Learning		\N	1	1	1	0	0	0
268	16	Industry		\N	1	1	1	0	0	0
269	16	Mechanic		\N	1	1	1	0	0	0
270	16	Science		\N	1	1	1	0	0	0
271	16	Engineering		\N	1	1	1	0	0	0
272	16	Electronics		\N	1	1	1	0	0	0
273	16	Drones		\N	1	1	1	0	0	0
274	16	Trade		\N	1	1	1	0	0	0
275	16	Navigation		\N	1	1	1	0	0	0
278	16	Social		\N	1	1	1	0	0	0
279	11	LCO Drone		0	0	1	1	0	0	0
280	17	General		0	1	1	1	0	0	0
281	17	Frozen		0	1	1	1	0	0	0
282	17	Radioactive		0	1	1	1	0	0	0
283	17	Livestock		0	1	1	1	0	0	0
284	17	Biohazard		0	1	1	1	0	0	0
285	7	CPU Enhancer		0	0	1	1	0	0	0
286	11	Tutorial Drone		0	0	1	1	0	0	0
287	11	Rogue Drone	These drones can be found by wrecks, mineral deposits and various other hang-outs for junk metal gone bad.	\N	0	1	1	0	0	0
288	11	Faction Drone		0	0	0	1	0	0	0
289	7	Projected ECCM	ECCM Projector	\N	0	1	1	0	0	0
290	7	Remote Sensor Booster	Electronic Warfare System 2	104	0	1	1	0	0	0
291	7	Tracking Disrupter		1639	0	1	1	0	0	0
295	7	Shield Amplifier		82	0	1	1	0	0	0
296	9	Shield Amplifier Blueprint		82	1	1	1	0	0	0
297	11	Convoy		0	0	1	1	0	0	0
298	11	Convoy Drone		0	0	1	1	0	0	0
299	18	Repair Drone	Repair drones reapair the structure and armor of ships	0	0	1	1	0	0	0
300	20	Cyberimplant		0	1	0	1	0	0	0
301	11	Concord Drone		0	0	0	1	0	0	0
302	7	Magnetic Field Stabilizer		0	0	1	1	0	0	0
303	20	Booster		0	0	0	1	0	0	0
304	20	DNA Mutator		0	0	1	1	0	0	0
305	2	Comet		0	0	1	1	0	0	0
306	11	Spawn Container		0	0	0	1	1	0	0
307	2	Construction Platform		0	0	1	1	0	1	0
308	7	Countermeasure Launcher		0	0	1	1	0	0	0
309	7	Autopilot		0	0	1	1	0	0	0
310	2	Beacon	This is a group for Beacons. Beacons are fixed global objects with no functionality	0	0	1	1	1	0	0
311	23	Refining Array		0	1	1	1	0	1	0
312	2	Planetary Cloud		0	0	1	1	0	0	0
313	17	Drugs	This group contains commodities that are drugs or 'boosters'.	0	1	1	1	0	0	0
314	17	Miscellaneous	Miscellaneos special mission items that should not be on the market and not available from random missions.	0	1	1	1	0	0	0
315	7	Anti Warp Scrambler		0	0	1	1	0	0	0
316	7	Gang Coordinator		0	0	1	1	0	0	0
317	7	Computer Interface Node		0	0	1	1	0	0	0
318	2	Landmark	Landmarks are used on the map for locations that are not physical objects neccesarily, such as important areas and regions, political borders and so on.	0	0	1	1	0	0	0
319	11	Large Collidable Structure		0	0	0	1	1	0	0
321	7	Shield Disruptor		0	0	1	1	0	0	0
323	11	Billboard		0	0	0	1	1	0	0
324	6	Elite Frigate	Da Leet Frigates	0	0	1	1	0	0	0
325	7	Armor Repair Projector		0	0	1	1	0	0	0
326	7	Armor Plating Energized		0	0	1	1	0	0	0
328	7	Armor Hardener		0	0	1	1	0	0	0
329	7	Armor Reinforcer		0	0	1	1	0	0	0
330	7	Cloaking Device		0	0	0	1	0	0	0
332	17	Tool	Tools used in manufacturing and Research	0	0	1	1	0	0	0
333	17	Datacores		0	0	1	1	0	0	0
334	17	Construction Components	components for use i item construction	0	0	1	1	0	0	0
335	11	Temporary Cloud		0	0	0	1	1	0	0
336	2	Mobile Sentry Gun		0	0	1	1	0	1	0
337	11	Mission Drone		0	0	0	1	0	0	0
338	7	Shield Boost Amplifier		0	0	1	1	0	0	0
339	7	Auxiliary Power Core		0	0	1	1	0	0	0
340	2	Secure Cargo Container		0	0	1	1	0	1	0
341	7	Signature Scrambling		0	0	1	1	0	0	0
342	9	Anti Warp Scrambler Blueprint		0	1	0	1	0	0	0
343	9	Tracking Disruptor Blueprint		0	1	0	1	0	0	0
344	9	Tracking Enhancer Blueprint		0	1	0	1	0	0	0
345	9	Tracking Link Blueprint		0	1	0	1	0	0	0
346	9	Co-Processor Blueprint		0	1	0	1	0	0	0
347	9	Signal Amplifier Blueprint		0	1	0	1	0	0	0
348	9	Armor Hardener Blueprint		0	1	0	1	0	0	0
349	9	Armor Reinforcer Blueprint		0	1	0	1	0	0	0
350	9	Armor Repair Projector Blueprint		0	1	0	1	0	0	0
352	9	Auxiliary Power Core Blueprint		0	1	0	1	0	0	0
353	7	GM Modules		0	0	0	1	0	0	0
355	17	Refinables	Group for mineral compounds and alloys that can be refined into valuable minerals.	0	0	1	1	0	0	0
356	9	Tool Blueprint		0	1	1	1	0	0	0
357	7	DroneBayExpander		0	0	1	1	0	0	0
358	6	Elite Cruiser		0	0	1	1	0	0	0
360	9	Shield Boost Amplifier Blueprint		0	1	1	1	0	0	0
361	22	Mobile Warp Disruptor	Self powered warp disruptors.  Do not require a control tower.	0	0	1	1	0	1	0
363	23	Ship Maintenance Array		0	1	1	1	0	1	0
364	23	Mobile Storage		0	0	1	1	0	1	0
365	23	Control Tower		0	1	1	1	0	1	0
366	2	Warp Gate		0	0	1	1	1	0	0
367	7	Ballistic Control system		0	0	1	1	0	0	0
368	2	Global Warp Disruptor	Prevents warping into the radius it covers.	0	0	1	1	1	0	0
369	17	Ship Logs		0	1	1	1	0	0	0
370	17	Criminal Tags	Items such as Dog Tags that NPC pirates drop.	0	1	1	1	0	0	0
371	9	Mobile Warp Disruptor Blueprint		0	1	1	1	0	0	0
372	8	Advanced Autocannon Ammo		0	0	1	1	0	0	1
373	8	Advanced Railgun Ammo		1326	0	1	1	0	0	1
374	8	Advanced Beam Laser Crystal		0	0	1	1	0	0	1
375	8	Advanced Pulse Laser Crystal		0	0	1	1	0	0	1
376	8	Advanced Artillery Ammo		0	0	1	1	0	0	1
377	8	Advanced Blaster Ammo		0	0	1	1	0	0	1
378	7	Cruise Control		0	0	1	1	0	0	0
379	7	Target Painter		0	0	1	1	0	0	0
380	6	Elite Industrial		0	0	1	1	0	0	0
381	6	Elite Battleship		0	1	1	1	0	0	0
382	2	Shipping Crates	Shipping Crate	0	0	1	1	0	0	0
383	11	Destructible Sentry Gun	Sentry guns inside scenarios, usually owned by pirate factions, that can be destroyed by players.	0	0	1	1	1	0	0
384	8	Light Missile	Light Missile Charges	182	0	1	1	0	0	1
385	8	Heavy Missile	Heavy Missile Charges	182	0	1	1	0	0	1
386	8	Cruise Missile		182	0	1	1	0	0	1
387	8	Rocket		182	0	1	1	0	0	1
394	8	FoF Light Missile		0	0	1	1	0	0	1
395	8	FoF Heavy Missile		0	0	1	1	0	0	1
396	8	FoF Cruise Missile		0	0	1	1	0	0	1
397	23	Assembly Array	Deployable Assembly Array	0	1	1	1	0	1	0
400	9	Ballistic Control System Blueprint		0	1	1	1	0	0	0
401	9	Cloaking Device Blueprint		0	1	1	1	0	0	0
404	23	Silo	Used to store or provide resources of a specific type.	0	1	1	1	0	1	0
405	7	Anti Cloaking Pulse	Broadcast a signal in all directions within a limited range that cause all the cloaked objects within it to decloak.	0	0	1	1	0	0	0
406	7	Smartbomb Supercharger	Modules that boost the Damage of Smartbombs	0	0	1	1	0	0	0
407	7	Drone Control Unit		0	0	1	1	0	0	0
408	9	Drone Control Unit Blueprint		0	1	1	1	0	0	0
409	17	Empire Insignia Drops	The insignia drops are implemented to replace the "bounty" feature for Empire mission drones, such as Navy ships.  Insignias are traded in to agents for money (will be implemented in Shiva).	0	1	1	1	0	0	0
410	9	Anti Cloaking Pulse Blueprint		0	1	1	1	0	0	0
411	2	Force Field	A spherical barrier, maybe placed around something.	0	0	1	1	1	0	0
413	23	Mobile Laboratory		0	1	1	1	0	1	0
414	23	Mobile Power Core		0	0	1	1	0	1	0
416	23	Moon Mining		0	1	1	1	0	1	0
417	23	Mobile Missile Sentry		0	1	1	1	0	1	0
418	23	Mobile Shield Generator		0	0	1	1	0	1	0
419	6	Battlecruiser		0	0	1	1	0	0	0
420	6	Destroyer		0	0	1	1	0	0	0
422	4	Gas Isotopes	Gas Isotopes harvested from gas clouds.	0	0	1	1	0	0	0
423	4	Ice Product		0	1	1	1	0	0	0
425	8	Orbital Assault Unit		0	0	1	1	0	0	1
426	23	Mobile Projectile Sentry		0	1	1	1	0	1	0
427	4	Moon Materials	Stuff Harvested directly from Moons	0	1	1	1	0	0	0
428	4	Intermediate Materials	Stuff made from moon materials in a reactor	0	1	1	1	0	0	0
429	4	Composite		0	1	1	1	0	0	0
430	23	Mobile Laser Sentry		0	1	1	1	0	1	0
435	11	Deadspace Overseer		0	0	1	1	0	0	0
436	24	Simple Reaction		0	1	1	1	0	0	0
438	23	Mobile Reactor		0	1	1	1	0	1	0
439	23	Electronic Warfare Battery	Group for mobile racial ECM.	0	1	1	1	0	1	0
440	23	Sensor Dampening Battery	Deployable Sensor Dampener	0	1	1	1	0	1	0
441	23	Stasis Webification Battery	Deployable Stasis Webber	0	1	1	1	0	1	0
443	23	Warp Scrambling Battery	Deployable warp jammers.	0	1	1	1	0	1	0
444	23	Shield Hardening Array	Increases control tower shield resistances	0	1	1	1	0	1	0
445	23	Force Field Array	Projects a shield around structures outside the range of a control tower.	0	1	1	1	0	1	0
446	11	Customs Official		0	0	1	1	0	0	0
447	9	Construction Component Blueprints		\N	1	1	1	0	0	0
448	2	Audit Log Secure Container		\N	1	1	1	0	1	0
449	23	Mobile Hybrid Sentry		0	1	1	1	0	1	0
450	25	Arkonor		15	0	1	1	1	0	0
451	25	Bistot		15	0	1	1	1	0	0
452	25	Crokite		15	0	1	1	1	0	0
453	25	Dark Ochre		15	0	1	1	1	0	0
454	25	Hedbergite		15	0	1	1	1	0	0
455	25	Hemorphite		15	0	1	1	1	0	0
456	25	Jaspet		15	0	1	1	1	0	0
457	25	Kernite		15	0	1	1	1	0	0
458	25	Plagioclase		15	0	1	1	1	0	0
459	25	Pyroxeres		15	0	1	1	1	0	0
460	25	Scordite		15	0	1	1	1	0	0
461	25	Spodumain		15	0	1	1	1	0	0
462	25	Veldspar		15	0	1	1	1	0	0
463	6	Mining Barge	Mining Barges	0	0	1	1	0	0	0
464	7	Strip Miner		0	0	1	1	0	0	0
465	25	Ice		15	0	1	1	1	0	0
467	25	Gneiss		15	0	1	1	1	0	0
468	25	Mercoxit		15	0	1	1	1	0	0
469	25	Omber		15	0	1	1	1	0	0
470	18	Unanchoring Drone		0	0	1	1	0	0	0
471	23	Corporate Hangar Array	A Corp Hangar in space.	0	1	1	1	0	1	0
472	7	System Scanner		0	0	1	1	0	0	0
473	23	Tracking Array	Increases Optimal Range and Tracking Speed of all Turret Sentries	0	1	1	1	0	1	0
474	17	Acceleration Gate Keys	Contains keys, passcards, cyphers and other objects required to open locked acceleration gates in deadspace complexes.	0	0	1	1	0	0	0
475	7	Microwarpdrive		96	0	1	1	0	0	0
476	8	Citadel Torpedo		0	0	1	1	0	0	1
477	9	Mining Barge Blueprint		0	1	1	1	0	0	0
478	9	System Scanner Blueprint		0	0	1	1	0	0	0
479	8	Scanner Probe		0	0	1	1	0	0	1
480	23	Stealth Emitter Array		0	0	1	1	0	1	0
481	7	Scan Probe Launcher		0	0	1	1	0	0	0
482	8	Mining Crystal		0	0	1	1	0	0	1
483	7	Frequency Mining Laser		138	0	1	1	0	0	0
484	24	Complex Reactions		0	1	1	1	0	0	0
485	6	Dreadnought		0	0	1	1	0	0	0
486	9	Scan Probe Blueprint		0	1	1	1	0	0	0
487	9	Destroyer Blueprint		0	1	1	1	0	0	0
489	9	Battlecruiser Blueprint		0	1	1	1	0	0	0
490	9	Strip Miner Blueprint		0	1	1	1	0	0	0
492	8	Survey Probe		0	0	1	1	0	0	1
493	17	Overseer Personal Effects		0	1	1	1	0	0	0
494	11	Deadspace Overseer's Structure	This structure belongs to the overseer of this deadspace pocket.	0	0	1	1	1	0	0
495	11	Deadspace Overseer's Sentry	This sentry is controlled by the overseer of this deadspace pocket.	0	0	1	1	1	0	0
496	11	Deadspace Overseer's Belongings	This container is tagged as the property of this deadspace pocket's overseer.	0	0	1	1	1	0	0
497	8	Fuel		0	0	1	1	0	0	1
498	8	Modifications		0	0	1	1	0	0	1
499	7	New EW Testing		0	0	1	1	0	0	0
500	8	Snowballs		0	0	1	1	0	0	1
501	7	Missile Launcher Snowball		0	0	1	1	0	0	0
502	2	Cosmic Signature	Disturbances and other anomalies in the electromagnetic or gravity field	0	0	1	1	1	0	0
503	9	Elite Industrial Blueprint		0	0	1	1	0	0	0
504	9	Target Painter Blueprint		0	1	1	1	0	0	0
505	16	Fake Skills	This group is for fake skills used for bonuses.	0	0	1	1	0	0	0
506	7	Missile Launcher Cruise		0	0	1	1	0	0	0
507	7	Missile Launcher Rocket		0	0	1	1	0	0	0
508	7	Missile Launcher Siege		0	0	1	1	0	0	0
509	7	Missile Launcher Standard		0	0	1	1	0	0	0
510	7	Missile Launcher Heavy		0	0	1	1	0	0	0
511	7	Missile Launcher Assault		0	0	1	1	0	0	0
512	7	Missile Launcher Defender		0	0	1	1	0	0	0
513	6	Freighter		0	0	1	1	0	0	0
514	7	ECM Stabilizer		0	0	1	1	0	0	0
515	7	Siege Module		0	0	1	1	0	0	0
516	9	Siege Module Blueprint		0	1	1	1	0	0	0
517	2	Agents in Space	Piiiiiigs iiiiiin Spaaaaaaaace.....	0	0	1	1	0	0	0
518	7	Anti Ballistic Defense System		0	0	1	1	0	0	0
519	25	Terran Artifacts		0	1	1	1	0	0	0
520	11	Storyline Frigate		0	0	1	1	0	0	0
521	17	Identification		0	0	1	1	0	0	0
522	11	Storyline Cruiser		0	0	1	1	0	0	0
523	11	Storyline Battleship		0	0	1	1	0	0	0
524	7	Missile Launcher Citadel		0	0	1	1	0	0	0
525	9	Freighter Blueprint		0	1	1	1	0	0	0
526	17	Commodities		0	0	1	1	0	0	0
527	11	Storyline Mission Frigate		0	0	1	1	0	0	0
528	17	Artifacts and Prototypes	Artifacts of ancient cultures in the world of eve.	0	0	1	1	0	0	0
529	17	Information and Lore	Various information and texts used in manufacture and research of Ancient technology	0	0	1	1	0	0	0
530	17	Materials and Compounds	Alloys and Special materials used in manufacture of Ancient technology	0	0	1	1	0	0	0
532	9	Gang Coordinator Blueprint		0	1	1	1	0	0	0
533	11	Storyline Mission Cruiser		0	0	1	1	0	0	0
534	11	Storyline Mission Battleship		0	0	1	1	0	0	0
535	9	Construction Platform Blueprint		0	1	1	1	0	0	0
536	17	Station Components		0	1	1	1	0	0	0
537	9	Dreadnought Blueprint		0	1	1	1	0	0	0
538	7	Data Miners		0	0	1	1	0	0	0
540	6	Elite Battlecruiser		0	0	1	1	0	0	0
541	6	Elite Destroyer		0	0	1	1	0	0	0
543	6	Elite Mining Barge		0	0	1	1	0	0	0
544	18	Cap Drain Drone		0	0	1	1	0	0	0
545	18	Warp Scrambling Drone		0	0	1	1	0	0	0
546	7	Mining Upgrade		0	0	1	1	0	0	0
547	6	Carrier		0	0	1	1	0	0	0
548	8	Warp Disruption Probe		0	0	1	1	0	0	1
549	18	Fighter Drone		0	0	1	1	0	0	0
550	11	Asteroid Angel Cartel Frigate		0	0	1	1	0	0	0
551	11	Asteroid Angel Cartel Cruiser		0	0	1	1	0	0	0
552	11	Asteroid Angel Cartel Battleship		0	0	1	1	0	0	0
553	11	Asteroid Angel Cartel Officer		0	0	1	1	0	0	0
554	11	Asteroid Angel Cartel Hauler		0	0	1	1	0	0	0
555	11	Asteroid Blood Raiders Cruiser		0	0	1	1	0	0	0
556	11	Asteroid Blood Raiders Battleship		0	0	1	1	0	0	0
557	11	Asteroid Blood Raiders Frigate		0	0	1	1	0	0	0
558	11	Asteroid Blood Raiders Hauler		0	0	1	1	0	0	0
559	11	Asteroid Blood Raiders Officer		0	0	1	1	0	0	0
560	11	Asteroid Guristas Battleship		0	0	1	1	0	0	0
561	11	Asteroid Guristas Cruiser		0	0	1	1	0	0	0
562	11	Asteroid Guristas Frigate		0	0	1	1	0	0	0
563	11	Asteroid Guristas Hauler		0	0	1	1	0	0	0
564	11	Asteroid Guristas Officer		0	0	1	1	0	0	0
565	11	Asteroid Sansha's Nation Battleship		0	0	1	1	0	0	0
566	11	Asteroid Sansha's Nation Cruiser		0	0	1	1	0	0	0
567	11	Asteroid Sansha's Nation Frigate		0	0	1	1	0	0	0
568	11	Asteroid Sansha's Nation Hauler		0	0	1	1	0	0	0
569	11	Asteroid Sansha's Nation Officer		0	0	1	1	0	0	0
570	11	Asteroid Serpentis Battleship		0	0	1	1	0	0	0
571	11	Asteroid Serpentis Cruiser		0	0	1	1	0	0	0
572	11	Asteroid Serpentis Frigate		0	0	1	1	0	0	0
573	11	Asteroid Serpentis Hauler		0	0	1	1	0	0	0
574	11	Asteroid Serpentis Officer		0	0	1	1	0	0	0
575	11	Asteroid Angel Cartel Destroyer		0	0	1	1	0	0	0
576	11	Asteroid Angel Cartel BattleCruiser		0	0	1	1	0	0	0
577	11	Asteroid Blood Raiders Destroyer		0	0	1	1	0	0	0
578	11	Asteroid Blood Raiders BattleCruiser		0	0	1	1	0	0	0
579	11	Asteroid Guristas Destroyer		0	0	1	1	0	0	0
580	11	Asteroid Guristas BattleCruiser		0	0	1	1	0	0	0
581	11	Asteroid Sansha's Nation Destroyer		0	0	1	1	0	0	0
582	11	Asteroid Sansha's Nation BattleCruiser		0	0	1	1	0	0	0
583	11	Asteroid Serpentis Destroyer		0	0	1	1	0	0	0
584	11	Asteroid Serpentis BattleCruiser		0	0	1	1	0	0	0
585	7	Remote Hull Repairer	Modules used to repair damaged hull of friendly vessels	0	0	1	1	0	0	0
586	7	Drone Modules		0	0	1	1	0	0	0
588	7	Super Weapon		0	0	1	1	0	0	0
589	7	Bubble Probe Launcher		0	0	1	1	0	0	0
590	7	Jump Portal Generator		0	0	1	1	0	0	0
593	11	Deadspace Angel Cartel BattleCruiser		0	0	1	1	0	0	0
594	11	Deadspace Angel Cartel Battleship		0	0	1	1	0	0	0
595	11	Deadspace Angel Cartel Cruiser		0	0	1	1	0	0	0
596	11	Deadspace Angel Cartel Destroyer		0	0	1	1	0	0	0
597	11	Deadspace Angel Cartel Frigate		0	0	1	1	0	0	0
602	11	Deadspace Blood Raiders BattleCruiser		0	0	1	1	0	0	0
603	11	Deadspace Blood Raiders Battleship		0	0	1	1	0	0	0
604	11	Deadspace Blood Raiders Cruiser		0	0	1	1	0	0	0
605	11	Deadspace Blood Raiders Destroyer		0	0	1	1	0	0	0
606	11	Deadspace Blood Raiders Frigate		0	0	1	1	0	0	0
611	11	Deadspace Guristas BattleCruiser		0	0	1	1	0	0	0
612	11	Deadspace Guristas Battleship		0	0	1	1	0	0	0
613	11	Deadspace Guristas Cruiser		0	0	1	1	0	0	0
614	11	Deadspace Guristas Destroyer		0	0	1	1	0	0	0
615	11	Deadspace Guristas Frigate		0	0	1	1	0	0	0
620	11	Deadspace Sansha’s Nation BattleCruiser		0	0	1	1	0	0	0
621	11	Deadspace Sansha’s Nation Battleship		0	0	1	1	0	0	0
622	11	Deadspace Sansha’s Nation Cruiser		0	0	1	1	0	0	0
623	11	Deadspace Sansha’s Nation Destroyer		0	0	1	1	0	0	0
624	11	Deadspace Sansha’s Nation Frigate		0	0	1	1	0	0	0
629	11	Deadspace Serpentis BattleCruiser		0	0	1	1	0	0	0
630	11	Deadspace Serpentis Battleship		0	0	1	1	0	0	0
631	11	Deadspace Serpentis Cruiser		0	0	1	1	0	0	0
632	11	Deadspace Serpentis Destroyer		0	0	1	1	0	0	0
633	11	Deadspace Serpentis Frigate		0	0	1	1	0	0	0
638	7	Navigation Computer		0	0	1	1	0	0	0
639	18	Electronic Warfare Drone		0	0	1	1	0	0	0
640	18	Logistic Drone		0	0	1	1	0	0	0
641	18	Stasis Webifying Drone		0	0	1	1	0	0	0
642	7	Super Gang Enhancer		0	0	1	1	0	0	0
643	9	Carrier Blueprint		0	1	1	1	0	0	0
644	7	Drone Navigation Computer		0	0	1	1	0	0	0
645	7	Drone Damage Modules		0	0	1	1	0	0	0
646	7	Drone Tracking Modules		0	0	1	1	0	0	0
647	7	Drone Control Range Module		0	0	1	1	0	0	0
648	8	Advanced Rocket		0	0	1	1	0	0	1
649	2	Freight Container	Freight Containers are commonly used in Freighter-class ships to accomodate their massive cargobays.	1174	1	1	1	0	0	0
650	7	Tractor Beam		0	0	1	1	0	0	0
651	9	Super Weapon Blueprint		0	1	1	1	0	0	0
652	17	Lease	Each 'Starbase Code Cycle' equals 1 hour of operation of a control tower in the sovereign space of the entity that issued the code. If no Starbase Code Cycle is available during a Control Tower consumption cycle, it should be considered as it has no fuel and therefore offlined.	0	1	1	1	0	0	0
653	8	Advanced Light Missile		0	0	1	1	0	0	1
654	8	Advanced Assault Missile		0	0	1	1	0	0	1
655	8	Advanced Heavy Missile		0	0	1	1	0	0	1
656	8	Advanced Cruise Missile		0	0	1	1	0	0	1
657	8	Advanced Torpedo		0	0	1	1	0	0	1
658	7	Cynosural Field		0	0	1	1	0	0	0
659	6	Mothership	Mothership	0	0	1	1	0	0	0
660	7	Energy Vampire Slayer		0	0	1	1	0	0	0
661	24	Simple Biochemical Reactions		0	0	1	1	0	0	0
662	24	Complex Biochemical Reactions		0	0	1	1	0	0	0
663	8	Mercoxit Mining Crystal		0	0	1	1	0	0	1
665	11	Mission Amarr Empire Frigate		0	0	1	1	0	0	0
666	11	Mission Amarr Empire Battlecruiser		0	0	1	1	0	0	0
667	11	Mission Amarr Empire Battleship		0	0	1	1	0	0	0
668	11	Mission Amarr Empire Cruiser		0	0	1	1	0	0	0
669	11	Mission Amarr Empire Destroyer		0	0	1	1	0	0	0
670	11	Mission Amarr Empire Other		0	0	1	1	0	0	0
671	11	Mission Caldari State Frigate		0	0	1	1	0	0	0
672	11	Mission Caldari State Battlecruiser		0	0	1	1	0	0	0
673	11	Mission Caldari State Cruiser		0	0	1	1	0	0	0
674	11	Mission Caldari State Battleship		0	0	1	1	0	0	0
675	11	Mission Caldari State Other		0	0	1	1	0	0	0
676	11	Mission Caldari State Destroyer		0	0	1	1	0	0	0
677	11	Mission Gallente Federation Frigate		0	0	1	1	0	0	0
678	11	Mission Gallente Federation Cruiser		0	0	1	1	0	0	0
679	11	Mission Gallente Federation Destroyer		0	0	1	1	0	0	0
680	11	Mission Gallente Federation Battleship		0	0	1	1	0	0	0
681	11	Mission Gallente Federation Battlecruiser		0	0	1	1	0	0	0
682	11	Mission Gallente Federation Other		0	0	1	1	0	0	0
683	11	Mission Minmatar Republic Frigate		0	0	1	1	0	0	0
684	11	Mission Minmatar Republic Destroyer		0	0	1	1	0	0	0
685	11	Mission Minmatar Republic Battlecruiser		0	0	1	1	0	0	0
686	11	Mission Minmatar Republic Other		0	0	1	1	0	0	0
687	11	Mission Khanid Frigate		0	0	1	1	0	0	0
688	11	Mission Khanid Destroyer		0	0	1	1	0	0	0
689	11	Mission Khanid Cruiser		0	0	1	1	0	0	0
690	11	Mission Khanid Battlecruiser		0	0	1	1	0	0	0
691	11	Mission Khanid Battleship		0	0	1	1	0	0	0
692	11	Mission Khanid Other		0	0	1	1	0	0	0
693	11	Mission CONCORD Frigate		0	0	1	1	0	0	0
694	11	Mission CONCORD Destroyer		0	0	1	1	0	0	0
695	11	Mission CONCORD Cruiser		0	0	1	1	0	0	0
696	11	Mission CONCORD Battlecruiser		0	0	1	1	0	0	0
697	11	Mission CONCORD Battleship		0	0	1	1	0	0	0
698	11	Mission CONCORD Other		0	0	1	1	0	0	0
699	11	Mission Mordu Frigate		0	0	1	1	0	0	0
700	11	Mission Mordu Destroyer		0	0	1	1	0	0	0
701	11	Mission Mordu Cruiser		0	0	1	1	0	0	0
702	11	Mission Mordu Battlecruiser		0	0	1	1	0	0	0
703	11	Mission Mordu Battleship		0	0	1	1	0	0	0
704	11	Mission Mordu Other		0	0	1	1	0	0	0
705	11	Mission Minmatar Republic Cruiser		0	0	1	1	0	0	0
706	11	Mission Minmatar Republic Battleship		0	0	1	1	0	0	0
707	23	Jump Portal Array		0	1	1	1	0	1	0
709	23	Scanner Array		0	1	1	1	0	1	0
710	23	Logistics Array		0	1	1	1	0	1	0
711	25	Harvestable Cloud		0	0	1	1	0	0	0
712	4	Biochemical Material		0	0	1	1	0	0	0
714	4	Processed Gas Clouds		0	0	1	1	0	0	0
715	11	Destructible Agents In Space		0	0	1	1	0	0	0
716	17	Data Interfaces		0	0	1	1	0	0	0
718	9	Booster Blueprints		0	0	1	1	0	0	0
719	11	Destructible Agents With Guns		0	0	1	1	0	0	0
720	11	Destructible Agent NPCs		0	0	1	1	0	0	0
721	20	Temp		0	0	1	1	0	0	0
\.


--
-- Name: invGroups invGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invGroups"
    ADD CONSTRAINT "invGroups_pkey" PRIMARY KEY ("groupID");


--
-- PostgreSQL database dump complete
--

\unrestrict xYW2GyerCgwi8lOFesdbsGdXRheXHOl5fGAyUEDsvwJeRzWiytnw5OxGiip4jLj

