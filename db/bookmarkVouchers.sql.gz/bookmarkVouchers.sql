--
-- PostgreSQL database dump
--

\restrict WDPuNihYtMrdiHvVICP6DJq7AKgoE84YOx5G6KxTCINXcLP3h628eoOJvWemKiv

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bookmarkVouchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."bookmarkVouchers" (
    "voucherID" integer NOT NULL,
    "itemID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    flag integer,
    memo text DEFAULT ''::text NOT NULL,
    created bigint DEFAULT 0 NOT NULL,
    x double precision,
    y double precision,
    z double precision,
    "locationID" integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "bookmarkVouchers"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."bookmarkVouchers" IS 'MADE: the bookmark a bookmark voucher item (typeBookmark, 51) carries, keyed by the item; a copy of the bookmarks row it was made from (CreateBookmarkVoucher, addressbook.py:182).';


--
-- Data for Name: bookmarkVouchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."bookmarkVouchers" ("voucherID", "itemID", "typeID", flag, memo, created, x, y, z, "locationID") FROM stdin;
\.


--
-- Name: bookmarkVouchers bookmarkVouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."bookmarkVouchers"
    ADD CONSTRAINT "bookmarkVouchers_pkey" PRIMARY KEY ("voucherID");


--
-- PostgreSQL database dump complete
--

\unrestrict WDPuNihYtMrdiHvVICP6DJq7AKgoE84YOx5G6KxTCINXcLP3h628eoOJvWemKiv

