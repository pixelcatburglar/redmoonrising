--
-- PostgreSQL database dump
--

\restrict FqZ42ZXbuf3YJZkKoWJ9lBpcVy2S8ekq7xKGoedrLo7tKgEqPCSceYKMgK5fA1c

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrAncestries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrAncestries" (
    "ancestryID" integer DEFAULT 0 NOT NULL,
    "ancestryName" text DEFAULT ''::text NOT NULL,
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "postPerception" integer DEFAULT 0 NOT NULL,
    "postWillpower" integer DEFAULT 0 NOT NULL,
    "postCharisma" integer DEFAULT 0 NOT NULL,
    "postMemory" integer DEFAULT 0 NOT NULL,
    "postIntelligence" integer DEFAULT 0 NOT NULL,
    perception integer DEFAULT 0 NOT NULL,
    willpower integer DEFAULT 0 NOT NULL,
    charisma integer DEFAULT 0 NOT NULL,
    memory integer DEFAULT 0 NOT NULL,
    intelligence integer DEFAULT 0 NOT NULL,
    "skillTypeID1" integer DEFAULT 0 NOT NULL,
    "skillTypeID2" integer DEFAULT 0 NOT NULL,
    "typeID" integer,
    "typeQuantity" integer,
    "typeID2" text,
    "typeQuantity2" integer,
    "graphicID" integer
);


--
-- Data for Name: chrAncestries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrAncestries" ("ancestryID", "ancestryName", "bloodlineID", description, "postPerception", "postWillpower", "postCharisma", "postMemory", "postIntelligence", perception, willpower, charisma, memory, intelligence, "skillTypeID1", "skillTypeID2", "typeID", "typeQuantity", "typeID2", "typeQuantity2", "graphicID") FROM stdin;
1	Liberal Holders	5	Holders, the elite caste in Amarr society, are usually very conservative and habitual. Some of them have rejected their traditional role as inactive power-mongers and are instead active members of the economical life of the Empire. Their champion is Catiz Tash-Murkon, the Udorian Royal Heir. 	0	1	3	0	0	0	1	3	0	0	3355	3417	\N	1	\N	5	1641
2	Wealthy Commoners	5	Some Commoners manage to break out of the strict caste form and make a name for themselves, usually through trade or other merchant activities. Although they can never enjoy political power within the empire they are still free to hoard vast amount of wealth through inter-stellar trade.	0	0	1	3	0	0	0	1	3	0	3380	3417	\N	1	\N	5	1642
3	Religious Reclaimers	5	Many Amarrians still dream of the glory days of the Empire when the Amarrians seemed poised to conquer the world. They abhor the peace policies of the current regime, regarding them as weak and against everything that the Empire has hitherto stood for.	0	4	0	0	0	0	4	0	0	0	3348	3417	\N	1	\N	\N	1643
4	Free Merchants	6	Ni-Kunnis, originally a slave race within the Amarr Empire, have adapted exceptionally well and most of them are today free. The Ni-Kunnis have used the inherent dislike Amarrians have for merchants to their advantage and Ni-Kunni merchants are now vital for the economic health of the Empire.	0	0	4	0	0	0	0	4	0	0	3355	3444	\N	1	\N	1	1644
5	Border Runners	6	The Amarr Empire has strict rules regarding trade with other races. This encourages smuggling operations to ferry goods not otherwise permitted to cross the border to flourish. None is better at this than the Ni-Kunnis, which have perfected their smuggler run operations for generations.	3	0	0	0	1	3	0	0	0	1	3449	3444	\N	1	\N	1	1645
6	Navy Veterans	6	A large portion of the Ni-Kunnis live in impoverished slums and ghettos. One of the few ways for them to escape is to enlist in the Imperial Navy. There they get the education and career they need to jump-start their, and their family's, life. 	0	4	0	0	0	0	4	0	0	0	3348	3444	\N	1	\N	1	1646
7	Entrepreneurs	2	Civire are usually not known for their business endeavors, but when they go into business they do it with the same aggressiveness and confidence as when fighting a battle. To them, business is war, and should thus be pursued with the same vigilance and ruthlessness. 	0	0	0	4	0	0	0	0	4	0	3380	3320	\N	10	\N	\N	1647
8	Mercs	2	Civire love the brutality of battle and take every opportunity to engage in one. This is the reason why so many of them sell their services as mercenaries - it promises a constant supply of combat. For many families, a merc career has become mandatory for every member before he can settle down for a quiet family life.	0	4	0	0	0	0	4	0	0	0	3426	3320	\N	10	\N	\N	1648
9	Dissenters	2	The cold, disciplined Caldari society does not appeal to everyone, nor are everyone happy with the stranglehold the mega-corporations have on everyday life. These people are not rebellious, but have for years been trying to actively change the system from within. One of these days the State will want to deal with them once and for all.	0	2	2	0	0	0	2	2	0	0	3355	3320	\N	10	\N	\N	1649
10	Merchandisers	1	There is nothing the Deteis love more than than having total control over all their activities and this holds true for producing items. They want to master every aspect of the process, from mining the materials, the actual production, and finally the distribution and marketing.	0	0	0	4	0	0	0	0	4	0	3380	3416	\N	1	\N	\N	1650
11	Scientists	1	The Deteis beautifully combine efficiency with inventiveness, making them superb researchers and scientists. It's the ability of the Deteis to continuously create hi-tech devices and the combat abilities of the Civire that together make the Caldari State such a formidable force. 	1	0	0	0	3	1	0	0	0	3	3402	3416	\N	1	\N	\N	1651
12	Tube Child	1	Acutely aware of the small population of the Caldari State in comparison with the sprawling Gallente Federation, the Deteis have for decades utilized artificial procreation to increase their population. These tube-children are then raised in inhospitable, State-run orphanages, making them tough and self-reliant. 	0	4	0	0	0	0	4	0	0	0	3374	3416	\N	1	\N	\N	1652
13	Activists	7	The common Gallente citizen is extremely politically aware compared to citizens of other races. To outsiders it seems like each and every Gallentean is fighting for one issue or another - anti-corruption, pro-war, anti-pollution, pro-Federation - anything and everything is worth at least one good rally and a general strike.	0	0	4	0	0	0	0	4	0	0	3355	3437	\N	1	\N	\N	1653
14	Miners	7	The insatiable Gallente industry demands massive amounts of minerals for its day-to-day operation. The Federation, loath to be dependent on other races, encourages asteroid mining on a large scale. The sense of independence while mining appeals greatly to the individualistic Gallenteans. 	0	0	0	4	0	0	0	0	4	0	3386	3437	\N	1	\N	\N	1654
15	Immigrants	7	Nowhere are honest immigrants as welcome as in the Gallente Federation and no nation is as quick to assimilate them and mold them gently into their own. Hard-working immigrants of every race, creed and color can quickly make it on their own - the opportunities are plentiful.	2	2	0	0	0	2	2	0	0	0	3443	3437	\N	1	\N	\N	1655
16	Artists	8	It is widely believed that the introvert Intakis create the most stunning and thought provoking art around. They've revolutionized many art-forms and created new, such as metapaints and touch sculpture. Intaki artists seem to have a unique ability to create and convey unparalleled beauty that is universal for all human races.	2	0	2	0	0	2	0	2	0	0	3374	3427	\N	1	\N	\N	1656
17	Diplomats	8	Since their inauguration into the Federation the Intakis have slowly established a reputation as superb diplomats, negotiators and bureaucrats. In the tense and often violent world of EVE these qualities can be of vital importance.	0	0	4	0	0	0	0	4	0	0	3355	3427	\N	1	\N	\N	1657
18	Reborn	8	Although persons in risky positions (such as space ship captains) use clones, the general Intaki public refrains from using them. Instead they have a unique method for transferring the personality of a dying person into a newborn baby. Steeped in tradition and perfected with technology the Reborn process is the ideal Intaki vision of 'afterlife'.	0	0	0	4	0	0	0	0	4	0	3402	3427	\N	1	\N	\N	1658
19	Tinkerers	3	The Sebiestors are the engineers and inventors of the Minmatars. They are especially adept at taking various ideas and techniques and molding them into their own special designs. Some Sebiestors seem to have an uncanny empathy with the ways things work and tick, making them extremely competent tinkerers.	0	0	0	0	4	0	0	0	0	4	3413	3393	\N	\N	\N	\N	1659
20	Traders	3	Many Sebiestor traders live like nomads and travel the width and breadth of the world in search of quick profit. They seldom settle down to exploit a prosperous trade route for long, always moving on to seek the big payoff that will make them rich beyond their wildest dreams.	0	0	4	0	0	0	0	4	0	0	3443	3393	\N	1	\N	\N	1660
21	Rebels	3	While most Minmatars are trying to establish some sort of a normal way of life since the Rebellion there are many that are not willing to forgive the Amarrians or forget their atrocities. Fighting to free the millions of Minmatars still enslaved by the Amarrians the rebels are building hidden bases close to Amarrian borders.	3	1	0	0	0	3	1	0	0	0	3449	3393	\N	1	\N	\N	1661
22	Workers	4	The majority of Brutors have a modest background - that of working the fields, mines and factories of the Republic (and before that of the Amarr Empire). Still, a lot of them take pride in their jobs and are expert craftsmen and builders.	0	0	0	4	0	0	0	0	4	0	3380	3450	\N	1	\N	\N	1662
23	Tribal Traditionalists	4	The Brutor clan was treated harshly while the Minmatars where under the yoke of the Amarr Empire. This strengthened their bond with their cultural heritage, the only thing the Amarrians couldn't take away from them.	0	3	1	0	0	0	3	1	0	0	3348	3450	\N	1	\N	\N	1663
24	Slave Child	4	The many millions of slaves within the Amarr Empire dream of escape, especially for their children. Every year thousands of newly born slave children are smuggled out of the Empire into Minmatar space, where foster parents raise them.	2	2	0	0	0	2	2	0	0	0	3303	3450	\N	1	\N	\N	1664
25	Elders	9	The Elders were one of the first groups to use genetic engineering for a special purpose, namely that of slowing the aging process. Once, the Elders were a prominent political force in the Jovian society, but after they brought about the fall of the first Jovian empire they have become more reclusive. Elders can become many centuries old, it's uncertain exactly how old they can become, but some suggest they can outlive even members of the Amarrian royal families.	0	3	0	1	0	0	3	0	1	0	3363	3755	\N	\N	\N	\N	\N
26	Unsullied	9	Genetic engineering has through the centuries transformed Jovian society in every aspect imaginable. Many Jovians believe that enough has been done. The Unsullied is a group of Jovians that have rejected further generic experiments and instead adopt conventional methods to deal with sickness and old age. They're advocates of cyber-implants and want to use machines instead of genes in the search for better life.	0	0	4	0	0	0	0	4	0	0	3355	3392	\N	\N	\N	\N	\N
27	Stasis People	9	For many Jovians their race is in the twilight of their greatness. Ever since the fall of the first empire the Jovian society have been in a slow, steady decline. Most blame the Jovian Disease for this and believe that the Jovians can only hope to turn the tide once a cure for the disease has been found. The Stasis People are Jovians that voluntarily go into cryo-stasis for decades or centuries, hoping that when they wake a bright and better world will greet them.	4	0	0	0	0	4	0	0	0	0	3378	3413	\N	\N	\N	\N	\N
28	Existentialists	10	The Existentialists are the most energetic and vociferous Jovian group. They live for the moment and are always ready to experiment, even with their own bodies. To them, nothing is sacred. The Existentialists tend to have little to do with the other races, as they find them boring and uninspiring.	1	0	0	0	3	1	0	0	0	3	3348	3426	\N	\N	\N	\N	\N
29	Puritan	10	Many Jovians dream of returning to their genetic roots, now long since lost during the Shrouded Days. Those that are most active in their search for the 'untainted' Jovian genes are called the Puritans. In the hope of cleansing the nation of the Jovian Disease the Puritans try out ever-more outrageous genetic engineering stunts, often with quite unexpected results. But unlike the Existentialists the genetic engineering of the Puritans has the specific aim to return the human element to the Jovians, instead of being just narcissistic in nature.	0	0	0	4	0	0	0	0	4	0	3380	3355	\N	\N	\N	\N	\N
30	Lab Rat	10	All Jovians are artificially conceived. In most cases a family unit is involved, donating genes, taking care of the rearing and so on, but this is not always so. Often, persons are conceived for some altruist reasons, usually research purposes. These Jovians are treated the same as everyone else, but they tend to be a little 'off', due to the clinical way of their conceivement.	0	4	0	0	0	0	4	0	0	0	3300	3404	\N	\N	\N	\N	\N
31	Inventors	11	Creativity is a prized attribute amongst the Achur, as inventions are considered spiritual rather than strictly scientific in nature. Only those in touch with themselves and the universe can ‘tap’ into the universal consciousness and return with novel ideas.	0	0	0	0	4	0	0	0	0	4	3402	3403	\N	\N	\N	\N	3025
32	Monks	11	Thousands of monasteries are scattered around Saisio III, operated by dozens of different monastic orders. While each order has its own code of conduct regarding member behaviour, celibacy and other issues, they all agree on one thing; that only by perfecting the body can you perfect the soul.	2	2	0	0	0	2	2	0	0	0	3449	3403	\N	\N	\N	\N	3027
33	Stargazers	11	While the spiritualism exercised by the Achur is not an organized religion in any sense, the Achura nation still holds seers and visionaries in high esteem. While the Achur are realistic enough not to attribute them with supernatural prophetic powers, these individuals are still regarded as possessing uncanny understanding of what makes the universe, and humans, tick.	1	0	0	3	0	1	0	0	3	0	3413	3403	\N	\N	\N	\N	3026
34	Sang Do Caste	12	The Sang Do caste (translates as overlords) is the ruling class in Jin-Mei society. Despite this, they rule with a benevolent hand and most are noble and charitable. With easy demeanor and insightful nature, they have an unparallel knack to inspire loyalty and command others.	0	3	1	0	0	0	3	1	0	0	3348	3374	\N	\N	\N	\N	3028
35	Saan Go Caste	12	The Saan Go caste (translates as standing high) are just below the Sang Do caste in this social hierarchy of the Jin-Meis. They are commonly found as governmental officials, administration officers, police commissioners and in similar positions. They are resilient and amiable, generally well educated and possessing good common sense.	0	0	0	2	2	0	0	0	2	2	3355	3374	\N	\N	\N	\N	3029
36	Jing Ko Caste	12	The Jing Ko caste (translates as good spirit) is the proverbial middle-class of Jin-Mei society. While most people that belong to this caste toil in obscurity all their life, a selective few of exceptional talent manage to rise above the masses. These individuals usually attach themselves to an upper class patron, which paves the way for them to receive the education and career opportunities they merit.	4	0	0	0	0	4	0	0	0	0	3300	3374	\N	\N	\N	\N	3030
37	Cyber Knights	13	Many Khanids want to keep their warrior traditions alive, but the only way to do so in the modern world is through massive body enhancements. The extensive knowledge on cyber implants possessed by the Amarrians is just the thing they need.  Some still aim to excel in physical combat, while the more progressive ones seek to become masters of modern warfare. 	3	0	0	0	1	3	0	0	0	1	3303	3316	\N	\N	\N	\N	3031
38	Unionists	13	A number of Khanids were unhappy with the break from the Amarr Empire. While they never succumbed to insurgence they are now rejoicing the improving relations with the Empire and are hoping the two nations can unite once more. They’re willing to do what it takes for that to happen, such as taking on common enemies of the Empire and the Kingdom.	0	0	2	0	2	0	0	2	0	2	3355	3316	\N	\N	\N	\N	3032
39	Zealots	13	The Khanids are not known to be as religious minded as the Amarrians, but when they are they tend to be even more fanatical. Religious Khanids are often involved in a cult of some sort, based to more or less extent on the Scriptures. The Amarrians regard religious Khanids with suspicious interest; on one hand they are alarmed by the extremism often shown by the Khanids, but on the other the religious fervor displayed often results in deep theosophical insights.	0	2	0	2	0	0	2	0	2	0	3348	3316	\N	\N	\N	\N	3033
40	Drifters	14	The wanderlust is still strong with many Vherokiors. While most have managed to curb their lust for adventure, there are those that can never settle down in one place for long. Never at rest, the horizon holds a constant fascination for them. For there are places to be seen and riches to be discovered.	2	0	0	0	2	2	0	0	0	2	3449	3385	\N	\N	\N	\N	3036
41	Mystics	14	The Vherokiors have always seemed a bit odd to the other Minmatar tribes. Doubly so in regard to those Vherokiors with mystical inclinations. Vherokior shamans are both revered and feared by the Minmatars. They possess insights that can be of great help to people, but these same insights can also grant them great power. 	0	3	0	0	1	0	3	0	0	1	3374	3385	\N	\N	\N	\N	3034
42	Retailers	14	Walk into any dingy little eatery in Minmatar space and odds are it’s owned and operated by a Vherokior. The same goes for any other small business establishment in the Republic. The Vherokiors are notorious peddlers, dating back to their caravan days. They usually run a family business and are seldom inclined to create big corporations. 	0	0	1	3	0	0	0	1	3	0	3443	3385	\N	\N	\N	\N	3035
\.


--
-- Name: chrAncestries chrAncestries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrAncestries"
    ADD CONSTRAINT "chrAncestries_pkey" PRIMARY KEY ("ancestryID");


--
-- PostgreSQL database dump complete
--

\unrestrict FqZ42ZXbuf3YJZkKoWJ9lBpcVy2S8ekq7xKGoedrLo7tKgEqPCSceYKMgK5fA1c

