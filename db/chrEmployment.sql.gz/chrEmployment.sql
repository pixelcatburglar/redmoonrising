--
-- PostgreSQL database dump
--

\restrict aXBSRqHNdNQZ4L14WnhS3Cv8oCdcNUfFd2TIocJ8SAffr6GiAnHPa76baHi3DWp

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrEmployment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrEmployment" (
    "characterID" integer DEFAULT 0 NOT NULL,
    "corporationID" integer DEFAULT 0 NOT NULL,
    "startDate" bigint DEFAULT 0 NOT NULL,
    deleted smallint DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrEmployment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrEmployment" ("characterID", "corporationID", "startDate", deleted) FROM stdin;
\.


--
-- Name: chrEmployment chrEmployment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrEmployment"
    ADD CONSTRAINT "chrEmployment_pkey" PRIMARY KEY ("characterID", "corporationID", "startDate");


--
-- Name: chrEmployment_corporationID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chrEmployment_corporationID_idx" ON public."chrEmployment" USING btree ("corporationID");


--
-- PostgreSQL database dump complete
--

\unrestrict aXBSRqHNdNQZ4L14WnhS3Cv8oCdcNUfFd2TIocJ8SAffr6GiAnHPa76baHi3DWp

