--
-- PostgreSQL database dump
--

\restrict pYywATnnqpaExU59ZJace4flD5wcJ99XCFzPJAX4gOol4htW2KrnRd28SvZ0N0G

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: allianceRelationships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."allianceRelationships" (
    "fromID" integer NOT NULL,
    "toID" integer NOT NULL,
    relationship smallint NOT NULL
);


--
-- Name: TABLE "allianceRelationships"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."allianceRelationships" IS 'Alliance-to-owner relationships. Serves allianceRegistry.GetRelationships / SetRelationship / DeleteRelationship (all_cso_relationships.py:21,30,37).';


--
-- Name: COLUMN "allianceRelationships"."fromID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceRelationships"."fromID" IS 'INFERRED as a column: the calls are alliance-bound through the moniker so the alliance ID never crosses the wire. It is the declaring alliance.';


--
-- Name: COLUMN "allianceRelationships"."toID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceRelationships"."toID" IS 'PROVEN: all_ui_relationships.py:55,90,103,237 read relationship.toID and resolve it with cfg.eveowners -- so it is any ownerID (corp, alliance or character).';


--
-- Name: COLUMN "allianceRelationships".relationship; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceRelationships".relationship IS 'PROVEN: all_ui_relationships.py:86 compares relationship.relationship to the tab''s view type; 1st arg of SetRelationship. Values from eveConstants: allianceRelationshipNAP 1, Friend 2, Competitor 3, Enemy 4.';


--
-- Data for Name: allianceRelationships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."allianceRelationships" ("fromID", "toID", relationship) FROM stdin;
\.


--
-- Name: allianceRelationships allianceRelationships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."allianceRelationships"
    ADD CONSTRAINT "allianceRelationships_pkey" PRIMARY KEY ("fromID", "toID");


--
-- Name: alliancerel_to_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alliancerel_to_ix ON public."allianceRelationships" USING btree ("toID");


--
-- Name: INDEX alliancerel_to_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.alliancerel_to_ix IS 'Reverse lookup: "who has declared a relationship towards me".';


--
-- PostgreSQL database dump complete
--

\unrestrict pYywATnnqpaExU59ZJace4flD5wcJ99XCFzPJAX4gOol4htW2KrnRd28SvZ0N0G

