--
-- PostgreSQL database dump
--

\restrict KIx7RQUwD6nJy0a9gmt4LS8957FnqBitXElPin2bXRwaGu2CVOeKkBkn86HzoYV

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: evemailDetails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."evemailDetails" (
    "attachmentID" integer NOT NULL,
    "messageID" integer DEFAULT 0 NOT NULL,
    "mimeTypeID" integer DEFAULT 0 NOT NULL,
    attachment text DEFAULT ''::text NOT NULL
);


--
-- Name: evemailDetails_attachmentID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."evemailDetails_attachmentID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evemailDetails_attachmentID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."evemailDetails_attachmentID_seq" OWNED BY public."evemailDetails"."attachmentID";


--
-- Name: evemailDetails attachmentID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."evemailDetails" ALTER COLUMN "attachmentID" SET DEFAULT nextval('public."evemailDetails_attachmentID_seq"'::regclass);


--
-- Data for Name: evemailDetails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."evemailDetails" ("attachmentID", "messageID", "mimeTypeID", attachment) FROM stdin;
\.


--
-- Name: evemailDetails_attachmentID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."evemailDetails_attachmentID_seq"', 1, false);


--
-- Name: evemailDetails evemailDetails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."evemailDetails"
    ADD CONSTRAINT "evemailDetails_pkey" PRIMARY KEY ("attachmentID");


--
-- Name: evemailDetails_messageID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evemailDetails_messageID_idx" ON public."evemailDetails" USING btree ("messageID");


--
-- PostgreSQL database dump complete
--

\unrestrict KIx7RQUwD6nJy0a9gmt4LS8957FnqBitXElPin2bXRwaGu2CVOeKkBkn86HzoYV

