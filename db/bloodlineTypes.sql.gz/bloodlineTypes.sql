--
-- PostgreSQL database dump
--

\restrict 5eESpbVtqsCEcSqdf4Gh3TgQeGBf3tmNdQ7NhUD0cZCIwhZ54QMOCdw9qkxKNGO

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bloodlineTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."bloodlineTypes" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: bloodlineTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."bloodlineTypes" ("bloodlineID", "typeID") FROM stdin;
5	1373
6	1374
2	1375
1	1376
7	1377
8	1378
3	1379
4	1380
9	1381
10	1382
11	1383
12	1384
13	1385
14	1386
\.


--
-- Name: bloodlineTypes bloodlineTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."bloodlineTypes"
    ADD CONSTRAINT "bloodlineTypes_pkey" PRIMARY KEY ("bloodlineID");


--
-- Name: bloodlineTypes_typeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "bloodlineTypes_typeID_idx" ON public."bloodlineTypes" USING btree ("typeID");


--
-- PostgreSQL database dump complete
--

\unrestrict 5eESpbVtqsCEcSqdf4Gh3TgQeGBf3tmNdQ7NhUD0cZCIwhZ54QMOCdw9qkxKNGO

