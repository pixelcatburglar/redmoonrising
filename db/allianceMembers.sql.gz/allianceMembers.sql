--
-- PostgreSQL database dump
--

\restrict 9kunjJA8HeVe9xXjuXyMuU9ObKeNGzICqRXrjAyPA9ns9cN9tLeTcvtUgOaqxMh

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: allianceMembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."allianceMembers" (
    "allianceID" integer NOT NULL,
    "corporationID" integer NOT NULL,
    "chosenExecutorID" integer,
    "startDate" bigint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "allianceMembers"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."allianceMembers" IS 'Corp membership of an alliance. PK is corporationID because a corp is in at most one alliance (corporation."allianceID" is the denormalised mirror). Serves allianceRegistry.GetMembers / DeclareExecutorSupport / DeleteMember.';


--
-- Name: COLUMN "allianceMembers"."allianceID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceMembers"."allianceID" IS 'PROVEN: all_ui_members.py:113 entry.member.allianceID; 1st arg of the OnAllianceMemberChanged notification.';


--
-- Name: COLUMN "allianceMembers"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceMembers"."corporationID" IS 'PROVEN: all_ui_members.py:57,78,81,113,176; the index key of the returned IndexRowset (all_cso_members.py:44-51).';


--
-- Name: COLUMN "allianceMembers"."chosenExecutorID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceMembers"."chosenExecutorID" IS 'PROVEN and NULLABLE: all_ui_members.py:99-100 `chosenExecutor = member.chosenExecutorID; if member.chosenExecutorID is None: ...`. Which corp THIS member backs for executor -- written by DeclareExecutorSupport(corpID) (all_cso_members.py:29).';


--
-- Name: COLUMN "allianceMembers"."startDate"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."allianceMembers"."startDate" IS 'INFERRED. Windows FILETIME the corp joined. No client read on the member row (alliances."startDate" is the alliance''s own founding date, which IS read).';


--
-- Data for Name: allianceMembers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."allianceMembers" ("allianceID", "corporationID", "chosenExecutorID", "startDate") FROM stdin;
\.


--
-- Name: allianceMembers allianceMembers_alliance_corp_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."allianceMembers"
    ADD CONSTRAINT "allianceMembers_alliance_corp_uq" UNIQUE ("allianceID", "corporationID");


--
-- Name: allianceMembers allianceMembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."allianceMembers"
    ADD CONSTRAINT "allianceMembers_pkey" PRIMARY KEY ("corporationID");


--
-- Name: alliancemembers_alliance_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alliancemembers_alliance_ix ON public."allianceMembers" USING btree ("allianceID");


--
-- Name: INDEX alliancemembers_alliance_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.alliancemembers_alliance_ix IS 'allianceRegistry.GetMembers -- the PK is corporationID, so the alliance direction needs its own index.';



--
-- PostgreSQL database dump complete
--

\unrestrict 9kunjJA8HeVe9xXjuXyMuU9ObKeNGzICqRXrjAyPA9ns9cN9tLeTcvtUgOaqxMh

