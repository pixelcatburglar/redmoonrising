--
-- PostgreSQL database dump
--

\restrict Qdp6nrIvQeLdxo7rbmMmcOd7CTx0dXwUAnXbAiuYBIbII7qAXOsEWF8ZMG1DLAI

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_refTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."market_refTypes" (
    "refTypeID" integer DEFAULT 0 NOT NULL,
    "refTypeText" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: market_refTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."market_refTypes" ("refTypeID", "refTypeText", description) FROM stdin;
0	Undefined	
1	Player Trading	
2	Market Transaction	
3	GM Cash Transfer	
4	ATM Withdraw	
5	ATM Deposit	
6	Backward Compatible	
7	Mission Reward	
8	Clone Activation	
9	Inheritance	
10	Player Donation	Player gave cash to another owner
11	Corporation Payment	CEO or Accountant transferred cash  from corp. account
12	Docking Fee	
13	Office Rental Fee	
14	Factory Slot Rental Fee	
15	Repair Bill	
16	Bounty	Player gave cash to someone's  bounty pool
17	Bounty Prize	Player got bounty prize for killing someone
18	Agents_temporary	TEMP
19	Insurance	
20	Mission Expiration	
21	Mission Completion	
22	Shares	
23	Courier Mission Escrow	
24	Mission Cost	
25	Agent Miscellaneous	Agent paid you
26	Miscellaneous Payment To Agent	You paid agent
27	Agent Location Services	You paid agent to locate somebody
28	Agent Donation	You donated/bribed the agent
29	Agent Security Services	You paid agent to clean your rep
30	Agent Mission Collateral Paid	You gave agent collateral for a mission
31	Agent Mission Collateral Refunded	The agent returned collateral to you
32	Agents_preward	The agent gave you this when you accepted the mission
33	Agent Mission Reward	The agent gave you this as a reward
34	Agent Mission Time Bonus Reward	The agent gave you this as a special reward for fast mission completion
35	CSPA	CONCORD Spam Prevention Act
36	CSPAOfflineRefund	Refunded CSPA charge because the other party was not online
37	Corporation Account Withdrawal	Withdrawal from corporation account
38	Corporation Dividend Payment	
39	Corporation Registration Fee	
40	Corporation Logo Change Cost	
41	Release Of Impounded Property	Charge for the receipt of goods from a corporation hangar that is no longer rented
42	Market Escrow	
43	Agent Services Rendered	For miscellaneous services rendered by the agent
44	Market Fine Paid	
45	Corporation Liquidation	Funds from the liquidation of a corporation to a shareholder
46	Broker fee	
47	Corporation Bulk Payment	A payment from a corporation
48	Alliance Registration Fee	
49	War Fee	
50	Alliance Maintainance Fee	
51	Contraband Fine	
52	Clone Transfer	
53	Acceleration Gate Fee	
54	Transaction Tax	Sales tax paid to the SCC for any transaction
55	Jump Clone Installation Fee	
56	Manufacturing	Installation and runtime cost for a manufacturing job
57	Researching Technology	Installation and runtime cost for a technological research job
58	Researching Time Productivity	Installation and runtime cost for a time productivity research job
59	Researching Material Productivity	Installation and runtime cost for a material productivity research job
60	Copying	Installation and runtime cost for a blueprint copying job
61	Duplicating	Installation and runtime cost for an item duplication job
62	Reverse Engineering	Installation and runtime cost for a reverse engineering job
\.


--
-- Name: market_refTypes market_refTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."market_refTypes"
    ADD CONSTRAINT "market_refTypes_pkey" PRIMARY KEY ("refTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict Qdp6nrIvQeLdxo7rbmMmcOd7CTx0dXwUAnXbAiuYBIbII7qAXOsEWF8ZMG1DLAI

