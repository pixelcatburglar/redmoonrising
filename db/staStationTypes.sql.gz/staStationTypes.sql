--
-- PostgreSQL database dump
--

\restrict uHHnCUYJglHktMM0pQrTe0KSGhrI8KT4Sr6e4t9c7mAQ7Lj8URgNOAAk1Jekdwu

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: staStationTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."staStationTypes" (
    "stationTypeID" integer NOT NULL,
    "dockingBayGraphicID" integer,
    "hangarGraphicID" integer,
    "dockEntryX" integer,
    "dockEntryY" integer,
    "dockEntryZ" integer,
    "dockOrientationX" integer,
    "dockOrientationY" integer,
    "dockOrientationZ" integer,
    "operationID" integer,
    "officeSlots" integer,
    "reprocessingEfficiency" double precision,
    conquerable double precision
);


--
-- Data for Name: staStationTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."staStationTypes" ("stationTypeID", "dockingBayGraphicID", "hangarGraphicID", "dockEntryX", "dockEntryY", "dockEntryZ", "dockOrientationX", "dockOrientationY", "dockOrientationZ", "operationID", "officeSlots", "reprocessingEfficiency", conquerable) FROM stdin;
16	\N	\N	101	0	-1498	0	0	-1351	\N	\N	\N	0
17	\N	\N	0	0	-2300	0	0	-1015	\N	\N	\N	0
54	\N	241	36	7224	-4856	0	0	-3725	\N	\N	\N	0
56	\N	1210	0	-198	4800	0	-4967	0	\N	\N	\N	0
57	\N	244	0	4908	-8527	0	1395	4294	\N	\N	\N	0
58	\N	241	0	0	0	0	0	-1	\N	\N	\N	0
59	\N	242	0	0	0	0	0	-1	\N	\N	\N	0
1529	\N	241	-170	3217	-5703	0	0	-8000	\N	\N	\N	0
1530	\N	241	7622	2443	-1162	3526	4854	0	\N	\N	\N	0
1531	\N	241	-2111	-3841	-2988	7608	2472	0	\N	\N	\N	0
1926	\N	1075	0	9615	0	0	5999	0	\N	\N	\N	0
1927	\N	1075	0	-32589	0	0	-5875	0	\N	\N	\N	0
1928	\N	1075	0	-20116	0	0	-4098	0	\N	\N	\N	0
1929	\N	1075	0	-9966	0	0	-8487	0	\N	\N	\N	0
1930	\N	1075	-10709	-9721	-2069	0	-3386	0	\N	\N	\N	0
1931	\N	1075	-13	-4790	0	0	-2799	0	\N	\N	\N	0
1932	\N	1075	-1792	-9488	27	0	-1911	0	\N	\N	\N	0
2496	\N	242	-2909	-1046	20657	0	0	8784	\N	\N	\N	0
2497	\N	242	6299	2566	-9462	0	50	-7985	\N	\N	\N	0
2498	\N	242	28076	-1172	1155	9663	0	0	\N	\N	\N	0
2499	\N	242	4758	8579	-9854	8784	55	0	\N	\N	\N	0
2500	\N	242	1038	27	20911	188	37	5996	\N	\N	\N	0
2501	\N	242	17	3115	10629	0	0	6000	\N	\N	\N	0
2502	\N	242	17	10096	8360	0	0	6000	\N	\N	\N	0
3864	\N	1075	2804	8566	-390	-5178	0	0	\N	\N	\N	0
3865	\N	244	-1663	4799	3200	0	0	1915	\N	\N	\N	0
3866	\N	244	7668	884	0	3923	0	0	\N	\N	\N	0
3867	\N	1210	14274	667	-7720	2420	0	0	\N	\N	\N	0
3868	\N	1210	10596	874	0	7270	2362	0	\N	\N	\N	0
3869	\N	244	9018	874	0	4514	-1466	0	\N	\N	\N	0
3870	\N	1210	6765	938	0	6947	-2257	0	\N	\N	\N	0
3871	\N	241	-171	-4480	12840	0	53	8469	\N	\N	\N	0
3872	\N	241	-14171	126	2399	-5529	0	0	\N	\N	\N	0
3873	\N	\N	-6	-335	3201	0	0	1015	\N	\N	\N	0
3874	\N	\N	0	-33	2923	0	-351	483	\N	\N	\N	0
3875	\N	\N	0	-32	-276	0	-290	399	\N	\N	\N	0
3876	\N	\N	0	0	-47	0	-2	892	\N	\N	\N	0
3877	\N	\N	0	0	0	0	0	-1948	\N	\N	\N	0
4023	\N	241	-14171	126	2399	-5529	0	0	\N	\N	\N	0
4024	\N	241	-28271	-2574	2477	-5856	1902	0	\N	\N	\N	0
9856	\N	1075	-176	-12300	2608	0	1726	5313	\N	\N	\N	0
9857	\N	1075	2804	8566	-390	-5178	0	0	\N	\N	\N	0
9866	\N	242	-1500	405	-1800	-1602	885	-2205	\N	\N	\N	0
9867	\N	2303	-896	-26555	4800	0	-21214	0	\N	\N	\N	0
9868	\N	2067	0	6110	0	0	5078	0	\N	\N	\N	0
9873	\N	242	-1449	-10148	24	-1645	-4313	-10	\N	\N	\N	0
9874	\N	242	0	-9631	0	0	-14338	0	\N	\N	\N	0
10795	\N	1075	-1203	-18300	5400	0	-4616	0	\N	\N	\N	0
12242	\N	2067	0	3676	-6410	0	1046	3221	\N	\N	\N	1
12294	\N	2067	0	-788	3600	0	-3725	0	\N	\N	\N	1
12295	\N	2067	-1247	3599	3463	1860	-254	3642	\N	\N	\N	1
19757	\N	2067	2397	-103	2124	1686423040	-100	-100	\N	\N	\N	0
21642	\N	2067	37	-1089	11224	0	0	5717	48	8	\N	1
21644	\N	2067	-10537	88	237	-8575	0	0	49	4	\N	1
21645	\N	2067	0	15	-220	0	-528	495	50	16	\N	1
21646	\N	2067	2397	-103	2124	1686423040	-100	-100	51	6	0.35	1
22296	\N	1075	4674	14278	-650	-3327	0	0	\N	\N	\N	0
22297	\N	1075	64	-1249	1261	0	0	-3948	\N	\N	\N	0
22298	\N	1075	-294	-20500	2504	0	0	5255	\N	\N	\N	0
\.


--
-- Name: staStationTypes staStationTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."staStationTypes"
    ADD CONSTRAINT "staStationTypes_pkey" PRIMARY KEY ("stationTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict uHHnCUYJglHktMM0pQrTe0KSGhrI8KT4Sr6e4t9c7mAQ7Lj8URgNOAAk1Jekdwu

