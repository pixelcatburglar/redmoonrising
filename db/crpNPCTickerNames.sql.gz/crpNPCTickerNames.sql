--
-- PostgreSQL database dump
--

\restrict WFYtGuBgZq0e0lQ4vsR6s3gbMmSWhWrQSPhf5U3hzAK6aePb4opVHHLbBoNnaL0

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpNPCTickerNames; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpNPCTickerNames" (
    "corporationID" integer DEFAULT 0 NOT NULL,
    "tickerName" text DEFAULT ''::text NOT NULL,
    shape1 integer,
    shape2 integer,
    shape3 integer,
    color1 text,
    color2 text,
    color3 text
);


--
-- Data for Name: crpNPCTickerNames; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpNPCTickerNames" ("corporationID", "tickerName", shape1, shape2, shape3, color1, color2, color3) FROM stdin;
1000001	666	\N	\N	\N	\N	\N	\N
1000002	CBDC	\N	\N	\N	\N	\N	\N
1000003	PD	\N	\N	\N	\N	\N	\N
1000004	Y	\N	\N	\N	\N	\N	\N
1000005	HC	\N	\N	\N	\N	\N	\N
1000006	DCMI	\N	\N	\N	\N	\N	\N
1000007	PMG	\N	\N	\N	\N	\N	\N
1000008	M	\N	\N	\N	\N	\N	\N
1000009	CP	\N	\N	\N	\N	\N	\N
1000010	KC	\N	\N	\N	\N	\N	\N
1000011	WC	\N	\N	\N	\N	\N	\N
1000012	TD	\N	\N	\N	\N	\N	\N
1000013	RA	\N	\N	\N	\N	\N	\N
1000014	P	\N	\N	\N	\N	\N	\N
1000015	CS	\N	\N	\N	\N	\N	\N
1000016	ZA	\N	\N	\N	\N	\N	\N
1000017	NC	\N	\N	\N	\N	\N	\N
1000018	EE	\N	\N	\N	\N	\N	\N
1000019	ISH	\N	\N	\N	\N	\N	\N
1000020	LDC	\N	\N	\N	\N	\N	\N
1000021	ZGRF	\N	\N	\N	\N	\N	\N
1000022	PRO	\N	\N	\N	\N	\N	\N
1000023	ED	\N	\N	\N	\N	\N	\N
1000024	CBDSD	\N	\N	\N	\N	\N	\N
1000025	SC	\N	\N	\N	\N	\N	\N
1000026	CC	\N	\N	\N	\N	\N	\N
1000027	EH	\N	\N	\N	\N	\N	\N
1000028	CFU	\N	\N	\N	\N	\N	\N
1000029	SRB	\N	\N	\N	\N	\N	\N
1000030	MF	\N	\N	\N	\N	\N	\N
1000031	CEP	\N	\N	\N	\N	\N	\N
1000032	MC	\N	\N	\N	\N	\N	\N
1000033	CBT	\N	\N	\N	\N	\N	\N
1000034	HR	\N	\N	\N	\N	\N	\N
1000035	CN	\N	\N	\N	\N	\N	\N
1000036	IN	\N	\N	\N	\N	\N	\N
1000037	LDPS	\N	\N	\N	\N	\N	\N
1000038	IW	\N	\N	\N	\N	\N	\N
1000039	HG	\N	\N	\N	\N	\N	\N
1000040	POU	\N	\N	\N	\N	\N	\N
1000041	SP	\N	\N	\N	\N	\N	\N
1000042	WPC	\N	\N	\N	\N	\N	\N
1000043	CPF	\N	\N	\N	\N	\N	\N
1000044	SAK	\N	\N	\N	\N	\N	\N
1000045	STI	\N	\N	\N	\N	\N	\N
1000046	S	\N	\N	\N	\N	\N	\N
1000047	K	\N	\N	\N	\N	\N	\N
1000048	V	\N	\N	\N	\N	\N	\N
1000049	B	\N	\N	\N	\N	\N	\N
1000050	RP	\N	\N	\N	\N	\N	\N
1000051	RF	\N	\N	\N	\N	\N	\N
1000052	RJD	\N	\N	\N	\N	\N	\N
1000053	UM	\N	\N	\N	\N	\N	\N
1000054	RSS	\N	\N	\N	\N	\N	\N
1000055	MMC	\N	\N	\N	\N	\N	\N
1000056	CCI	\N	\N	\N	\N	\N	\N
1000057	BC	\N	\N	\N	\N	\N	\N
1000058	EC	\N	\N	\N	\N	\N	\N
1000059	SKD	\N	\N	\N	\N	\N	\N
1000060	NF	\N	\N	\N	\N	\N	\N
1000061	FE	\N	\N	\N	\N	\N	\N
1000062	TLG	\N	\N	\N	\N	\N	\N
1000063	AC	\N	\N	\N	\N	\N	\N
1000064	C	\N	\N	\N	\N	\N	\N
1000065	IA	\N	\N	\N	\N	\N	\N
1000066	VI	\N	\N	\N	\N	\N	\N
1000067	ZS	\N	\N	\N	\N	\N	\N
1000068	NA	\N	\N	\N	\N	\N	\N
1000069	DF	\N	\N	\N	\N	\N	\N
1000070	HZOR	\N	\N	\N	\N	\N	\N
1000071	II	\N	\N	\N	\N	\N	\N
1000072	IS	\N	\N	\N	\N	\N	\N
1000073	ACN	\N	\N	\N	\N	\N	\N
1000074	JH	\N	\N	\N	\N	\N	\N
1000075	N	\N	\N	\N	\N	\N	\N
1000076	FU	\N	\N	\N	\N	\N	\N
1000077	RIN	\N	\N	\N	\N	\N	\N
1000078	IC	\N	\N	\N	\N	\N	\N
1000079	ACS	\N	\N	\N	\N	\N	\N
1000080	MW	\N	\N	\N	\N	\N	\N
1000081	MI	\N	\N	\N	\N	\N	\N
1000082	MIO	\N	\N	\N	\N	\N	\N
1000083	ATR	\N	\N	\N	\N	\N	\N
1000084	AN	\N	\N	\N	\N	\N	\N
1000085	CO	\N	\N	\N	\N	\N	\N
1000086	EF	\N	\N	\N	\N	\N	\N
1000087	KF	\N	\N	\N	\N	\N	\N
1000088	SF	\N	\N	\N	\N	\N	\N
1000089	KAF	\N	\N	\N	\N	\N	\N
1000090	AF	\N	\N	\N	\N	\N	\N
1000091	TMF	\N	\N	\N	\N	\N	\N
1000092	CI	\N	\N	\N	\N	\N	\N
1000093	T	\N	\N	\N	\N	\N	\N
1000094	TSS	\N	\N	\N	\N	\N	\N
1000095	FF	\N	\N	\N	\N	\N	\N
1000096	IZS	\N	\N	\N	\N	\N	\N
1000097	MA	\N	\N	\N	\N	\N	\N
1000098	AMI	\N	\N	\N	\N	\N	\N
1000099	CH	\N	\N	\N	\N	\N	\N
1000100	QC	\N	\N	\N	\N	\N	\N
1000101	CD	\N	\N	\N	\N	\N	\N
1000102	RS	\N	\N	\N	\N	\N	\N
1000103	AI	\N	\N	\N	\N	\N	\N
1000104	PP	\N	\N	\N	\N	\N	\N
1000105	I	\N	\N	\N	\N	\N	\N
1000106	EI	\N	\N	\N	\N	\N	\N
1000107	TS	\N	\N	\N	\N	\N	\N
1000108	CT	\N	\N	\N	\N	\N	\N
1000109	DL	\N	\N	\N	\N	\N	\N
1000110	FM	\N	\N	\N	\N	\N	\N
1000111	A	\N	\N	\N	\N	\N	\N
1000112	BL	\N	\N	\N	\N	\N	\N
1000113	PI	\N	\N	\N	\N	\N	\N
1000114	GIB	\N	\N	\N	\N	\N	\N
1000115	UC	\N	\N	\N	\N	\N	\N
1000116	PR	\N	\N	\N	\N	\N	\N
1000117	SE	\N	\N	\N	\N	\N	\N
1000118	SU	\N	\N	\N	\N	\N	\N
1000119	FA	\N	\N	\N	\N	\N	\N
1000120	FN	\N	\N	\N	\N	\N	\N
1000121	FIO	\N	\N	\N	\N	\N	\N
1000122	FC	\N	\N	\N	\N	\N	\N
1000123	ATF	\N	\N	\N	\N	\N	\N
1000124	ARCA	\N	\N	\N	\N	\N	\N
1000125	CONCO	\N	\N	\N	\N	\N	\N
1000126	ATC	\N	\N	\N	\N	\N	\N
1000127	G	\N	\N	\N	\N	\N	\N
1000128	MLG	\N	\N	\N	\N	\N	\N
1000129	ORE	\N	\N	\N	\N	\N	\N
1000130	SEVE	\N	\N	\N	\N	\N	\N
1000131	SCT	\N	\N	\N	\N	\N	\N
1000132	SCC	\N	\N	\N	\N	\N	\N
1000133	SAG	\N	\N	\N	\N	\N	\N
1000134	TBR	\N	\N	\N	\N	\N	\N
1000135	SPC	\N	\N	\N	\N	\N	\N
1000136	GA	\N	\N	\N	\N	\N	\N
1000137	DED	\N	\N	\N	\N	\N	\N
1000138	DOM	\N	\N	\N	\N	\N	\N
1000139	FRL	\N	\N	\N	\N	\N	\N
1000140	GNL	\N	\N	\N	\N	\N	\N
1000141	GUP	\N	\N	\N	\N	\N	\N
1000142	IPR	\N	\N	\N	\N	\N	\N
1000143	ICR	\N	\N	\N	\N	\N	\N
1000144	IBK	\N	\N	\N	\N	\N	\N
1000145	ICM	\N	\N	\N	\N	\N	\N
1000146	ISP	\N	\N	\N	\N	\N	\N
1000147	ISD	\N	\N	\N	\N	\N	\N
1000148	INB	\N	\N	\N	\N	\N	\N
1000149	JVN	\N	\N	\N	\N	\N	\N
1000150	JDR	\N	\N	\N	\N	\N	\N
1000151	KIV	\N	\N	\N	\N	\N	\N
1000152	KTP	\N	\N	\N	\N	\N	\N
1000153	KWK	\N	\N	\N	\N	\N	\N
1000154	NMA	\N	\N	\N	\N	\N	\N
1000155	PRP	\N	\N	\N	\N	\N	\N
1000156	RKN	\N	\N	\N	\N	\N	\N
1000157	SPI	\N	\N	\N	\N	\N	\N
1000158	SPS	\N	\N	\N	\N	\N	\N
1000159	SAN	\N	\N	\N	\N	\N	\N
1000160	TMX	\N	\N	\N	\N	\N	\N
1000161	TCR	\N	\N	\N	\N	\N	\N
1000162	TPW	\N	\N	\N	\N	\N	\N
1000163	TPT	\N	\N	\N	\N	\N	\N
1000164	XSN	\N	\N	\N	\N	\N	\N
1000165	HU	\N	\N	\N	\N	\N	\N
1000166	IAC	\N	\N	\N	\N	\N	\N
1000167	SWA	\N	\N	\N	\N	\N	\N
1000168	FNA	\N	\N	\N	\N	\N	\N
1000169	CAS	\N	\N	\N	\N	\N	\N
1000170	RMS	\N	\N	\N	\N	\N	\N
1000171	RUN	\N	\N	\N	\N	\N	\N
1000172	PTS	\N	\N	\N	\N	\N	\N
1000173	POLAR	\N	\N	\N	\N	\N	\N
1000174	POLBU	\N	\N	\N	\N	\N	\N
1000175	POLEV	511	507	450	\N	\N	\N
1000176	PANNS	\N	\N	\N	\N	\N	\N
1000177	MAI	\N	\N	\N	\N	\N	\N
1000178	AAB	\N	\N	\N	\N	\N	\N
\.


--
-- Name: crpNPCTickerNames crpNPCTickerNames_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpNPCTickerNames"
    ADD CONSTRAINT "crpNPCTickerNames_pkey" PRIMARY KEY ("corporationID");


--
-- PostgreSQL database dump complete
--

\unrestrict WFYtGuBgZq0e0lQ4vsR6s3gbMmSWhWrQSPhf5U3hzAK6aePb4opVHHLbBoNnaL0

