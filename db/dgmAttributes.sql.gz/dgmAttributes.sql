--
-- PostgreSQL database dump
--

\restrict xRc7r36ZgBocVhKrgtujrs9cUja3VQZujFkrjTQVdQdIIVSS3W4KiqAbvu78ild

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dgmAttributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."dgmAttributes" (
    "attributeID" integer DEFAULT 0 NOT NULL,
    "attributeName" text DEFAULT ''::text NOT NULL,
    "attributeCategory" integer DEFAULT 0 NOT NULL,
    description text,
    "maxAttributeID" integer,
    "attributeIdx" integer,
    "graphicID" integer,
    "chargeRechargeTimeID" integer,
    "defaultValue" integer DEFAULT 0 NOT NULL,
    published integer DEFAULT 0 NOT NULL,
    "unitID" integer,
    "displayName" text DEFAULT ''::text NOT NULL,
    stackable integer DEFAULT 0 NOT NULL,
    "highIsGood" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: dgmAttributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."dgmAttributes" ("attributeID", "attributeName", "attributeCategory", description, "maxAttributeID", "attributeIdx", "graphicID", "chargeRechargeTimeID", "defaultValue", published, "unitID", "displayName", stackable, "highIsGood") FROM stdin;
2	isOnline	0	Boolean to store status of online effect	\N	1	\N	\N	0	0	\N	isOnline	1	1
3	damage	1	current damage dealt to module	9	2	\N	\N	0	1	\N	Damage	1	1
4	mass	9	Integer that describes the types mass	\N	\N	409	\N	0	1	2	Mass	1	1
6	capacitorNeed	5	The amount of charge used from the capacitor for a module activation.	\N	\N	1400	\N	0	1	114	activation cost	1	1
8	minRange	4	tbd	\N	\N	1391	\N	0	0	\N	minRange	1	1
9	hp	4	The maximum hitpoints of an object.	\N	\N	408	\N	0	0	\N	hp	1	1
11	powerOutput	4	power output of power core	\N	\N	1400	\N	0	1	107	powergrid Output	1	1
12	lowSlots	4	The number of low power slots on the ship.	\N	\N	295	\N	0	1	122	Low Slots	1	1
13	medSlots	4	tbd	\N	\N	294	\N	0	1	122	Med Slots	1	1
14	hiSlots	4	tbd	\N	\N	293	\N	0	1	122	High Slots	1	1
15	powerLoad	4	Current load of power core	\N	\N	1400	\N	0	1	107	Powerload	1	1
18	charge	6	charge of module	482	3	1668	55	0	0	114	charge	1	1
19	powerToSpeed	4	tbd	\N	\N	\N	\N	0	0	\N	powerToSpeed	1	1
20	speedFactor	5	Factor by which topspeed increases.	\N	\N	1389	\N	1	1	124	Max Velocity Bonus	1	1
21	warpFactor	5	tbd instance param	\N	\N	\N	\N	0	0	\N	warpFactor	1	1
29	warpInhibitor	4	tbd	\N	\N	\N	\N	0	0	\N	warpInhibitor	1	1
30	power	4	current power need	\N	\N	1400	\N	0	1	107	powergrid usage	1	1
31	maxArmor	4	The number of hit points this module can take  	\N	\N	1383	\N	0	0	\N	maxArmor	1	1
32	breakPoint	4	The number of hit points when this module goes offline  	\N	\N	\N	\N	0	0	\N	breakPoint	1	1
37	maxVelocity	4	Maximum velocity of ship	\N	\N	1389	\N	0	1	11	Max Velocity	1	1
38	capacity	9	The cargo space allowed	\N	\N	71	\N	0	1	9	Capacity	1	1
39	damageHP	4	The damage this weapon deals	\N	\N	\N	\N	0	1	105	Damage Repaired Bonus	1	1
47	slots	4	The number of slots this module requires.  Only used for launchers, bays and turrets.	\N	\N	\N	\N	1	0	\N	slots occupied	1	1
48	cpuOutput	4	CPU output of ship	\N	\N	1405	\N	0	1	106	CPU Output	1	1
49	cpuLoad	4	CPU load of ship	\N	\N	1405	\N	0	1	106	CPU Load	1	1
50	cpu	4	CPU need of module	\N	\N	1405	\N	0	1	106	CPU usage	1	1
51	speed	4	Time in milliseconds between possible activations	\N	\N	1397	\N	0	1	101	Rate of fire	0	0
52	damageResistance	5	Substracted before damage application.	\N	\N	\N	\N	0	0	\N	damageResistance	1	1
54	maxRange	4	Distance below which range does not affect the to-hit equation.	\N	\N	1391	\N	0	1	1	Optimal Range	0	1
55	rechargeRate	5	Amount of time taken to fully recharge the capacitor.	\N	\N	1392	\N	0	1	101	Recharge time	1	1
56	chargeRate	4	Number of charges consumed per activation	\N	\N	1397	\N	1	1	\N	Charge Rate	1	1
61	targetModule	4	GroupID of module targeted by this weapon	\N	\N	\N	\N	0	0	\N	targetModule	1	1
63	accuracyBonus	5	Something to do with accuracy.	\N	\N	1399	\N	0	0	\N	accuracyBonus	1	1
64	damageMultiplier	5	Damage multiplier.	\N	\N	1432	\N	1	1	104	Damage Modifier	0	1
65	armorBonus	4	HP bonus to armor.	\N	\N	1383	\N	0	0	\N	armorBonus	1	1
66	durationBonus	5	Bonus to duration.	\N	\N	1392	\N	0	1	105	Duration Bonus	1	1
67	capacitorBonus	4	Extra batteries to add capacitor.	\N	\N	1400	\N	0	1	114	Capacitor Bonus	1	1
68	shieldBonus	5	Bonus to shield.	\N	\N	1384	\N	0	1	\N	shield Bonus	0	1
69	rateBonus	5	Bonus to rate/conversion ratio.	\N	\N	1397	\N	0	0	\N	rateBonus	1	1
70	agility	5	The agility of the object.	\N	\N	1401	\N	0	0	104	agility	1	1
72	capacityBonus	4	Bonus to capacity (shield at least).	\N	\N	69	\N	0	1	113	Shield HP bonus	1	1
73	duration	5	Length of activation time.	\N	\N	1392	\N	0	1	101	Activation time / duration	1	1
75	hpToCapacity	5	DO NOT MESS WITH. How many hp are in one capacity unit	\N	\N	\N	\N	1	0	\N	hpToCapacity	1	1
76	maxTargetRange	5	Maximum range at which the scanner can lock a target.	797	\N	1391	\N	0	1	1	Maximum Targeting Range	0	1
77	miningAmount	4	How much ore gets mined	\N	\N	\N	\N	0	1	118	Mining amount	1	1
79	scanSpeed	4	scanning speed in milliseconds	\N	\N	74	\N	0	0	101	Targeting Speed	0	0
80	speedBonus	4	Amount to increase the maximum speed by.	\N	\N	1389	\N	0	1	11	Speed Bonus	1	1
81	hpFactor	5	Factor to modify the hp by.	\N	\N	\N	\N	0	0	\N	hpFactor	1	1
82	structureBonus	4	Modifier for the maximum structural strength.	\N	\N	\N	\N	0	0	\N	structureBonus	1	1
83	structureDamageAmount	4	An amount to modify the structural damage by.	\N	\N	\N	\N	0	1	\N	Structure hp Repaired	1	1
84	armorDamageAmount	4	An amount to modify the armor damage by.	\N	\N	80	\N	0	1	\N	Armor hp Repaired	1	1
87	shieldTransferRange	4	Maximum range for use of a shield transfer.	\N	\N	1391	\N	0	1	\N	shield Transfer Range	1	1
88	shieldDrainAmount	4	Amount to drain from shield.	\N	\N	1384	\N	0	0	\N	shieldDrainAmount	1	1
89	shieldDrainRange	4	Maximum range shield can be drained at.	\N	\N	\N	\N	0	0	\N	shieldDrainRange	1	1
90	powerTransferAmount	5	Amount of power to transfer.	\N	\N	1033	\N	0	1	\N	Energy transfer amount	1	1
91	powerTransferRange	5	Maximum range to transfer power from.	\N	\N	1391	\N	0	1	1	Transfer range	1	1
92	kineticDampeningFieldStrength	4	The strength of the kinetic dampening field.  If high may nullify projectiles.	\N	\N	\N	\N	0	0	\N	kineticDampeningFieldStrength	1	1
93	kineticDampeningFieldBonus	4	Amount to adjust a kinetic dampening field by.	\N	\N	\N	\N	0	0	\N	kineticDampeningFieldBonus	1	1
95	energyReflectionStrength	4	The strength of the energy reflection field. If high may reflect energy at shooter.	\N	\N	\N	\N	0	0	\N	energyReflectionStrength	1	1
96	energyReflectionBonus	4	Amount to adjust a energy reflection strength by.	\N	\N	\N	\N	0	0	\N	energyReflectionBonus	1	1
97	energyDestabilizationAmount	4	An amount to modify the power of the target by.	\N	\N	1400	\N	0	1	\N	Energy neutralized	1	1
98	energyDestabilizationRange	4	Range of energy destabilizer.	\N	\N	1391	\N	0	1	\N	Range	1	1
99	empFieldRange	4	Range of broadcasted EMP field.	\N	\N	1391	\N	0	1	1	Area of effect	1	1
101	launcherSlotsLeft	4	The number of remaining unused launcher slots.	\N	\N	412	\N	0	1	\N	Launcher hardpoints	1	1
102	turretSlotsLeft	4	Remaining number of unused turret slots on the ship.	\N	\N	414	\N	0	1	\N	Turret hardpoints	1	1
103	warpScrambleRange	4	Maximum range objects can be warp scrambled from.	\N	\N	\N	\N	0	1	\N	Warp Scramble Range	1	1
104	warpScrambleStatus	4	Warp ability of a ship.  If greater than zero than the ship cannot warp.	\N	\N	\N	\N	0	1	\N	Warp Scramble Status	1	1
105	warpScrambleStrength	4	Amount to modify ships warp scramble status by.	\N	\N	111	\N	0	1	\N	Warp Scramble Strength	1	1
106	droneBaySlotsLeft	4	The remaining amount of unused drone bay slots on the ship.	\N	\N	139	\N	0	1	\N	Dronebay hardpoints	1	1
107	explosionRange	4	Range in meters of explosion effect area.	\N	\N	1390	\N	0	0	1	Explosion radius	1	1
108	detonationRange	4	the range in meters for an object to trigger detonation of missile. (own ship excluded)	\N	\N	\N	\N	0	0	1	Detonation proximity	1	1
109	kineticDamageResonance	5	damage multiplier vs. kinetic damagers.	\N	\N	1393	\N	1	1	108	Kinetic dmg resistance	1	1
110	thermalDamageResonance	5	damage multiplier vs. thermal.	\N	\N	1394	\N	1	1	108	Thermal dmg resistance	1	1
111	explosiveDamageResonance	5	damage multiplier vs. explosive damagers.	\N	\N	1395	\N	1	1	108	Explosive dmg resistance	1	1
112	energyDamageAbsorptionFactor	5	Percentage of energy damage that is absorbed as available power.	\N	\N	1400	\N	0	0	\N	energyDamageAbsorptionFactor	1	1
113	emDamageResonance	5	Electro magnetic damage multiplier for shield and armor. Represented as "% Resistance" in the UI.	\N	\N	1396	\N	1	1	108	EM dmg resistance	1	1
114	emDamage	8	EM damage done.	\N	\N	1388	113	0	1	113	EM damage	1	1
116	explosiveDamage	8	Explosive damage done.	\N	\N	1387	111	0	1	113	explosive damage	1	1
117	kineticDamage	8	Kinetic damage done.	\N	\N	1385	109	0	1	113	Kinetic damage	1	1
118	thermalDamage	8	Thermal damage done.	\N	\N	1386	110	0	1	113	Thermal damage	1	1
120	weaponRangeMultiplier	5	Multiplier of range the relevant weapon.	\N	\N	1391	\N	1	1	109	Range bonus	1	1
121	powerOutputBonus	4	Bonus to output of power core.	\N	\N	1384	\N	0	1	107	Power Output Bonus	1	1
122	armorPiercingChance	5	Chance of piercing the armor.	\N	\N	1383	\N	0	0	\N	armorPiercingChance	1	1
123	shieldPiercingChance	5	Chance of piercing the shield.	\N	\N	\N	\N	0	0	\N	shieldPiercingChance	1	1
124	mainColor	7	The main color of a ship type.	\N	\N	\N	\N	0	0	\N	mainColor	1	1
125	shipScanRange	4	Maximum range that something can be ship scanned from.	\N	\N	1391	\N	0	1	1	Ship scanning range	1	1
126	cargoScanRange	4	Maximum range the cargo of a ship can be scanned from.	\N	\N	1391	\N	0	1	1	Cargoscan range	1	1
127	ammoLoaded	11	A temporary attribute for projectile/hybrid weapons to indicate which charges they have loaded when created in newbie ships ala ammo.	\N	\N	\N	\N	0	0	\N	Default ammo loaded	1	1
128	chargeSize	4	The size of the charges that can fit in the turret/whatever.	\N	\N	1666	\N	0	1	117	Charge size	1	1
129	maxPassengers	4	Specifies the maximum numbers of passengers that the ship can have	\N	\N	413	\N	0	0	\N	maxPassengers	1	1
130	thermalDamageResonanceMultiplier	5	Multipler to adjust the thermal damage resonance of an object.	\N	\N	1394	\N	1	1	111	Thermal dmg resistance bonus	1	1
131	kineticDamageResonanceMultiplier	5	Multiplier to the kinetic damage resonance of something.	\N	\N	1393	\N	1	1	111	Kinetic dmg resistance bonus	1	1
132	explosiveDamageResonanceMultiplier	5	Multiplier to the explosive damage resistance of something.	\N	\N	1395	\N	1	1	111	Explosive dmg resistance bonus	1	1
133	emDamageResonanceMultiplier	5	Multiplier to the EM damage resonance of something.	\N	\N	1396	\N	1	1	111	EM dmg resistance bonus	0	0
134	shieldRechargeRateMultiplier	5	Multiplier to a recharge rate time.	\N	\N	1392	\N	1	1	111	Shield recharge rate bonus	1	1
135	moduleSize	4	The size of the module, 1 = small, 2 = medium, 3 = large.  Used for turrets and projectile weapons but will work for any module that defines it.	\N	\N	\N	\N	0	0	\N	moduleSize	1	1
136	uniformity	5	This number is deducted from the %chance of the seeping to armor, to slow seep of damage through shield.	\N	\N	\N	\N	0	0	\N	uniformity	1	1
137	launcherGroup	12	One of the groups of launcher this charge can be loaded into.	\N	\N	\N	\N	0	1	115	Used with (launchergroup)	1	1
138	emDamageBonus	4	+/- amount to the EM damage done.	\N	\N	1388	\N	0	1	113	EM dmg bonus	1	1
139	explosiveDamageBonus	4	+/- amount to the explosive damage done.	\N	\N	1387	\N	0	1	113	Explosive dmg bonus	1	1
140	kineticDamageBonus	4	+/- amount to the kinetic damage done.	\N	\N	1385	\N	0	1	113	Kinetic dmg bonus	1	1
141	thermalDamageBonus	4	+/- bonus to the thermal damage done.	\N	\N	1386	\N	0	1	113	Thermal dmg bonus	1	1
142	ecmBurstRange	4	Range that an ECM burst has an effect within.	\N	\N	1390	\N	0	1	1	ECM Burst Radius	1	1
143	targetHostileRange	4	Range of the automated targeting systems hostile targeting area.	\N	\N	\N	\N	0	1	1	Targeting range	1	1
144	capacitorRechargeRateMultiplier	5	Multiplier to the capacitors recharge rate.	\N	\N	1400	\N	1	1	111	Capacitor recharge rate bonus	1	1
145	powerOutputMultiplier	5	Multipier to power core output.	\N	\N	70	\N	1	1	109	Powergrid bonus	1	1
146	shieldCapacityMultiplier	5	Multiplier to the capacity of a shield.	\N	\N	1384	\N	1	1	109	Shield HP bonus	1	1
147	capacitorCapacityMultiplier	5		\N	\N	1400	\N	1	1	109	Capacitor bonus	1	1
148	armorHPMultiplier	5	Multiplier to the HP of a ships armor module.	\N	\N	1383	\N	1	1	109	Armor HP bonus	1	1
149	cargoCapacityMultiplier	5	Multiplier to the amount of cargo capacity for a ship.	\N	\N	71	\N	1	1	109	Cargo capacity bonus	1	1
150	structureHPMultiplier	5	Multiplier to the ships structural HP.	\N	\N	67	\N	1	1	109	Structure HP bonus	1	1
151	agilityBonus	5	Bonus to the agility for a ship.	\N	\N	1401	\N	1	1	121	Agility bonus	1	1
152	maxPassengersBonus	4	+/- a number to the max passengers.	\N	\N	\N	\N	0	1	\N	Max Passengers Bonus	1	1
153	warpCapacitorNeed	5	The power cost to warp per one kg per AU (floats do not have the resolution for meters).	\N	\N	\N	\N	0	0	\N	warpCapacitorNeed	1	1
154	proximityRange	4	The distance at which to react when relevant objects come within range.	\N	\N	1390	\N	0	1	1	Activation proximity	1	1
156	incapacitationRatio	5	The damage proportion at which an entity becomes incapacitated.	\N	\N	\N	\N	0	0	\N	incapacitationRatio	1	1
157	orbitRange	4	The range at which this thing does it thing.	\N	\N	\N	\N	0	0	\N	orbitRange	1	1
158	falloff	5	distance from maximum range at which accuracy has fallen by half	\N	\N	1399	\N	1	1	1	Accuracy falloff	1	1
160	trackingSpeed	5	Angular speed of turret rotation in radians/seconds	\N	\N	1398	\N	0	1	112	Trackingspeed / Accuracy	0	1
161	volume	9	Volume of things in cubic meters	\N	\N	67	\N	0	1	9	Volume	1	1
162	radius	9	Radius of an object in meters	\N	\N	1390	\N	0	0	\N	radius	1	1
163	dummyDuration	4	Where you want an effect to finish instantly.	\N	\N	\N	\N	0	0	\N	dummyDuration	1	1
164	charisma	4	The charisma of a character.	\N	4	1378	\N	0	1	120	Charisma	1	1
165	intelligence	4	The intelligence of a character.	\N	8	1380	\N	0	1	120	Intelligence	1	1
166	memory	4	The memory of a character.	\N	7	1381	\N	0	1	120	Memory	1	1
167	perception	4	The perception of a character.	\N	6	1382	\N	0	1	120	Perception	1	1
168	willpower	4	The willpower of a character.	\N	5	1379	\N	0	1	120	Willpower	1	1
169	agilityMultiplier	5	Multiplier to the agility of an object.	\N	\N	1401	\N	0	1	121	Inertia Multiplier	1	1
170	customCharismaBonus	4	Bonus to the charisma of a character specified by the player in character creation.	\N	\N	1378	\N	0	0	\N	customCharismaBonus	1	1
171	customWillpowerBonus	4	Bonus to the willpower of a character specified by the player in character creation.	\N	\N	1379	\N	0	0	\N	customWillpowerBonus	1	1
172	customPerceptionBonus	4	Bonus to the perception of a character specified by the player in character creation.	\N	\N	1382	\N	0	0	\N	customPerceptionBonus	1	1
173	customMemoryBonus	4	Bonus to the memory of a character specified by the player in character creation.	\N	\N	1381	\N	0	0	\N	customMemoryBonus	1	1
174	customIntelligenceBonus	4	Bonus to the intelligence of a character specified by the player in character creation.	\N	\N	1380	\N	0	0	\N	customIntelligenceBonus	1	1
175	charismaBonus	4	+/- bonus to the charisma of a character.	\N	\N	1378	\N	0	1	120	Charisma Modifier	1	1
176	intelligenceBonus	4	+/- bonus to the intelligence of a character.	\N	\N	1380	\N	0	1	120	Intelligence Modifier	1	1
177	memoryBonus	4	+/- bonus to the memory of a character.	\N	\N	1381	\N	0	1	\N	Memory Modifier	1	1
178	perceptionBonus	4	+/- bonus to the perception of a character.	\N	\N	1382	\N	0	1	120	Perception Modifier	1	1
179	willpowerBonus	4	+/- bonus to the willpower of a character.	\N	\N	1379	\N	0	1	\N	Willpower Modifier	1	1
180	primaryAttribute	10	Only refers to another dogma attribute.	\N	\N	\N	\N	0	1	119	Primary attribute	1	1
181	secondaryAttribute	10	Only refers to another dogma attribute.	\N	\N	\N	\N	0	1	119	Secondary attribute	1	1
182	requiredSkill1	11	The type ID of the skill that is required.	\N	\N	\N	\N	0	1	116	Primary Skill required	1	1
183	requiredSkill2	11	The type ID of the skill that is required.	\N	\N	\N	\N	0	1	116	Secondary Skill required	1	1
184	requiredSkill3	11	The type ID of the skill that is required.	\N	\N	\N	\N	0	1	116	Tertiary Skill required	1	1
185	attributePoints	4	The number of attribute points needed to be accrued to learn this skill.	\N	\N	\N	\N	0	0	\N	attributePoints	1	1
186	warpCapacitorNeedMultiplier	5	Multiplier to the warping power cost.	\N	\N	\N	\N	0	0	\N	warpCapacitorNeedMultiplier	1	1
187	repairCostMultiplier	5	Multiplier to adjust the cost of repairs.	\N	\N	\N	\N	1	0	\N	repairCostMultiplier	1	1
188	cargoScanResistance	5	Chance of being able to resist a cargo scan.	\N	\N	\N	\N	0	0	\N	cargoScanResistance	1	1
189	targetGroup	12	Restrict activation to this one module group.	\N	\N	\N	\N	0	0	\N	targetGroup	1	1
190	corporationMemberLimit	4	The maximum number of members that a CEO can manage within their corporation.	\N	\N	\N	\N	0	0	\N	corporationMemberLimit	1	1
191	corporationMemberBonus	4	+/- modifier to the number of members that a CEO can manage within their corporation.	\N	\N	\N	\N	0	1	\N	corporation Member Bonus	1	1
192	maxLockedTargets	4	Maximum number of locked targets that the character or their ships electronics can handle at any given time.  Both have individual limits which apply separately.	\N	\N	109	\N	0	1	\N	Max  Locked Targets	1	1
193	maxAttackTargets	4	The maximum number of their targets that the character can attack at a given time.	\N	\N	\N	\N	0	0	\N	maxAttackTargets	1	1
194	jammingResistance	5	The resistance to target jamming.	\N	\N	\N	\N	0	0	\N	jammingResistance	1	1
195	raceID	9	The race ID of the type.	\N	\N	\N	\N	0	0	\N	raceID	1	1
196	manufactureSlotLimit	4	The maximum amount of manufacture slots that can be used at a time.	\N	\N	\N	\N	0	0	\N	manufactureSlotLimit	1	1
197	surveyScanRange	4	Distance from thing to survey.	\N	\N	\N	\N	0	1	1	Surveyscan range	1	1
202	cpuMultiplier	5	Factor to adjust module cpu need by.	\N	\N	1405	\N	1	1	109	CPU Output bonus	1	1
203	miningDurationMultiplier	5	Factor to scale mining laser durations by.	\N	\N	\N	\N	0	0	\N	miningDurationMultiplier	1	1
204	speedMultiplier	5	Typically scales the firing speed of a weapon.  Reducing speed means faster, strangely..	\N	\N	1389	\N	1	1	111	rate of fire bonus	1	1
205	accuracyMultiplier	5	Scales the accuracy of some targeted weapon.	\N	\N	1399	\N	1	0	\N	accuracyMultiplier	1	1
207	miningAmountMultiplier	5	The factor by which the amount mined by a mining laser is scaled.	\N	\N	\N	\N	1	1	\N	Mining Amount Multiplier	0	1
208	scanRadarStrength	5	Radar strength.	\N	\N	2031	\N	0	1	120	RADAR Sensor Strength	0	1
209	scanLadarStrength	5	Ladar strength.	\N	\N	2030	\N	0	1	120	LADAR Sensor Strength	0	1
210	scanMagnetometricStrength	5	Magnetometric strength.	\N	\N	2029	\N	0	1	120	Magnetometric Sensor Strength	0	1
211	scanGravimetricStrength	5	Gravimetric strength.	\N	\N	2028	\N	0	1	120	Gravimetric Sensor Strength	0	1
212	missileDamageMultiplier	5	The characters missile use efficiency, scales the damage missiles do.	\N	\N	\N	\N	1	1	104	Missile Damage Bonus	0	1
213	missileDamageMultiplierBonus	5	Additional percentage to the characters missile damage multiplier.	\N	\N	\N	\N	0	1	109	Missile Damage Bonus	1	1
216	capacitorNeedMultiplier	5	Scales the capacitor need for fitted modules.	\N	\N	1400	\N	1	1	\N	Capacitor Need Multiplier	1	1
217	propulsionGraphicID	4	The graphicID of the propulsion system.	\N	\N	\N	\N	0	0	\N	propulsionGraphicID	1	1
218	blueprintResearchTimeMultiplier	5	Scales the time it takes a character to research a blueprint.	\N	\N	1392	\N	1	0	\N	blueprintResearchTimeMultiplier	1	1
219	manufactureTimeMultiplier	5	Scales the time it takes to manufacture something.	\N	\N	\N	\N	1	0	\N	manufactureTimeMultiplier	1	1
220	blueprintResearchTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to research a blueprint.	\N	\N	1392	\N	0	0	\N	blueprintResearchTimeMultiplierBonus	1	1
221	blueprintManufactureTimeMultiplier	5	Scales the time it takes a character to manufacture a blueprint.	\N	\N	1392	\N	1	0	\N	blueprintManufactureTimeMultiplier	1	1
222	blueprintManufactureTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to manufacture from a blueprint.	\N	\N	1392	\N	0	0	\N	blueprintManufactureTimeMultiplierBonus	1	1
223	charismaSkillTrainingTimeMultiplier	5	Scales the time it takes to train skills with Charisma as the primary attribute.	\N	\N	\N	\N	1	0	\N	charismaSkillTrainingTimeMultiplier	1	1
224	intelligenceSkillTrainingTimeMultiplier	5	Scales the time it takes to train skills with Intelligence as the primary attribute. 	\N	\N	\N	\N	1	0	\N	intelligenceSkillTrainingTimeMultiplier	1	1
225	memorySkillTrainingTimeMultiplier	5	Scales the time it takes to train skills with Memory as the primary attribute.	\N	\N	\N	\N	1	0	\N	memorySkillTrainingTimeMultiplier	1	1
226	perceptionSkillTrainingTimeMultiplier	5	Scales the time it takes to train skills with Perception as the primary attribute.	\N	\N	\N	\N	1	0	\N	perceptionSkillTrainingTimeMultiplier	1	1
227	willpowerSkillTrainingTimeMultiplier	5	Scales the time it takes to train skills with Willpower as the primary attribute.	\N	\N	\N	\N	1	0	\N	willpowerSkillTrainingTimeMultiplier	1	1
228	charismaSkillTrainingTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to train skills with Charisma as the primary attribute.	\N	\N	\N	\N	0	0	\N	charismaSkillTrainingTimeMultiplierBonus	1	1
229	intelligenceSkillTrainingTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to train skills with Intelligence as the primary attribute.	\N	\N	\N	\N	0	0	\N	intelligenceSkillTrainingTimeMultiplierBonus	1	1
230	memorySkillTrainingTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to train skills with Memory as the primary attribute.	\N	\N	\N	\N	0	0	\N	memorySkillTrainingTimeMultiplierBonus	1	1
231	perceptionSkillTrainingTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to train skills with Perception as the primary attribute.	\N	\N	\N	\N	0	0	\N	perceptionSkillTrainingTimeMultiplierBonus	1	1
232	willpowerSkillTrainingTimeMultiplierBonus	5	Bonus or penalty to the percentage time it takes to train skills with Willpower as the primary attribute.	\N	\N	\N	\N	0	0	\N	willpowerSkillTrainingTimeMultiplierBonus	1	1
235	maxLockedTargetsBonus	4	Additional amount of locked targets that can be handled.	\N	\N	\N	\N	0	1	\N	Max Locked Targets Bonus	1	1
236	maxAttackTargetsBonus	4	Additional amount of attack targets that can be handled.	\N	\N	\N	\N	0	0	\N	maxAttackTargetsBonus	1	1
237	maxTargetRangeMultiplier	5	Scales the max target range of a ships electronics.	\N	\N	1391	\N	1	1	109	Targeting Range Bonus	1	1
238	scanGravimetricStrengthBonus	5	+/- modifier to the gravimetric strength of an electronic system.	\N	\N	109	\N	0	1	\N	Gravimetric Strength	0	1
239	scanLadarStrengthBonus	5	+/- modifier to the ladar strength of an electronic system.	\N	\N	109	\N	0	1	\N	LADAR Strength	0	1
240	scanMagnetometricStrengthBonus	5	+/- modifier to the magnetometric strength of an electronic system.	\N	\N	109	\N	0	1	\N	Magnetometric Strength	0	1
241	scanRadarStrengthBonus	5	+/- modifier to the radar strength of an electronic system.	\N	\N	109	\N	0	1	\N	RADAR Strength	0	1
242	scanSpeedMultiplier	5	Scales the time it takes to lock a target.	\N	\N	104	\N	1	0	111	Targeting speed bonus	1	1
243	maxRangeMultiplier	5	Scales the range at which something can reach.	\N	\N	1391	\N	1	1	104	Max Range Multiplier	1	1
244	trackingSpeedMultiplier	5	Scale the tracking speed of a weapon.	\N	\N	1398	\N	1	1	121	Tracking Speed Multiplier	1	1
245	gfxTurretID	4	Graphic ID of the turrets for drone type ships.	\N	\N	\N	\N	0	0	\N	gfxTurretID	1	1
246	gfxBoosterID	4	Graphic ID of the boosters for drone type ships.	\N	\N	\N	\N	0	0	\N	gfxBoosterID	1	1
247	entityAttackRange	4	The distance from a target an entity starts using its weapons.	\N	\N	1391	\N	15000	0	\N	entityAttackRange	1	1
248	entityLootValueMin	4	The minimum value of any given unit of loot dropped by this entity.  Not the minimum value of all the loot, but of any given item dropped.	\N	\N	\N	\N	0	0	\N	entityLootValueMin	1	1
249	entityLootValueMax	4	The maximum value of any loot dropped by this entity.  Thats for each unit of any given item of loot, not for the total value of all items of loot dropped.	\N	\N	\N	\N	0	0	\N	entityLootValueMax	1	1
250	entityLootCountMin	4	The minimum number of pieces of loot dropped by this entity.	\N	\N	\N	\N	0	0	\N	entityLootCountMin	1	1
251	entityLootCountMax	4	The maximum number of pieces of loot dropped by this entity.	\N	\N	\N	\N	0	0	\N	entityLootCountMax	1	1
252	entitySecurityStatusKillBonus	5	How much security status is modified by for killing this entity.  Depending on the entity, this may be a positive or negative amount.	\N	\N	\N	\N	0	1	\N	Security Status Kill Amount	1	1
253	entitySecurityStatusAggressionBonus	5	The amount of security status lost of aggressing agaisnt this entity first.	\N	\N	\N	\N	0	0	\N	entitySecurityStatusAggressionBonus	1	1
254	minLootCount	4	Minimum loot count that an entity can take from the NPC corp loot resource	\N	\N	\N	\N	1	0	\N	minLootCount	1	1
256	maxLootCount	4	Maximum loot count that an entity can take from the NPC corp loot resource	\N	\N	\N	\N	0	0	\N	maxLootCount	1	1
257	entityFollowRange	4	The range in m that the entity follows it's target.	\N	\N	\N	\N	0	0	\N	followRange	1	1
258	minLootValue	4	Minimum value of each resource the entity is able to take as loot.	\N	\N	\N	\N	0	0	\N	minLootValue	1	1
259	maxLootValue	4	Maximum value of each resource the entity is able to take as loot.	\N	\N	\N	\N	0	0	\N	maxLootValue	1	1
260	attackRange	4	The range in m when the entity starts attacking it's target.	\N	\N	1391	\N	0	0	\N	attackRange	1	1
261	killStatusModifier	5	How much the security status changes when this entity is killed.	\N	\N	\N	\N	0	0	\N	killStatusModifier	1	1
262	attackStatusModifier	5	How much the security status changes when this entity is attacked.	\N	\N	\N	\N	0	0	\N	attackStatusModifier	1	1
263	shieldCapacity	5	Amount of maximum shield HP on the item.	\N	\N	1384	\N	0	1	113	Shield Capacity	1	1
264	shieldCharge	6	DO NOT MESS WITH. Helper attribute for entities, stands in for the shield charge.	263	11	0	479	0	0	\N	shieldCharge	1	1
265	armorHP	4	The number of hit points on the entities armor.	\N	\N	1383	\N	0	1	\N	Armor Hitpoints	0	1
266	armorDamage	1	DO NOT MESS WITH. The amount of damage done to the entities armor hit points.	265	10	0	\N	0	1	\N	Armor Damage	1	1
267	armorEmDamageResonance	5	Multiplies EM damage taken by Armor. 	\N	\N	1396	\N	1	1	108	Armor Em Damage Resistance	0	0
268	armorExplosiveDamageResonance	5	Multiplies EXPLOSIVE damage taken by Armor. 	\N	\N	1395	\N	1	1	108	Armor Explosive Damage Resistance	0	0
269	armorKineticDamageResonance	5	Multiplies KINETIC damage taken by Armor. 	\N	\N	1393	\N	1	1	108	Armor Kinetic Damage Resistance	0	0
270	armorThermalDamageResonance	5	Multiplies THERMAL damage taken by Armor. 	\N	\N	1394	\N	1	1	108	Armor Thermal Damage Resistance	0	0
271	shieldEmDamageResonance	5	Multiplies EM damage taken by shield	\N	\N	1396	\N	1	1	108	Shield Em Damage Resistance	0	0
272	shieldExplosiveDamageResonance	5	Multiplies EXPLOSIVE damage taken by Armor. 	\N	\N	1395	\N	1	1	108	Shield Explosive Damage Resistance	0	0
273	shieldKineticDamageResonance	5	Multiplies KINETIC damage taken by Armor. 	\N	\N	1393	\N	1	1	108	Shield Kinetic Damage Resistance	0	0
274	shieldThermalDamageResonance	5	Multiplies THERMAL damage taken by Shield. 	\N	\N	1386	\N	1	1	108	Shield Thermal Damage Resistance	0	0
275	skillTimeConstant	5	Time constant for skill training	\N	\N	1392	\N	0	1	104	Training time multiplier	1	1
276	skillPoints	1	Total accumulated points for skill	\N	9	33	\N	0	1	\N	Skillpoints	1	1
277	requiredSkill1Level	4	Required skill level for skill 1	\N	\N	\N	\N	0	0	\N	requiredSkill1Level	1	1
278	requiredSkill2Level	4	Required skill level for skill 2	\N	\N	\N	\N	0	0	\N	requiredSkill2Level	1	1
279	requiredSkill3Level	4	Required skill level for skill 3	\N	\N	\N	\N	0	0	\N	requiredSkill3Level	1	1
280	skillLevel	4	Level of skill	\N	\N	33	\N	0	1	\N	level	1	1
281	explosionDelay	4	The amount of milliseconds before the object explodes.	\N	\N	1392	\N	60000	1	3	Max Flight Time	1	1
282	launcherCapacityMultiplier	5	Multiplier to the amount of charge storage space in a launcher.	\N	\N	0	\N	1	0	104	launcherCapacityMultiplier	1	1
283	droneCapacity	5	This defines the total capacity of drones allowed in the drone bay of the ship	\N	\N	76	\N	0	1	9	Drone Capacity	1	1
284	excludeGangMembers	3	Indicates whether the modules ranged effects exlude  members of the users gang.	\N	\N	0	\N	0	0	\N	excludeGangMembers	1	1
285	excludeCorporationMembers	3	Indicates whether the modules ranged effects exlude  members of the users corporation.	\N	\N	0	\N	0	0	\N	excludeCorporationMembers	1	1
286	excludeHostiles	3	Indicates whether the modules ranged effects exclude ships hostile to the user.	\N	\N	0	\N	0	0	\N	excludeHostiles	1	1
287	kDmgBonus	4	Autogenerated skill attribute, kDmgBonus	\N	\N	0	\N	0	0	\N	kDmgBonus	1	1
288	shipCPUBonus	4	Autogenerated skill attribute, shipCPUBonus	\N	\N	0	\N	0	0	\N	shipCPUBonus	1	1
289	turretDamageBonus	4	Autogenerated skill attribute, turretDamageBonus	\N	\N	0	\N	0	0	\N	turretDamageBonus	1	1
290	skillTurretDmgBonus	4	Autogenerated skill attribute, skillTurretDmgBonus	\N	\N	0	\N	0	0	\N	skillTurretDmgBonus	1	1
291	cpuskillBonus	4	Autogenerated skill attribute, CpuskillBonus	\N	\N	0	\N	0	1	\N	CpuskillBonus	1	1
292	damageMultiplierBonus	4	Autogenerated skill attribute, damageMultiplierBonus	\N	\N	1432	\N	0	1	105	Damage Multiplier Bonus	1	1
293	rofBonus	4	Autogenerated skill attribute, rofBonus	\N	\N	1397	\N	0	1	105	Rate Of Fire Bonus	1	1
294	rangeSkillBonus	4	Autogenerated skill attribute, rangeSkillBonus	\N	\N	0	\N	0	1	121	Optimal Range Modifier	1	1
295	abPowerBonus	4	Autogenerated skill attribute, abPowerBonus	\N	\N	1400	\N	0	0	\N	abPowerBonus	1	1
296	acPowerBonus	4	Autogenerated skill attribute, acPowerBonus	\N	\N	1400	\N	0	0	\N	acPowerBonus	1	1
297	afPowerBonus	4	Autogenerated skill attribute, afPowerBonus	\N	\N	1400	\N	0	0	\N	afPowerBonus	1	1
298	atPowerBonus	4	Autogenerated skill attribute, atPowerBonus	\N	\N	0	\N	0	0	\N	atPowerBonus	1	1
299	cbTRangeBonus	4	Autogenerated skill attribute, cbTRangeBonus	\N	\N	0	\N	0	0	\N	cbTRangeBonus	1	1
300	ccTRangeBonus	4	Autogenerated skill attribute, ccTRangeBonus	\N	\N	0	\N	0	0	\N	ccTRangeBonus	1	1
301	cfTRangeBonus	4	Autogenerated skill attribute, cfTRangeBonus	\N	\N	0	\N	0	0	\N	cfTRangeBonus	1	1
302	ciTRangeBonus	4	Autogenerated skill attribute, ciTRangeBonus	\N	\N	0	\N	0	0	\N	ciTRangeBonus	1	1
303	aiPowerBonus	4	Autogenerated skill attribute, aiPowerBonus	\N	\N	0	\N	0	0	\N	aiPowerBonus	1	1
304	ctTRangeBonus	4	Autogenerated skill attribute, ctTRangeBonus	\N	\N	0	\N	0	0	\N	ctTRangeBonus	1	1
305	gbCpuBonus	4	Autogenerated skill attribute, gbCpuBonus	\N	\N	0	\N	0	0	\N	gbCpuBonus	1	1
306	maxVelocityBonus	5	Autogenerated skill attribute, mMaxVelocityBonus	\N	\N	1389	\N	0	1	109	Maximum Velocity Penalty	1	1
307	scannerDurationBonus	4	Autogenerated skill attribute, scannerDurationBonus	\N	\N	1392	\N	0	0	\N	scannerDurationBonus	1	1
308	scanspeedBonus	4	Autogenerated skill attribute, scanspeedBonus	\N	\N	0	\N	0	1	105	Scan Speed Bonus	1	1
309	maxTargetRangeBonus	4	Autogenerated skill attribute, MaxTargetRangeBonus	\N	\N	0	\N	0	1	\N	MaxTargetRangeBonus	1	1
310	cpuNeedBonus	4	Autogenerated skill attribute, cpuNeedBonus	\N	\N	0	\N	0	0	\N	cpuNeedBonus	1	1
311	maxTargetBonus	4	Autogenerated skill attribute, maxTarget Bonus	\N	\N	0	\N	0	1	105	Max Target Bonus	1	1
312	durationSkillBonus	4	Autogenerated skill attribute, DurationBonus	\N	\N	1392	\N	0	1	121	Duration Bonus	1	1
313	powerEngineeringOutputBonus	4	Autogenerated skill attribute, PowerOutputBonus	\N	\N	1400	\N	0	1	\N	PowerOutputBonus	1	1
314	capRechargeBonus	4	Autogenerated skill attribute, CapRechargeBonus	\N	\N	1400	\N	0	1	\N	Cap Recharge Time Reduction	1	1
315	velocityBonus	4	Autogenerated skill attribute, velocityBonus	\N	\N	1389	\N	0	1	121	Velocity Modifier	1	1
316	corpMemberBonus	4	Autogenerated skill attribute, corpMemberBonus	\N	\N	0	\N	0	0	\N	corpMemberBonus	1	1
317	capNeedBonus	4	Autogenerated skill attribute, capNeedBonus	\N	\N	1400	\N	0	1	105	Capacitor Need Bonus	1	1
318	speedFBonus	4	Autogenerated skill attribute, speedFBonus	\N	\N	1389	\N	0	1	\N	speed Bonus	1	1
319	warpCapacitorNeedBonus	4	Autogenerated skill attribute, warpCapacitorNeedBonus	\N	\N	0	\N	0	1	124	Warp Capacitor Need Bonus	1	1
320	powerUseBonus	4	Autogenerated skill attribute, powerUseBonus	\N	\N	0	\N	0	0	\N	powerUseBonus	1	1
321	burstSpeed	4		\N	\N	1397	\N	0	1	3	Burst Rate Of Fire	1	1
322	burstSpeedMutator	4		\N	\N	0	\N	0	1	\N	Burst Speed Mutator	1	1
323	powerNeedBonus	5	Autogenerated skill attribute, PowerNeedBonus	\N	\N	1400	\N	0	1	\N	PowerNeedBonus	1	1
324	barrageDmgMutator	4		\N	\N	0	\N	0	0	\N	Barrage Damage Bonus	1	1
325	barrageFalloffMutator	4		\N	\N	0	\N	0	0	\N	Barrage falloff Penalty	1	1
326	barrageDmgMultiplier	4		\N	\N	0	\N	0	0	\N	Barrage damage multiplier	1	1
327	hullHpBonus	4	Autogenerated skill attribute, hullHpBonus	\N	\N	0	\N	0	1	105	Hull Hp Bonus	1	1
328	barrageFalloff	4		\N	\N	0	\N	75	0	\N	Barrage Falloff	1	1
329	gangRofBonus	4	Autogenerated skill attribute, GangRofBonus	\N	\N	0	\N	0	1	\N	GangRofBonus	1	1
330	boosterDuration	4	Duration of booster, after this duration the booster is destroyed	\N	\N	1392	\N	0	1	123	Booster Duration	1	1
331	implantness	4	Whether an item is an implant or not	\N	\N	2224	\N	0	1	\N	Implant Slot	1	1
332	burstDmg	4		\N	\N	0	\N	0	0	\N	burstDmg	1	1
333	burstDmgMutator	3		\N	\N	0	\N	0	0	\N	burstDmgMutator	1	1
334	shipPowerBonus	4	Autogenerated skill attribute, shipPowerBonus	\N	\N	0	\N	0	0	\N	shipPowerBonus	1	1
335	armorHpBonus	4	Autogenerated skill attribute, armorHpBonus	\N	\N	1383	\N	0	1	\N	Armor Hp Bonus	1	1
336	uniformityBonus	4	Autogenerated skill attribute, uniformityBonus	\N	\N	0	\N	0	1	105	Uniformity Bonus	1	1
337	shieldCapacityBonus	4	Autogenerated skill attribute, shieldCapacityBonus	\N	\N	0	\N	0	1	121	Shield Capacity Bonus	1	1
338	rechargeratebonus	4	Autogenerated skill attribute, rechargeratebonus	\N	\N	1392	\N	0	1	105	Rechargerate Bonus	1	1
349	falloffBonus	4	Autogenerated skill attribute, falloffBonus	\N	\N	1399	\N	0	1	105	Falloff Bonus	1	1
350	skillTrainingTimeBonus	4	Autogenerated skill attribute, skillTrainingTimeBonus	\N	\N	0	\N	0	0	\N	skillTrainingTimeBonus	1	1
351	maxRangeBonus	4	Autogenerated skill attribute, maxRangeBonus	\N	\N	1391	\N	0	1	\N	Optimal Range Bonus	1	1
352	maxActiveDrones	4	The maximum amount of drones that a character can control at a given time.	\N	\N	0	\N	0	0	\N	maxActiveDrones	1	1
353	maxActiveDroneBonus	4	Autogenerated skill attribute, maxActiveDroneBonus	\N	\N	0	\N	0	1	\N	Max Active Drone Bonus	1	1
354	maxDroneBonus	4	Autogenerated skill attribute, maxDroneBonus	\N	\N	0	\N	0	0	\N	maxDroneBonus	1	1
355	negotiationPercentage	5	Percentage of pay from agent 	\N	\N	0	\N	1	1	\N	Negotiation Multiplyer	1	1
356	diplomacyBonus	5	Bonus to Effective Standing towards Hostile NPC	\N	\N	0	\N	0	1	\N	Diplomacy Bonus	1	1
359	fastTalkPercentage	5	a percentage multiplyer to sec status recovery	\N	\N	0	\N	100	1	\N	Fast Talk Percentage	1	1
360	connectionsBonus	5	Bonus to standing towards Friendly npcs	\N	\N	0	\N	0	1	\N	Connections Bonus	1	1
361	criminalConnectionsBonus	5	a bonus to standing towards npc with negativa security status	\N	\N	0	\N	0	1	\N	Criminal Connections Bonus	1	1
362	socialBonus	5	Bonus To standing gain towards non CONCORD npcs  	\N	\N	0	\N	100	1	\N	Social Bonus	1	1
363	amarrTechTimePercent	4	Production time multiplier when manufacturing amarr tech   	\N	\N	0	\N	100	1	\N	Amarr Tech	1	1
364	minmatarTechTimePercent	4	Production time multiplier when manufacturing Minmatar tech   	\N	\N	0	\N	100	1	\N	Minmatar Tech	1	1
365	gallenteTechTimePercent	4	Production time multiplier when manufacturing Gallente tech   	\N	\N	0	\N	0	1	\N	GallenteTech	1	1
366	caldariTechTimePercent	4	Production time multiplier when manufacturing caldari tech   	\N	\N	0	\N	0	1	\N	Caldari Tech	1	1
367	productionTimePercent	4	Production time percentage	\N	\N	0	\N	100	1	\N	Production time percent	1	1
368	refiningTimePercentage	4	Refining speed percentage	\N	\N	0	\N	100	1	\N	refining pime percentage	1	1
369	manufactureCostMultiplier	5	Manufacturing cost multiplyer	\N	\N	0	\N	1	1	\N	manufacture cost Multiplyer	1	1
370	amarrTechMutator	4	Autogenerated skill attribute, amarrTechMutator	\N	\N	0	\N	0	0	\N	amarrTechMutator	1	1
371	caldariTechMutator	4	Autogenerated skill attribute, caldariTechMutator	\N	\N	0	\N	0	0	\N	caldariTechMutator	1	1
372	gallenteTechMutator	4	Autogenerated skill attribute, gallenteTechMutator	\N	\N	0	\N	0	0	\N	gallenteTechMutator	1	1
373	productionTimeMutator	4	Autogenerated skill attribute, productionTimeMutator	\N	\N	0	\N	0	0	\N	productionTimeMutator	1	1
374	minmatarTechMutator	4	Autogenerated skill attribute, minmatarTechMutator	\N	\N	0	\N	0	0	\N	minmatarTechMutator	1	1
375	productionCostMutator	4	Autogenerated skill attribute, productionCostMutator	\N	\N	0	\N	0	0	\N	productionCostMutator	1	1
376	refiningTimePercent	4	Refining time Multiplier	\N	\N	0	\N	100	1	\N	Refining time Multiplier	1	1
377	refiningTimeMutator	4	Autogenerated skill attribute, refiningTimeMutator	\N	\N	0	\N	0	0	\N	refiningTimeMutator	1	1
378	refiningYieldPercentage	5	Refining yield percentage	\N	\N	0	\N	0	1	\N	Refining yield percentage	1	1
379	refiningYieldMutator	4	Autogenerated skill attribute, refiningYieldMutator	\N	\N	0	\N	0	1	105	Refining Yield Mutator	1	1
380	maxActiveFactory	4	Max active factories that a player can operate 	\N	\N	0	\N	0	1	\N	Max active factory	1	1
383	maxActiveFactories	4	Max active factories	\N	\N	0	\N	0	1	\N	Max active factories	1	1
384	maxResearchGangSize	4	The max numbers of scientists that can work on CSO´s research project.	\N	\N	0	\N	0	1	\N	Max research gang size	1	1
385	manufacturingTimeResearchSpeed	5	Research speed 	\N	\N	0	\N	1	1	\N	Production time research speed	1	1
386	researchCostPercent	4	Research cost percent	\N	\N	0	\N	100	1	\N	Research cost percent	1	1
387	copySpeedPercent	5	Blueprint copying speed	\N	\N	0	\N	1	1	\N	Blueprint copying speed	1	1
388	frigateConstructionCost	4	The % of Frigate assembly cost a player has to pay to assemble a frigate	\N	\N	0	\N	100	1	\N	Frigate construction cost	1	1
389	cruiserConstructionCost	4	The % of cruiser assembly cost a player has to pay to assemble a cruiser	\N	\N	0	\N	0	1	\N	Cruiser construction cost	1	1
392	industrialConstructionCost	4	The % of industrial assembly cost a player has to pay to assemble a industrial	\N	\N	0	\N	0	1	\N	Industrial construction cost	1	1
393	battleshipConstructionCost	4	The % of battleship assembly cost a player has to pay to assemble a battleship	\N	\N	1392	\N	0	1	\N	Battleship construction cost	1	1
394	titanConstructionTime	4	Titan construction time	\N	\N	0	\N	100	1	\N	Titan construction time	1	1
395	stationConstructionTime	4	Station construction time	\N	\N	0	\N	100	1	\N	Station construction time	1	1
396	repairCostPercent	4	Repair cost percent	\N	\N	0	\N	100	1	\N	Repair cost percent	1	1
397	reverseEngineeringChance	4	Chance of making a research breakthrough when researching a higher tech level of a blueprint	\N	\N	0	\N	0	1	\N	Breakthrough percent	1	1
398	mineralNeedResearchSpeed	5	speed bonus when researching blueprint mineral need	\N	\N	0	\N	1	1	\N	Mineral need research speed	1	1
399	duplicatingChance	4	Chance of upgrading a module to next tech level 	\N	\N	0	\N	0	1	\N	prototypingChance	1	1
400	missileStandardVelocityPecent	4	Missiles velocity multiplier	\N	\N	0	\N	100	0	\N	missileVelocityPecent	1	1
401	cruiseMissileVelocityPercent	5	Damage Bonus for Cruise Missiles	\N	\N	0	\N	0	0	\N	Cruise missile Velocity percent	1	1
402	heavyMissileSpeedPercent	5	Heavy missile speed percent	\N	\N	0	\N	0	0	\N	Heavy missile speed  percent	1	1
403	rocketDmgPercent	4	Rocket Dmg Percent	\N	\N	0	\N	0	1	105	Rocket Dmg Percent	1	1
404	torpedoVelocityPercent	5	Torpedo velocity percent	\N	\N	0	\N	0	0	\N	Torpedo velocity percent	1	1
405	defenderVelocityPercent	4	Defender velocity percent	\N	\N	0	\N	100	1	105	Defender velocity percent	1	1
406	missileFOFVelocityPercent	5	Missile FOF velocity percent	\N	\N	0	\N	100	0	\N	Missile FOF velocity percent	1	1
407	researchGangSizeBonus	4	Max research gang size bonus	\N	\N	0	\N	0	0	\N	Research gang size bonus	1	1
408	battleshipConstructionTimeBonus	4	Autogenerated skill attribute, battleshipConstructionTimeBonus	\N	\N	1392	\N	0	0	\N	battleshipConstructionTimeBonus	1	1
409	cruiserConstructionTimeBonus	4	Autogenerated skill attribute, cruiserConstructionTimeBonus	\N	\N	0	\N	0	0	\N	cruiserConstructionTimeBonus	1	1
410	frigateConstructionTimeBonus	4	Autogenerated skill attribute, frigateConstructionTimeBonus	\N	\N	0	\N	0	0	\N	frigateConstructionTimeBonus	1	1
411	industrialConstructionTimeBonus	4	Autogenerated skill attribute, industrialConstructionTimeBonus	\N	\N	0	\N	0	0	\N	industrialConstructionTimeBonus	1	1
412	connectionBonusMutator	5	Autogenerated skill attribute, connectionBonusMutator	\N	\N	0	\N	0	0	\N	connectionBonusMutator	1	1
413	criminalConnectionsMutator	5	Autogenerated skill attribute, criminalConnectionsMutator	\N	\N	0	\N	0	1	\N	Criminal Connections Mutator	1	1
414	diplomacyMutator	5	Autogenerated skill attribute, diplomacyMutator	\N	\N	0	\N	0	1	\N	Diplomacy Mutator	1	1
415	fastTalkMutator	4	Autogenerated skill attribute, fastTalkMutator	\N	\N	0	\N	0	0	\N	fastTalkMutator	1	1
416	entityFlyRange	4	The distance at which the entity orbits, follows.. and more.	\N	\N	0	\N	500	0	\N	entityFlyRange	1	1
417	maxNonRaceCorporationMembers	4	Max non  race corporationMembers	\N	\N	0	\N	0	1	\N	Max non  race corporationMembers	1	1
418	nonRaceCorporationMembersBonus	4	Autogenerated skill attribute, nonRaceCorporationMembersBonus	\N	\N	0	\N	0	1	\N	non Race Corporation Members Bonus	1	1
419	skillPointsSaved	4	Amount of skill points saved by clone	\N	\N	33	\N	10000	1	\N	Skill Points Saved	1	1
420	trackingBonus	4	Autogenerated skill attribute, trackingBonus	\N	\N	0	\N	0	0	121	trackingBonus	1	1
421	shieldRechargerateBonus	4	Autogenerated skill attribute, shieldRechargerateBonus	\N	\N	0	\N	0	0	\N	shieldRechargerateBonus	1	1
422	techLevel	4	Tech level of an item	\N	\N	1446	\N	0	1	\N	Tech Level	1	1
423	entityDroneCount	4		\N	\N	0	\N	0	0	\N	entityDroneCount	1	1
424	cpu OutputBonus	4	Autogenerated skill attribute, cpu OutputBonus	\N	\N	0	\N	0	1	105	cpu Output Bonus	1	1
425	cpuOutputBonus	4	Autogenerated skill attribute, cpuOutputBonus	\N	\N	0	\N	0	0	\N	cpuOutputBonus	1	1
426	heavyDroneDamagePercent	5		\N	\N	0	\N	1	1	109	droneDamagePercent	1	1
427	heavyDroneDamageBonus	4	Autogenerated skill attribute, heavyDroneDamageBonus	\N	\N	0	\N	0	0	\N	heavyDroneDamageBonus	1	1
428	miningDroneAmountPercent	4	Mining drone speed percent	\N	\N	0	\N	100	1	\N	miningDroneSpeedPercent	1	1
429	miningDroneSpeedBonus	4	Autogenerated skill attribute, miningDroneSpeedBonus	\N	\N	0	\N	0	0	\N	miningDroneSpeedBonus	1	1
430	scoutDroneVelocityPercent	4		\N	\N	0	\N	100	0	\N	scoutDroneVelocityPercent	1	1
431	scoutDroneVelocityBonus	4	Autogenerated skill attribute, scoutDroneVelocityBonus	\N	\N	0	\N	0	0	\N	scoutDroneVelocityBonus	1	1
432	defenderVelocityBonus	4	Autogenerated skill attribute, defenderVelocityBonus	\N	\N	0	\N	0	1	\N	Velocity Bonus	1	1
433	heavyMissileDamageBonus	4	Autogenerated skill attribute, heavyMissileDamageBonus	\N	\N	0	\N	0	0	\N	heavyMissileDamageBonus	1	1
434	miningAmountBonus	4	Autogenerated skill attribute, miningAmountBonus	\N	\N	0	\N	0	1	105	Mining Amount Bonus	1	1
435	maxGangModules	4		\N	\N	0	\N	3	1	\N	max Active Command Relays Bonus	1	1
436	standingIncreasePercent	4		\N	\N	0	\N	100	0	105	standingIncreasePercent	1	1
437	negotiationBonus	4	Autogenerated skill attribute, NegotiationBonus	\N	\N	0	\N	0	1	\N	NegotiationBonus	1	1
438	socialMutator	4	Autogenerated skill attribute, socialMutator	\N	\N	0	\N	0	1	105	Social Mutator	1	1
439	targetingSpeedBonus	4	Autogenerated skill attribute, targetingSpeedBonus	\N	\N	0	\N	0	0	\N	targetingSpeedBonus	1	1
440	manufacturingTimeBonus	4	Autogenerated skill attribute, manufacturingTimeBonus	\N	\N	0	\N	0	1	105	Manufacturing Time Bonus	1	1
441	turretSpeeBonus	4	Autogenerated skill attribute, TurretSpeeBonus	\N	\N	0	\N	0	1	121	Turret speed bonus	1	1
442	barterDiscount	5	skill discount when selling to npc corps	\N	\N	0	\N	0	0	\N	barterDiscount	1	1
443	tradePremium	5	price bonus when selling to npc corps\n	\N	\N	0	\N	0	1	\N	Trade premium	1	1
444	contrabandFencingChance	5	Chance of being caught selling contraband on market. 	\N	\N	0	\N	0	1	\N	Contraband fencing chance	1	1
445	smugglingChance	5	Chance of being caught Transporting contraband. 	\N	\N	0	\N	0	0	\N	smugglingChance	1	1
446	tradePremiumBonus	4	Autogenerated skill attribute, tradePremiumBonus	\N	\N	0	\N	0	0	\N	tradePremiumBonus	1	1
447	smugglingChanceBonus	5	Autogenerated skill attribute, smugglingChanceBonus	\N	\N	1196	\N	0	1	105	Smuggling Chance Bonus	1	1
448	fencingChanceBonus	4	Autogenerated skill attribute, fencingChanceBonus	\N	\N	0	\N	0	0	\N	fencingChanceBonus	1	1
449	barterDiscountBonus	4	Autogenerated skill attribute, BarterDiscountBonus	\N	\N	0	\N	0	1	\N	BarterDiscountBonus	1	1
450	manufacturingSlotBonus	4	Autogenerated skill attribute, manufacturingSlotBonus	\N	\N	0	\N	0	1	\N	Manufacturing Slot Bonus	1	1
451	manufactureCostBonus	4	Autogenerated skill attribute, manufactureCostBonus	\N	\N	0	\N	0	1	105	Manufacture Cost Bonus	1	1
452	copySpeedBonus	4	Autogenerated skill attribute, CopySpeedBonus	\N	\N	0	\N	0	1	\N	Copy Speed Bonus	1	1
453	blueprintmanufactureTimeBonus	4	Autogenerated skill attribute, blueprintmanufactureTimeBonus	\N	\N	0	\N	0	1	105	Blueprint Manufacture Time Bonus	1	1
454	mutaton	4		\N	\N	0	\N	0	0	\N	mutaton	1	1
455	learningBonus	4	Autogenerated skill attribute, learningBonus	\N	\N	0	\N	0	1	105	Learning Bonus	1	1
456	entityEquipmentMin	4		\N	\N	0	\N	0	0	\N	entityEquipmentMin	1	1
457	entityEquipmentMax	4		\N	\N	0	\N	0	0	\N	entityEquipmentMax	1	1
458	droneControlDistance	4		\N	\N	0	\N	20000	1	1	Max drone control distance	1	1
459	droneRangeBonus	4	Autogenerated skill attribute, droneRangeBonus	\N	\N	0	\N	0	1	105	Drone Control Range Bonus	1	1
460	shipBonusMF	4		\N	\N	0	\N	0	1	105	Special Ability Bonus	1	1
461	specialAbilityBonus	4	Autogenerated skill attribute, specialAbilityBonus	\N	\N	0	\N	0	0	\N	specialAbilityBonus	1	1
462	shipBonusGF	5		\N	\N	0	\N	0	0	\N	shipBonusGF	1	1
463	shipBonusCF	4		\N	\N	0	\N	0	0	\N	shipBonusCF	1	1
464	shipBonusAF	4		\N	\N	0	\N	0	0	\N	shipBonusAF	1	1
465	entityEquipmentGroupMax	4	The maximum drops of same group (example: entity can only drop 1 of group: energy laser)	\N	\N	0	\N	1	0	\N	entityEquipmentGroupMax	1	1
466	entityReactionFactor	5	The chance of an entity attacking the same person as its group members.  Scales delay in joining in on fights too.	\N	\N	0	\N	1	0	\N	entityReactionFactor	1	1
467	maxLaborotorySlots	4		\N	\N	0	\N	1	1	\N	Max Active Laboratories	1	1
468	mineralNeedResearchBonus	4	Autogenerated skill attribute, mineralNeedResearchBonus	\N	\N	0	\N	0	1	105	Mineral Need Research Bonus	1	1
469	entityBluePrintDropChance	5		\N	\N	0	\N	0	0	\N	entityBluePrintDropChance	1	1
470	lootRespawnTime	4	The number of milliseconds before the container replenishes the loot inside itself.	\N	\N	0	\N	600000	0	101	lootRespawnTime	1	1
471	laboratorySlotsBonus	4	Autogenerated skill attribute, laboratorySlotsBonus	\N	\N	0	\N	0	0	\N	laboratorySlotsBonus	1	1
472	stationTypeID	11	The type of station this platform can be used to build.	\N	\N	0	\N	0	1	116	Station Type	1	1
473	prototypingBonus	4	Autogenerated skill attribute, prototypingBonus	\N	\N	0	\N	0	0	\N	prototypingBonus	1	1
474	inventionBonus	4	Autogenerated skill attribute, inventionBonus	\N	\N	0	\N	0	0	\N	inventionBonus	1	1
475	entityAttackDelayMin	4	Minimum attack delay time for entity.	\N	\N	0	\N	0	0	\N	entityAttackDelayMin	1	1
476	entityAttackDelayMax	4	Maximum attack delay time for entity.	\N	\N	0	\N	0	0	\N	entityAttackDelayMax	1	1
478	shipBonusAC	4		\N	\N	0	\N	0	0	\N	shipBonusAC	1	1
479	shieldRechargeRate	5	Amount of time taken to fully recharge the shield.	\N	\N	1392	\N	0	1	101	Shield recharge time	1	1
480	maxEffectiveRange	5		\N	\N	0	\N	0	0	1	maxEffectiveRange	1	1
481	entityKillBounty	4	Reward for destroying this entity.	\N	\N	0	\N	0	1	\N	Bounty	1	1
482	capacitorCapacity	5	Capacitor capacity	\N	\N	0	\N	0	1	114	Capacitor Capacity	1	1
484	shieldUniformity	5	DO NOT MESS WITH This number is deducted from the %chance of the seeping to armor, to slow seep of damage through shield.	\N	\N	\N	\N	0	0	\N	Shield Uniformity	1	1
485	shipBonus2AF	4		\N	\N	0	\N	5	0	\N	shipBonus2AF	1	1
486	shipBonusGC	4		\N	\N	0	\N	5	0	\N	shipBonusGC	1	1
487	shipBonusCC	4		\N	\N	0	\N	5	0	\N	shipBonusCC	1	1
488	shipVelocityBonusMC	4		\N	\N	0	\N	5	0	\N	shipVelocityBonusMC	1	1
489	shipBonusMC	4		\N	\N	0	\N	0	0	\N	shipBonusMC	1	1
490	shipBonusMB	4		\N	\N	0	\N	5	0	\N	shipBonusMB	1	1
491	shipBonusCB	4		\N	\N	0	\N	5	0	\N	shipBonusCB	1	1
492	shipBonusAB	4		\N	\N	0	\N	5	0	\N	shipBonusAB	1	1
493	shipBonusMI	4		\N	\N	0	\N	5	0	\N	shipBonusMI	1	1
494	shipBonusAI	4		\N	\N	0	\N	5	0	\N	shipBonusAI	1	1
495	shipBonusCI	4		\N	\N	0	\N	5	0	\N	shipBonusCI	1	1
496	shipBonusGI	4		\N	\N	0	\N	5	0	\N	shipBonusGI	1	1
497	entityDefenderChance	5	% chance of entity to shoot defender at incoming missile	\N	\N	0	\N	0	0	\N	entityDefenderChance	1	1
499	droneCapacityBonus	4		\N	\N	0	\N	0	0	\N	droneCapacityBonus	1	1
500	shipBonusGB	5		\N	\N	0	\N	0	0	\N	shipBonusGB	1	1
501	shipBonus2CB	4		\N	\N	0	\N	0	0	\N	shipBonus2CB	1	1
502	entityConvoyDroneMin	4	Minimum number of drones the convoy can have for protection.	\N	\N	0	\N	1	0	\N	entityConvoyDroneMin	1	1
503	entityConvoyDroneMax	4	Maximum number of convoy drones a convoy can have for proetcion.	\N	\N	0	\N	1	0	\N	entityConvoyDroneMax	1	1
504	entityWarpScrambleChance	5	Chance of entity warp scrambling it's target.	\N	\N	0	\N	0	0	\N	entityWarpScrambleChance	1	1
505	warpScrambleDuration	5		\N	\N	0	\N	8000	1	3	Duration	1	1
506	missileLaunchDuration	5		\N	\N	0	\N	20000	0	3	missileLaunchDuration	1	1
507	entityMissileTypeID	11	The type of missiles the entity launches.	\N	\N	0	\N	0	0	116	Missile Type	1	1
508	entityCruiseSpeed	4	The speed that entities fly at when not chasing a target.	\N	\N	0	\N	0	1	\N	Orbit Velocity	1	1
509	cargoScanFalloff	5	Distance from maximum range at which accuracy has fallen by half.	\N	\N	0	\N	0	0	1	cargoScanFalloff	1	1
510	shipScanFalloff	5	Distance from maximum range at which accuracy has fallen by half.	\N	\N	0	\N	0	1	1	Ship Scan Falloff	1	1
511	shipScanResistance	5	Chance of being able to resist a ship scan.	\N	\N	0	\N	0	0	121	shipScanResistance	1	1
512	modifyTargetSpeedChance	5	Chance that  an entity will use a Stasis Web on a target.	\N	\N	0	\N	0	0	\N	modifyTargetSpeedChance	1	1
513	modifyTargetSpeedDuration	5	Duration of entities Stasis Web 	\N	\N	0	\N	5000	0	3	modifyTargetSpeedDuration	1	1
514	modifyTargetSpeedRange	4	Range of entities Stasis Web	\N	\N	0	\N	20000	0	1	modifyTargetSpeedRange	1	1
515	modifyTargetSpeedCapacitorNeed	4		\N	\N	0	\N	0	0	\N	modifyTargetSpeedCapacitorNeed	1	1
516	chassisType	11		\N	\N	0	\N	0	1	116	Required chassis Type	1	1
517	fallofMultiplier	5		\N	\N	0	\N	1	1	109	Fallof Modifier	1	1
518	shipBonusMB2	5		\N	\N	0	\N	0	0	\N	shipBonusMB2	1	1
519	cloakingCapacitorNeedRatio	5	The percentage of capacitor capacity required to engage cloaking.	\N	\N	0	\N	1	0	\N	cloakingCapacitorNeedRatio	1	1
522	damageCloudChance	5	%chance of new asteroid releasing damage cloud each mining turn.	\N	\N	0	\N	0	0	\N	damageCloudChance	1	1
524	armorUniformity	5	DO NOT MESS WITH	\N	\N	0	\N	0	0	\N	armorUniformity	1	1
525	structureUniformity	5	DO NOT MESS WITH	\N	\N	0	\N	0	0	\N	structureUniformity	1	1
526	reqResearchSkill	11		\N	\N	0	\N	0	1	\N	Research Skill Required	1	1
527	reqManufacturingSkill	11		\N	\N	0	\N	0	1	\N	Required Manufacturing Skill	1	1
528	reqManufacturingSkillLevel	4		\N	\N	0	\N	0	1	\N	requiredManufacturingSkillLevel	1	1
529	reqResearchSkillLevel	4		\N	\N	0	\N	0	1	\N	Required Research Skill Level	1	1
530	reqManufacturingTool	11		\N	\N	0	\N	0	1	\N	req Manufacturing Tool	1	1
531	reqResearchTool	11		\N	\N	0	\N	0	1	\N	req Research Tool	1	1
532	reqResearchComponent	11		\N	\N	0	\N	0	0	\N	reqResearchComponent	1	1
534	Manufacturer_ID	11		\N	\N	0	\N	0	1	\N	Manufacturer Bonus	1	1
535	installedMod	11		\N	\N	0	\N	0	1	\N	Modification Type	1	1
536	reqResearchComponetAmount	4		\N	\N	0	\N	0	0	\N	reqResearchComponetAmount	1	1
537	reqManufacturingComponent1Amount	4		\N	\N	0	\N	0	1	\N	Primary Manufacture Componet A	1	1
538	reqManufacturingComponent2Amount	4		\N	\N	0	\N	0	1	\N	Secondary Manufacture Componet	1	1
542	entityStrength	4	A relative strength that indicates how powerful this NPC entity is in combat.	\N	\N	0	\N	0	0	\N	entityStrength	1	1
543	damageCloudChanceReduction	4	Autogenerated skill attribute, damageCloudChanceReduction	\N	\N	0	\N	0	0	\N	damageCloudChanceReduction	1	1
544	cloudEffectDelay	4	The amount of time before applications of the cloud's effect.	\N	\N	0	\N	0	0	101	cloudEffectDelay	1	1
545	cloudDuration	4	Number of milliseconds a temporary cloud hangs around.	\N	\N	0	\N	0	0	101	cloudDuration	1	1
546	damageCloudType	11	The type of damage cloud generated by the asteroid.	\N	\N	0	\N	0	0	116	damageCloudType	1	1
547	missileVelocityBonus	4	Autogenerated skill attribute, missileVelocityBonus 	\N	\N	0	\N	0	1	105	Missile Velocity Bonus	1	1
548	shieldBoostMultiplier	5		\N	\N	2104	\N	1	1	121	Shield Boost Bonus	1	1
549	powerIncrease	4		\N	\N	0	\N	0	1	\N	Power Bonus	1	1
550	resistanceBonus	4	Autogenerated skill attribute, resistanceBonus	\N	\N	0	\N	0	1	121	Resistance Bonus	1	1
551	rocketVelocityPercent	5		\N	\N	0	\N	1	0	\N	rocketVelocityPercent	1	1
552	signatureRadius	5	Signature Radius is used for turret tracking and scanning.	\N	\N	1390	\N	100	1	1	Signature Radius	0	1
553	maxGangSizeBonus	4	Autogenerated skill attribute, maxGangSizeBonus	\N	\N	0	\N	0	0	\N	maxGangSizeBonus	1	1
554	signatureRadiusBonus	5	Autogenerated skill attribute, signatureRadiusBonus	\N	\N	0	\N	0	1	124	Signature Radius Bonus	1	1
555	cloakVelocityBonus	4	Autogenerated skill attribute, cloakVelocityBonus	\N	\N	0	\N	0	0	105	Cloak Velocity Bonus	1	1
556	anchoringDelay	4	How long it takes to anchor or unanchor this object.	\N	\N	0	\N	60000	1	101	Anchoring Delay	1	1
557	maxFlightTimeBonus	4	Autogenerated skill attribute, max flightTimeBonus	\N	\N	0	\N	0	1	121	Flight Time Bonus	1	1
558	explosionRangeBonus	4	Autogenerated skill attribute, explosionRangeBonus	\N	\N	0	\N	0	0	\N	explosionRangeBonus	1	1
559	Inertia	5	Inertia is a basic multiplier of agility and the mass of the ship, it determines how fast the ship can accelerate and how fast it can fly when orbiting.	\N	\N	0	\N	0	0	2	Inertia	1	1
560	cloakingTargetingDelay	4	The time targeting systems take to recalibrate after cloaking.	\N	\N	0	\N	0	1	3	Sensor Recalibration Time	1	1
561	shipBonusGB2	5	skill bonus attribute2 for gallente battleship	\N	\N	0	\N	0	0	\N	shipBonusGB2	1	1
562	entityFactionLoss	5		\N	\N	0	\N	0	0	\N	entityFactionLoss	1	1
563	entitySecurityMaxGain	5		\N	\N	0	\N	0	0	\N	entitySecurityMaxGain	1	1
564	scanResolution	5	The resolution that the vessel can target other objects at.	\N	\N	74	\N	0	1	102	Scan Resolution	0	1
565	scanResolutionMultiplier	5	Improves the targeting time of ships by boosting the Scan Resolution.	\N	\N	74	\N	0	1	109	Scan Resolution Bonus	1	1
566	scanResolutionBonus	4	Skill bonus for scan resolution	\N	\N	74	\N	0	1	124	Scan Resolution Bonus	1	1
567	speedBoostFactor	4	Used to divide with mass to give a factor for speed boost modules	\N	\N	96	\N	0	1	125	Thrust	1	1
568	eliteBonusInterceptor	5		\N	\N	0	\N	0	0	\N	eliteBonusInterceptor	1	1
569	eliteBonusCoverOps1	5		\N	\N	0	\N	0	0	\N	eliteBonusCoverOps1	1	1
570	eliteBonusBombers	5		\N	\N	0	\N	0	0	\N	eliteBonusBombers	1	1
571	eliteBonusGunships	5		\N	\N	0	\N	0	0	\N	eliteBonusGunships	1	1
573	eliteBonusdestroyers	5		\N	\N	0	\N	0	0	\N	eliteBonusdestroyers	1	1
575	eliteBonusBattlecruiser	5		\N	\N	0	\N	0	0	\N	eliteBonusBattlecruiser	1	1
576	speedBoostFactorCalc	5	Hidden attribute that is used for speedBoostFactor calculation because Dogma cant handle it.	\N	\N	0	\N	1	0	\N	speedBoostFactorCalc	1	1
578	speedBoostFactorCalc2	5	Second hidden attribute.	\N	\N	0	\N	1	0	\N	speedBoostFactorCalc2	1	1
579	testForEggert	4		\N	\N	0	\N	0	0	\N	testForEggert	1	1
580	entityChaseMaxDelay	4	The maximum amount of time stalled before entity chase speed kicks in.	\N	\N	0	\N	5000	0	\N	entityChaseMaxDelay	1	1
581	entityChaseMaxDelayChance	5	Chance that the max delay is waited before chase is engaged.	\N	\N	0	\N	1	0	\N	entityChaseMaxDelayChance	1	1
582	entityChaseMaxDuration	4	The maximum amount of time chase is ever engaged for.	\N	\N	0	\N	5000	0	101	entityChaseMaxDuration	1	1
583	entityChaseMaxDurationChance	5	The chance of engaging chase for the maximum duration.	\N	\N	0	\N	1	0	\N	entityChaseMaxDurationChance	1	1
584	entityMaxWanderRange	4	The maximum distance an entity of this type can be led from its point of placement.	\N	\N	0	\N	100000	0	1	entityMaxWanderRange	1	1
585	shipBonusAB2	5		\N	\N	0	\N	0	0	\N	shipBonusAB2	1	1
586	shipBonusGF2	4		\N	\N	0	\N	0	0	\N	shipBonusGF2	1	1
587	shipBonusMF2	5		\N	\N	0	\N	0	0	\N	shipBonusMF2	1	1
588	shipBonusCF2	4		\N	\N	0	\N	0	0	\N	shipBonusCF2	1	1
589	isPlayerOwnable	3	Whether a station type is player ownable.	\N	\N	0	\N	0	0	\N	isPlayerOwnable	1	1
590	gestaltBonus1	5		\N	\N	0	\N	0	0	\N	gestaltBonus1	1	1
591	droneMaxVelocityBonus	4	Increases max velocity of all drone types.	\N	\N	0	\N	0	1	105	Drone Velocity Bonus	1	1
592	cloakCapacitorBonus	4	Autogenerated skill attribute, cloakCapacitorBonus	\N	\N	0	\N	0	0	\N	cloakCapacitorBonus	1	1
594	Die	4	Autogenerated skill attribute, cloakCapacitor Bonus	\N	\N	0	\N	0	0	\N	Die	1	1
595	capBoostMultipler	5		\N	\N	0	\N	0	0	\N	CapBoostMultipler	1	1
596	explosionDelayBonus	4	Autogenerated skill attribute, explosionDelayBonus	\N	\N	0	\N	0	0	\N	explosionDelayBonus	1	1
597	eliteBonusEscorts	4	bonus for escort class frigates	\N	\N	0	\N	10	0	\N	eliteBonusEscorts	1	1
598	shipBonusCB3	4		\N	\N	0	\N	0	0	\N	shipBonusCB3	1	1
600	warpSpeedMultiplier	5		\N	\N	0	\N	1	1	\N	WarpSpeedMultiplyer	1	1
601	warpSpeedBonus	4	Autogenerated skill attribute, warpSpeedBonus	\N	\N	0	\N	0	1	105	Warp Speed Bonus	1	1
602	launcherGroup2	12	One of the groups of launcher this charge can be loaded into.	\N	\N	0	\N	0	1	115	Used with (launchergroup)	1	1
603	launcherGroup3	12	One of the groups of launcher this charge can be loaded into.	\N	\N	0	\N	0	1	115	Used with (launchergroup)	1	1
604	chargeGroup1	12	One of the groups of charge this launcher can be loaded with.	\N	\N	0	\N	0	1	115	Used with (chargegroup)	1	1
605	chargeGroup2	12	One of the groups of charge this launcher can be loaded with.	\N	\N	0	\N	0	1	115	Used with (chargegroup)	1	1
606	chargeGroup3	12	One of the groups of charge this launcher can be loaded with.	\N	\N	0	\N	0	1	115	Used with (chargegroup)	1	1
608	powerNeedMultiplier	5		\N	\N	0	\N	1	1	109	Turret Power Need	1	1
609	chargeGroup4	12	One of the groups of charge this launcher can be loaded with.	\N	\N	0	\N	0	1	115	Used with (chargegroup)	1	1
610	chargeGroup5	12	One of the groups of charge this launcher can be loaded with.	\N	\N	0	\N	0	1	115	Used with (chargegroup)	1	1
611	durationMultiplier	5		\N	\N	0	\N	0	1	111	Duration Bonus	1	1
612	baseShieldDamage	5	Just for the UI to display base damage on shield.	\N	\N	69	\N	0	1	\N	Base Shield Damage	1	1
613	baseArmorDamage	5	Just for the UI to display base damage on armor.	\N	\N	68	\N	0	1	\N	Base Armor Damage	1	1
614	cargoCapacityBonus	4	Autogenerated skill attribute, cargoCapacityBonus	\N	\N	0	\N	0	0	\N	cargoCapacityBonus	1	1
616	maxVelocityMultiplier	5	Multiplier applied to the ship's maximum velocity.	\N	\N	0	\N	1	1	109	Max Velocity Bonus	1	1
619	cloakingTargetingDelayBonus	4	Skill bonus for cloaking targeting delay.	\N	\N	0	\N	0	1	105	Cloaking Targeting Delay Bonus	1	1
620	optimalSigRadius	5	Prefered target signature. The base signature radius at which the turret's tracking speed is rated. 	\N	\N	0	\N	1000	1	1	Signature Resolution	1	1
621	trackingSpeedAtOptimal	4	Rated target transverse velocity at optimal range.	\N	\N	0	\N	1	1	10	Tracking Speed at Optimal Range	1	1
622	massLimit	5	Determines the maximum weight of a ship that, ships that are to heavy get denied of service by this attribute	\N	\N	0	\N	0	0	2	capacityLimit	1	1
623	cloakingSlotsLeftSuper	4	hot-fix for not allowing warpable cloaking modules on anything but covert-ops frigs	\N	\N	0	\N	0	0	\N	cloakingSlotsLeftSuper	1	1
624	WarpSBonus	4	Autogenerated skill attribute, WarpSBonus	\N	\N	0	\N	0	0	\N	WarpSBonus	1	1
625	bountyBonus	5	Flat Bonus To NPC Bountys	\N	\N	0	\N	0	0	\N	bountyBonus	1	1
626	bountyMultiplier	5	Npc Bounty Multiplier	\N	\N	0	\N	1	0	\N	bountyMultiplier	1	1
627	bountySkillBonus	4	Autogenerated skill attribute, bountySkillBonus	\N	\N	0	\N	0	0	\N	bountySkillBonus	1	1
628	bountySkillMultiplyer	4	Autogenerated skill attribute, bountySkillMultiplyer	\N	\N	0	\N	0	0	\N	bountySkillMultiplyer	1	1
629	cargoGroup	12	The cargo group that can be loaded into this container	\N	\N	0	\N	0	0	\N	cargoGroup	1	1
630	entityArmorRepairDuration	4	Duration between armor repair actions for entities.	\N	\N	0	\N	0	0	\N	entityArmorRepairDuration	1	1
631	entityArmorRepairAmount	5	Amount of armor repaired per cycle for entities.	\N	\N	0	\N	0	0	\N	entityArmorRepairAmount	1	1
632	interceptorGF	4		\N	\N	0	\N	0	0	\N	interceptorGF	1	1
633	metaLevel	4	The ranking of the module within its tech level	\N	\N	0	\N	0	0	\N	metaLevel	1	1
634	newAgility	5	Maximum "Thrust angle" for an object in Radians, 0 to pi (3.14).	\N	\N	0	\N	3	0	\N	newAgility	1	1
635	turnAngle	5	Maximum turn angle of a ship in Radians, 0 to pi (3.14).	\N	\N	0	\N	3	0	\N	turnAngle	1	1
636	entityShieldBoostDuration	4	How long between repeats.	\N	\N	0	\N	10000	0	\N	entityShieldBoostDuration	1	1
637	entityShieldBoostAmount	5	How much the shield is boosted each duration.	\N	\N	0	\N	0	0	\N	entityShieldBoostAmount	1	1
638	entityArmorRepairDelayChance	5	Chance that an entity will delay employing armor repair.	\N	\N	0	\N	0	0	\N	entityArmorRepairDelayChance	1	1
639	entityShieldBoostDelayChance	5	The chance an entity will delay repeating use of its shield boosting effect if it has one.	\N	\N	0	\N	1	0	\N	entityShieldBoostDelayChance	1	1
640	entityGroupRespawnChance	5	The chance an entity will respawn into his group if destroyed.	\N	\N	0	\N	1	0	\N	entityGroupRespawnChance	1	1
641	prereqimplant	4	typeID of an implant that the character must have to use this implant. 	\N	\N	0	\N	0	0	\N	Prerequisite Implant Type	1	1
643	armingTime	4	Delay after launch until a missile will do damage on impact.	\N	\N	0	\N	0	1	3	Arming Time	1	1
644	aimedLaunch	4	Determines wether a missile launches aligned with the ship (0) or directly at the target (1).	\N	\N	0	\N	0	0	\N	aimedLaunch	1	1
645	missileEntityVelocityMultiplier	5		\N	\N	0	\N	1	1	104	Missile Velocity Bonus	1	1
646	missileEntityFlightTimeMultiplier	5		\N	\N	0	\N	1	1	104	Missile Flight Time Bonus	1	1
647	missileEntityArmingTimeMultiplier	5		\N	\N	0	\N	1	0	\N	missileEntityArmingTimeMultiplier	1	1
648	shieldTUNEBonus	5		\N	\N	0	\N	0	1	113	Shield tuneup bonus	1	1
649	cloakingCpuNeedBonus	5		\N	\N	0	\N	0	0	\N	cloakingCpuNeedBonus	1	1
650	maxStructureDistance	4	The distance that stuctures have to be from a control tower in order to work with it.	\N	\N	0	\N	0	1	1	Maximum Structure Distance	1	1
651	decloakFieldRange	4	Range of broadcasted decloaking field.	\N	\N	0	\N	0	1	1	Area of effect	1	1
652	signatureRadiusMultiplier	5		\N	\N	0	\N	0	1	109	Signature Penalty	1	1
653	aoeVelocity	4	Velocity of the damage cloud created on impact.	\N	\N	0	\N	0	1	10	Explosion Velocity	1	1
654	aoeCloudSize	4	Size of the damage cloud caused by impact.	\N	\N	1390	\N	0	1	1	Explosion Radius	1	1
655	aoeFalloff	5		\N	\N	0	\N	0	0	\N	aoeFalloff	1	1
656	shipBonusAC2	5		\N	\N	0	\N	0	0	\N	shipBonusAC2	1	1
657	shipBonusCC2	5		\N	\N	0	\N	0	0	\N	shipBonusCC2	1	1
658	shipBonusGC2	5		\N	\N	0	\N	0	0	\N	shipBonusGC2	1	1
659	shipBonusMC2	5		\N	\N	0	\N	0	0	\N	shipBonusMC2	1	1
660	impactDamage	4	The amount of kinetic damage that might be inflicted on collision.	\N	\N	0	\N	0	0	113	Kinetic Damage	1	1
661	maxDirectionalVelocity	5		\N	\N	0	\N	1	0	\N	maxDirectionalVelocity	1	1
662	minTargetVelDmgMultiplier	5		\N	\N	0	\N	1	0	\N	minTargetVelDmgMultiplier	1	1
663	minMissileVelDmgMultiplier	5		\N	\N	0	\N	1	0	\N	minMissileVelDmgMultiplier	1	1
664	maxMissileVelocity	5	A multiplier used for the missile impact damage calculations.	\N	\N	0	\N	1	0	\N	maxMissileVelocity	1	1
665	entityChaseMaxDistance	4	The distance outside of which the entity activates their MWD equivalent.	\N	\N	0	\N	2500	0	1	entityChaseMaxDistance	1	1
666	moduleShipGroup2	12	This module only fits on specific ship groups.  This is one of them.	\N	\N	0	\N	0	1	115	Restricted Ship Type	1	1
667	moduleShipGroup3	12	This module only fits on specific ship groups.  This is one of them.	\N	\N	0	\N	0	1	115	Restricted Ship Type	1	1
668	moduleShipGroup1	12	This module only fits on specific ship groups.  This is one of them.	\N	\N	0	\N	0	1	115	Restricted Ship Type	1	1
669	moduleReactivationDelay	4	Amount of time that has to be waited after the deactivation of this module until it can be reactivated.	\N	\N	0	\N	0	1	101	Reactivation Delay	1	1
670	areaOfEffectBonus	5		\N	\N	1390	\N	0	1	1	Area Of Effect Bonus	1	1
672	entityCruiseSpeedMultiplier	5		\N	\N	0	\N	1	1	109	Orbit Velocity Bonus	1	1
673	eliteBonusGunship1	5		\N	\N	0	\N	0	0	\N	eliteBonusGunship1	1	1
675	eliteBonusGunship2	5		\N	\N	0	\N	0	0	\N	eliteBonusGunship2	1	1
676	unanchoringDelay	4	How long it takes to unanchor this object.	\N	\N	0	\N	60000	1	101	Unanchoring Delay	1	1
677	onliningDelay	4	How long it takes to bring this object online.	\N	\N	0	\N	60000	1	101	Onlining Delay	1	1
678	eliteBonusLogistics1	5	first bonus for support cruisers	\N	\N	0	\N	0	0	\N	eliteBonusLogistics1	1	1
679	eliteBonusLogistics2	5	second bonus for support cruisers	\N	\N	0	\N	0	0	\N	eliteBonusLogistics2	1	1
680	shieldRadius	4	Radius of the force shield that this structure generates.	\N	\N	0	\N	0	1	1	Shield Radius	1	1
681	typeContainerType1	11	A type allowed to be placed in this container.	\N	\N	0	\N	0	1	116	Stored Type 1	1	1
682	typeContainerType2	11	A type allowed to be placed in this container.	\N	\N	0	\N	0	1	116	Stored Type 2	1	1
683	typeContainerType3	11	A type allowed to be placed in this container.	\N	\N	0	\N	0	1	116	Stored Type 3	1	1
684	typeContainerCapacity1	4	The amount of storage type 1 that can be fitted inside this structure.	\N	\N	0	\N	0	1	9	Storage Capacity 1	1	1
685	typeContainerCapacity2	4	The amount of storage type 2 that can be fitted inside this structure.	\N	\N	0	\N	0	1	9	Storage Capacity 2	1	1
686	typeContainerCapacity3	4	The amount of storage type 3 that can be fitted inside this structure.	\N	\N	0	\N	0	1	9	Storage Capacity 3	1	1
687	operationConsumptionRate	4	The number of units of a resource consumed per minute of operation.	\N	\N	0	\N	0	1	\N	Operation Consumption Rate	1	1
688	reinforcedConsumptionRate	4	The number of units of a resource consumed per minute of reinforced mode.	\N	\N	0	\N	0	1	\N	Resinforced Consumption Rate	1	1
689	packageGraphicID	4	The graphicID used for the structure when it is in package form.	\N	\N	2391	\N	2391	0	\N	packageGraphicID	1	1
690	packageRadius	5	The radius of the structure when it is in package form.	\N	\N	0	\N	250	0	\N	packageRadius	1	1
691	targetSwitchDelay	4	The amount of time after attacking a target that an entity will wait before switching to a new one.	\N	\N	0	\N	0	0	101	Target Cycling Speed	1	1
692	eliteBonusHeavyGunship1	5		\N	\N	0	\N	0	0	\N	eliteBonusHeavyGunship1	1	1
693	eliteBonusHeavyGunship2	5		\N	\N	0	\N	0	0	\N	eliteBonusHeavyGunship2	1	1
694	resourceReinforced1Type	11		\N	\N	0	\N	0	1	116	Reinforced Mode Type	1	1
695	resourceReinforced2Type	11		\N	\N	0	\N	0	1	116	Reinforced Mode Type	1	1
696	resourceReinforced3Type	11		\N	\N	0	\N	0	1	116	Reinforced Mode Type	1	1
697	resourceReinforced4Type	11		\N	\N	0	\N	0	1	116	Reinforced Mode Type	1	1
698	resourceReinforced5Type	11		\N	\N	0	\N	0	1	116	Reinforced Mode Type	1	1
699	resourceReinforced1Quantity	4		\N	\N	0	\N	0	1	9	Reinforced Mode Quantity	1	1
700	resourceReinforced2Quantity	4		\N	\N	0	\N	0	1	9	Reinforced Mode Quantity	1	1
701	resourceReinforced3Quantity	4		\N	\N	0	\N	0	1	9	Reinforced Mode Quantity	1	1
703	resourceReinforced4Quantity	4		\N	\N	0	\N	0	1	9	Reinforced Mode Quantity	1	1
704	resourceReinforced5Quantity	4		\N	\N	0	\N	0	1	9	Reinforced Mode Quantity	1	1
705	resourceOnline1Type	11		\N	\N	\N	\N	0	1	116	Online Mode Type	1	1
706	resourceOnline2Type	11		\N	\N	0	\N	0	1	116	Online Mode Type	1	1
707	resourceOnline3Type	11		\N	\N	0	\N	0	1	116	Online Mode Type	1	1
708	resourceOnline4Type	11		\N	\N	0	\N	0	1	\N	Online Mode Type	1	1
709	harvesterType	11	The type of material harvested.	\N	\N	0	\N	0	1	116	Harvested Type	1	1
710	harvesterQuality	4	The quality of the material harvested.	\N	\N	0	\N	0	1	\N	Harvester Quality	1	1
711	moonAnchorDistance	4	How many meters from the standard warp-in distance a moon can be anchored from.	\N	\N	0	\N	0	1	1	Moon Anchor Distance	1	1
712	usageDamagePercent	4	How much a charge used by this object is damaged each time the object operates.	\N	\N	0	\N	0	1	105	Charge Usage Damage	1	1
713	consumptionType	11	The type of resource needed to be consumed for each activation cycle of this structure.	\N	\N	0	\N	0	1	116	Consumption Type	1	1
714	consumptionQuantity	4	The amount of the given resource type needed to be consumed for each activation cycle of this structure.	\N	\N	0	\N	0	1	\N	Consumption Quantity	1	1
715	maxOperationalDistance	4	The maximum distance at which the object can be used.	\N	\N	0	\N	0	1	1	Maximim Operational Distance	1	1
716	maxOperationalUsers	4	The maximum number of users that can be present within the operational range of the structure for it to be capable of operation.	\N	\N	0	\N	0	1	\N	Maximum Concurrent Operational Users	1	1
717	refiningYieldMultiplier	5	The factor by which the structure modifies the using pilot's refining yield rate.	\N	\N	0	\N	1	1	104	Refining Yield Multiplier	1	1
719	operationalDuration	4	The amount of time that is taken to refine the ore into the end product.  The structure is busy for the length of this process.	\N	\N	0	\N	0	1	101	Operational Duration	1	1
720	refineryCapacity	4	The capacity of the refinery container.	\N	\N	0	\N	0	1	9	Refinery Capacity	1	1
721	refiningDelayMultiplier	5	The factor by which the character can effect the amount of time that the Refining Delay takes.	\N	\N	0	\N	1	0	\N	refiningDelayMultiplier	1	1
722	posControlTowerPeriod	4	The interval for fuel consumption of a control tower	\N	\N	0	\N	10000	1	101	Starbase Control Tower Period	1	1
723	contrabandDetectionChance	5	The chance that the customs official has of detecting contraband on board a scanned vessel	\N	\N	0	\N	0	0	\N	contrabandDetectionChance	1	1
724	contrabandDetectionResistance	5	A modifier to the chance of contraband detection success of police who scan the pilot's vessel.	\N	\N	0	\N	0	0	\N	contrabandDetectionResistance	1	1
725	contrabandScanChance	5	The chance that a passer by will be chosen as a target of a scan for contraband.	\N	\N	0	\N	0	0	\N	contrabandScanChance	1	1
726	moonMiningAmount	4		\N	\N	0	\N	1	1	9	Moon Mining Amount	1	1
727	destroyerROFpenality	5		\N	\N	0	\N	0	0	\N	destroyerROFpenality	1	1
728	controlTowerLaserDamageBonus	5		\N	\N	0	\N	0	0	105	Laser Sentry Damage Bonus	1	1
729	shipBonusMD1	5		\N	\N	0	\N	0	0	\N	shipBonusMD1	1	1
732	shipBonusD1	5		\N	\N	0	\N	0	0	\N	shipBonusD1	1	1
733	shipBonusD2	5		\N	\N	0	\N	0	0	\N	shipBonusD2	1	1
734	shipBonusCD1	5		\N	\N	0	\N	0	0	\N	shipBonusCD1	1	1
735	shipBonusCD2	5		\N	\N	0	\N	0	0	\N	shipBonusCD2	1	1
738	shipBonusGD1	5		\N	\N	0	\N	0	0	\N	shipBonusGD1	1	1
739	shipBonusGD2	5		\N	\N	0	\N	0	0	\N	shipBonusGD2	1	1
740	shipBonusMD2	5		\N	\N	0	\N	0	0	\N	shipBonusMD2	1	1
741	shipBonusBC1	5		\N	\N	0	\N	0	0	\N	shipBonusBC1	1	1
742	shipBonusBC2	5		\N	\N	0	\N	0	0	\N	shipBonusBC2	1	1
743	shipBonusCBC1	5		\N	\N	0	\N	0	0	\N	shipBonusCBC1	1	1
745	shipBonusCBC2	5		\N	\N	0	\N	0	0	\N	shipBonusCBC2	1	1
746	shipBonusGBC2	5		\N	\N	0	\N	0	0	\N	shipBonusGBC2	1	1
747	shipBonusGBC1	5		\N	\N	0	\N	0	0	\N	shipBonusGBC1	1	1
748	shipBonusMBC1	5		\N	\N	0	\N	0	0	\N	shipBonusMBC1	1	1
749	shipBonusMBC2	5		\N	\N	0	\N	0	0	\N	shipBonusMBC2	1	1
750	controlTowerLaserOptimalBonus	5		\N	\N	0	\N	0	0	105	Laser Sentry Optimal Bonus	1	1
751	controlTowerHybridOptimalBonus	5		\N	\N	0	\N	0	1	105	Hybrid Sentry Optimal Bonus	1	1
752	controlTowerProjectileOptimalBonus	5		\N	\N	0	\N	0	0	105	Projectile Sentry Optimal Bonus	1	1
753	controlTowerProjectileFallOffBonus	5		\N	\N	0	\N	0	0	105	Projectile Sentry Fall Off Bonus	1	1
754	controlTowerProjectileROFBonus	5		\N	\N	0	\N	0	0	105	Projectile Sentry Rate of Fire Bonus	1	1
755	controlTowerMissileROFBonus	5		\N	\N	0	\N	0	0	105	Missile Bay Rate of Fire Bonus	1	1
756	controlTowerMoonHarvesterCPUBonus	5		\N	\N	0	\N	0	0	105	Moon Harvester CPU Bonus	1	1
757	controlTowerSiloCapacityBonus	5		\N	\N	0	\N	0	0	105	Silo Capacity Bonus	1	1
758	shipBonusDF1	5	destroyers attribute 1	\N	\N	0	\N	0	0	\N	shipBonusDF1	1	1
759	shipBonusDF2	5	destroyer attribute 2	\N	\N	0	\N	0	0	\N	shipBonusDF2	1	1
760	controlTowerLaserProximityRangeBonus	5		\N	\N	0	\N	0	1	105	Laser Sentry Proximity Bonus	1	1
761	controlTowerProjectileProximityRangeBonus	5		\N	\N	0	\N	0	1	105	Projectile Sentry Proximity Bonus	1	1
762	controlTowerHybridProximityRangeBonus	5		\N	\N	0	\N	0	1	105	Hybrid Sentry Proximity Bonus	1	1
763	maxGroupActive	4	Maximum modules of same group that can be activated at same time, 0 = no limit, 1 = 1	\N	\N	0	\N	0	0	\N	maxGroupActive	1	1
764	controlTowerEwRofBonus	5		\N	\N	0	\N	0	1	105	Target Jamming Duration Bonus	1	1
765	scanRange	4	Effective range of scanner in multiples of AUs	\N	\N	0	\N	10	1	\N	Scan Range	1	1
766	controlTowerHybridDamageBonus	5		\N	\N	0	\N	0	0	105	Hybrid Sentry Damage Bonus	1	1
767	trackingSpeedBonus	5		\N	\N	1398	\N	0	1	105	Tracking Speed Bonus	1	1
769	maxRangeBonus2	5		\N	\N	0	\N	0	1	105	Optimal Range Bonus	1	1
770	controlTowerEwTargetSwitchDelayBonus	5	Bonus attribute to entity Target Switch Delay	\N	\N	0	\N	0	0	105	EW Target Switch Delay Bonus	1	1
771	ammoCapacity	5		\N	\N	0	\N	0	1	\N	Ammo Capacity	1	1
772	entityFlyRangeFactor	5		\N	\N	0	\N	1	0	\N	entityFlyRangeFactor	1	1
773	shipBonusORE1	5	ORE mining barge bonus	\N	\N	0	\N	0	0	\N	shipBonusORE1	1	1
774	shipBonusORE2	5	ORE Mining barge bonus 2	\N	\N	0	\N	0	0	\N	shipBonusORE2	1	1
775	miningCPUNeedBonus	5	funky stuff for mining barges	\N	\N	0	\N	0	0	\N	miningCPUNeedBonus	1	1
776	structureMissileVelocityBonus	5	Velocity %bonus for given missile group for missile batteries.	\N	\N	0	\N	0	1	105	Missile Velocity Bonus	1	1
777	structureMissileDamageBonus	5	Damage %bonus for given missile group for missile batteries.	\N	\N	0	\N	0	1	105	Missile Damage Bonus	1	1
778	structureMissileExplosionDelayBonus	5	Exploision Delay (range) bonus for missile batteries	\N	\N	0	\N	0	1	105	Missile Explosion Delay Bonus	1	1
779	entityFlyRangeMultiplier	5	For charges, hidden attribute used by sentry guns to modify target pick range.	\N	\N	0	\N	1	0	\N	entityFlyRangeMultiplier	1	1
780	iceHarvestCycleBonus	5		\N	\N	0	\N	0	1	105	Cycle Time bonus	1	1
781	specialisationAsteroidGroup	12	The group at which the mining crystal is tuned to mine.	\N	\N	0	\N	0	1	115	Asteroid Specialisation Group	1	1
782	specialisationAsteroidYieldMultiplier	5	The amount the yield is modified when mining the asteroid group this crystal is tuned for.	\N	\N	0	\N	0	1	105	Asteroid Specialisation Yield Modifier	1	1
783	crystalVolatilityChance	5	The chance of damage to the crystal each time it is used.	\N	\N	0	\N	0	1	105	Volatility	1	1
784	crystalVolatilityDamage	5	The amount of damage done if the crystal is damaged in the process of using it.	\N	\N	0	\N	0	1	\N	Volatility Damage	1	1
785	unfitCapCost	5	The capacitor charge required to disengage this crystal from the unit it is installed in.	\N	\N	0	\N	0	1	114	Unfitting Capacitor Cost	1	1
786	crystalsGetDamaged	3	Whether this tool causes damage to crystals with each use of them.	\N	\N	0	\N	0	1	\N	Crystals Damage	1	1
787	minScanDeviation	5	Minimum scanning error	\N	\N	0	\N	0	1	1	Minimum Scan Deviation	1	1
788	maxScanDeviation	5	Maximum scan error	\N	\N	0	\N	0	1	1	Maximum Scan Deviation	1	1
789	specialtyMiningAmount	5		\N	\N	0	\N	0	1	118	Specialty Crystal Mining Amount	1	1
790	reprocessingSkillType	11	The skill required to reprocess this ore type.	\N	\N	0	\N	0	1	116	Reprocessing Skill	1	1
791	scanAnalyzeCount	4	Number of probes needed for an analyzis	\N	\N	0	\N	3	1	\N	Probes to Analyze	1	1
792	controlTowerMissileVelocityBonus	5		\N	\N	0	\N	0	0	105	Missile Velocity Bonus	1	1
793	shipBonusPirateFaction	5	Stock Bonus on Pirate Faction Ships.	\N	\N	0	\N	0	0	\N	shipBonusPirateFaction	1	1
794	probesInGroup	4	Number of probes to analyze	\N	\N	0	\N	3	1	\N	Probes To Analyze	1	1
795	shipBonusABC1	5		\N	\N	0	\N	0	0	\N	shipBonusABC1	1	1
796	massAddition	5	Attribute for adding mass to a ship via an afterburner or MWD.	\N	\N	0	\N	0	1	2	Mass Addition	1	1
797	maximumRangeCap	5	The maximum possible target range.	\N	\N	1391	\N	249999	1	1	Theoretical Maximum Targetting Range	1	1
798	entityBracketColour	4	so far: 0 = white, 1 = red	\N	\N	0	\N	0	0	\N	entityBracketColour	1	1
799	implantSetBloodraider	5		\N	\N	0	\N	2	1	104	Talisman Set Bonus	1	1
800	contrabandDetectionChanceBonus	5	Autogenerated skill attribute, contrabandDetectionChanceBonus	\N	\N	0	\N	0	1	\N	Contraband Detection Modifier	1	1
801	deadspaceUnsafe	3	Modules with this attribute set to 1 can not be used in deadspace.	\N	\N	0	\N	0	0	\N	deadspaceUnsafe	1	1
802	implantSetSerpentis	5		\N	\N	0	\N	0	1	104	Snake Set Bonus	1	1
803	implantSetSerpentis2	5		\N	\N	0	\N	0	0	\N	implantSetSerpentis2	1	1
804	eliteBonusInterceptor2	5		\N	\N	0	\N	0	0	\N	eliteBonusInterceptor2	1	1
805	quantity	1	Quantity contained.	\N	\N	0	\N	0	1	\N	Quantity	1	1
806	repairBonus	4	Autogenerated skill attribute, repairBonus	\N	\N	0	\N	0	1	105	Repair Bonus	1	1
807	eliteBonusIndustrial1	5		\N	\N	0	\N	0	0	\N	eliteBonusIndustrial1	1	1
808	eliteBonusIndustrial2	5		\N	\N	0	\N	0	0	\N	eliteBonusIndustrial2	1	1
809	shipBonusAI2	5		\N	\N	0	\N	0	0	\N	shipBonusAI2	1	1
811	shipBonusCI2	5		\N	\N	0	\N	0	0	\N	shipBonusCI2	1	1
813	shipBonusGI2	5		\N	\N	0	\N	0	0	\N	shipBonusGI2	1	1
814	shipBonusMI2	5		\N	\N	0	\N	0	0	\N	shipBonusMI2	1	1
815	propulsionFusionStrengthBonus	5	Amarr Propulsion Attack Strength for Warp Scramblers etc.	\N	\N	0	\N	0	1	120	Fusion Strength	1	1
816	propulsionIonStrengthBonus	5	Caldari Propulsion Attack Strength for Warp Scramblers etc.	\N	\N	0	\N	0	1	120	Ion Strength	1	1
817	propulsionMagpulseStrengthBonus	5	Gallente Propulsion Attack Strength for Warp Scramblers etc.	\N	\N	0	\N	0	1	120	Magpulse Strength	1	1
818	propulsionPlasmaStrengthBonus	5	Minmatar Propulsion Attack Strength for Warp Scramblers etc.	\N	\N	0	\N	0	1	120	Plasma Strength	1	1
819	propulsionFusionStrength	5	Amarr propulsion strength for ship.	\N	\N	2736	\N	0	1	120	Fusion Propulsion Strength	1	1
820	propulsionIonStrength	5	Caldari propulsion strength for ship.	\N	\N	2733	\N	0	1	120	Ion Propulsion Strength	1	1
821	propulsionMagpulseStrength	5	Gallente propulsion strength for ship.	\N	\N	2734	\N	0	1	120	Magpulse Propulsion Strength	1	1
822	propulsionPlasmaStrength	5	Minmatar propulsion strength for ship.	\N	\N	2735	\N	0	1	120	Plasma Propulsion Strength	1	1
823	hitsMissilesOnly	4	Effect for smartbombs, used to hit missiles only.	\N	\N	0	\N	0	0	\N	hitsMissilesOnly	1	1
828	scanSkillEwStrengthBonus	5	Skill attribute for increasing strength of EW modules.	\N	\N	0	\N	0	0	\N	scanSkillEwStrengthBonus	1	1
829	propulsionSkillPropulsionStrengthBonus	5	Skill attribute for increasing strength of Propulsion modules.	\N	\N	0	\N	0	0	\N	propulsionSkillPropulsionStrengthBonus	1	1
830	bonusComplexAngel10	5	Bonus used on Unique Loot in level 10 Angel cartel Deadspace Complexes.	\N	\N	0	\N	5	0	\N	bonusComplexAngel10	1	1
831	ewTargetJam	4	Used for target jam effects to reduce max locked targets of victem to a negative value to ensure the victem looses its targets, use extreme value	\N	\N	0	\N	0	0	\N	ewTargetJam	1	1
832	scanSkillTargetPaintStrengthBonus	5	Skill attribute for increasing effectiveness on Target Painters	\N	\N	0	\N	0	1	105	Target Painting Bonus	1	1
833	commandBonus	5		\N	\N	0	\N	0	1	121	Command Bonus	1	1
834	wingCommandBonus	5		\N	\N	0	\N	0	0	\N	WingCommandBonus	1	1
837	stealthBomberLauncherPower	5	Used for stealth bombers to decrease power need on cruise launchers.	\N	\N	0	\N	1	0	\N	stealthBomberLauncherPower	1	1
838	implantSetGuristas	5		\N	\N	0	\N	1	1	104	Crystal Set Bonus	1	1
839	eliteBonusCoverOps2	5		\N	\N	0	\N	0	0	\N	eliteBonusCoverOps2	1	1
840	agentID	4	agentID to use when initiating NPC communications with this type.	\N	\N	0	\N	0	1	\N	Agent ID	1	1
841	agentCommRange	4	The range of the agent's communication sphere	\N	\N	0	\N	50000	1	1	Agent Comm Range	1	1
842	reactionGroup1	12		\N	\N	0	\N	0	1	115	Reaction Type 1	1	1
843	reactionGroup2	12		\N	\N	0	\N	0	1	115	Reaction Type 2	1	1
844	agentAutoPopupRange	4	If the player comes within this range of this agent-in-space, an automatic communication window popup will occur.	\N	\N	0	\N	5000	1	\N	Agent Auto Popup Range	1	1
845	hiddenLauncherDamageBonus	5	Hidden Attribute for tech 2 launcher damage bonus.	\N	\N	0	\N	1	0	\N	hiddenLauncherDamageBonus	1	1
846	scanStrengthBonus	5		\N	\N	0	\N	0	1	105	Scan Strength Bonus	1	1
847	aoeVelocityBonus	5	Increases velocity of missile explosion	\N	\N	1389	\N	0	1	105	Explosion Velocity Bonus	1	1
848	aoeCloudSizeBonus	5	Booster attribute to explosion radius of missiles vs. signature radius.	\N	\N	0	\N	0	1	\N	Explosion Radius Bonus	1	1
849	canUseCargoInSpace	5	Can use cargo in space or not, 0 = no, 1 = yes	\N	\N	0	\N	1	0	\N	canUseCargoInSpace	1	1
850	squadronCommandBonus	4	Autogenerated skill attribute, relayCPUBonus	\N	\N	0	\N	0	1	\N	Squadron Command Bonus	1	1
851	shieldBoostCapacitorBonus	4	Bonus to capacitor need for shield boosters.	\N	\N	0	\N	0	1	124	Capacitor Need Bonus	1	1
852	siegeModeWarpStatus	4		\N	\N	0	\N	0	0	\N	siegeModeWarpStatus	1	1
853	advancedAgility	5	Attribute on ship to make advanced command affect only ships that we want.	\N	\N	0	\N	1	0	\N	Agility Bonus	1	1
854	disallowAssistance	4	If this module is in use and this attribute is 1, then assistance modules cannot be used on the ship.	\N	\N	0	\N	0	0	\N	Disallows Assistance	1	1
855	activationTargetLoss	4	Activating this module results in the temporary loss of all targets currently held or being locked.	\N	\N	0	\N	0	0	\N	Activation Target Loss	1	1
857	aoeFalloffBonus	5		\N	\N	0	\N	0	0	105	Velocity Falloff Bonus	1	1
858	missileEntityAoeCloudSizeMultiplier	5		\N	\N	0	\N	1	1	109	Explosion Radius Bonus	1	1
859	missileEntityAoeVelocityMultiplier	5		\N	\N	0	\N	1	1	109	Explosion Velocity Bonus	1	1
860	missileEntityAoeFalloffMultiplier	5		\N	\N	0	\N	1	0	\N	missileEntityAoeFalloffMultiplier	1	1
861	canJump	4	1 = ship can use jump drive	\N	\N	0	\N	0	1	\N	Onboard Jump Drive	1	1
862	usageWeighting	5	The weighting given to this type and its chance of being picked for a grouping.	\N	\N	0	\N	0	0	\N	usageWeighting	1	1
863	implantSetAngel	5		\N	\N	0	\N	1	1	104	Halo Set Bonus	1	1
864	implantSetSansha	5		\N	\N	0	\N	0	1	104	Slave Set Bonus	1	1
865	planetAnchorDistance	4	How many meters from the standard warp-in distance a planet can be anchored from.	\N	\N	0	\N	100000	0	1	planetAnchorDistance	1	1
866	jumpDriveConsumptionType	11	Type that is used for consumption from cargo hold when activating jump drive operation.	\N	\N	0	\N	0	1	116	Jump Drive Fuel Need	1	1
867	jumpDriveRange	5	Range in light years the ship can maximum jump to.	\N	\N	1391	\N	0	1	126	Maximum Jump Range	1	1
868	jumpDriveConsumptionAmount	5	Number of units it consumes per light year.	\N	\N	0	\N	0	1	\N	Jump Drive Consumption Amount	1	1
869	jumpDriveDuration	4	The amount of time before the ship actually jumps.	\N	\N	0	\N	300000	0	\N	jumpDriveDuration	1	1
870	jumpDriveRangeBonus	4	Jump range bonus for jump drive operation.	\N	\N	0	\N	0	1	105	Jump Drive Range Bonus	1	1
871	jumpDriveDurationBonus	4	Skill bonus attribute that decreases the duration before iniating a jump.	\N	\N	0	\N	0	0	105	Jump Drive Duration Bonus	1	1
872	disallowOffensiveModifiers	4	(Buffer)	\N	\N	0	\N	0	0	\N	Disallows Offensive Modifiers	1	1
874	advancedCapitalAgility	5		\N	\N	0	\N	1	0	\N	advancedCapitalAgility	1	1
875	dreadnoughtShipBonusA1	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusA1	1	1
876	dreadnoughtShipBonusA2	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusA2	1	1
877	dreadnoughtShipBonusC1	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusC1	1	1
878	dreadnoughtShipBonusC2	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusC2	1	1
879	dreadnoughtShipBonusG1	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusG1	1	1
880	dreadnoughtShipBonusG2	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusG2	1	1
881	dreadnoughtShipBonusM1	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusM1	1	1
882	dreadnoughtShipBonusM2	5		\N	\N	0	\N	0	0	\N	dreadnoughtShipBonusM2	1	1
884	mindlinkBonus	5		\N	\N	0	\N	0	1	105	Mindlink Bonus	1	1
885	consumptionQuantityBonus	4		\N	\N	0	\N	0	1	\N	Consumption Quantity Bonus	1	1
886	freighterBonusA1	5		\N	\N	0	\N	0	0	\N	freighterBonusA1	1	1
887	freighterBonusA2	5		\N	\N	0	\N	0	0	\N	freighterBonusA2	1	1
888	freighterBonusC1	5		\N	\N	0	\N	0	0	\N	freighterBonusC1	1	1
889	freighterBonusC2	5		\N	\N	0	\N	0	0	\N	freighterBonusC2	1	1
890	freighterBonusG2	5		\N	\N	0	\N	0	0	\N	freighterBonusG2	1	1
891	freighterBonusG1	5		\N	\N	0	\N	0	0	\N	freighterBonusG1	1	1
892	freighterBonusM1	5		\N	\N	0	\N	0	0	\N	freighterBonusM1	1	1
893	freighterBonusM2	5		\N	\N	0	\N	0	0	\N	freighterBonusM2	1	1
894	speedBoostBonus	5	Testing for fuels for speed boosters.	\N	\N	0	\N	0	1	105	Speed Boost Bonus	1	1
895	armorDamageAmountBonus	5	Bonus attribute for armor repair amount.	\N	\N	80	\N	0	1	105	Armor Repair Bonus	1	1
896	armorDamageDurationBonus	5		\N	\N	1392	\N	0	1	105	Armor Repair Duration Bonus	1	1
897	shieldBonusDurationBonus	5		\N	\N	1392	\N	0	1	105	Shield Boost Duration Bonus	1	1
898	jumpDriveCapacitorNeed	5	Minimum capacitor need for jump drive operation from full capacitor in modifier%.	\N	\N	1032	\N	1	1	\N	Jump Drive Capacitor Need	1	1
899	jumpDriveCapacitorNeedBonus	5		\N	\N	1032	\N	0	1	105	Jump Drive Capacitor Need Bonus	1	1
901	accessDifficulty	5	The difficulty in opening this object.	\N	\N	0	\N	0	1	\N	Access Difficulty	1	1
902	accessDifficultyBonus	5	Bonus to chance of opening a container.	\N	\N	0	\N	0	1	121	Access Difficulty Bonus	1	1
903	spawnWithoutGuardsToo	5	Whether a spawn container should refill itself when there are no guards assigned to it.	\N	\N	0	\N	0	0	\N	spawnWithoutGuardsToo	1	1
904	warcruiserCPUBonus	5		\N	\N	0	\N	0	0	\N	warcruiserCPUBonus	1	1
905	tacklerBonus	4		\N	\N	0	\N	10	0	\N	tacklerBonus	1	1
906	disallowEarlyDeactivation	3	Signifies that this module if activated, will prevent ejection from the ship it is fitted to and extend the log out ship removal timer.	\N	\N	0	\N	0	0	\N	disallowEarlyDeactivation	1	1
907	hasShipMaintenanceBay	3	Indicates whether a ship type has a ship maintenance bay.	\N	\N	0	\N	0	0	\N	hasShipMaintenanceBay	1	1
908	shipMaintenanceBayCapacity	5	The capacity of the hangar in a ship.	\N	\N	71	\N	0	1	9	Ship Maintenance Bay Capacity	1	1
909	maxShipGroupActiveID	12	Which group of modules that this ship limits the number of concurrent activations of.	\N	\N	0	\N	0	0	\N	maxShipGroupActiveID	1	1
910	maxShipGroupActive	4	The amount of modules belonging to the same group that can be active at the same time.	\N	\N	0	\N	0	1	\N	Max Group Active	1	1
911	hasCorporateHangars	3	Whether this ship has corporate hangars.	\N	\N	0	\N	0	0	\N	hasCorporateHangars	1	1
912	corporateHangarCapacity	5	The capacity of each hangar.	\N	\N	71	\N	0	1	9	Corporate Hangar Capacity	1	1
913	gallenteNavyBonus	5		\N	\N	0	\N	0	0	\N	gallenteNavyBonus	1	1
914	gallenteNavyBonusMultiplier	5		\N	\N	0	\N	0	0	\N	gallenteNavyBonusMultiplier	1	1
915	caldariNavyBonus	5		\N	\N	0	\N	0	0	\N	caldariNavyBonus	1	1
916	caldariNavyBonusMultiplier	5		\N	\N	0	\N	0	0	\N	caldariNavyBonusMultiplier	1	1
917	amarrNavyBonus	5		\N	\N	0	\N	0	0	\N	amarrNavyBonus	1	1
918	amarrNavyBonusMulitplier	5		\N	\N	0	\N	0	0	\N	amarrNavyBonusMulitplier	1	1
919	republicFleetBonus	5		\N	\N	0	\N	0	0	\N	republicFleetBonus	1	1
920	republicFleetBonusMultiplier	5		\N	\N	0	\N	0	0	\N	republicFleetBonusMultiplier	1	1
921	oreCompression	3		\N	\N	0	\N	0	0	\N	oreCompression	1	1
924	eliteBonusBarge1	5		\N	\N	0	\N	0	0	\N	eliteBonusBarge1	1	1
925	eliteBonusBarge2	5		\N	\N	0	\N	0	0	\N	eliteBonusBarge2	1	1
926	shipBonusORE3	5	ORE Mining Barge bonus 3	\N	\N	0	\N	0	0	\N	shipBonusORE3	1	1
927	miningUpgradeCPUReductionBonus	5		\N	\N	0	\N	0	0	\N	miningUpgradeCPUReductionBonus	1	1
928	entityTargetJam	5	Target Jam multiplier on max locked targets for NPCs	\N	\N	0	\N	1	0	\N	entityTargetJam	1	1
929	entityTargetJamDuration	4	Duration of NPC effect	\N	\N	0	\N	30000	0	\N	entityTargetJamDuration	1	1
930	entityTargetJamDurationChance	5	Chance of NPC effect to be activated each duration	\N	\N	0	\N	0	0	\N	entityTargetJamDurationChance	1	1
931	entityCapacitorDrainDurationChance	5	Chance of NPC effect to be activated each duration	\N	\N	0	\N	0	0	\N	entityCapacitorDrainDurationChance	1	1
932	entitySensorDampenDurationChance	5	Chance of NPC effect to be activated each duration	\N	\N	0	\N	0	0	\N	entitySensorDampenDurationChance	1	1
933	entityTrackingDisruptDurationChance	5	Chance of NPC effect to be activated each duration	\N	\N	0	\N	0	0	\N	entityTrackingDisruptDurationChance	1	1
935	entityTargetPaintDurationChance	5	Chance of NPC effect to be activated each duration	\N	\N	0	\N	0	0	\N	entityTargetPaintDurationChance	1	1
936	entityTargetJamMaxRange	4	Max Range for NPC Target Jam	\N	\N	0	\N	0	0	\N	entityTargetJamActivationRange	1	1
937	entityCapacitorDrainMaxRange	4	Range for NPC capacitor drain	\N	\N	0	\N	0	0	\N	entityCapacitorDrainActivationRange	1	1
938	entitySensorDampenMaxRange	4	Range from target for when the NPC activates the effect	\N	\N	0	\N	0	0	\N	entitySensorDampenActivationRange	1	1
940	entityTrackingDisruptMaxRange	4	Max range from for NPC tracking disrupt	\N	\N	0	\N	0	0	\N	entityTrackingDisruptActivationRange	1	1
941	entityTargetPaintMaxRange	4	Max Range for NPC Target Paint	\N	\N	0	\N	0	0	\N	entityTargetPaintActivationRange	1	1
942	entityCapacitorDrainDuration	4	Duration of NPC effect	\N	\N	0	\N	30000	0	\N	entityCapacitorDrainDuration	1	1
943	entitySensorDampenDuration	4	Duration of NPC effect	\N	\N	0	\N	30000	0	\N	entitySensorDampenDuration	1	1
944	entityTrackingDisruptDuration	4	Duration of NPC effect	\N	\N	0	\N	30000	0	\N	entityTrackingDisruptDuration	1	1
945	entityTargetPaintDuration	4	Duration of NPC effect	\N	\N	0	\N	30000	0	\N	entityTargetPaintDuration	1	1
946	entityCapacitorDrainAmount	4	Amount of capacitor drained by NPC from target	\N	\N	0	\N	0	0	\N	entityCapacitorDrainAmount	1	1
947	entitySensorDampenMultiplier	5	Multiplier on max target range and scan resolution of target ship done by NPC	\N	\N	0	\N	1	0	\N	entitySensorDampenMultiplier	1	1
948	entityTrackingDisruptMultiplier	5	Multiplier on tracking speed and optimal range of player turrets done by NPC	\N	\N	0	\N	1	0	\N	entityTrackingDisruptMultiplier	1	1
949	entityTargetPaintMultiplier	5	Multiplier on signature radius of player ship done by NPC	\N	\N	0	\N	1	0	\N	entityTargetPaintMultiplier	1	1
950	entitySensorDampenFallOff	4	Fall Off for NPC sensor dampen	\N	\N	0	\N	0	0	\N	entitySensorDampenFallOff	1	1
951	entityTrackingDisruptFallOff	4	Fall Off for NPC Tracking Disrupt	\N	\N	0	\N	0	0	\N	entityTrackingDisruptFallOff	1	1
952	entityCapacitorFallOff	4	Fall Off for NPC Capacitor Drain	\N	\N	0	\N	0	0	\N	entityCapacitorFallOff	1	1
953	entityTargetJamFallOff	4	Fall Off for NPC Target Jam	\N	\N	0	\N	0	0	\N	entityTargetJamFallOff	1	1
954	entityTargetPaintFallOff	4	Fall Off for NPC Target Paint	\N	\N	0	\N	0	0	\N	entityTargetPaintFallOff	1	1
955	isCaldariNavy	5		\N	\N	0	\N	0	0	\N	isCaldariNavy	1	1
956	damageModifierMultiplierBonus	5		\N	\N	0	\N	0	0	\N	damageModifierMultiplierBonus	1	1
957	cNavyModOncNavyShip	5		\N	\N	0	\N	0	0	\N	cNavyModOncNavyShip	1	1
958	hardeningBonus	5	Autogenerated skill attribute, hardeningBonus	\N	\N	0	\N	0	1	105	Hardening Bonus	1	1
959	entityShieldBoostLargeDelayChance	5		\N	\N	0	\N	0	0	\N	entityShieldBoostLargeDelayChance	1	1
960	caldariNavyBonusMultiplier2	5		\N	\N	0	\N	0	0	\N	caldariNavyBonusMultiplier2	1	1
961	caldarNavyBonus2	5		\N	\N	0	\N	0	0	\N	caldarNavyBonus2	1	1
962	eliteBonusReconShip1	5		\N	\N	0	\N	0	0	\N	eliteBonusReconShip1	1	1
963	eliteBonusReconShip2	5		\N	\N	0	\N	0	0	\N	eliteBonusReconShip2	1	1
964	passiveEmDamageResonanceMultiplier	5		\N	\N	1396	\N	1	0	111	Passive EM damage resistance bonus	0	0
965	passiveThermalDamageResonanceMultiplier	5		\N	\N	1394	\N	1	0	111	Passive Thermal dmg resistance bonus	0	0
966	passiveKineticDamageResonanceMultiplier	5		\N	\N	1393	\N	1	0	111	Passive Kinetic dmg resistance bonus	0	0
967	passiveExplosiveDamageResonanceMultiplier	5		\N	\N	1395	\N	1	0	111	Passive Explosive dmg resistance bonus	0	0
968	hasStasisWeb	4	Used for Probes.	\N	\N	0	\N	0	0	\N	hasStasisWeb	1	1
969	activeEmDamageResonance	5		\N	\N	1396	\N	1	0	111	Active EM dmg resistance bonus	0	0
970	activeThermalDamageResonance	5		\N	\N	1394	\N	1	0	111	Active Thermal dmg resistance bonus	0	0
971	activeKineticDamageResonance	5		\N	\N	1393	\N	1	0	111	Active Kinetic dmg resistance bonus	0	0
972	activeExplosiveDamageResonance	5		\N	\N	1395	\N	1	0	111	Active Explosive dmg resistance bonus	0	0
973	signatureRadiusBonusPercent	5		\N	\N	0	\N	0	1	105	Signature radius bonus	0	1
974	hullEmDamageResonance	5		\N	\N	0	\N	1	1	108	Hull Em Damage Resistance	1	1
975	hullExplosiveDamageResonance	5		\N	\N	0	\N	1	1	108	Hull Explosive Damage Resistance	1	1
976	hullKineticDamageResonance	5		\N	\N	0	\N	1	1	108	Hull Kinetic Damage Resistance	1	1
977	hullThermalDamageResonance	5		\N	\N	0	\N	1	1	108	Hull Thermal Damage Resistance	1	1
978	maxGroupOnline	4	Maximum modules of same group that can be onlined at same time, 0 = no limit, 1 = 1	\N	\N	0	\N	0	0	\N	maxGroupOnline	1	1
979	maxJumpClones	4	The maximum amount of jump clones that the character may have in existence.	\N	\N	0	\N	0	0	\N	maxJumpClones	1	1
980	hasCloneJumpSlots	4	The number of clone jump slots that the ship offers.	\N	\N	0	\N	0	0	\N	hasCloneJumpSlots	1	1
981	allowsCloneJumpsWhenActive	4	If this module is active and the ship supports it, the ship can serve as a destination for clone jumps.	\N	\N	0	\N	0	0	\N	allowsCloneJumpsWhenActive	1	1
982	canReceiveCloneJumps	4	Defines whether a ship has the functionality to allow it to receive clone jumps and host jump clones.	\N	\N	0	\N	0	0	\N	canReceiveCloneJumps	1	1
983	signatureRadiusAdd	5		\N	\N	0	\N	0	1	\N	Signature radius bonus	1	1
984	emDamageResistanceBonus	5		\N	\N	1396	\N	0	1	124	EM dmg resistance bonus	0	0
985	explosiveDamageResistanceBonus	5		\N	\N	1395	\N	0	1	124	Explosive dmg resistance bonus	0	0
986	kineticDamageResistanceBonus	5		\N	\N	1393	\N	0	1	105	Kinetic dmg resistance bonus	0	0
987	thermalDamageResistanceBonus	5		\N	\N	1394	\N	0	1	124	Thermal dmg resistance bonus	0	0
988	hardeningbonus2	5		\N	\N	0	\N	0	0	\N	hardeningbonus2	1	1
989	volumePostPercent	5		\N	\N	0	\N	0	0	\N	volumePostPercent	1	1
990	activeEmResistanceBonus	5		\N	\N	0	\N	0	0	\N	activeEmResistanceBonus	1	1
991	activeExplosiveResistanceBonus	5		\N	\N	0	\N	0	0	\N	activeExplosiveResistanceBonus	1	1
992	activeThermicResistanceBonus	5		\N	\N	0	\N	0	0	\N	activeThermicResistanceBonus	1	1
993	activeKineticResistanceBonus	5		\N	\N	0	\N	0	0	\N	activeKineticResistanceBonus	1	1
994	passiveEmDamageResistanceBonus	5		\N	\N	1396	\N	0	1	105	Passive EM dmg resistance bonus	0	0
995	passiveExplosiveDamageResistanceBonus	5		\N	\N	1395	\N	0	1	105	Passive Explosive dmg resistance bonus	0	0
996	passiveKineticDamageResistanceBonus	5		\N	\N	1393	\N	0	1	105	Passive kinetic dmg resistance bonus	0	0
997	passiveThermicDamageResistanceBonus	5		\N	\N	1394	\N	0	1	105	Passive thermal dmg resistance bonus	0	0
998	isRAMcompatible	3	Can have research and manufacturing functionality	\N	\N	0	\N	0	0	\N	Research and Manufacturing Compatible	1	1
999	eliteBonusCommandShips2	5		\N	\N	0	\N	0	0	\N	eliteBonusCommandShips2	1	1
1000	eliteBonusCommandShips1	5		\N	\N	0	\N	0	0	\N	eliteBonusCommandShips1	1	1
1001	jumpPortalConsumptionMassFactor	5	Multiplier used to calculate amount of quantity used for jumping via portals based on mass of ship.	\N	\N	0	\N	0	0	\N	jumpPortalConsumptionMassFactor	1	1
1002	jumpPortalDuration	4		\N	\N	0	\N	300000	0	\N	jumpPortalDuration	1	1
1003	eliteBonusCommandShip1	5		\N	\N	0	\N	0	0	\N	eliteBonusCommandShip1	1	1
1004	eliteBonusCommandShip2	5		\N	\N	0	\N	0	0	\N	eliteBonusCommandShip2	1	1
1005	jumpPortalCapacitorNeed	5		\N	\N	1032	\N	0	1	114	jumpPortalCapacitorNeed	1	1
1006	entityShieldBoostDelayChanceSmall	5		\N	\N	0	\N	0	0	\N	entityShieldBoostDelayChanceSmall	1	1
1007	entityShieldBoostDelayChanceMedium	5		\N	\N	0	\N	0	0	\N	entityShieldBoostDelayChanceMedium	1	1
1008	entityShieldBoostDelayChanceLarge	5		\N	\N	0	\N	0	0	\N	entityShieldBoostDelayChanceLarge	1	1
1009	entityArmorRepairDelayChanceSmall	5		\N	\N	0	\N	0	0	\N	entityArmorRepairDelayChanceSmall	1	1
1010	entityArmorRepairDelayChanceMedium	5		\N	\N	0	\N	0	0	\N	entityArmorRepairDelayChanceMedium	1	1
1011	entityArmorRepairDelayChanceLarge	5		\N	\N	0	\N	0	0	\N	entityArmorRepairDelayChanceLarge	1	1
1012	eliteBonusInterdictors1	5	eliteBonusInterdictors1	\N	\N	0	\N	0	0	\N	eliteBonusInterdictors1	1	1
1013	eliteBonusInterdictors2	5	eliteBonusInterdictors2	\N	\N	0	\N	0	0	\N	eliteBonusInterdictors2	1	1
1014	disallowRepeatingActivation	4	If set, this module cannot be activated and made to autorepeat.	\N	\N	0	\N	0	1	\N	Can Not Auto Repeat	1	1
1015	entityShieldBoostDelayChanceSmallMultiplier	5		\N	\N	0	\N	1	0	\N	entityShieldBoostDelayChanceSmallMultiplier	1	1
1016	entityShieldBoostDelayChanceMediumMultiplier	5		\N	\N	0	\N	1	0	\N	entityShieldBoostDelayChanceMediumMultiplier	1	1
1017	entityShieldBoostDelayChanceLargeMultiplier	5		\N	\N	0	\N	1	0	\N	entityShieldBoostDelayChanceLargeMultiplier	1	1
1018	entityArmorRepairDelayChanceSmallMultiplier	5		\N	\N	0	\N	1	0	\N	entityArmorRepairDelayChanceSmallMultiplier	1	1
1019	entityArmorRepairDelayChanceMediumMultiplier	5		\N	\N	0	\N	1	0	\N	entityArmorRepairDelayChanceMediumMultiplier	1	1
1020	entityArmorRepairDelayChanceLargeMultiplier	5		\N	\N	0	\N	1	0	\N	entityArmorRepairDelayChanceLargeMultiplier	1	1
1021	warpAccuracyMaxRange	5		\N	\N	0	\N	15000	0	\N	warpAccuracyMaxRange	1	1
1022	warpAccuracyFactor	5		\N	\N	0	\N	1	0	\N	warpAccuracyFactor	1	1
1023	warpAccuracyFactorMultiplier	5		\N	\N	0	\N	1	0	\N	warpAccuracyFactorMultiplier	1	1
1024	warpAccuracyMaxRangeMultiplier	5		\N	\N	0	\N	1	0	\N	warpAccuracyMaxRangeMultiplier	1	1
1025	warpAccuracyFactorPercentage	5		\N	\N	0	\N	0	0	\N	warpAccuracyFactorPercentage	1	1
1026	warpAccuracyMaxRangePercentage	5		\N	\N	0	\N	0	0	\N	warpAccuracyMaxRangePercentage	1	1
1027	scanGravimetricStrengthPercent	5		\N	\N	0	\N	0	1	105	Gravimetric Strength	1	1
1028	scanLadarStrengthPercent	5		\N	\N	0	\N	0	1	105	Ladar Strength	1	1
1029	scanMagnetometricStrengthPercent	5		\N	\N	0	\N	0	1	105	Magnetometric Strength	1	1
1030	scanRadarStrengthPercent	5		\N	\N	0	\N	0	1	105	Radar Strength	1	1
1031	controlTowerSize	3	numeric classification for tower size\n	\N	\N	0	\N	1	1	117	Control Tower Size	1	1
1032	anchoringSecurityLevelMax	5	The maximum security level at which the structure can be anchored.	\N	\N	0	\N	1	0	\N	anchoringSecurityLevelMax	1	1
1033	anchoringRequiresSovereignty	4	Whether the structure requires the anchorers alliance to hold sovereignty in the system for it to be anchorable.	\N	\N	0	\N	0	0	\N	anchoringRequiresSovereignty	1	1
1034	covertOpsAndReconOpsCloakModuleDelay	5		\N	\N	0	\N	30000	1	101	covertOpsStealthBomberCloakModuleDelay	1	1
1035	covertOpsStealthBomberTargettingDelay	5		\N	\N	0	\N	20000	0	101	covertOpsStealthBomberTargettingDelay	1	1
1036	titanAmarrBonus1	5		\N	\N	0	\N	0	0	\N	titanAmarrBonus1	1	1
1038	titanAmarrBonus2	5		\N	\N	0	\N	0	0	\N	titanAmarrBonus2	1	1
1039	titanCaldariBonus1	5		\N	\N	0	\N	0	0	\N	titanCaldariBonus1	1	1
1040	titanCaldariBonus2	5		\N	\N	0	\N	0	0	\N	titanCaldariBonus2	1	1
1041	titanGallenteBonus1	5		\N	\N	0	\N	0	0	\N	titanGallenteBonus1	1	1
1042	titanGallenteBonus2	5		\N	\N	0	\N	0	0	\N	titanGallenteBonus2	1	1
1043	titanMinmatarBonus1	5		\N	\N	0	\N	0	0	\N	titanMinmatarBonus1	1	1
1044	titanMinmatarBonus2	5		\N	\N	0	\N	0	0	\N	titanMinmatarBonus2	1	1
1045	maxTractorVelocity	5	The maximum speed that the tractor beam draws objects closer at.	\N	\N	0	\N	0	1	10	Max Tractor Velocity	1	1
1047	canNotBeTrainedOnTrial	4	If set to 1 on a skill then this skill can not be trained on accounts that are marked as Trial.	\N	\N	0	\N	0	0	\N	canNotBeTrainedOnTrial	1	1
1048	disallowOffensiveModifierBonus	5		\N	\N	0	\N	0	0	\N	disallowOffensiveModifierBonus	1	1
1049	carrierAmarrBonus1	5		\N	\N	0	\N	0	0	\N	carrierAmarrBonus1	1	1
1050	carrierAmarrBonus2	5		\N	\N	0	\N	0	0	\N	carrierAmarrBonus2	1	1
1051	carrierAmarrBonus3	5		\N	\N	0	\N	0	0	\N	carrierAmarrBonus3	1	1
1052	carrierCaldariBonus1	5		\N	\N	0	\N	0	0	\N	carrierCaldariBonus1	1	1
1053	carrierCaldariBonus2	5		\N	\N	0	\N	0	0	\N	carrierCaldariBonus2	1	1
1054	carrierCaldariBonus3	5		\N	\N	0	\N	0	0	\N	carrierCaldariBonus3	1	1
1055	carrierGallenteBonus1	5		\N	\N	0	\N	0	0	\N	carrierGallenteBonus1	1	1
1056	carrierGallenteBonus2	5		\N	\N	0	\N	0	0	\N	carrierGallenteBonus2	1	1
1057	carrierGallenteBonus3	5		\N	\N	0	\N	0	0	\N	carrierGallenteBonus3	1	1
1058	carrierMinmatarBonus1	5		\N	\N	0	\N	0	0	\N	carrierMinmatarBonus1	1	1
1059	carrierMinmatarBonus2	5		\N	\N	0	\N	0	0	\N	carrierMinmatarBonus2	1	1
1060	carrierMinmatarBonus3	5		\N	\N	0	\N	0	0	\N	carrierMinmatarBonus3	1	1
1061	titanAmarrBonus3	5		\N	\N	0	\N	0	0	\N	titanAmarrBonus3	1	1
1062	titanAmarrBonus4	5		\N	\N	0	\N	0	0	\N	titanAmarrBonus4	1	1
1063	titanCaldariBonus3	5		\N	\N	0	\N	0	0	\N	titanCaldariBonus3	1	1
1064	titanCaldariBonus4	5		\N	\N	0	\N	0	0	\N	titanCaldariBonus4	1	1
1065	titanGallenteBonus3	5		\N	\N	0	\N	0	0	\N	titanGallenteBonus3	1	1
1066	titanGallenteBonus4	5		\N	\N	0	\N	0	0	\N	titanGallenteBonus4	1	1
1067	titanMinmatarBonus4	5		\N	\N	0	\N	0	0	\N	titanMinmatarBonus4	1	1
1068	titanMinmatarBonus3	5		\N	\N	0	\N	0	0	\N	titanMinmatarBonus3	1	1
1069	carrierAmarrBonus4	5		\N	\N	0	\N	0	0	\N	carrierAmarrBonus4	1	1
1070	carrierCaldariBonus4	5		\N	\N	0	\N	0	0	\N	carrierCaldariBonus4	1	1
1071	carrierGallenteBonus4	5		\N	\N	0	\N	0	0	\N	carrierGallenteBonus4	1	1
1072	carrierMinmatarBonus4	5		\N	\N	0	\N	0	0	\N	carrierMinmatarBonus4	1	1
1073	maxJumpClonesBonus	4		\N	\N	0	\N	0	1	\N	Clone Bay Bonus	1	1
1074	disallowInEmpireSpace	4	If set on a charge or module type, will prevent it from being activated in empire space.	\N	\N	0	\N	0	0	\N	disallowInEmpireSpace	1	1
1075	missileNeverDoesDamage	4	If present on a type which is used like a missile, signifies that it should never do damage (whether it has any to do or not).	\N	\N	0	\N	0	0	\N	missileNeverDoesDamage	1	1
1076	implantBonusVelocity	5		\N	\N	0	\N	0	1	121	Velocity Modifier	1	1
1077	maxDCUModules	5		\N	\N	0	\N	0	1	\N	Drone Modules	1	1
1079	capacitorCapacityBonus	4	Autogenerated skill attribute, CapacitorCapacityBonus	\N	\N	0	\N	0	1	105	Capacitor Bonus	1	1
1080	cpuPenaltySuperWeapon	5		\N	\N	0	\N	0	0	\N	cpuPenaltySuperWeapon	1	1
1081	cpuBonusSuperWeapon	5		\N	\N	0	\N	0	0	\N	cpuBonusSuperWeapon	1	1
1082	cpuPenaltyPercent	5		\N	\N	0	\N	0	1	105	Cpu Penalty	1	1
1083	armorHpBonus2	4		\N	\N	1383	\N	0	1	\N	Armor Hp Bonus	1	1
1084	velocityBonus2	5		\N	\N	1389	\N	0	1	121	Velocity Modifier	1	1
1085	hasFuelCargo	4	Module consumption mechanic uses fuel cargo. Ships that have this with value of 1 can have fuel cargo. Need fuelCargoCapacity set as well.	\N	\N	0	\N	0	0	\N	hasFuelCargo	1	1
1086	fuelCargoCapacity	5	Used for ships that are supposed to be able to use fuel.	\N	\N	0	\N	0	1	\N	Fuel Cargo Capacity	1	1
1087	boosterness	4	Whether an item is a booster or not.	\N	\N	0	\N	0	1	\N	Booster Slot	1	1
1088	expiryTime	4	Internally set expiry time for objects which expire, so that the client knows when.	\N	\N	0	\N	0	0	\N	Expiry Timestamp	1	1
1089	boosterEffectChance1	5		\N	\N	0	\N	0	0	\N	boosterEffectChance1	1	1
1090	boosterEffectChance2	5		\N	\N	0	\N	0	0	\N	boosterEffectChance2	1	1
1091	boosterEffectChance3	5		\N	\N	0	\N	0	0	\N	boosterEffectChance3	1	1
1092	boosterEffectChance4	5		\N	\N	0	\N	0	0	\N	boosterEffectChance4	1	1
1093	boosterEffectChance5	5		\N	\N	0	\N	0	0	\N	boosterEffectChance5	1	1
1094	displayCapacitorCapacityBonus	5		\N	\N	0	\N	0	1	105	Capacitor Capacity Bonus	1	1
1095	displayShieldBoostMultiplier	5		\N	\N	0	\N	0	1	105	Shield Boost Bonus	1	1
1096	displayShieldCapacityBonus	5		\N	\N	0	\N	0	1	105	Shield Capacity Bonus	1	1
1097	displayAoeVelocityBonus	5		\N	\N	0	\N	0	1	105	Explosion Velocity	1	1
1098	displayRangeSkillBonus	5		\N	\N	0	\N	0	1	105	Optimal Range Bonus	1	1
1099	boosterAttribute1	5		\N	\N	0	\N	0	0	\N	boosterAttribute1	1	1
1100	boosterAttribute2	5		\N	\N	0	\N	0	0	\N	boosterAttribute2	1	1
1101	boosterAttribute3	5		\N	\N	0	\N	0	0	\N	boosterAttribute3	1	1
1102	boosterAttribute4	5		\N	\N	0	\N	0	0	\N	boosterAttribute4	1	1
1103	boosterAttribute5	5		\N	\N	0	\N	0	0	\N	boosterAttribute5	1	1
1104	displayMaxVelocityBonus	5		\N	\N	0	\N	0	1	105	Max Velocity Bonus	1	1
1105	displayArmorHpBonus	5		\N	\N	0	\N	0	1	105	Armor HP Penalty	1	1
1106	displayMissileMaxVelocityBonus	5		\N	\N	0	\N	0	1	105	Missile Max Velocity Bonus	1	1
1107	displayArmorDamageAmountBonus	5		\N	\N	0	\N	0	1	105	Armor Repaired Bonus	1	1
1108	displayFalloffModifier	5		\N	\N	0	\N	0	1	105	falloff bonus	1	1
1109	displayTrackingSpeedModifier	5		\N	\N	0	\N	0	1	105	Tracking Speed bonus	1	1
1110	displayAoeCloudsizeModifier	5		\N	\N	0	\N	0	1	105	Explosion Cloud Bonus	1	1
1111	displayMaxRangeModifier	5		\N	\N	0	\N	0	1	105	Optimal Range Bonus	1	1
1112	reverseEngineerPropabilityMultiplier	5	Modifies base chance of successful reverse engineering	\N	\N	0	\N	0	1	104	Probability Multiplier	1	1
1113	reverseEngineerMEMultiplier	5	Modifies the mineral efficiency of reverse engineered BPCs	\N	\N	0	\N	0	1	104	ME Multiplier	1	1
1114	reverseEngineerPEMultiplier	5	Modifies the production efficiency of reverse engineered BPCS	\N	\N	0	\N	0	1	104	PE Multiplier	1	1
1115	decryptorID	12	Used to show usable decryptors when starting reverse engineering based on data interface	\N	\N	0	\N	0	0	\N	decryptorID	1	1
1116	scanProbeStrength	5	The strength of the probe.	\N	\N	0	\N	0	1	\N	scanProbeStrength	1	1
1117	scanStrengthSignatures	5		\N	\N	0	\N	0	1	\N	scanStrengthSignatures	1	1
1118	scanStrengthDronesProbes	5		\N	\N	0	\N	0	1	\N	scanStrengthDronesProbes	1	1
1119	scanStrengthScrap	5		\N	\N	0	\N	0	1	\N	scanStrengthScrap	1	1
1120	scanStrengthShips	5		\N	\N	0	\N	0	1	\N	scanStrengthShips	1	1
1121	scanStrengthStructures	5		\N	\N	0	\N	0	1	\N	scanStrengthStructures	1	1
1122	maxScanGroups	4	Max groups that a character can scan for with probes. Default is 0 and max groups will be 5 with a single skill adding 1 per skill level.	\N	\N	0	\N	0	0	\N	maxScanGroups	1	1
1123	scanDuration	4	How long this probe has to scan until it can obtain results.	\N	\N	0	\N	60000	1	101	scanDuration	1	1
1124	reverseEngineerMaxRunMultiplier	5	Modifies the max runs in a blueprint created through reverse engineering	\N	\N	0	\N	0	1	104	Max Run Multiplier	1	1
1125	boosterChanceBonus	5		\N	\N	0	\N	0	1	105	Negative Side Effect Chance Bonus	1	1
1126	boosterAttributeModifier	5		\N	\N	0	\N	0	0	105	Side effect Modifier	1	1
1127	interfaceID	11	Links blueprints to the data interface required to reverse engineer it	\N	\N	0	\N	0	0	\N	InterfaceID	1	1
1128	datacore1ID	11	Datacore required to reverse engineer this blueprint	\N	\N	0	\N	0	0	\N	datacore1ID	1	1
1129	datacore2ID	11	Datacore required to reverse engineer this blueprint	\N	\N	0	\N	0	1	\N	datacore2ID	1	1
1130	ecmStrengthBonusPercent	5		\N	\N	0	\N	0	1	105	Jam Strength Bonus	1	1
\.


--
-- Name: dgmAttributes dgmAttributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dgmAttributes"
    ADD CONSTRAINT "dgmAttributes_pkey" PRIMARY KEY ("attributeID");


--
-- PostgreSQL database dump complete
--

\unrestrict xRc7r36ZgBocVhKrgtujrs9cUja3VQZujFkrjTQVdQdIIVSS3W4KiqAbvu78ild

