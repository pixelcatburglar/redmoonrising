--
-- PostgreSQL database dump
--

\restrict e2IAF0dulYF6HOKzsQtwXaNgmtK0a7w4pcbtCkNq2TCRWOhTKe5XWl5ZhahOIK8

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpVotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpVotes" (
    "voteCaseID" integer NOT NULL,
    "characterID" integer NOT NULL,
    "optionID" integer NOT NULL
);


--
-- Name: TABLE "crpVotes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."crpVotes" IS 'Cast votes, one per character per case. Serves corpRegistry.GetVotes(corpID, voteCaseID) and InsertVote(corporationID, voteCaseID, voteValue) (bco_voting.py:64,75). Push: OnCorporationVoteChanged(corporationID, voteCaseID, characterID, change) (corp_ui_votes.py:996).';


--
-- Name: COLUMN "crpVotes"."voteCaseID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVotes"."voteCaseID" IS 'PROVEN: 2nd arg of GetVotes/InsertVote (bco_voting.py:64,75).';


--
-- Name: COLUMN "crpVotes"."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVotes"."characterID" IS 'PROVEN: GetVotes returns rows the client indexes BY CHARACTER -- corp_ui_votes.py:1113 `votedFor = charVotes[eve.session.charid].optionID`. So the returned rowset is an IndexRowset keyed on characterID.';


--
-- Name: COLUMN "crpVotes"."optionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVotes"."optionID" IS 'PROVEN: corp_ui_votes.py:1113 reads .optionID off the indexed vote row. Written as InsertVote''s voteValue argument (corp_ui_votes.py:1135 passes option.optionID).';


--
-- Data for Name: crpVotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpVotes" ("voteCaseID", "characterID", "optionID") FROM stdin;
\.


--
-- Name: crpVotes crpVotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpVotes"
    ADD CONSTRAINT "crpVotes_pkey" PRIMARY KEY ("voteCaseID", "characterID");


--
-- Name: crpvotes_char_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crpvotes_char_ix ON public."crpVotes" USING btree ("characterID");


--
-- Name: INDEX crpvotes_char_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.crpvotes_char_ix IS '"have I already voted" -- corp_ui_votes.py:1113 charVotes[eve.session.charid].';



--
-- PostgreSQL database dump complete
--

\unrestrict e2IAF0dulYF6HOKzsQtwXaNgmtK0a7w4pcbtCkNq2TCRWOhTKe5XWl5ZhahOIK8

