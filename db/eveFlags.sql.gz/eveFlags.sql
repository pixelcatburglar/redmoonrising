--
-- PostgreSQL database dump
--

\restrict dTkAIkjujCnP0LOtVMAl1m7EehPTQ2fVLZJ448R5FlvZy4hjshNMb80rnwLLw8W

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eveFlags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."eveFlags" (
    "flagID" integer DEFAULT 0 NOT NULL,
    "flagName" text DEFAULT ''::text NOT NULL,
    "flagText" text DEFAULT ''::text NOT NULL,
    "flagType" text DEFAULT ''::text NOT NULL,
    "orderID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: eveFlags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."eveFlags" ("flagID", "flagName", "flagText", "flagType", "orderID") FROM stdin;
0	None	None		0
1	Wallet	Wallet		10
2	Factory	Factory		20
4	Hangar	Hangar		30
5	Cargo	Cargo		3000
6	Briefcase	Briefcase		12
7	Skill	Skill		15
8	Reward	Reward		17
9	Connected	Character in station connected		0
10	Disconnected	Character in station offline		0
11	LoSlot0	Low power slot 1		0
12	LoSlot1	Low power slot 2		0
13	LoSlot2	Low power slot 3		0
14	LoSlot3	Low power slot 4		0
15	LoSlot4	Low power slot 5		0
16	LoSlot5	Low power slot 6		0
17	LoSlot6	Low power slot 7		0
18	LoSlot7	Low power slot 8		0
19	MedSlot0	Medium power slot 1		0
20	MedSlot1	Medium power slot 2		0
21	MedSlot2	Medium power slot 3		0
22	MedSlot3	Medium power slot 4		0
23	MedSlot4	Medium power slot 5		0
24	MedSlot5	Medium power slot 6		0
25	MedSlot6	Medium power slot 7		0
26	MedSlot7	Medium power slot 8		0
27	HiSlot0	High power slot 1		0
28	HiSlot1	High power slot 2		0
29	HiSlot2	High power slot 3		0
30	HiSlot3	High power slot 4		0
31	HiSlot4	High power slot 5		0
32	HiSlot5	High power slot 6		0
33	HiSlot6	High power slot 7		0
34	HiSlot7	High power slot 8		0
35	Fixed Slot	Fixed Slot		0
36	Factory Blueprint	Factory blueprint		21
37	Factory Minerals	Factory mineral		22
38	Factory Output	Factory output		23
39	Factory Active	Factory active		0
40	Factory_Slot_0	Factory slot 1		0
41	Factory_Slot_1	Factory slot 2		0
42	Factory_Slot_2	Factory slot 3		0
43	Factory_Slot_3	Factory slot 4		0
44	Factory_Slot_4	Factory slot 5		0
45	Factory_Slot_5	Factory slot 6		0
46	Factory_Slot_6	Factory slot 7		0
47	Factory_Slot_7	Factory slot 8		0
48	Factory_Slot_8	Factory slot 9		0
49	Factory_Slot_9	Factory slot 10		0
50	Factory_Slot_10	Factory slot 11		0
51	Factory_Slot_11	Factory slot 12		0
52	Factory_Slot_12	Factory slot 13		0
53	Factory_Slot_13	Factory slot 14		0
54	Factory_Slot_14	Factory slot 15		0
55	Factory_Slot_15	Factory slot 16		0
56	Capsule	Capsule	Capsule item in spac	0
57	Pilot	Pilot		0
58	Passenger	Passenger		0
59	Boarding Gate	Boarding gate		0
60	Crew	Crew		0
61	Skill In Training	Skill in training	Where a skill goes.	0
62	CorpMarket	Corporation Market Deliveries / Returns		0
63	Locked	Locked item, can not be moved unless unlocked		0
64	Unlocked	Unlocked item, can be moved		0
70	Office Slot 1	Office slot 1		0
71	Office Slot 2	Office slot 2		0
72	Office Slot 3	Office slot 3		0
73	Office Slot 4	Office slot 4		0
74	Office Slot 5	Office slot 5		0
75	Office Slot 6	Office slot 6		0
76	Office Slot 7	Office slot 7		0
77	Office Slot 8	Office slot 8		0
78	Office Slot 9	Office slot 9		0
79	Office Slot 10	Office slot 10		0
80	Office Slot 11	Office slot 11		0
81	Office Slot 12	Office slot 12		0
82	Office Slot 13	Office slot 13		0
83	Office Slot 14	Office slot 14		0
84	Office Slot 15	Office slot 15		0
85	Office Slot 16	Office slot 16		0
86	Bonus	Bonus	Char bonus/penalty	0
87	DroneBay	Drone Bay		0
88	Booster	Booster	Char booster	0
89	Implant	Implant	Character implant	0
90	ShipHangar	Ship Hangar	Solarsystem location	0
91	ShipOffline	Ship Offline	Solarsystem location	0
100	Research_Facility_Slot_100	Research Facility Slot 100		0
101	Research_Facility_Slot_101	Research Facility Slot 101		0
102	Research_Facility_Slot_102	Research Facility Slot 102		0
103	Research_Facility_Slot_103	Research Facility Slot 103		0
104	Research_Facility_Slot_104	Research Facility Slot 104		0
105	Research_Facility_Slot_105	Research Facility Slot 105		0
106	Research_Facility_Slot_106	Research Facility Slot 106		0
107	Research_Facility_Slot_107	Research Facility Slot 107		0
108	Research_Facility_Slot_108	Research Facility Slot 108		0
109	Research_Facility_Slot_109	Research Facility Slot 109		0
110	Research_Facility_Slot_110	Research Facility Slot 110		0
111	Research_Facility_Slot_111	Research Facility Slot 111		0
112	Research_Facility_Slot_112	Research Facility Slot 112		0
113	Research_Facility_Slot_113	Research Facility Slot 113		0
114	Research_Facility_Slot_114	Research Facility Slot 114		0
115	Research_Facility_Slot_115	Research Facility Slot 115		0
116	CorpSAG2	Corp Security Access Group 2		0
117	CorpSAG3	Corp Security Access Group 3		0
118	CorpSAG4	Corp Security Access Group 4		0
119	CorpSAG5	Corp Security Access Group 5		0
120	CorpSAG6	Corp Security Access Group 6		0
121	CorpSAG7	Corp Security Access Group 7		0
140	Factory Slot 0	Factory slot 1		0
141	Factory Slot 1	Factory slot 2		0
142	Factory Slot 2	Factory slot 3		0
143	Factory Slot 3	Factory slot 4		0
144	Factory Slot 4	Factory slot 5		0
145	Factory Slot 5	Factory slot 6		0
146	Factory Slot 6	Factory slot 7		0
147	Factory Slot 7	Factory slot 8		0
148	Factory Slot 8	Factory slot 9		0
149	Factory Slot 9	Factory slot 10		0
150	Factory Slot 10	Factory slot 11		0
151	Factory Slot 11	Factory slot 12		0
152	Factory Slot 12	Factory slot 13		0
153	Factory Slot 13	Factory slot 14		0
154	Factory Slot 14	Factory slot 15		0
155	Factory Slot 15	Factory slot 16		0
156	Factory Slot 16	Factory slot 17		0
157	Factory Slot 17	Factory slot 18		0
158	Factory Slot 18	Factory slot 19		0
159	Factory Slot 19	Factory slot 20		0
160	Factory Slot 20	Factory slot 21		0
161	Factory Slot 21	Factory slot 22		0
162	Factory Slot 22	Factory slot 23		0
163	Factory Slot 23	Factory slot 24		0
164	Factory Slot 24	Factory slot 25		0
165	Factory Slot 25	Factory slot 26		0
166	Factory Slot 26	Factory slot 27		0
167	Factory Slot 27	Factory slot 28		0
168	Factory Slot 28	Factory slot 29		0
169	Factory Slot 29	Factory slot 30		0
170	Factory Slot 30	Factory slot 31		0
171	Factory Slot 31	Factory slot 32		0
172	Factory Slot 32	Factory slot 33		0
173	Factory Slot 33	Factory slot 34		0
174	Factory Slot 34	Factory slot 35		0
175	Factory Slot 35	Factory slot 36		0
176	Factory Slot 36	Factory slot 37		0
177	Factory Slot 37	Factory slot 38		0
178	Factory Slot 38	Factory slot 39		0
179	Factory Slot 39	Factory slot 40		0
180	Factory Slot 40	Factory slot 41		0
181	Factory Slot 41	Factory slot 42		0
182	Factory Slot 42	Factory slot 43		0
183	Factory Slot 43	Factory slot 44		0
184	Factory Slot 44	Factory slot 45		0
185	Factory Slot 45	Factory slot 46		0
186	Factory Slot 46	Factory slot 47		0
187	Factory Slot 47	Factory slot 48		0
188	Factory Slot 48	Factory slot 49		0
189	Factory Slot 49	Factory slot 50		0
190	Factory Slot 50	Factory slot 51		0
191	Factory Slot 51	Factory slot 52		0
192	Factory Slot 52	Factory slot 53		0
193	Factory Slot 53	Factory slot 54		0
194	Factory Slot 54	Factory slot 55		0
195	Factory Slot 55	Factory slot 56		0
200	Research Facility Slot 0	Research facility slot 1		0
201	Research Facility Slot 1	Research facility slot 2		0
202	Research Facility Slot 2	Research facility slot 3		0
203	Research Facility Slot 3	Research facility slot 4		0
204	Research Facility Slot 4	Research facility slot 5		0
205	Research Facility Slot 5	Research facility slot 6		0
206	Research Facility Slot 6	Research facility slot 7		0
207	Research Facility Slot 7	Research facility slot 8		0
208	Research Facility Slot 8	Research facility slot 9		0
209	Research Facility Slot 9	Research facility slot 10		0
210	Research Facility Slot 10	Research facility slot 11		0
211	Research Facility Slot 11	Research facility slot 12		0
212	Research Facility Slot 12	Research facility slot 13		0
213	Research Facility Slot 13	Research facility slot 14		0
214	Research Facility Slot 14	Research facility slot 15		0
215	Research Facility Slot 15	Research facility slot 16		0
216	Research Facility Slot 16	Research facility slot 17		0
217	Research Facility Slot 17	Research facility slot 18		0
218	Research Facility Slot 18	Research facility slot 19		0
219	Research Facility Slot 19	Research facility slot 20		0
220	Research Facility Slot 20	Research facility slot 21		0
221	Research Facility Slot 21	Research facility slot 22		0
222	Research Facility Slot 22	Research facility slot 23		0
223	Research Facility Slot 23	Research facility slot 24		0
224	Research Facility Slot 24	Research facility slot 25		0
225	Research Facility Slot 25	Research facility slot 26		0
226	Research Facility Slot 26	Research facility slot 27		0
227	Research Facility Slot 27	Research facility slot 28		0
228	Research Facility Slot 28	Research facility slot 29		0
229	Research Facility Slot 29	Research facility slot 30		0
230	Research Facility Slot 30	Research facility slot 31		0
231	Research Facility Slot 31	Research facility slot 32		0
232	Research Facility Slot 32	Research facility slot 33		0
233	Research Facility Slot 33	Research facility slot 34		0
234	Research Facility Slot 34	Research facility slot 35		0
235	Research Facility Slot 35	Research facility slot 36		0
236	Research Facility Slot 36	Research facility slot 37		0
237	Research Facility Slot 37	Research facility slot 38		0
238	Research Facility Slot 38	Research facility slot 39		0
239	Research Facility Slot 39	Research facility slot 40		0
240	Research Facility Slot 40	Research facility slot 41		0
241	Research Facility Slot 41	Research facility slot 42		0
242	Research Facility Slot 42	Research facility slot 43		0
243	Research Facility Slot 43	Research facility slot 44		0
244	Research Facility Slot 44	Research facility slot 45		0
245	Research Facility Slot 45	Research facility slot 46		0
246	Research Facility Slot 46	Research facility slot 47		0
247	Research Facility Slot 47	Research facility slot 48		0
248	Research Facility Slot 48	Research facility slot 49		0
249	Research Facility Slot 49	Research facility slot 50		0
250	Research Facility Slot 50	Research facility slot 51		0
251	Research Facility Slot 51	Research facility slot 52		0
252	Research Facility Slot 52	Research facility slot 53		0
253	Research Facility Slot 53	Research facility slot 54		0
254	Research Facility Slot 54	Research facility slot 55		0
255	Research Facility Slot 55	Research facility slot 56		0
\.


--
-- Name: eveFlags eveFlags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."eveFlags"
    ADD CONSTRAINT "eveFlags_pkey" PRIMARY KEY ("flagID");


--
-- PostgreSQL database dump complete
--

\unrestrict dTkAIkjujCnP0LOtVMAl1m7EehPTQ2fVLZJ448R5FlvZy4hjshNMb80rnwLLw8W

