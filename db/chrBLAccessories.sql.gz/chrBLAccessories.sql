--
-- PostgreSQL database dump
--

\restrict GG2irbiKWiA9jJnce8a11XICY09XB210hW36m5xV9Hxrt71bb3u0CgQSnxlCycG

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLAccessories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLAccessories" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "accessoryID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLAccessories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLAccessories" ("bloodlineID", gender, "accessoryID", npc) FROM stdin;
2	1	1	0
3	0	1	0
3	0	7	0
3	0	8	0
3	0	9	0
3	0	10	0
3	0	11	0
3	1	1	0
3	1	12	0
3	1	13	0
3	1	14	0
4	1	1	0
4	1	2	0
4	1	3	0
4	1	4	0
4	1	5	0
4	1	6	0
14	1	1	0
14	1	15	0
14	1	16	0
14	1	17	0
14	1	18	0
14	1	19	0
14	1	20	0
14	1	21	0
\.


--
-- Name: chrBLAccessories chrBLAccessories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLAccessories"
    ADD CONSTRAINT "chrBLAccessories_pkey" PRIMARY KEY ("bloodlineID", gender, "accessoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict GG2irbiKWiA9jJnce8a11XICY09XB210hW36m5xV9Hxrt71bb3u0CgQSnxlCycG

