--
-- PostgreSQL database dump
--

\restrict XOtRUPmhHJUIcmI9R9sGDfR8FZf7dFTpiHYh4r8q0CA6qHChwKj8MmPdJGOuY0D

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account (
    "accountID" integer NOT NULL,
    "accountName" text DEFAULT ''::text NOT NULL,
    password text DEFAULT ''::text NOT NULL,
    role bigint DEFAULT 0 NOT NULL,
    "passwordAlgo" text DEFAULT 'plain'::text NOT NULL,
    banned smallint DEFAULT 0 NOT NULL,
    "createdAt" bigint DEFAULT 0 NOT NULL,
    "lastLogin" bigint,
    "languageID" text DEFAULT 'EN'::text NOT NULL
);


--
-- Name: COLUMN account.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account.role IS 'machoNet role bitmask. bigint because common/script/sys/service.py:64-65 defines ROLE_TRANSLATIONEDITOR = 2^32 and ROLE_SPAWN = 2^33, which do not fit in integer.';


--
-- Name: COLUMN account."passwordAlgo"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account."passwordAlgo" IS 'How "password" is stored: ''plain'' (what the current server compares, db.rs authenticate) or ''argon2id''. The wire password is cleartext -- client/script/ui/login/login.py:437-535 passes the edit-box value straight to Authenticate and the ARC4 at login.py:539 only obscures prefs.ini -- so the at-rest format is entirely our choice.';


--
-- Name: COLUMN account.banned; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account.banned IS 'INFERRED 0/1. No client read; needed operationally. A banned account should fail authentication before any session exists.';


--
-- Name: COLUMN account."createdAt"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account."createdAt" IS 'INFERRED. Windows FILETIME of account creation.';


--
-- Name: COLUMN account."lastLogin"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account."lastLogin" IS 'INFERRED. Windows FILETIME of the last successful Authenticate.';


--
-- Name: COLUMN account."languageID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account."languageID" IS 'Session languageID. PROOF: common/script/sys/sessions.py:214 lists languageID in __persistvars__ and :494 makes it dependent on userid; authentication.SetLanguageID is the client call that changes it.';


--
-- Name: account_accountID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."account_accountID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_accountID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."account_accountID_seq" OWNED BY public.account."accountID";


--
-- Name: account accountID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account ALTER COLUMN "accountID" SET DEFAULT nextval('public."account_accountID_seq"'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account ("accountID", "accountName", password, role, "passwordAlgo", banned, "createdAt", "lastLogin", "languageID") FROM stdin;
1	testuser	testpass	3	plain	0	0	\N	EN
2	root	root	3	plain	0	0	\N	EN
\.


--
-- Name: account_accountID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."account_accountID_seq"', 2, true);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY ("accountID");


--
-- Name: account_accountName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "account_accountName_key" ON public.account USING btree ("accountName");


--
-- Name: account_name_lower_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_name_lower_ix ON public.account USING btree (lower("accountName"));


--
-- Name: INDEX account_name_lower_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.account_name_lower_ix IS 'Login is a case-insensitive account-name lookup (db.rs authenticate does an exact match today; the client upper/lower-cases nothing, so this index is what makes a case-insensitive comparison affordable).';


--
-- PostgreSQL database dump complete
--

\unrestrict XOtRUPmhHJUIcmI9R9sGDfR8FZf7dFTpiHYh4r8q0CA6qHChwKj8MmPdJGOuY0D

