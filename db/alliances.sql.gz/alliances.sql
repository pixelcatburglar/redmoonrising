--
-- PostgreSQL database dump
--

\restrict Wbr3HwrMvZ5Pjm39ub5QWjJsZtUXXmkacrBdoatAL9ENOP6IfmzG4SMv0oSptie

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alliances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alliances (
    "allianceID" integer DEFAULT nextval('public.dyn_id_seq'::regclass) NOT NULL,
    "allianceName" text NOT NULL,
    "shortName" text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    "executorCorpID" integer,
    "creatorCorpID" integer,
    "creatorCharID" integer,
    dictatorial smallint DEFAULT 0 NOT NULL,
    "startDate" bigint DEFAULT 0 NOT NULL,
    "memberCount" integer DEFAULT 0 NOT NULL,
    deleted smallint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE alliances; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.alliances IS 'Player alliances. Serves allianceRegistry.GetAlliance / GetRankedAlliances / CreateAlliance / UpdateAlliance. GetAlliance returns a util.Row (all_cso_alliance.py:51 uses alliance.header and alliance.line); GetRankedAlliances returns a rowset the UI iterates.';


--
-- Name: COLUMN alliances."allianceID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."allianceID" IS 'From dyn_id_seq, so >= 100 000 000: cfg.IsAlliance (cfg.py:1459) refuses anything lower and then resolves the ID through cfg.eveowners, whose IsAlliance() is typeID == const.typeAlliance == invTypes 16159 (cfg.py:1568 + cfg.py:562-566). Creating an alliance must also insert eveStaticOwners(allianceID, allianceName, 16159).';


--
-- Name: COLUMN alliances."allianceName"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."allianceName" IS 'PROVEN: all_ui_rankings.py:60 row.allianceName. 1st arg of CreateAlliance (bco_alliance.py:29); all_ui_home.py:132 caps the input at maxlength 100.';


--
-- Name: COLUMN alliances."shortName"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."shortName" IS 'PROVEN: all_ui_rankings.py:60 row.shortName and all_ui_home.py:78 special-cases the column name ''shortName''. 2nd arg of CreateAlliance; all_ui_home.py:134 caps the input at maxlength 5. Also the payload of alliance_shortnames / the allianceshortnames bulkdata key.';


--
-- Name: COLUMN alliances.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances.description IS 'PROVEN: all_ui_home.py:186 setvalue = alliance.description, maxLength 5000. 3rd arg of CreateAlliance, 1st of UpdateAlliance.';


--
-- Name: COLUMN alliances.url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances.url IS 'PROVEN: all_ui_home.py:184 setvalue = alliance.url, maxLength 2048. 4th arg of CreateAlliance, 2nd of UpdateAlliance.';


--
-- Name: COLUMN alliances."executorCorpID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."executorCorpID" IS 'PROVEN and NULLABLE: all_ui_rankings.py:54 `if row.executorCorpID is not None`, all_ui_home.py:59, all_cso_members.py:28 `corpID != current.executorCorpID`. The corp currently executing for the alliance.';


--
-- Name: COLUMN alliances."creatorCorpID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."creatorCorpID" IS 'INFERRED. The corp that called CreateAlliance. No client read.';


--
-- Name: COLUMN alliances."creatorCharID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."creatorCharID" IS 'INFERRED. The character that called CreateAlliance. No client read.';


--
-- Name: COLUMN alliances.dictatorial; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances.dictatorial IS 'PROVEN 0/1: all_ui_rankings.py:60 [''No'',''Yes''][row.dictatorial]; all_cso_members.py:27 `if current.dictatorial and corpID != current.executorCorpID: raise UserError(''CanNotChooseExecutorAsDictatorial'')`.';


--
-- Name: COLUMN alliances."startDate"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."startDate" IS 'Windows FILETIME of creation. PROVEN: all_ui_rankings.py:60 util.FmtDate(row.startDate).';


--
-- Name: COLUMN alliances."memberCount"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances."memberCount" IS 'PROVEN: all_ui_rankings.py:60 row.memberCount. Denormalised count of allianceMembers -- keep it in step on join/leave.';


--
-- Name: COLUMN alliances.deleted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alliances.deleted IS 'INFERRED 0/1 soft delete, mirroring corporation."deleted".';


--
-- Data for Name: alliances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alliances ("allianceID", "allianceName", "shortName", description, url, "executorCorpID", "creatorCorpID", "creatorCharID", dictatorial, "startDate", "memberCount", deleted) FROM stdin;
\.


--
-- Name: alliances alliances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alliances
    ADD CONSTRAINT alliances_pkey PRIMARY KEY ("allianceID");


--
-- Name: alliances alliances_shortname_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alliances
    ADD CONSTRAINT alliances_shortname_uq UNIQUE ("shortName");


--
-- Name: alliances_executor_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alliances_executor_ix ON public.alliances USING btree ("executorCorpID") WHERE ("executorCorpID" IS NOT NULL);


--
-- Name: INDEX alliances_executor_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.alliances_executor_ix IS 'Ranked-alliance list resolves executorCorpID for every row (all_ui_rankings.py:35-36).';


--
-- Name: alliances_name_lower_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alliances_name_lower_ix ON public.alliances USING btree (lower("allianceName"));


--
-- Name: INDEX alliances_name_lower_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.alliances_name_lower_ix IS 'CreateAlliance must reject a duplicate name; GetSuggestedAllianceShortNames scans by name.';


--
-- Name: alliances trg_sync_alliance_shortnames; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_alliance_shortnames AFTER INSERT OR DELETE OR UPDATE ON public.alliances FOR EACH ROW EXECUTE FUNCTION public.sync_alliance_shortnames();


--
-- PostgreSQL database dump complete
--

\unrestrict Wbr3HwrMvZ5Pjm39ub5QWjJsZtUXXmkacrBdoatAL9ENOP6IfmzG4SMv0oSptie

