--
-- PostgreSQL database dump
--

\restrict Xt5XTJc5ivOoekSs6uZwHXB5OuJDee0WJ3ZGyGCwl3Aa73IAUUTEbtzJ0mgQRPA

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpTitles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpTitles" (
    "corporationID" integer NOT NULL,
    "titleID" bigint NOT NULL,
    "titleName" text DEFAULT ''::text NOT NULL,
    roles bigint DEFAULT 0 NOT NULL,
    "grantableRoles" bigint DEFAULT 0 NOT NULL,
    "rolesAtHQ" bigint DEFAULT 0 NOT NULL,
    "grantableRolesAtHQ" bigint DEFAULT 0 NOT NULL,
    "rolesAtBase" bigint DEFAULT 0 NOT NULL,
    "grantableRolesAtBase" bigint DEFAULT 0 NOT NULL,
    "rolesAtOther" bigint DEFAULT 0 NOT NULL,
    "grantableRolesAtOther" bigint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "crpTitles"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."crpTitles" IS 'Corp titles. Serves corpRegistry.GetTitles / UpdateTitle / UpdateTitles / DeleteTitle (bco_titles.py:56,76,80,84). GetTitles returns an IndexRowset keyed on titleID (bco_titles.py:58-60).';


--
-- Name: COLUMN "crpTitles"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."corporationID" IS 'Owning corp. INFERRED as a column (the call is corp-bound through the corpRegistry moniker so it never crosses the wire), but the table is obviously per-corp: bco_titles.py:14-16 flushes the cache when session corpid changes.';


--
-- Name: COLUMN "crpTitles"."titleID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."titleID" IS 'A SINGLE BIT, not an ordinal: bco_members.py:136-137 does `member.titleMask & titleID == titleID`. bigint to match character_."titleMask". PROVEN read: title.titleID in the corp UI; PROVEN write: 1st arg of UpdateTitle (bco_titles.py:76).';


--
-- Name: COLUMN "crpTitles"."titleName"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."titleName" IS 'PROVEN: 2nd arg of UpdateTitle (bco_titles.py:76); read as title.titleName in the corp UI.';


--
-- Name: COLUMN "crpTitles".roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles".roles IS 'Role mask granted everywhere. PROVEN: 3rd arg of UpdateTitle; read as title.roles.';


--
-- Name: COLUMN "crpTitles"."grantableRoles"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."grantableRoles" IS 'PROVEN: 4th arg of UpdateTitle; read as title.grantableRoles.';


--
-- Name: COLUMN "crpTitles"."rolesAtHQ"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."rolesAtHQ" IS 'PROVEN: 5th arg of UpdateTitle; read as title.rolesAtHQ.';


--
-- Name: COLUMN "crpTitles"."grantableRolesAtHQ"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."grantableRolesAtHQ" IS 'PROVEN: 6th arg of UpdateTitle; read as title.grantableRolesAtHQ.';


--
-- Name: COLUMN "crpTitles"."rolesAtBase"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."rolesAtBase" IS 'PROVEN: 7th arg of UpdateTitle; read as title.rolesAtBase.';


--
-- Name: COLUMN "crpTitles"."grantableRolesAtBase"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."grantableRolesAtBase" IS 'PROVEN: 8th arg of UpdateTitle; read as title.grantableRolesAtBase.';


--
-- Name: COLUMN "crpTitles"."rolesAtOther"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."rolesAtOther" IS 'PROVEN: 9th arg of UpdateTitle; read as title.rolesAtOther.';


--
-- Name: COLUMN "crpTitles"."grantableRolesAtOther"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpTitles"."grantableRolesAtOther" IS 'PROVEN: 10th arg of UpdateTitle; read as title.grantableRolesAtOther.';


--
-- Data for Name: crpTitles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpTitles" ("corporationID", "titleID", "titleName", roles, "grantableRoles", "rolesAtHQ", "grantableRolesAtHQ", "rolesAtBase", "grantableRolesAtBase", "rolesAtOther", "grantableRolesAtOther") FROM stdin;
\.


--
-- Name: crpTitles crpTitles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpTitles"
    ADD CONSTRAINT "crpTitles_pkey" PRIMARY KEY ("corporationID", "titleID");


--
-- PostgreSQL database dump complete
--

\unrestrict Xt5XTJc5ivOoekSs6uZwHXB5OuJDee0WJ3ZGyGCwl3Aa73IAUUTEbtzJ0mgQRPA

