--
-- PostgreSQL database dump
--

\restrict 1vVnet9fIDvHcZvUoAl9HRDX4Oy5ubmXNQ75Nn5I51VorX9bBrvxFTKzAsb4V2x

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eveGraphics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."eveGraphics" (
    "graphicID" integer NOT NULL,
    "url3D" text,
    "urlWeb" text,
    description text,
    published integer,
    obsolete integer,
    icon text,
    "urlSound" text,
    "explosionID" integer
);


--
-- Data for Name: eveGraphics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."eveGraphics" ("graphicID", "url3D", "urlWeb", description, published, obsolete, icon, "urlSound", "explosionID") FROM stdin;
0		Unknown		1	0	07_15		\N
1		Character		1	0			\N
2		Corporation		1	0			\N
4		Region		1	0			\N
5		Constellation		1	0			\N
6	res:/Scene/Askur/default.blue	SolarSystem		1	0			\N
8		Sun		1	0			\N
9	res:/Model/WorldObject/EmeraldPlanets/planet_solid1.blue	Planet		1	0			\N
10	res:/Model/WorldObject/EmeraldPlanets/planet_moon1.blue	Moon		1	0			\N
11	res:/Model/WorldObject/Asteroid/asteroid.blue	AsteroidBelt		1	0	05_11		\N
12	res:/Model/Jumpgate/Caldari/cj2/cj2.blue	Stargate		1	1			\N
13	res:/Model/WorldObject/JumpBeacon/jumpBeacon.blue	Beacon		1	0			\N
14		Jumpzone		1	0			\N
15	res:/Model/WorldObject/Asteroid/asteroid_1.blue	Asteroid		1	0	05_11		\N
16	res:/Model/WorldObject/Cargo/cargoContainer.blue	CargoContainer		1	0	26_11		\N
17	res:/Model/Station/Caldari/cs4/cs4.blue	Station	Station: Caldari 4	1	1		res:/Sound/Station/Station02.blue	\N
18		OfficeFolder		1	0			\N
19		Office		1	0			\N
20		Factory		1	0			\N
21		Money	Money	1	0	06_03		\N
22		Tritium	Mineral	1	0	06_14		\N
23		Platinum	Mineral	1	0	06_14		\N
24		Cesium	Mineral	1	0	06_14		\N
25		ArgonIsotope	Mineral	1	0	06_14		\N
26		ConstructionBlocks	Commodity	1	0	06_05		\N
27		SpicedWine	Commodity	1	0	06_11		\N
28		Antibiotics	Commodity	1	0	06_09		\N
29		DepletedUranium	Commodity	1	0	06_06		\N
30		FrozenPlantSeeds	Commodity	1	0	11_08		\N
31		NuclearMethadone	Commodity	1	0	06_10		\N
32		PersonalNuclearMethadone	Drug	1	0	06_10		\N
33		Skill		1	0	06_01		\N
34		CloneBasic		1	0	08_16		\N
35		CloneAdvanced		1	0	08_16		\N
36		CloneDeluxe		1	0	08_16		\N
37		Voucher		1	0			\N
38	res:/Model/Ship/Caldari/CF1/cf1.blue	Bantam	Ship: Caldari Frigate 1	1	0			2025
39	res:/Model/Ship/Caldari/CF2/cf2.blue	Condor	Ship: Caldari Frigate 2	1	0			2025
40	res:/Model/Ship/Caldari/CF4/cf4.blue	Griffin	Ship: Caldari Frigate 4	1	0			2025
41	res:/Model/Ship/Caldari/CC1/cc1.blue	Osprey	Ship: Caldari Cruiser 1	1	0			2026
42	res:/Model/Ship/Caldari/CC3/cc3.blue	Caracal	Ship: Caldari Cruiser 3	1	0			2026
43	res:/Model/Ship/Caldari/CB1/cb1.blue	Raven	Ship: Caldari Battleship 1	1	0			2027
44	res:/Model/Ship/Minmatar/MF1/mf1.blue	Slasher	Ship: Minmatar Frigate 1	1	0			2025
45	res:/Model/Ship/Minmatar/MF2/mf2.blue	Probe	Ship: Minmatar Frigate 2	1	0			2025
46	res:/Model/Ship/Minmatar/MF4/mf4.blue	Rifter	Ship: Minmatar Frigate 4	1	0			2025
47	res:/Model/Ship/Minmatar/MC1/mc1.blue	Stabber	Ship: Minmatar Cruiser 1	1	0			2026
48	res:/Model/Ship/Minmatar/MB2/mb2.blue	Tempest	Ship: Minmatar Battleship 2	1	0			2027
49	res:/Model/Ship/Caldari/cc2/cc2.blue	Moa	Ship	1	0			2026
50	res:/Model/Ship/Caldari/cb2/cb2.blue	Scorpion	Ship	1	0			2027
51	res:/Model/Ship/Caldari/ci1/ci1.blue	Badger	Ship	1	0			2026
52	res:/Model/Ship/Caldari/ci2/ci2.blue	BadgerII	Ship	1	0			2026
53	res:/Model/Ship/Minmatar/mf3/mf3.blue	Reaper	Ship	1	0			2025
54	res:/Model/Ship/Amarr/af4/af4.blue	Executioner	Ship	1	0			2025
55	res:/Model/Ship/Amarr/af5/af5.blue	Inquisitor	Ship	1	0			2025
56	res:/Model/Ship/Amarr/af6/af6.blue	Tormentor	Ship	1	0			2025
57	res:/Model/Ship/Amarr/ac2/ac2.blue	Maller	Ship	1	0			2026
58	res:/Model/Ship/Amarr/ac3/ac3.blue	Augoror	Ship	1	0			2026
59	res:/Model/Ship/Gallente/gf2/gf2.blue	Navitas	Ship	1	0			2025
60	res:/Model/Ship/Gallente/gf3/gf3.blue	Tristan	Ship	1	0			2025
61	res:/Model/Ship/Gallente/gf4/gf4.blue	Incursus	Ship	1	0			2025
62	res:/Model/Ship/Gallente/gc3/gc3.blue	Vexor	Ship	1	0			2026
63	res:/Model/Ship/Gallente/gc4/gc4.blue	Thorax	Ship	1	0			2026
64	res:/Model/Ship/Gallente/gb2/gb2.blue	Megathron	Ship	1	0			2027
65	res:/Model/Ship/Gallente/gi1/gi1.blue	Iteron	Ship	1	0			2026
66	res:/Model/Ship/Gallente/gp1/gp1.blue	GallentePoliceShip	Ship	1	0			2026
67		Structure	Module	1	0	02_09		\N
68		Armor	Module	1	0	01_09		\N
69		Shield	Module	1	0	01_13		\N
70		PowerCore	Module	1	0	02_07		\N
71		CargoHold	Module	1	0	03_13		\N
72		Propulsion	Module	1	0	03_01		\N
73	res:/Model/WorldObject/Capsule/capsule.blue	Capsule	Module	1	0	02_14		\N
74		Sensors	Module	1	0	03_09		\N
75		StructureEnhancer	Module	1	0	02_13		\N
76		StructurePlating	Module	1	0	02_10		\N
77		DamageControl	Module	1	0	02_11		\N
78		ArmorEnhancer	Module	1	0	01_12		\N
79		ArmoredPlates	Module	1	0	01_10		\N
80		AutoRepairUnit	Module	1	0	01_11		\N
81		ShieldEnhancer	Module	1	0	02_02		\N
82		ShieldExtender	Module	1	0	02_04		\N
83		ShieldRecharger	Module	1	0	01_15		\N
84		ShieldBooster	Module	1	0	02_03		\N
85		ShieldDischarger	Module	1	0	02_01		\N
86		ShieldTransporter	Module	1	0	01_16		\N
87		GeneratorSteelplates	Module	1	0	01_14		\N
88		ShieldExchanger	Module	1	0	04_08		\N
89			Capacitor Battery	1	0	01_04		\N
90		PowerRecharger	Module	1	0	01_01		\N
91		ProtectiveShell	Module	1	0	02_08		\N
92		StorageEnhancer	Module	1	0	04_13		\N
93		FrostCompartment	Module	1	0	03_15		\N
94		RadioactiveCompartment	Module	1	0	04_14		\N
95		ArmoredBulkheads	Module	1	0	03_14		\N
96		Afterburner	Module	1	0	03_02		\N
97		JumpEnhancer	Module	1	0	03_08		\N
98		ThrusterEnhancer	Module	1	0	03_05		\N
99		AgilityEnhancer	Module	1	0	03_05		\N
100		NeuralRigger	Module	1	0			\N
101		RoyalInsignia	Module	1	0			\N
102		GCDLink	Module	1	0			\N
103		TradeLink	Module	1	0			\N
104		EnhancedSensors	Module	1	0	04_10		\N
105		ReinforcedSensors	Module	1	0	04_11		\N
106		CargoScanner	Module	1	0	03_11		\N
107		ShipScanner	Module	1	0	03_10		\N
108		SurveyScanner	Module	1	0	03_10		\N
109		Jammer	Module	1	0	04_12		\N
110		AntiJammer	Module	1	0	05_01		\N
111		JumpScrambler	Module	1	0	04_09		\N
112		ECMShutdownWave	Module	1	0	03_04		\N
113	cse141	GatlingLaser		1	0			\N
114	mse141	GatlingLaser		1	0			\N
115	cse441	PlasmaProjector		1	0			\N
116	mse441	PlasmaProjector		1	0			\N
117	csh341	NeutronBlaster		1	0			\N
118	csh241	ElectronBeam		1	0			\N
119	msh241	ElectronBeam		1	0			\N
120	cse541	FusionBlaster		1	0			\N
121	mse541	FusionBlaster		1	0			\N
122	cme241	TraserLaser		1	0			\N
123	mme241	TraserLaser		1	0			\N
124	cme341	PhotonProjector		1	0			\N
125	mme341	PhotonProjector		1	0			\N
126	cmh141	IonStreamer		1	0			\N
127	mmh141	IonStreamer		1	0			\N
128	cmh341	ParticleBeam		1	0			\N
129	mmh341	ParticleBeam		1	0			\N
130	cmh441	MoleculeRay		1	0			\N
131	mmh441	MoleculeRay		1	0			\N
132	cle441	NuclearLaser		1	0			\N
133	mle441	NuclearLaser		1	0			\N
134	clh541	Pulsifier		1	0			\N
135	mlh541	Pulsifier		1	0			\N
136	cle541	TachyonBeam		1	0			\N
137	mle541	TachyonBeam		1	0			\N
138	mim111	MinerBasic	Turret - Mining	1	0	04_01		\N
139	mim111	MinerBasic		1	0	04_01		\N
140	mim111	MinerBasic		1	0	04_01		\N
141	mim111	MinerBasic		1	0	04_01		\N
142	mim111	MinerBasic		1	0	04_01		\N
143	mim111	MinerBasic		1	0	04_01		\N
144	mim111	MinerAdvanced		1	0	04_01		\N
145	mim111	MinerAdvanced		1	0	04_01		\N
146	mim111	MinerAdvanced		1	0	04_01		\N
147	mim111	MinerAdvanced		1	0	04_01		\N
148	mim111	MinerAdvanced		1	0	04_01		\N
149	mim111	MinerAdvanced		1	0	04_01		\N
150	mim111	MinerDeluxe		1	0	04_01		\N
151	mim111	MinerDeluxe		1	0	04_01		\N
152	mim111	MinerDeluxe		1	0	04_01		\N
153	mim111	MinerDeluxe		1	0	04_01		\N
154	mim111	MinerDeluxe		1	0	04_01		\N
155	mim111	MinerDeluxe		1	0	04_01		\N
156	csp141	HarrowerSelfpropelledGun		1	0			\N
157	msp141	BoreSelfpropelledGun		1	0			\N
158	csp441	HailMultibarreledGun		1	0			\N
159	msp441	GutterMultibarreledGun		1	0			\N
160	cmp341	Enthropy280mmCannon		1	0			\N
161	mmp341	Crash280mmCannon		1	0			\N
162	cmp441	SurgeArtilleryGun		1	0			\N
163	mmp441	ThrustArtilleryGun		1	0			\N
164	mlp341	PiercerHowitzerCannon		1	0			\N
165	clp341	StirHowitzerCannon		1	0			\N
166	mlp441	CoffinNailArtilleryCannon		1	0			\N
167	clp441	StormArtilleryCannon		1	0			\N
168	res:/Model/Missile/Small/MissileSFire.blue	MissileLauncherBasic		1	0	12_12		\N
169	res:/Model/Missile/Small/MissileSFire.blue	MissileLauncherAdvanced		1	0	21_12		\N
170	res:/Model/Missile/Small/MissileSFire.blue	MissileLauncherDeluxe		1	0	21_16		\N
171	res:/Model/Missile/Small/MissileSFire.blue	LeadPellets	Charge	1	0			\N
172	res:/Model/Missile/Small/MissileSFire.blue	TitaniumTip	Charge	1	0			\N
173	res:/Model/Missile/Small/MissileSFire.blue	ExplosiveTip	Charge	1	0			\N
174	res:/Model/Missile/Small/MissileSFire.blue	PlasmaTip	Charge	1	0			\N
175	res:/Model/Missile/Small/MissileSFire.blue	TitaniumTipUranium	Charge	1	0			\N
176	res:/Model/Missile/Small/MissileSFire.blue	ExplosiveShell	Charge	1	0			\N
177	res:/Model/Missile/Small/MissileSFire.blue	PlutoniumChargeMedium	Charge	1	0			\N
178	res:/Model/Missile/Small/MissileSFire.blue	AntimatterCoated	Charge	1	0			\N
179	res:/Model/Missile/Small/MissileSFire.blue	ArgonIsotopeCharge	Charge	1	0			\N
180	res:/Model/Missile/Small/MissileSFire.blue	PlutoniumChargeLarge	Charge	1	0			\N
181	res:/Model/Missile/Small/MissileSFire.blue	FusionCharge	Charge	1	0			\N
182	res:/Model/Missile/Missile_Paradise.blue	Paradise Missile	Basic missile	1	0	20_16		\N
183	res:/Model/Missile/Missile_wrath.blue	Wrath Missile	Rapid missile	1	0	20_04		\N
184	res:/Model/Missile/Missile_Cataclysm.blue	Cataclysm missile	Trek missile	1	0	20_08		\N
185	res:/Model/Missile/Missile_Devastator.blue	Devastatormissile	Discharge missile	1	0	20_12		\N
186	res:/Model/Missile/Missile_Havoc.blue	HavocMissile	Standard missile	1	0	20_10		\N
187	res:/Model/Missile/Missile_Thunderbolt.blue	ThunderboltMissile	Tiger missile	1	0	20_14		\N
188	res:/Model/Missile/Missile_widowmaker.blue	WidowmakerMissile	Widowmaker missile	1	0	20_06		\N
189	res:/Model/Missile/Missile_Deathbringer.blue	Deathbringer	Blast missile	1	0	20_02		\N
190	res:/Model/Missile/Missile_Bloodclaw.blue	Bloodclaw	Regular missile	1	0	13_04		\N
191	res:/Model/Missile/Missile_Flameburst.blue	FlameburstMissile	Flameburst missile	1	0	13_08		\N
192	res:/Model/Missile/Missile_Sabretooth.blue	SabretoothMissile	Sabretooth missile	1	0	13_16		\N
193	res:/Model/Missile/Missile_pirahna.blue	PirahnaMissile	Pirahna missile	1	0	13_12		\N
194		Blueprint		1	0	06_03		\N
195		Trading		1	0			\N
196		TradeSession		1	0			\N
202	res:/Model/WorldObject/EmeraldPlanets/planet_solid1.blue	Planet		1	0			\N
203	res:/Model/WorldObject/EmeraldPlanets/planet_solid2.blue	Planet		1	0			\N
204	res:/Model/WorldObject/EmeraldPlanets/planet_solid3.blue	Planet		1	0			\N
205	res:/Model/WorldObject/EmeraldPlanets/planet_solid4.blue	Planet		1	0			\N
206	res:/Model/WorldObject/EmeraldPlanets/planet_solid5.blue	Planet		1	0			\N
207	res:/Model/WorldObject/EmeraldPlanets/planet_solid6.blue	Planet		1	0			\N
208	res:/Model/WorldObject/EmeraldPlanets/planet_solid7.blue	Planet		1	0			\N
209	res:/Model/WorldObject/EmeraldPlanets/planet_solid8.blue	Planet		1	0			\N
210	res:/Model/WorldObject/EmeraldPlanets/planet_solid9.blue	Planet		1	0			\N
211	res:/Model/WorldObject/EmeraldPlanets/planet_solid10.blue	Planet		1	0			\N
212	res:/Model/WorldObject/EmeraldPlanets/planet_ice1.blue	Planet		1	0			\N
213	res:/Model/WorldObject/EmeraldPlanets/planet_ice2.blue	Planet		1	0			\N
214	res:/Model/WorldObject/EmeraldPlanets/planet_gas1.blue	Planet		1	0			\N
215	res:/Model/WorldObject/EmeraldPlanets/planet_gas2.blue	Planet		1	0			\N
216	res:/Model/WorldObject/EmeraldPlanets/planet_gas3.blue	Planet		1	0			\N
217	res:/Model/WorldObject/EmeraldPlanets/planet_gas4.blue	Planet		1	0			\N
218	res:/Model/WorldObject/EmeraldPlanets/planet_moon1.blue	Moon		1	0			\N
219	res:/Model/WorldObject/EmeraldPlanets/planet_moon2.blue	Moon		1	0			\N
220	res:/Model/WorldObject/EmeraldPlanets/planet_moon3.blue	Moon		1	0			\N
221	res:/Model/WorldObject/EmeraldPlanets/planet_moon4.blue	Moon		1	0			\N
222	res:/Model/WorldObject/EmeraldPlanets/planet_moon5.blue	Moon		1	0			\N
223	res:/Model/WorldObject/EmeraldPlanets/planet_moon6.blue	Moon		1	0			\N
224	res:/Model/WorldObject/EmeraldPlanets/planet_moon7.blue	Moon		1	0			\N
225	res:/Model/WorldObject/EmeraldPlanets/planet_moon8.blue	Moon		1	0			\N
226	res:/Model/WorldObject/EmeraldPlanets/planet_moon9.blue	Moon		1	0			\N
227	res:/Model/WorldObject/EmeraldPlanets/planet_moon10.blue	Moon		1	0			\N
228	res:/Model/WorldObject/EmeraldPlanets/planet_moon11.blue	Moon		1	0			\N
229	res:/Model/WorldObject/EmeraldPlanets/planet_moon12.blue	Moon		1	0			\N
230	res:/Model/WorldObject/Asteroid/asteroid_1.blue	Asteroid1		1	0	24_02		\N
231	res:/Model/WorldObject/Asteroid/asteroid_2.blue	Asteroid2		1	0	23_16		\N
232	res:/Model/WorldObject/Asteroid/asteroid_3.blue	Asteroid3		1	0	24_01		\N
233	res:/Model/WorldObject/Asteroid/asteroid_4.blue	Asteroid4		1	0			\N
234	res:/Model/WorldObject/Asteroid/asteroid_5.blue	Asteroid5		1	0			\N
235	res:/Model/Jumpgate/Caldari/cj2/cj2.blue	StargateCaldari2		1	0			\N
236	res:/Model/Jumpgate/Amarr/aj1.blue	StargateAmarr1		1	0			\N
237	res:/Model/Station/Caldari/cs4/cs4.blue	StationCaldari4		1	0		res:/Sound/Station/Station02.blue	\N
238	res:/Model/Station/Minmatar/ms7/ms7.blue	StationMinmatar7		1	0		res:/Sound/Station/Station16.blue	\N
239	res:/Model/Station/Gallente/gs1/gs1.blue	StationGallente1		1	0		res:/Sound/Station/Station19.blue	\N
240	res:/Model/Station/Gallente/gs2/gs2.blue	StationGallente2		1	0		res:/Sound/Station/Station02.blue	\N
241	res:/Scene/Hangar/Caldari.blue	Hangar	Station hangar, Caldari	1	0			\N
242	res:/Scene/Hangar/Minmatar.blue	Hangar	Station hangar, Minmatar	1	0			\N
243	res:/Scene/Hangar/Druglords.blue	Hangar	Station hangar, Druglord	1	0			\N
244	res:/Scene/Hangar/GallenteBlue.blue	Hangar	Station hangar, Gallente	1	0			\N
245	res:/Scene/Angelice/default.blue	Angelice	Solar system	1	0			\N
246	res:/Scene/Memphis/default.blue	Memphis	Solar system	1	0			\N
247	res:/Scene/KK-X5/default.blue	KKX5	Solar system	1	0			\N
248	res:/Scene/Solitude/default.blue	Solitude	Solar system	1	0			\N
249	res:/Scene/Navicular/default.blue	Navicular	Solar system	1	0			\N
250	res:/Scene/Askur/default.blue	Askur	Solar system	1	0			\N
251	res:/Scene/Hades/default.blue	Hades	Solar system	1	0			\N
252	res:/Scene/Serpentis/default.blue	Serpentis	Solar system	1	0			\N
253	res:/Scene/Memphis/default.blue	Bouchorre	Solar system	1	0			\N
254	res:/Scene/Memphis/default.blue	Cypher	Solar system	1	0			\N
255	res:/Scene/Memphis/default.blue	Phantomin	Solar system	1	0			\N
256	res:/Scene/Memphis/default.blue	Lonetrail	Solar system	1	0			\N
257	res:/Scene/Memphis/default.blue	Ethernity	Solar system	1	0			\N
258	res:/Scene/Memphis/default.blue	Destine	Solar system	1	0			\N
259	res:/Scene/Memphis/default.blue	Myre	Solar system	1	0			\N
260	res:/Scene/Memphis/default.blue	Centor	Solar system	1	0			\N
261	res:/Scene/Memphis/default.blue	Medusa	Solar system	1	0			\N
262	res:/Scene/Memphis/default.blue	Caelum	Solar system	1	0			\N
263	res:/Scene/Memphis/default.blue	Blue	Solar system	1	0			\N
264	res:/Scene/Memphis/default.blue	Brilliant	Solar system	1	0			\N
265	res:/Scene/Memphis/default.blue	Celestion	Solar system	1	0			\N
266	res:/Scene/Memphis/default.blue	Waylay	Solar system	1	0			\N
267	res:/Scene/Memphis/default.blue	Zurum	Solar system	1	0			\N
292		FactoryFolder		1	0			\N
293		HiSlot	Ship slot	1	0	08_11		\N
294		MedSlot	Ship slot	1	0	08_10		\N
295		LoSlot	Ship slot	1	0	08_09		\N
296	res:/Model/Ship/Amarr/ab1/ab1.blue	Apocalypse	Ship	1	0			2027
297	res:/Model/Ship/Amarr/ab2/ab2.blue	Armageddon	Ship	1	0			2027
298	res:/Model/Ship/Amarr/ac1/ac1.blue	Arbitrator	Ship	1	0			2026
299	res:/Model/Ship/Amarr/af1/af1.blue	Impairor	Ship	1	0			2025
300	res:/Model/Ship/Amarr/AF3/af3.blue	Punisher	Ship	1	0			2025
301	res:/Model/Ship/Minmatar/mb1/mb1.blue	Typhoon	Ship	1	0			2027
302	res:/Model/Ship/Minmatar/mc2/mc2.blue	Rupture	Ship	1	0			2026
303	res:/Model/Ship/Minmatar/mc3/mc3.blue	Bellicose	Ship	1	0			2026
304	res:/Model/Ship/Minmatar/mc4/Mc4.blue	Scythe	Ship	1	0			2026
305	res:/Model/Ship/Minmatar/mf5/MF5.blue	Breacher	Ship	1	0			2025
306	res:/Model/Ship/Minmatar/mf6/Mf6.blue	Burst	Ship	1	0			2025
307	res:/Model/Ship/Minmatar/mf_p/mf_p1.blue	MinmatarPeacekeeperShip	Ship	1	0			2025
308	res:/Model/Ship/Minmatar/mi1/mi1.blue	Hoarder	Ship	1	0			2026
309	res:/Model/Ship/Minmatar/mi2/Mi2.blue	Mammoth	Ship	1	0			2026
310	res:/Model/Ship/Minmatar/mi3/Mi3.blue	Wreathe	Ship	1	0			2026
311	res:/Model/Ship/Caldari/cc4/cc4.blue	Blackbird	Ship	1	0			2026
312	res:/Model/Ship/Caldari/cf5/cf5.blue	Ibis	Ship	1	0			2025
313	res:/Model/Ship/Caldari/cf6/cf6.blue	Kestrel	Ship	1	0			2025
314	res:/Model/Ship/Caldari/cf7/cf7.blue	Merlin	Ship	1	0			2025
315	res:/Model/Ship/Caldari/cf8/cf8.blue	CaldariEnforcerShip	Ship	1	0			2025
316	res:/Model/Ship/Caldari/cf9/cf9.blue	Heron	Ship	1	0			2025
317	res:/Model/Ship/Caldari/cshuttle1/cshuttle1.blue	CaldariShuttle	Ship	1	0			2026
318	res:/Model/Ship/Gallente/gb1/gb1.blue	Dominix	Ship	1	0			2027
319	res:/Model/Ship/Gallente/gc1/gc1.blue	Celestis	Ship	1	0			2026
320	res:/Model/Ship/Gallente/gc2/gc2.blue	Exequror	Ship	1	0			2026
321	res:/Model/Ship/Gallente/gf1/gf1.blue	Velator	Ship	1	0			2025
322	res:/Model/Ship/Gallente/gf5/gf5.blue	Imicus	Ship	1	0			2025
323	res:/Model/Ship/Gallente/gf6/gf6.blue	Atron	Ship	1	0			2025
324	res:/Model/Ship/Gallente/gf7/gf7.blue	Maulus	Ship	1	0			2025
325	res:/Model/Ship/Gallente/gi2/gi2.blue	IteronMarkII	Ship	1	0			2026
326	res:/Model/Ship/Gallente/gi3/gi3.blue	IteronMarkIII	Ship	1	0			2026
327	res:/Model/Ship/Gallente/gi4/gi4.blue	Iteron Mark IV	Ship	1	0			2026
328	res:/Model/Ship/Gallente/gi5/gi5.blue	IteronMarkV	Ship	1	0			2026
329	res:/Model/Ship/Gallente/gt1/gt1.blue	GallenteSoltueur	Ship	1	0			2026
330	res:/Model/Ship/Gallente/gy1/gy1.blue	OpuxLuxuryYacht	Ship	1	0			2026
331	res:/Model/Ship/Jove/jb1/jb1.blue	Eidolon	Ship	1	0			2027
332	res:/Model/Ship/Jove/jf2/jf2.blue	Wraith	Ship	1	0			2025
333	res:/Model/Ship/Jove/jf3/jf3.blue	Specter	Ship	1	0			2025
334	res:/Model/Ship/Jove/ji1/ji1.blue	Visitant	Ship	1	0			2026
335	res:/Model/Ship/pirate/pirb1/pirb1.blue	Tyrant	Ship	1	0			2026
336	res:/Model/Ship/pirate/pirc1/pirc1.blue	Ixion	Ship	1	0			2026
337	res:/Model/Ship/pirate/pirc2/pirc2.blue	Basilisk	Ship	1	0			2026
338	res:/Model/Ship/pirate/pirf1/pirf1.blue	Chaos	Ship	1	0			2026
339	res:/Model/Ship/pirate/pirf2/pir2.blue	Devourer	Ship	1	0			2026
340	res:/Model/Ship/pirate/pirf3/pir3.blue	Fury	Ship	1	0			2026
341	res:/Model/Ship/pirate/pirf4/pir4.blue	Styx	Ship	1	0			2026
342	res:/Model/Ship/pirate/Pirf5/pirf5.blue	Harpy	Ship	1	0			2026
343	res:/Model/Ship/pirate/pirf6/pf6.blue	Echo	Ship	1	0			2026
344	res:/Model/Ship/pirate/pirf7/pirf7.blue	Lynx	Ship	1	0			2026
345	res:/Model/Ship/pirate/pirf8/pirf8.blue	Swordspine	Ship	1	0			2026
346	res:/Model/Ship/Caldari/co1/co1.blue	CO1	Station	1	0			2026
347	res:/Model/Ship/Caldari/co2/co2.blue	CO1	Station	1	0			2026
348	ash111	Hybrid75mmGatlingRail		1	0			\N
349	csh111	75mmGatlingRail		1	0	13_05		\N
350	ase111	GatlingPulseLaser		1	0	13_13		\N
351	ase211	dual light pulse laser		1	0	13_13		\N
352	ase311	DualLightBeamLaser		1	0	13_09		\N
353	ase411	MediumPulseLaser		1	0	13_13		\N
354	ase511	MediumBeamLaser		1	0	13_09		\N
355	gme111	QuadLightBeamLaser		1	0	13_10		\N
356	ame211	FocusedMediumPulseLaser		1	0	13_14		\N
357	ame311	FocusedMediumBeamLaser		1	0	13_10		\N
358	ame411	HeavyPulseLaser		1	0	13_14		\N
359	ame511	HeavyBeamLaser		1	0	13_10		\N
360	ale111	DualHeavyPulseLaser		1	0	13_15		\N
361	ale211	DualHeavyBeamLaser		1	0	13_11		\N
362	ale311	MegaPulseLaser		1	0	13_15		\N
363	ale411	MegaBeamLaser		1	0	13_11		\N
364	ale511	ThacyonBeamLaser		1	0	13_11		\N
365	glh511	IonBlasterCannon	Caldari	1	0	13_03		\N
366	clh411	425mmRailgun	Caldari	1	0	13_07		\N
367	clh311	NeutronBlasterCannon		1	0	13_03		\N
368	clh211	Dual250mmRailgun		1	0	13_07		\N
369	glh111	DualHeavyIonBlaster		1	0	13_03		\N
370	cmh511	250mmRailgun		1	0	13_06		\N
371	cmh411	HeavyIonBlaster		1	0	13_02		\N
372	cmh311	HeavyNeutronBlaster		1	0	13_02		\N
373	cmh211	Dual150mmRailgun		1	0	13_06		\N
374	cmh111	HeavyElectronBlaster		1	0	13_02		\N
375	csh511	150mmRailgun		1	0	13_05		\N
376	gsh411	LightNeutronBlaster	Caldari	1	0	13_01		\N
377	csh311	LightIonBlaster	Caldari	1	0	13_01		\N
378	gsh211	LightElectronBlaster	Caldari	1	0	13_01		\N
379	mlp511	LargeArtilleryRocket		1	0	12_15		\N
380	mlp411	1200mmArtilleryCannon		1	0	12_15		\N
381	mlp311	800mmArtilleryCannon		1	0	12_11		\N
382	mlp211	Dual650mmArtilleryCannon		1	0	12_11		\N
383	mlp111	Dual425mmRailgun		1	0	12_11		\N
384	mmp511	MediumArtilleryRocket		1	0	12_14		\N
385	mmp411	650mmArtilleryCannon		1	0	12_14		\N
386	mmp311	425mmAutoCannon		1	0	12_10		\N
387	mmp211	220mmVulcanAutoCannon		1	0	12_09		\N
388	mmp111	Dual80mmAutoCannon		1	0	12_10		\N
389	msp511	SmallArtilleryRocket		1	0	12_13		\N
390	msp411	250mmLightArtilleryCannon		1	0	12_13		\N
391	msp311	200mmAutoCannon		1	0	12_09		\N
392	msp211	150mmLightAutoCannon		1	0	12_09		\N
393	msp111	125mmGatlingAutoCannon		1	0	12_09		\N
394	res:/model/ship/Booster/booster_blue.blue	FusionBooster		1	0	03_01		\N
395	res:/model/Ship/booster/Booster_yellow.blue	FissionBooster		1	0	03_01		\N
396	res:/model/Ship/booster/Booster_green.blue	GravitonBooster		1	0	03_01		\N
397	res:/model/Ship/booster/Booster_red.blue	CombustionEngine		1	0	03_01		\N
398	res:/Model/Face/fullbody_char/corpses/corpseMale123.blue	Corpse	Corpse floating in space (male?).	1	0	11_05		\N
399		Tritanium	Mineral	1	0	06_14		\N
400		Pyerite	Mineral	1	0	06_15		\N
401		Mexallon	Mineral	1	0	06_12		\N
402		Isogen	Mineral	1	0	06_16		\N
403		Nocxium	Mineral	1	0	06_09		\N
404		Zydrine	Mineral	1	0	11_11		\N
405		Megacyte	Mineral	1	0	11_10		\N
406	res:/Model/Missile/Missile_xl.blue	Testmisslie	Testmisslie	1	0			\N
407		CargoCapacity		1	0	03_13		\N
408		HitPoints		1	0	02_09		\N
409		Mass	mass	1	0	02_10		\N
410		MaxVelocity		1	0	08_09		\N
411		MiningSlots		1	0			\N
412		MissileSlots		1	0	12_12		\N
413		Passengers		1	0	08_12		\N
414		TurretSlots		1	0	12_09		\N
415	res:/UI/Station/Paintshop/Lib/LayerShape/0.blue			1	0			\N
416	res:/UI/Station/Paintshop/Lib/LayerShape/1.blue			1	0			\N
417	res:/UI/Station/Paintshop/Lib/LayerShape/2.blue			1	0			\N
418	res:/UI/Station/Paintshop/Lib/LayerShape/3.blue			1	0			\N
419	res:/UI/Station/Paintshop/Lib/LayerShape/4.blue			1	0			\N
420	res:/UI/Station/Paintshop/Lib/LayerShape/5.blue			1	0			\N
421	res:/UI/Station/Paintshop/Lib/LayerShape/6.blue			1	0			\N
422	res:/UI/Station/Paintshop/Lib/LayerShape/7.blue			1	0			\N
423	res:/UI/Station/Paintshop/Lib/LayerShape/8.blue			1	0			\N
424	res:/UI/Station/Paintshop/Lib/LayerShape/9.blue			1	0			\N
425	res:/UI/Station/Paintshop/Lib/LayerShape/10.blue			1	0			\N
426	res:/UI/Station/Paintshop/Lib/LayerShape/11.blue			1	0			\N
427	res:/UI/Station/Paintshop/Lib/LayerShape/12.blue			1	0			\N
428	res:/UI/Station/Paintshop/Lib/LayerShape/13.blue			1	0			\N
429	res:/UI/Station/Paintshop/Lib/LayerShape/14.blue			1	0			\N
430	res:/UI/Station/Paintshop/Lib/LayerShape/15.blue			1	0			\N
431	res:/UI/Station/Paintshop/Lib/LayerShape/16.blue			1	0			\N
432	res:/UI/Station/Paintshop/Lib/LayerShape/17.blue			1	0			\N
433	res:/UI/Station/Paintshop/Lib/LayerShape/18.blue			1	0			\N
434	res:/UI/Station/Paintshop/Lib/LayerShape/19.blue			1	0			\N
435	res:/UI/Station/Paintshop/Lib/LayerShape/20.blue			1	0			\N
436	res:/UI/Station/Paintshop/Lib/LayerShape/21.blue			1	0			\N
437	res:/UI/Station/Paintshop/Lib/LayerShape/22.blue			1	0			\N
438	res:/UI/Station/Paintshop/Lib/LayerShape/23.blue			1	0			\N
439	res:/UI/Station/Paintshop/Lib/LayerShape/24.blue			1	0			\N
440	res:/UI/Station/Paintshop/Lib/LayerShape/25.blue			1	0			\N
441	res:/UI/Station/Paintshop/Lib/LayerShape/26.blue			1	0			\N
442	res:/UI/Station/Paintshop/Lib/LayerShape/27.blue			1	0			\N
443	res:/UI/Station/Paintshop/Lib/LayerShape/28.blue			1	0			\N
444	res:/UI/Station/Paintshop/Lib/LayerShape/29.blue			1	0			\N
445	res:/UI/Station/Paintshop/Lib/LayerShape/30.blue			1	0			\N
446	res:/UI/Station/Paintshop/Lib/LayerShape/31.blue			1	0			\N
447	res:/UI/Station/Paintshop/Lib/LayerShape/32.blue			1	0			\N
448	res:/UI/Station/Paintshop/Lib/LayerShape/33.blue			1	0			\N
449	res:/UI/Station/Paintshop/Lib/LayerShape/34.blue			1	0			\N
450	res:/UI/Station/Paintshop/Lib/LayerShape/35.blue			1	0			\N
451	res:/UI/Station/Paintshop/Lib/LayerShape/36.blue			1	0			\N
452	res:/UI/Station/Paintshop/Lib/LayerShape/37.blue			1	0			\N
453	res:/UI/Station/Paintshop/Lib/LayerShape/38.blue			1	0			\N
454	res:/UI/Station/Paintshop/Lib/LayerShape/39.blue			1	0			\N
455	res:/UI/Station/Paintshop/Lib/LayerShape/40.blue			1	0			\N
456	res:/UI/Station/Paintshop/Lib/LayerShape/41.blue			1	0			\N
457	res:/UI/Station/Paintshop/Lib/LayerShape/42.blue			1	0			\N
458	res:/UI/Station/Paintshop/Lib/LayerShape/43.blue			1	0			\N
459	res:/UI/Station/Paintshop/Lib/LayerShape/44.blue			1	0			\N
460	res:/UI/Station/Paintshop/Lib/LayerShape/45.blue			1	0			\N
461	res:/UI/Station/Paintshop/Lib/LayerShape/46.blue			1	0			\N
462	res:/UI/Station/Paintshop/Lib/LayerShape/47.blue			1	0			\N
463	res:/UI/Station/Paintshop/Lib/LayerShape/48.blue			1	0			\N
464	res:/UI/Station/Paintshop/Lib/LayerShape/49.blue			1	0			\N
465	res:/UI/Station/Paintshop/Lib/LayerShape/50.blue			1	0			\N
466	res:/UI/Station/Paintshop/Lib/LayerShape/51.blue			1	0			\N
467	res:/UI/Station/Paintshop/Lib/LayerShape/52.blue			1	0			\N
468	res:/UI/Station/Paintshop/Lib/LayerShape/53.blue			1	0			\N
469	res:/UI/Station/Paintshop/Lib/LayerShape/54.blue			1	0			\N
470	res:/UI/Station/Paintshop/Lib/LayerShape/55.blue			1	0			\N
471	res:/UI/Station/Paintshop/Lib/LayerShape/56.blue			1	0			\N
472	res:/UI/Station/Paintshop/Lib/LayerShape/57.blue			1	0			\N
473	res:/UI/Station/Paintshop/Lib/LayerShape/58.blue			1	0			\N
474	res:/UI/Station/Paintshop/Lib/LayerShape/59.blue			1	0			\N
475	res:/UI/Station/Paintshop/Lib/LayerShape/60.blue			1	0			\N
476	res:/UI/Station/Paintshop/Lib/LayerShape/61.blue			1	0			\N
477	res:/UI/Station/Paintshop/Lib/LayerShape/62.blue			1	0			\N
478	res:/UI/Station/Paintshop/Lib/LayerShape/63.blue			1	0			\N
479	res:/UI/Station/Paintshop/Lib/LayerShape/64.blue			1	0			\N
480	res:/UI/Station/Paintshop/Lib/LayerShape/65.blue			1	0			\N
481	res:/UI/Station/Paintshop/Lib/LayerShape/66.blue			1	0			\N
482	res:/UI/Station/Paintshop/Lib/LayerShape/67.blue			1	0			\N
483	res:/UI/Station/Paintshop/Lib/LayerShape/68.blue			1	0			\N
484	res:/UI/Station/Paintshop/Lib/LayerShape/69.blue			1	0			\N
485	res:/UI/Station/Paintshop/Lib/LayerShape/70.blue			1	0			\N
486	res:/UI/Station/Paintshop/Lib/LayerShape/71.blue			1	0			\N
487	res:/UI/Station/Paintshop/Lib/LayerShape/72.blue			1	0			\N
488	res:/UI/Station/Paintshop/Lib/LayerShape/73.blue			1	0			\N
489	res:/UI/Station/Paintshop/Lib/LayerShape/74.blue			1	0			\N
490	res:/UI/Station/Paintshop/Lib/LayerShape/75.blue			1	0			\N
491	res:/UI/Station/Paintshop/Lib/LayerShape/76.blue			1	0			\N
492	res:/UI/Station/Paintshop/Lib/LayerShape/77.blue			1	0			\N
493	res:/UI/Station/Paintshop/Lib/LayerShape/78.blue			1	0			\N
494	res:/UI/Station/Paintshop/Lib/LayerShape/79.blue			1	0			\N
495	res:/UI/Station/Paintshop/Lib/LayerShape/80.blue			1	0			\N
496	res:/UI/Station/Paintshop/Lib/LayerShape/81.blue			1	0			\N
497	res:/UI/Station/Paintshop/Lib/LayerShape/82.blue			1	0			\N
498	res:/UI/Station/Paintshop/Lib/LayerShape/83.blue			1	0			\N
499	res:/UI/Station/Paintshop/Lib/LayerShape/84.blue			1	0			\N
500	res:/UI/Station/Paintshop/Lib/LayerShape/85.blue			1	0			\N
501	res:/UI/Station/Paintshop/Lib/LayerShape/86.blue			1	0			\N
502	res:/UI/Station/Paintshop/Lib/LayerShape/87.blue			1	0			\N
503	res:/UI/Station/Paintshop/Lib/LayerShape/88.blue			1	0			\N
504	res:/UI/Station/Paintshop/Lib/LayerShape/89.blue			1	0			\N
505	res:/UI/Station/Paintshop/Lib/LayerShape/90.blue			1	0			\N
506	res:/UI/Station/Paintshop/Lib/LayerShape/91.blue			1	0			\N
507	res:/UI/Station/Paintshop/Lib/LayerShape/92.blue			1	0			\N
508	res:/UI/Station/Paintshop/Lib/LayerShape/93.blue			1	0			\N
509	res:/UI/Station/Paintshop/Lib/LayerShape/94.blue			1	0			\N
510	res:/UI/Station/Paintshop/Lib/LayerShape/95.blue			1	0			\N
511	res:/UI/Station/Paintshop/Lib/LayerShape/96.blue			1	0			\N
512	res:/UI/Station/Paintshop/Lib/LayerShape/97.blue			1	0			\N
513	res:/UI/Station/Paintshop/Lib/LayerShape/98.blue			1	0			\N
514	res:/UI/Station/Paintshop/Lib/LayerShape/99.blue			1	0			\N
515	res:/UI/Station/Paintshop/Lib/LayerShape/100.blue			1	0			\N
516	res:/UI/Station/Paintshop/Lib/LayerShape/101.blue			1	0			\N
517	res:/UI/Station/Paintshop/Lib/LayerShape/102.blue			1	0			\N
518	res:/UI/Station/Paintshop/Lib/LayerShape/103.blue			1	0			\N
519	res:/UI/Station/Paintshop/Lib/LayerShape/104.blue			1	0			\N
520	res:/UI/Station/Paintshop/Lib/LayerShape/105.blue			1	0			\N
521	res:/UI/Station/Paintshop/Lib/LayerShape/106.blue			1	0			\N
522	res:/UI/Station/Paintshop/Lib/LayerShape/107.blue			1	0			\N
523	res:/UI/Station/Paintshop/Lib/LayerShape/108.blue			1	0			\N
524	res:/UI/Station/Paintshop/Lib/LayerShape/109.blue			1	0			\N
525	res:/UI/Station/Paintshop/Lib/LayerShape/110.blue			1	0			\N
526	res:/UI/Station/Paintshop/Lib/LayerShape/111.blue			1	0			\N
527	res:/UI/Station/Paintshop/Lib/LayerShape/112.blue			1	0			\N
528	res:/UI/Station/Paintshop/Lib/LayerShape/113.blue			1	0			\N
529	res:/UI/Station/Paintshop/Lib/LayerShape/114.blue			1	0			\N
530	res:/UI/Station/Paintshop/Lib/LayerShape/115.blue			1	0			\N
531	res:/UI/Station/Paintshop/Lib/LayerShape/116.blue			1	0			\N
532	res:/UI/Station/Paintshop/Lib/LayerShape/117.blue			1	0			\N
533	res:/UI/Station/Paintshop/Lib/LayerShape/118.blue			1	0			\N
534	res:/UI/Station/Paintshop/Lib/LayerShape/119.blue			1	0			\N
535	res:/UI/Station/Paintshop/Lib/LayerShape/120.blue			1	0			\N
536	res:/UI/Station/Paintshop/Lib/LayerShape/121.blue			1	0			\N
537	res:/UI/Station/Paintshop/Lib/LayerShape/122.blue			1	0			\N
538	res:/UI/Station/Paintshop/Lib/LayerShape/123.blue			1	0			\N
539	res:/UI/Station/Paintshop/Lib/LayerShape/124.blue			1	0			\N
540	res:/UI/Station/Paintshop/Lib/LayerShape/125.blue			1	0			\N
541	res:/UI/Station/Paintshop/Lib/LayerShape/126.blue			1	0			\N
542	res:/UI/Station/Paintshop/Lib/LayerShape/127.blue			1	0			\N
543	res:/UI/Station/Paintshop/Lib/LayerShape/128.blue			1	0			\N
544	res:/UI/Station/Paintshop/Lib/LayerShape/129.blue			1	0			\N
545	res:/UI/Station/Paintshop/Lib/LayerShape/130.blue			1	0			\N
546	res:/UI/Station/Paintshop/Lib/LayerShape/131.blue			1	0			\N
547	res:/UI/Station/Paintshop/Lib/LayerShape/132.blue			1	0			\N
548	res:/UI/Station/Paintshop/Lib/LayerShape/133.blue			1	0			\N
549	res:/UI/Station/Paintshop/Lib/LayerShape/134.blue			1	0			\N
550	res:/UI/Station/Paintshop/Lib/LayerShape/135.blue			1	0			\N
551	res:/UI/Station/Paintshop/Lib/LayerShape/136.blue			1	0			\N
552	res:/UI/Station/Paintshop/Lib/LayerShape/137.blue			1	0			\N
553	res:/UI/Station/Paintshop/Lib/LayerShape/138.blue			1	0			\N
554	res:/UI/Station/Paintshop/Lib/LayerShape/139.blue			1	0			\N
555	res:/UI/Station/Paintshop/Lib/LayerShape/140.blue			1	0			\N
556	res:/UI/Station/Paintshop/Lib/LayerShape/141.blue			1	0			\N
557	res:/UI/Station/Paintshop/Lib/LayerShape/142.blue			1	0			\N
558	res:/UI/Station/Paintshop/Lib/LayerShape/143.blue			1	0			\N
559	res:/UI/Station/Paintshop/Lib/LayerShape/144.blue			1	0			\N
560	res:/UI/Station/Paintshop/Lib/LayerShape/145.blue			1	0			\N
561	res:/UI/Station/Paintshop/Lib/LayerShape/146.blue			1	0			\N
562	res:/UI/Station/Paintshop/Lib/LayerShape/147.blue			1	0			\N
563	res:/UI/Station/Paintshop/Lib/LayerShape/148.blue			1	0			\N
564	res:/UI/Station/Paintshop/Lib/LayerShape/149.blue			1	0			\N
565	res:/UI/Station/Paintshop/Lib/LayerShape/150.blue			1	0			\N
566	res:/UI/Station/Paintshop/Lib/LayerShape/151.blue			1	0			\N
567	res:/UI/Station/Paintshop/Lib/LayerShape/152.blue			1	0			\N
568	res:/UI/Station/Paintshop/Lib/LayerShape/153.blue			1	0			\N
569	res:/UI/Station/Paintshop/Lib/LayerShape/154.blue			1	0			\N
570	res:/UI/Station/Paintshop/Lib/LayerShape/155.blue			1	0			\N
571	res:/UI/Station/Paintshop/Lib/LayerShape/156.blue			1	0			\N
572	res:/UI/Station/Paintshop/Lib/LayerShape/157.blue			1	0			\N
573	res:/UI/Station/Paintshop/Lib/LayerShape/158.blue			1	0			\N
574	res:/UI/Station/Paintshop/Lib/LayerShape/159.blue			1	0			\N
575	res:/UI/Station/Paintshop/Lib/LayerShape/160.blue			1	0			\N
576	res:/UI/Station/Paintshop/Lib/LayerShape/161.blue			1	0			\N
577	res:/UI/Station/Paintshop/Lib/LayerShape/162.blue			1	0			\N
578	res:/UI/Station/Paintshop/Lib/LayerShape/163.blue			1	0			\N
579	res:/UI/Station/Paintshop/Lib/LayerShape/164.blue			1	0			\N
580	res:/UI/Station/Paintshop/Lib/LayerShape/165.blue			1	0			\N
581	res:/UI/Station/Paintshop/Lib/LayerShape/166.blue			1	0			\N
582	res:/UI/Station/Paintshop/Lib/LayerShape/167.blue			1	0			\N
583	res:/UI/Station/Paintshop/Lib/LayerShape/168.blue			1	0			\N
584	res:/UI/Station/Paintshop/Lib/LayerShape/169.blue			1	0			\N
585	res:/UI/Station/Paintshop/Lib/LayerShape/170.blue			1	0			\N
586	res:/UI/Station/Paintshop/Lib/LayerShape/171.blue			1	0			\N
587	res:/UI/Station/Paintshop/Lib/LayerShape/172.blue			1	0			\N
588	res:/UI/Station/Paintshop/Lib/LayerShape/173.blue			1	0			\N
589	res:/UI/Station/Paintshop/Lib/LayerShape/174.blue			1	0			\N
590	res:/UI/Station/Paintshop/Lib/LayerShape/175.blue			1	0			\N
591	res:/UI/Station/Paintshop/Lib/LayerShape/176.blue			1	0			\N
592	res:/UI/Station/Paintshop/Lib/LayerShape/177.blue			1	0			\N
593	res:/UI/Station/Paintshop/Lib/LayerShape/178.blue			1	0			\N
594	res:/UI/Station/Paintshop/Lib/LayerShape/179.blue			1	0			\N
595	res:/UI/Station/Paintshop/Lib/LayerShape/180.blue			1	0			\N
596	res:/UI/Station/Paintshop/Lib/LayerShape/181.blue			1	0			\N
597	res:/UI/Station/Paintshop/Lib/LayerShape/182.blue			1	0			\N
598	res:/UI/Station/Paintshop/Lib/LayerShape/183.blue			1	0			\N
599	res:/UI/Station/Paintshop/Lib/LayerShape/184.blue			1	0			\N
600	res:/UI/Station/Paintshop/Lib/LayerShape/185.blue			1	0			\N
601	res:/UI/Station/Paintshop/Lib/LayerShape/186.blue			1	0			\N
602	res:/UI/Station/Paintshop/Lib/LayerShape/187.blue			1	0			\N
603	res:/UI/Station/Paintshop/Lib/LayerShape/188.blue			1	0			\N
604	res:/UI/Station/Paintshop/Lib/LayerShape/189.blue			1	0			\N
605	res:/UI/Station/Paintshop/Lib/LayerShape/190.blue			1	0			\N
606	res:/UI/Station/Paintshop/Lib/LayerShape/191.blue			1	0			\N
607	res:/UI/Station/Paintshop/Lib/LayerShape/192.blue			1	0			\N
608	res:/UI/Station/Paintshop/Lib/LayerShape/193.blue			1	0			\N
609	res:/UI/Station/Paintshop/Lib/LayerShape/194.blue			1	0			\N
610	res:/UI/Station/Paintshop/Lib/LayerShape/195.blue			1	0			\N
611	res:/UI/Station/Paintshop/Lib/LayerShape/196.blue			1	0			\N
612	res:/UI/Station/Paintshop/Lib/LayerShape/197.blue			1	0			\N
613	res:/UI/Station/Paintshop/Lib/LayerShape/198.blue			1	0			\N
614	res:/UI/Station/Paintshop/Lib/LayerShape/199.blue			1	0			\N
615	res:/UI/Station/Paintshop/Lib/LayerShape/200.blue			1	0			\N
616	res:/UI/Station/Paintshop/Lib/LayerShape/201.blue			1	0			\N
617	res:/UI/Station/Paintshop/Lib/LayerShape/202.blue			1	0			\N
618	res:/UI/Station/Paintshop/Lib/LayerShape/203.blue			1	0			\N
619	res:/UI/Station/Paintshop/Lib/LayerShape/204.blue			1	0			\N
620	res:/UI/Station/Paintshop/Lib/LayerShape/205.blue			1	0			\N
621	res:/UI/Station/Paintshop/Lib/LayerShape/206.blue			1	0			\N
622	res:/UI/Station/Paintshop/Lib/LayerShape/207.blue			1	0			\N
623	res:/UI/Station/Paintshop/Lib/LayerShape/208.blue			1	0			\N
624	res:/UI/Station/Paintshop/Lib/LayerShape/209.blue			1	0			\N
625	res:/UI/Station/Paintshop/Lib/LayerShape/210.blue			1	0			\N
626	res:/UI/Station/Paintshop/Lib/LayerShape/211.blue			1	0			\N
627	res:/UI/Station/Paintshop/Lib/LayerShape/212.blue			1	0			\N
628	res:/UI/Station/Paintshop/Lib/LayerShape/213.blue			1	0			\N
629	res:/UI/Station/Paintshop/Lib/LayerShape/214.blue			1	0			\N
630	res:/UI/Station/Paintshop/Lib/LayerShape/215.blue			1	0			\N
631	res:/UI/Station/Paintshop/Lib/LayerShape/216.blue			1	0			\N
632	res:/UI/Station/Paintshop/Lib/LayerShape/217.blue			1	0			\N
633	res:/UI/Station/Paintshop/Lib/LayerShape/218.blue			1	0			\N
634	res:/UI/Station/Paintshop/Lib/LayerShape/219.blue			1	0			\N
635	res:/UI/Station/Paintshop/Lib/LayerShape/220.blue			1	0			\N
636	res:/UI/Station/Paintshop/Lib/LayerShape/221.blue			1	0			\N
637	res:/UI/Station/Paintshop/Lib/LayerShape/222.blue			1	0			\N
638	res:/UI/Station/Paintshop/Lib/LayerShape/223.blue			1	0			\N
639	res:/UI/Station/Paintshop/Lib/LayerShape/224.blue			1	0			\N
640	res:/UI/Station/Paintshop/Lib/LayerShape/225.blue			1	0			\N
641	res:/UI/Station/Paintshop/Lib/LayerShape/226.blue			1	0			\N
642	res:/UI/Station/Paintshop/Lib/LayerShape/227.blue			1	0			\N
643	res:/UI/Station/Paintshop/Lib/LayerShape/228.blue			1	0			\N
644	res:/UI/Station/Paintshop/Lib/LayerShape/229.blue			1	0			\N
645	res:/UI/Station/Paintshop/Lib/LayerShape/230.blue			1	0			\N
646	res:/UI/Station/Paintshop/Lib/LayerShape/231.blue			1	0			\N
647	res:/UI/Station/Paintshop/Lib/LayerShape/232.blue			1	0			\N
648	res:/UI/Station/Paintshop/Lib/LayerShape/233.blue			1	0			\N
649	res:/UI/Station/Paintshop/Lib/LayerShape/234.blue			1	0			\N
650	res:/UI/Station/Paintshop/Lib/LayerShape/235.blue			1	0			\N
651	res:/UI/Station/Paintshop/Lib/LayerShape/236.blue			1	0			\N
652	res:/UI/Station/Paintshop/Lib/LayerShape/237.blue			1	0			\N
653	res:/UI/Station/Paintshop/Lib/LayerShape/238.blue			1	0			\N
654	res:/UI/Station/Paintshop/Lib/LayerShape/239.blue			1	0			\N
655	res:/UI/Station/Paintshop/Lib/LayerShape/240.blue			1	0			\N
656	res:/UI/Station/Paintshop/Lib/LayerShape/241.blue			1	0			\N
657	res:/UI/Station/Paintshop/Lib/LayerShape/242.blue			1	0			\N
658	res:/UI/Station/Paintshop/Lib/LayerShape/243.blue			1	0			\N
659	res:/UI/Station/Paintshop/Lib/LayerShape/244.blue			1	0			\N
660	res:/UI/Station/Paintshop/Lib/LayerShape/245.blue			1	0			\N
661	res:/UI/Station/Paintshop/Lib/LayerShape/246.blue			1	0			\N
662	res:/UI/Station/Paintshop/Lib/LayerShape/247.blue			1	0			\N
663	res:/UI/Station/Paintshop/Lib/LayerShape/248.blue			1	0			\N
664	res:/UI/Station/Paintshop/Lib/LayerShape/249.blue			1	0			\N
665	res:/UI/Station/Paintshop/Lib/LayerShape/250.blue			1	0			\N
666	res:/UI/Station/Paintshop/Lib/LayerShape/251.blue			1	0			\N
667	res:/UI/Station/Paintshop/Lib/LayerShape/252.blue			1	0			\N
668	res:/UI/Station/Paintshop/Lib/LayerShape/253.blue			1	0			\N
669	res:/UI/Station/Paintshop/Lib/LayerShape/254.blue			1	0			\N
670	res:/UI/Station/Paintshop/Lib/LayerShape/255.blue			1	0			\N
671	res:/UI/Station/Paintshop/Lib/LayerColor/Black Plain.blue	Black Plain		1	0			\N
672	res:/UI/Station/Paintshop/Lib/LayerColor/Gold Plating.blue	Gold Plating		1	0			\N
673	res:/UI/Station/Paintshop/Lib/LayerColor/Gray Blue Shade.blue	Gray Blue Shade		1	0			\N
674	res:/UI/Station/Paintshop/Lib/LayerColor/Grey Paint.blue	Grey Paint		1	0			\N
675	res:/UI/Station/Paintshop/Lib/LayerColor/Lead.blue	Lead		1	0			\N
676	res:/UI/Station/Paintshop/Lib/LayerColor/Luminant Blue.blue	Luminant Blue		1	0			\N
677	res:/UI/Station/Paintshop/Lib/LayerColor/Luminant Yellow.blue	Luminant Yellow		1	0			\N
678	res:/UI/Station/Paintshop/Lib/LayerColor/Military Grey.blue	Military Grey		1	0			\N
679	res:/UI/Station/Paintshop/Lib/LayerColor/Orange Dangercolor.blue	Orange Dangercolor		1	0			\N
680	res:/UI/Station/Paintshop/Lib/LayerColor/Red Shade Paint.blue	Red Shade Paint		1	0			\N
681	res:/UI/Station/Paintshop/Lib/LayerColor/Silver Plating.blue	Silver Plating		1	0			\N
682	res:/UI/Station/Paintshop/Lib/LayerColor/Thin Black.blue	Thin Black		1	0			\N
683	res:/UI/Station/Paintshop/Lib/LayerColor/Thin White.blue	Thin White		1	0			\N
684	res:/UI/Station/Paintshop/Lib/LayerColor/White Plain.blue	White Plain		1	0			\N
685	res:/UI/Station/Paintshop/Lib/LayerColor/Yellow Plain.blue	Yellow Plain		1	0			\N
686	res:/UI/Station/Paintshop/Lib/LayerColor/15.blue			1	0			\N
687	res:/UI/Station/Paintshop/Lib/LayerColor/16.blue			1	0			\N
688	res:/UI/Station/Paintshop/Lib/LayerColor/17.blue			1	0			\N
689	res:/UI/Station/Paintshop/Lib/LayerColor/18.blue			1	0			\N
690	res:/UI/Station/Paintshop/Lib/LayerColor/19.blue			1	0			\N
691	res:/UI/Station/Paintshop/Lib/LayerColor/20.blue			1	0			\N
692	res:/UI/Station/Paintshop/Lib/LayerColor/21.blue			1	0			\N
693	res:/UI/Station/Paintshop/Lib/LayerColor/22.blue			1	0			\N
694	res:/UI/Station/Paintshop/Lib/LayerColor/23.blue			1	0			\N
695	res:/UI/Station/Paintshop/Lib/LayerColor/24.blue			1	0			\N
696	res:/UI/Station/Paintshop/Lib/LayerColor/25.blue			1	0			\N
697	res:/UI/Station/Paintshop/Lib/LayerColor/26.blue			1	0			\N
698	res:/UI/Station/Paintshop/Lib/LayerColor/27.blue			1	0			\N
699	res:/UI/Station/Paintshop/Lib/LayerColor/28.blue			1	0			\N
700	res:/UI/Station/Paintshop/Lib/LayerColor/29.blue			1	0			\N
701	res:/UI/Station/Paintshop/Lib/LayerColor/30.blue			1	0			\N
702	res:/UI/Station/Paintshop/Lib/LayerColor/31.blue			1	0			\N
703	res:/UI/Station/Paintshop/Lib/TagFont01			1	0			\N
704	res:/UI/Station/Paintshop/Lib/TagFont01			1	0			\N
705	res:/UI/Station/Paintshop/Lib/TagFont02			1	0			\N
706	res:/UI/Station/Paintshop/Lib/TagFont03			1	0			\N
707	res:/UI/Station/Paintshop/Lib/TagFont04			1	0			\N
708	res:/UI/Station/Paintshop/Lib/TagFont05			1	0			\N
709	res:/UI/Station/Paintshop/Lib/TagFont06			1	0			\N
710	res:/UI/Station/Paintshop/Lib/TagColor/0.blue			1	0			\N
711	res:/UI/Station/Paintshop/Lib/TagColor/1.blue			1	0			\N
712	res:/UI/Station/Paintshop/Lib/TagColor/2.blue			1	0			\N
713	res:/UI/Station/Paintshop/Lib/TagColor/3.blue			1	0			\N
714	res:/UI/Station/Paintshop/Lib/TagColor/4.blue			1	0			\N
715	res:/UI/Station/Paintshop/Lib/TagColor/5.blue			1	0			\N
716	res:/UI/Station/Paintshop/Lib/TagColor/6.blue			1	0			\N
717	res:/UI/Station/Paintshop/Lib/TagColor/7.blue			1	0			\N
718	res:/UI/Station/Paintshop/Lib/TagColor/8.blue			1	0			\N
719	res:/UI/Station/Paintshop/Lib/TagColor/9.blue			1	0			\N
720	res:/UI/Station/Paintshop/Lib/TagColor/10.blue			1	0			\N
721	res:/UI/Station/Paintshop/Lib/TagColor/11.blue			1	0			\N
722	res:/UI/Station/Paintshop/Lib/TagColor/12.blue			1	0			\N
723	res:/UI/Station/Paintshop/Lib/TagColor/13.blue			1	0			\N
724	res:/UI/Station/Paintshop/Lib/TagColor/14.blue			1	0			\N
725	res:/UI/Station/Paintshop/Lib/TagColor/15.blue			1	0			\N
726	res:/UI/Station/Paintshop/Lib/TagColor/16.blue			1	0			\N
727	res:/UI/Station/Paintshop/Lib/TagColor/17.blue			1	0			\N
728	res:/UI/Station/Paintshop/Lib/TagColor/18.blue			1	0			\N
729	res:/UI/Station/Paintshop/Lib/TagColor/19.blue			1	0			\N
730	res:/UI/Station/Paintshop/Lib/TagColor/20.blue			1	0			\N
731	res:/UI/Station/Paintshop/Lib/TagColor/21.blue			1	0			\N
732	res:/UI/Station/Paintshop/Lib/TagColor/22.blue			1	0			\N
733	res:/UI/Station/Paintshop/Lib/TagColor/23.blue			1	0			\N
734	res:/UI/Station/Paintshop/Lib/TagColor/24.blue			1	0			\N
735	res:/UI/Station/Paintshop/Lib/TagColor/25.blue			1	0			\N
736	res:/UI/Station/Paintshop/Lib/TagColor/26.blue			1	0			\N
737	res:/UI/Station/Paintshop/Lib/TagColor/27.blue			1	0			\N
738	res:/UI/Station/Paintshop/Lib/TagColor/28.blue			1	0			\N
739	res:/UI/Station/Paintshop/Lib/TagColor/29.blue			1	0			\N
740	res:/UI/Station/Paintshop/Lib/TagColor/30.blue			1	0			\N
741	res:/UI/Station/Paintshop/Lib/TagColor/31.blue			1	0			\N
742	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/0.blue			1	0			\N
743	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/1.blue			1	0			\N
744	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/2.blue			1	0			\N
1042			Internal structure mods	1	0	02_12		\N
745	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/3.blue			1	0			\N
746	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/4.blue			1	0			\N
747	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/5.blue			1	0			\N
748	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/6.blue			1	0			\N
749	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/7.blue			1	0			\N
750	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/8.blue			1	0			\N
751	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/9.blue			1	0			\N
752	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/10.blue			1	0			\N
753	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/11.blue			1	0			\N
754	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/12.blue			1	0			\N
755	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/13.blue			1	0			\N
756	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/14.blue			1	0			\N
757	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/15.blue			1	0			\N
758	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/16.blue			1	0			\N
759	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/17.blue			1	0			\N
760	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/18.blue			1	0			\N
761	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/19.blue			1	0			\N
762	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/20.blue			1	0			\N
763	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/21.blue			1	0			\N
764	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/22.blue			1	0			\N
765	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/23.blue			1	0			\N
766	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/24.blue			1	0			\N
767	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/25.blue			1	0			\N
768	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/26.blue			1	0			\N
769	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/27.blue			1	0			\N
770	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/28.blue			1	0			\N
771	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/29.blue			1	0			\N
772	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/30.blue			1	0			\N
773	res:/UI/Station/Paintshop/Lib/ShipColor1/Caldari/31.blue			1	0			\N
774	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/0.blue			1	0			\N
775	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/1.blue			1	0			\N
776	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/2.blue			1	0			\N
777	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/3.blue			1	0			\N
778	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/4.blue			1	0			\N
779	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/5.blue			1	0			\N
780	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/6.blue			1	0			\N
781	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/7.blue			1	0			\N
782	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/8.blue			1	0			\N
783	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/9.blue			1	0			\N
784	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/10.blue			1	0			\N
785	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/11.blue			1	0			\N
786	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/12.blue			1	0			\N
787	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/13.blue			1	0			\N
788	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/14.blue			1	0			\N
789	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/15.blue			1	0			\N
790	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/16.blue			1	0			\N
791	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/17.blue			1	0			\N
792	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/18.blue			1	0			\N
793	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/19.blue			1	0			\N
794	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/20.blue			1	0			\N
795	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/21.blue			1	0			\N
796	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/22.blue			1	0			\N
797	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/23.blue			1	0			\N
798	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/24.blue			1	0			\N
799	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/25.blue			1	0			\N
800	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/26.blue			1	0			\N
801	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/27.blue			1	0			\N
802	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/28.blue			1	0			\N
803	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/29.blue			1	0			\N
804	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/30.blue			1	0			\N
805	res:/UI/Station/Paintshop/Lib/ShipColor1/Minmatar/31.blue			1	0			\N
806	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/0.blue			1	0			\N
807	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/1.blue			1	0			\N
808	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/2.blue			1	0			\N
809	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/3.blue			1	0			\N
810	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/4.blue			1	0			\N
811	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/5.blue			1	0			\N
812	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/6.blue			1	0			\N
813	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/7.blue			1	0			\N
814	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/8.blue			1	0			\N
815	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/9.blue			1	0			\N
816	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/10.blue			1	0			\N
817	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/11.blue			1	0			\N
818	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/12.blue			1	0			\N
819	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/13.blue			1	0			\N
820	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/14.blue			1	0			\N
821	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/15.blue			1	0			\N
822	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/16.blue			1	0			\N
823	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/17.blue			1	0			\N
824	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/18.blue			1	0			\N
825	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/19.blue			1	0			\N
826	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/20.blue			1	0			\N
827	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/21.blue			1	0			\N
828	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/22.blue			1	0			\N
829	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/23.blue			1	0			\N
830	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/24.blue			1	0			\N
831	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/25.blue			1	0			\N
832	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/26.blue			1	0			\N
833	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/27.blue			1	0			\N
834	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/28.blue			1	0			\N
835	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/29.blue			1	0			\N
836	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/30.blue			1	0			\N
837	res:/UI/Station/Paintshop/Lib/ShipColor1/Amarr/31.blue			1	0			\N
838	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/0.blue			1	0			\N
839	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/1.blue			1	0			\N
840	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/2.blue			1	0			\N
841	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/3.blue			1	0			\N
842	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/4.blue			1	0			\N
843	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/5.blue			1	0			\N
844	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/6.blue			1	0			\N
845	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/7.blue			1	0			\N
846	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/8.blue			1	0			\N
847	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/9.blue			1	0			\N
848	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/10.blue			1	0			\N
849	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/11.blue			1	0			\N
850	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/12.blue			1	0			\N
851	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/13.blue			1	0			\N
852	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/14.blue			1	0			\N
853	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/15.blue			1	0			\N
854	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/16.blue			1	0			\N
855	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/17.blue			1	0			\N
856	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/18.blue			1	0			\N
857	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/19.blue			1	0			\N
858	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/20.blue			1	0			\N
859	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/21.blue			1	0			\N
860	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/22.blue			1	0			\N
861	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/23.blue			1	0			\N
862	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/24.blue			1	0			\N
863	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/25.blue			1	0			\N
864	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/26.blue			1	0			\N
865	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/27.blue			1	0			\N
866	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/28.blue			1	0			\N
867	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/29.blue			1	0			\N
868	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/30.blue			1	0			\N
869	res:/UI/Station/Paintshop/Lib/ShipColor1/Gallente/31.blue			1	0			\N
870	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/0.blue			1	0			\N
871	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/1.blue			1	0			\N
872	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/2.blue			1	0			\N
873	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/3.blue			1	0			\N
874	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/4.blue			1	0			\N
875	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/5.blue			1	0			\N
876	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/6.blue			1	0			\N
877	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/7.blue			1	0			\N
878	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/8.blue			1	0			\N
879	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/9.blue			1	0			\N
880	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/10.blue			1	0			\N
881	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/11.blue			1	0			\N
882	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/12.blue			1	0			\N
883	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/13.blue			1	0			\N
884	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/14.blue			1	0			\N
885	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/15.blue			1	0			\N
886	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/16.blue			1	0			\N
887	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/17.blue			1	0			\N
888	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/18.blue			1	0			\N
889	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/19.blue			1	0			\N
890	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/20.blue			1	0			\N
891	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/21.blue			1	0			\N
892				1	0	01_04		\N
893	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/23.blue			1	0			\N
894	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/24.blue			1	0			\N
895	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/25.blue			1	0			\N
896	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/26.blue			1	0			\N
897	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/27.blue			1	0			\N
898	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/28.blue			1	0			\N
899	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/29.blue			1	0			\N
900	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/30.blue			1	0			\N
901	res:/UI/Station/Paintshop/Lib/ShipColor2/Caldari/31.blue			1	0			\N
902	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/0.blue			1	0			\N
903	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/1.blue			1	0			\N
904	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/2.blue			1	0			\N
905	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/3.blue			1	0			\N
906	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/4.blue			1	0			\N
907	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/5.blue			1	0			\N
908	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/6.blue			1	0			\N
909	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/7.blue			1	0			\N
910	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/8.blue			1	0			\N
911	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/9.blue			1	0			\N
912	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/10.blue			1	0			\N
913	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/11.blue			1	0			\N
914	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/12.blue			1	0			\N
915	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/13.blue			1	0			\N
916	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/14.blue			1	0			\N
917	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/15.blue			1	0			\N
918	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/16.blue			1	0			\N
919	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/17.blue			1	0			\N
920	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/18.blue			1	0			\N
921	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/19.blue			1	0			\N
922	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/20.blue			1	0			\N
923	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/21.blue			1	0			\N
924	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/22.blue			1	0			\N
925	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/23.blue			1	0			\N
926	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/24.blue			1	0			\N
927	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/25.blue			1	0			\N
928	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/26.blue			1	0			\N
929	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/27.blue			1	0			\N
930	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/28.blue			1	0			\N
931	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/29.blue			1	0			\N
932	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/30.blue			1	0			\N
933	res:/UI/Station/Paintshop/Lib/ShipColor2/Minmatar/31.blue			1	0			\N
934	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/0.blue			1	0			\N
935	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/1.blue			1	0			\N
936	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/2.blue			1	0			\N
937	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/3.blue			1	0			\N
938	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/4.blue			1	0			\N
939	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/5.blue			1	0			\N
940	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/6.blue			1	0			\N
941	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/7.blue			1	0			\N
942	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/8.blue			1	0			\N
943	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/9.blue			1	0			\N
944	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/10.blue			1	0			\N
945	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/11.blue			1	0			\N
946	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/12.blue			1	0			\N
947	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/13.blue			1	0			\N
948	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/14.blue			1	0			\N
949	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/15.blue			1	0			\N
950	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/16.blue			1	0			\N
951	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/17.blue			1	0			\N
952	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/18.blue			1	0			\N
953	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/19.blue			1	0			\N
954	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/20.blue			1	0			\N
955	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/21.blue			1	0			\N
956	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/22.blue			1	0			\N
957	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/23.blue			1	0			\N
958	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/24.blue			1	0			\N
959	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/25.blue			1	0			\N
960	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/26.blue			1	0			\N
961	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/27.blue			1	0			\N
962	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/28.blue			1	0			\N
963	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/29.blue			1	0			\N
964	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/30.blue			1	0			\N
965	res:/UI/Station/Paintshop/Lib/ShipColor2/Amarr/31.blue			1	0			\N
966	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/0.blue			1	0			\N
967	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/1.blue			1	0			\N
968	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/2.blue			1	0			\N
969	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/3.blue			1	0			\N
970	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/4.blue			1	0			\N
971	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/5.blue			1	0			\N
972	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/6.blue			1	0			\N
973	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/7.blue			1	0			\N
974	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/8.blue			1	0			\N
975	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/9.blue			1	0			\N
976	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/10.blue			1	0			\N
977	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/11.blue			1	0			\N
978	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/12.blue			1	0			\N
979	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/13.blue			1	0			\N
980	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/14.blue			1	0			\N
981	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/15.blue			1	0			\N
982	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/16.blue			1	0			\N
983	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/17.blue			1	0			\N
984	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/18.blue			1	0			\N
985	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/19.blue			1	0			\N
986	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/20.blue			1	0			\N
987	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/21.blue			1	0			\N
988	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/22.blue			1	0			\N
989	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/23.blue			1	0			\N
990	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/24.blue			1	0			\N
991	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/25.blue			1	0			\N
992	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/26.blue			1	0			\N
993	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/27.blue			1	0			\N
994	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/28.blue			1	0			\N
995	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/29.blue			1	0			\N
996	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/30.blue			1	0			\N
997	res:/UI/Station/Paintshop/Lib/ShipColor2/Gallente/31.blue			1	0			\N
998		Unknown	Info Message Box Icon	1	0	09_09		\N
999		Unknown	Warning Message Box Icon	1	0	09_11		\N
1001		Unknown	Question Message Box Icon	1	0	09_10		\N
1002		Unknown	Error Message box Icon	1	0	09_08		\N
1004	Unknown	Unknown		1	0	14_01		\N
1006	res:/Model/Sentry/Amarr/asg1.blue ale311	SentryGun	Sentry Gun	1	0			\N
1007	res:/Model/mine/Hex_mine.blue	HexMine	Hex Mine	1	0	21_08		\N
1008	res:/Model/Drone/inflitrator1.blue	CombatDrone		1	0			2024
1009	res:/Model/Drone/inflitrator_mining.blue	MiningDrone		1	0			2024
1010	res:/Model/Ship/pirate/pirf2/pir2_dev.blue	Enigma	This is a ship intended for testing purposes.	1	0			2026
1011	res:/Model/Lensflare/blue.blue	Sun		1	0			\N
1012	res:/Model/Lensflare/orange.blue	Sun		1	0			\N
1013	res:/Model/Lensflare/red.blue	Sun		1	0			\N
1014	res:/Model/Lensflare/white.blue	Sun		1	0			\N
1015	res:/Model/Lensflare/yellow.blue	Sun		1	0			\N
1016	res:/Model/Ship/Gallente/gp1/gp1.blue	PoliceDrone		1	0			2026
1017	res:/Model/Station/Caldari/cs3/cs3.blue	Station	Station: Caldari 3	1	0		res:/Sound/Station/Station13.blue	\N
1018	res:/Model/Station/Caldari/cs2/cs2.blue	Station	Station: Caldari 2	1	0		res:/Sound/Station/Station04.blue	\N
1019	res:/Model/Station/Caldari/cs1/cs1.blue	Station	Station: Caldari 1	1	0		res:/Sound/Station/Station01.blue	\N
1020	res:/Model/Drone/Pirate/af2_pir.blue	Pirate		1	0			2024
1021	res:/Model/WorldObject/Derelict/derelict1.blue	Derelict ship	Derelict ship	1	0			\N
1029			Capacitor vampire	1	0	01_03		\N
1030			ArmorCoating	1	0	01_08		\N
1031			Capacitor Booster	1	0	01_06		\N
1032		Unknown	Capacitor Recharger	1	0	01_01		\N
1033			Capacitor Booster Charge	1	0	01_07		\N
1034		Unknown	Damage control	1	0	02_11		\N
1035		Unknown	Energy transfer array	1	0	01_02		\N
1036		Unknown	Power Manager	1	0	02_06		\N
1037		Unknown	Cargo expansion	1	0	04_13		\N
1038		Unknown	Armored bulkheads	1	0	02_10		\N
1039		Unknown	Energy Reflection	1	0	02_04		\N
1040			MaxSpeedBonus	1	0	03_05		\N
1041			Agility Enhancement	1	0	03_06		\N
1043			Basic Cargo Container	1	0	02_12		\N
1044			Shield Extender	1	0	02_05		\N
1045		Unknown	Shield resistanceboosters	1	0	02_02		\N
1046		Unknown	Gyrostabilizer	1	0	05_12		\N
1047	res:/Model/Turret/Ammo/h8.blue	Antimatter Charge S	hybrid ammo	1	0	15_09		\N
1048		Unknown	sensor upgrade/sybsystem	1	0	04_10		\N
1049	res:/Model/Ship/Concord/ConF1/ConF1_police.blue	Concord Police Frigate	Ship	1	0			2026
1050	res:/Model/Ship/Concord/ConC1/ConC1_black.blue	Concord Special Ops Cruiser		1	0			2026
1051	res:/Model/Ship/Concord/ConC1/ConC1_police.blue	Concord Police Cruiser		1	0			2026
1052	res:/Model/Ship/Concord/ConC1/ConC1_Army.blue	Concord Army Cruiser		1	0			2026
1053	res:/Model/Ship/Concord/ConF1/ConF_Black.blue	Concord Special Ops Frigate		1	0			2026
1054	res:/Model/Ship/Concord/ConF1/ConF1_Swat.blue	Concord SWAT Frigate		1	0			2026
1055	res:/Model/Ship/Concord/ConF1/ConF_Army.blue	Concord Army Frigate		1	0			2026
1056	res:/Model/Ship/Concord/ConC1/ConC1_SWAT.blue	Concord SWAT Cruiser		1	0			2026
1057	res:/Model/Ship/Concord/ConB1/ConB1_SWAT.blue	Concord SWAT Battleship		1	0			2026
1058	res:/Model/Ship/Concord/ConB1/ConB1_police.blue	Concord Police Battleship		1	0			2026
1059	res:/Model/Ship/Concord/ConB1/ConB1_black.blue	Concord Special Ops Battleship		1	0			2026
1060	res:/Model/Ship/Concord/ConB1/ConB1_army.blue	Concord Army Battleship		1	0			2026
1061	mim111	Mining Laser	Mining Laser	1	0	12_08		\N
1062		Unknown	Shield recharge bonus	1	0	01_15		\N
1063		Unknown	ammo capacity bonus	1	0	05_16		\N
1064	res:/Model/Ship/Amarr/ai2/ai2.blue	Amarr Industrial 2		1	0			2026
1065	res:/Model/Ship/Amarr/ac4/ac4.blue	Omen		1	0			\N
1066	res:/Model/Ship/Amarr/af2/af2.blue	Amarr Frigate 2		1	0			2025
1067	res:/Model/Ship/Amarr/af_p/af_p.blue	Amarr Police Frigate		1	0			2025
1068	res:/Model/Station/Amarr/AS_hub.blue	Amarr Station Hub		1	0		res:/Sound/Station/Station19.blue	\N
1069	res:/Model/Station/Amarr/as_millitary.blue	Amarr Station Military		1	0		res:/Sound/Station/Station17.blue	\N
1070	res:/Model/Station/Amarr/as_industrial.blue	Amarr Industrial Station		1	0		res:/Sound/Station/stationFlame.blue	\N
1071	res:/Model/Station/Amarr/as_standard.blue	Amarr standard station		1	0		res:/Sound/Station/stationFlame.blue	\N
1072	res:/Model/Station/Amarr/as_mining.blue	Amarr Mining Station		1	0		res:/Sound/Station/stationFlame.blue	\N
1073	res:/Model/Station/Amarr/as_research.blue	Amarr Research Station		1	0		res:/Sound/Station/Station02.blue	\N
1074	res:/Model/Station/Amarr/as_tradepost.blue	Amarr Trade Post		1	0		res:/Sound/Station/Station07.blue	\N
1075	res:/Scene/Hangar/Amarr.blue	Amarr Hangar	Station hangar, Amarr	1	0			\N
1076	res:/Model/Ship/Amarr/ac1/ac1_Ardishapur.blue	ac1_Ardishapur		1	0			2026
1077	res:/Model/Ship/Amarr/ac1/ac1_Tash-Murkon.blue	ac1_Tash-Murkon		1	0			2026
1078	res:/Model/Ship/Amarr/ac1/ac1_Kor-Azor.blue	ac1_Kor-Azor		1	0			2026
1079	res:/Model/Drone/New_Wasp.blue	Unknown		1	0			\N
1080	res:/Model/Drone/New_Wasp2.blue	Unknown		1	0			\N
1081	res:/Model/Drone/Wasp2.blue	Unknown		1	0			2024
1082	res:/Model/Drone/Wasp3.blue	Unknown		1	0			2024
1083	res:/Model/Drone/Wasp4.blue	Unknown		1	0			2024
1084	res:/Model/Drone/New_Acolyte.blue	Unknown		1	0	11_16		\N
1085	res:/Model/Drone/Acolyte2.blue	Unknown		1	0			2024
1086	res:/Model/Drone/Acolyte3.blue	Unknown		1	0			2024
1087	res:/Model/Drone/Acolyte4.blue	Unknown		1	0			2024
1088	res:/Model/Drone/Acolyte5.blue	Unknown		1	0			2024
1089	res:/Model/Drone/New_Berserker.blue	Unknown		1	0			\N
1090	res:/Model/Drone/Berserker2.blue	Unknown		1	0			2024
1091	res:/Model/Drone/Berserker3.blue	Unknown		1	0			2024
1092	res:/Model/Drone/Berserker4.blue	Unknown		1	0			2024
1093	res:/Model/Drone/Berserker5.blue	Unknown		1	0			2024
1094	res:/Model/Drone/New_Valkyrie2.blue	Unknown		1	0			\N
1095	res:/Model/Drone/New_Hammerhead2.blue	Unknown		1	0			\N
1096	res:/Model/Drone/hammerhead3.blue	Unknown		1	0			2024
1097	res:/Model/Drone/hammerhead4.blue	Unknown		1	0			2024
1098	res:/Model/Drone/hammerhead5.blue	Unknown		1	0			2024
1099	res:/Model/Drone/New_hobgoblin.blue	Unknown		1	0			\N
1100	res:/Model/Drone/New_hobgoblin2.blue	Unknown		1	0			\N
1101	res:/Model/Drone/Hobgoblin3.blue	Unknown		1	0			2024
1102	res:/Model/Drone/Hobgoblin4.blue	Unknown		1	0			2024
1103	res:/Model/Drone/Hobgoblin5.blue	Unknown		1	0			2024
1104	res:/Model/Drone/New_Hornet.blue	Unknown		1	0			\N
1105	res:/Model/Drone/New_Hornet2.blue	Unknown		1	0			\N
1106	res:/Model/Drone/Hornet3.blue	Unknown		1	0			2024
1107	res:/Model/Drone/Hornet4.blue	Unknown		1	0			2024
1108	res:/Model/Drone/Hornet5.blue	Unknown		1	0			2024
1109	res:/Model/Drone/New_Infiltrator2.blue	Unknown		1	0			\N
1110	res:/Model/Drone/inflitrator3.blue	Unknown		1	0			2024
1111	res:/Model/Drone/inflitrator4.blue	Unknown		1	0			2024
1112	res:/Model/Drone/inflitrator5.blue	Unknown		1	0			2024
1113	res:/Model/Drone/inflitrator_mom.blue	Unknown		1	0			2024
1114	res:/Model/Drone/New_Ogre.blue	Unknown		1	0			\N
1115	res:/Model/Drone/New_Ogre2.blue	Unknown		1	0			\N
1116	res:/Model/Drone/Ogre3.blue	Unknown		1	0			2024
1117	res:/Model/Drone/Ogre4.blue	Unknown		1	0			2024
1118	res:/Model/Drone/Ogre5.blue	Unknown		1	0			2024
1119	res:/Model/Drone/New_Praeator.blue	Unknown		1	0			\N
1120	res:/Model/Drone/New_Praeator2.blue	Unknown		1	0			\N
1121	res:/Model/Drone/Praeator3.blue	Unknown		1	0			2024
1122	res:/Model/Drone/Praeator4.blue	Unknown		1	0			2024
1123	res:/Model/Drone/Praeator5.blue	Unknown		1	0			2024
1124	res:/Model/Drone/New_Warrior.blue	Unknown		1	0			\N
1125	res:/Model/Drone/New_Warrior2.blue	Unknown		1	0			\N
1126	res:/Model/Drone/Warrior3.blue	Unknown		1	0			2024
1127	res:/Model/Drone/Warrior4.blue	Unknown		1	0			2024
1128	res:/Model/Drone/Warrior5.blue	Unknown		1	0			2024
1130	res:/bla/bla/blablab/testing123.blue	testing123		1	0			\N
1131	res:/Model/Turret/Ammo/wh1.blue	Unknown	MultiFrequencyCrystalSmall	1	0	08_01		\N
1132	res:/Model/Station/Minmatar/MS_hub.blue	MS_hub		1	0		res:/Sound/Station/Station11.blue	\N
1133	res:/Model/Station/Minmatar/MS_industrial.blue	MS_industrial		1	0		res:/Sound/Station/stationFlame.blue	\N
1134	res:/Model/Station/Minmatar/MS_millitary.blue	MS_millitary		1	0		res:/Sound/Station/stationFlame.blue	\N
1135	res:/Model/Station/Minmatar/MS_mining.blue	MS_mining		1	0		res:/Sound/Station/stationFlame.blue	\N
1136	res:/Model/Station/Minmatar/MS_research.blue	MS_research		1	0		res:/Sound/Station/Station02.blue	\N
1137	res:/Model/Station/Minmatar/MS_standard.blue	MS_standard		1	0		res:/Sound/Station/stationFlame.blue	\N
1138	res:/Model/Station/Minmatar/MS_Tradepost.blue	MS_Tradepost		1	0		res:/Sound/Station/Station02.blue	\N
1139	res:/Model/Turret/Ammo/bl1.blue	Unknown	FreqCrystal Gamma small	1	0	08_02		\N
1140	res:/Model/Turret/Ammo/gr1.blue	Unknown	FreqCrystal Roentgen small	1	0	08_03		\N
1141	res:/Model/Turret/Ammo/pu1.blue	Unknown	FreqCrystal UV small	1	0	08_04		\N
1142	res:/Model/Turret/Ammo/ye1.blue	Unknown	FreqCrystal Standard small	1	0	08_05		\N
1143	res:/Model/Turret/Ammo/or1.blue	Unknown	FreqCrystal Microwave	1	0	08_06		\N
1144	res:/Model/Turret/Ammo/re1.blue	Unknown	FreqCrystal Infrared small	1	0	08_07		\N
1145	res:/Model/Turret/Ammo/re1.blue	Unknown	FreqCrystal Radio small	1	0	08_08		\N
1146	res:/Model/WorldObject/HollowAsteroid/hollowAsteroid.blue	Hollow Asteroid		1	0			\N
1147	res:/Model/WorldObject/Cloud/redcloud.blue	Red Cloud		1	0			\N
1148	res:/Model/WorldObject/CargoBox/Cargo_Medium.blue	Cargo_Medium		1	0	03_13		\N
1149	res:/Model/WorldObject/CargoBox/Cargo_Radioactive.blue	Cargo_Radioactive		1	0			\N
1150	res:/Model/WorldObject/CargoBox/Cargo_Passenger.blue	Cargo_Passenger		1	0			\N
1151	res:/Model/WorldObject/CargoBox/cargo_Large.blue	cargo_Large		1	0	03_13		\N
1152	res:/Model/WorldObject/CargoBox/cargo_small.blue	cargo_small		1	0	03_13		\N
1153	res:/Model/WorldObject/CargoBox/cargo_Hangar.blue	cargo_Hangar		1	0			\N
1154	res:/Model/WorldObject/Cargobox/BioM_Cargo.blue	BioM_Cargo		1	0			\N
1155	res:/Model/WorldObject/Cargobox/BioS_Cargo.blue	BioS_Cargo		1	0			\N
1156	res:/Model/WorldObject/Cargobox/cargo_Hangar.blue	cargo_Hangar		1	0	26_14		\N
1157	res:/Model/WorldObject/Cargobox/CryoL_Cargo.blue	CryoL_Cargo		1	0	27_08		\N
1158	res:/Model/WorldObject/Cargobox/CryoM_Cargo.blue	CryoM_Cargo		1	0	27_07		\N
1159	res:/Model/WorldObject/Cargobox/CryoS_Cargo.blue	CryoS_Cargo		1	0	27_06		\N
1160	res:/Model/WorldObject/Cargobox/HydroM_Cargo.blue	HydroM_Cargo		1	0			\N
1161	res:/Model/WorldObject/Cargobox/HydroS_Cargo.blue	HydroS_Cargo		1	0			\N
1162	res:/Model/WorldObject/Cargobox/LifeL_Cargo.blue	LifeL_Cargo		1	0	27_12		\N
1163	res:/Model/WorldObject/Cargobox/LifeM_Cargo.blue	LifeM_Cargo		1	0	27_11		\N
1164	res:/Model/WorldObject/Cargobox/LifeS_Cargo.blue	LifeS_Cargo		1	0	27_10		\N
1165	res:/Model/WorldObject/Cargobox/OreL_Cargo.blue	OreL_Cargo		1	0	03_14		\N
1166	res:/Model/WorldObject/Cargobox/OreM_Cargo.blue	OreM_Cargo		1	0	03_14		\N
1167	res:/Model/WorldObject/Cargobox/OreS_Cargo.blue	OreS_Cargo		1	0	03_14		\N
1168	res:/Model/WorldObject/Cargobox/RadiationL_Cargo.blue	RadiationL_Cargo		1	0	27_16		\N
1169	res:/Model/WorldObject/Cargobox/RadiationM_Cargo.blue	RadiationM_Cargo		1	0	27_15		\N
1170	res:/Model/WorldObject/Cargobox/RadiationS_Cargo.blue	RadiationS_Cargo		1	0	27_14		\N
1171	res:/Model/WorldObject/Cargobox/SecureL_Cargo.blue	SecureL_Cargo		1	0	27_05		\N
1172	res:/Model/WorldObject/Cargobox/SecureM_Cargo.blue	SecureM_Cargo		1	0	26_16		\N
1173	res:/Model/WorldObject/Cargobox/SecureS_Cargo.blue	SecureS_Cargo		1	0	26_15		\N
1174	res:/Model/WorldObject/Cargobox/StandardL_Cargo.blue	StandardL_Cargo		1	0	26_13		\N
1175	res:/Model/WorldObject/Cargobox/StandardM_Cargo.blue	StandardM_Cargo		1	0	26_12		\N
1176	res:/Model/WorldObject/Cargobox/StandardS_Cargo.blue	StandardS_Cargo		1	0	26_11		\N
1177		Holoreels		1	0	10_05		\N
1178		Water		1	0	10_04		\N
1179		Garbage		1	0	10_03		\N
1180		Slaver		1	0	10_01		\N
1181		Soil		1	0	10_02		\N
1182		Wheat		1	0	10_06		\N
1183		Oxygen		1	0	10_07		\N
1184		Hydrogen batteries		1	0	10_08		\N
1185		Electronic parts		1	0	10_09		\N
1186		Mechanical parts		1	0	10_10		\N
1187		Synthetic oil		1	0	10_11		\N
1188		Fertilizer		1	0	10_12		\N
1189		Polytextiles		1	0	10_13		\N
1190		Silicate glass		1	0	10_14		\N
1191		Quafe		1	0	10_15		\N
1192		Certification results		1	0	10_16		\N
1193		Nerve Sticks		1	0	11_01		\N
1194		Crash		1	0	11_02		\N
1195		Blue Pill		1	0	11_03		\N
1196		Drop		1	0	11_04		\N
1197		Biomass		1	0	11_05		\N
1198		Dairy Products		1	0	11_06		\N
1199		Biohazard		1	0	11_07		\N
1200		Frozen Plantseeds		1	0	06_13		\N
1201		Nocxium		1	0	11_09		\N
1202		Megacyte		1	0	11_10		\N
1203		Pyerite		1	0	06_15		\N
1204		Slaves		1	0	11_12		\N
1205		Livestock		1	0	11_13		\N
1206		X-Instinct		1	0	11_14		\N
1207		Vitoc		1	0	11_15		\N
1208		Nanotech		1	0	11_16		\N
1209	res:/Model/WorldObject/Cargo/cargoContainer.blue		Plastic Wrap Icon	1	0	07_16		\N
1210	res:/Scene/Hangar/gallente_hub.blue	GallenteHubHangar	Station hangar, Gallente Hub	1	0			\N
1211	res:/Model/Sentry/Beacon/beacon.blue	beacon		1	0			\N
1212	res:/Model/Sentry/Caldari/csg2/csg2.blue clh411	csg2.blue a		1	0			\N
1213	res:/Model/Sentry/Caldari/csg3/csg3.blue clh211	csg3.blue a		1	0			\N
1214	res:/Model/Sentry/Caldari/csg4/csg4.blue clh2211	csg4.blue a		1	0			\N
1215	res:/Model/Sentry/Gallente/gsg1/gsg1.blue glh111	gsg1.blue a		1	0			\N
1216	res:/Model/Sentry/Minmatar/L1/sentry_L1.blue mlp111	sentry_L1.blue a		1	0			\N
1217	res:/Model/Sentry/Scanner/SensorJammer.blue	Sensor Jammer		1	0			\N
1219	res:/Model/Drone/drone_n/Drone_01.blue	Drone_01		1	0			2024
1220	res:/Model/Drone/drone_n/Drone_02.blue	Drone_02		1	0			2024
1221	res:/Model/Drone/drone_n/Drone_03.blue	Drone_03		1	0			2024
1222	res:/Model/Drone/drone_n/Drone_04.blue	Drone_04		1	0			2024
1223	res:/Model/Drone/drone_n/Drone_05.blue	Drone_05		1	0			2024
1224	res:/Model/Drone/drone_n/Drone_06.blue	Drone_06		1	0			2024
1225	res:/Model/Drone/drone_n/Drone_07.blue	Drone_07		1	0			2024
1226	res:/Model/Drone/drone_n/Drone_08.blue	Drone_08		1	0			2024
1227	res:/Model/Drone/drone_n/Drone_09.blue	Drone_09		1	0			2024
1228	res:/Model/Drone/drone_n/Drone_10.blue	Drone_10		1	0			2024
1229	res:/Model/Drone/drone_n/Drone_11.blue	Drone_11		1	0			2024
1230	res:/Model/Drone/drone_n/Drone_12.blue	Drone_12		1	0			2024
1231	res:/Model/Ship/soct/soctc1/soctc1.blue	soctc1		1	0			2026
1232	res:/Model/Ship/soct/soctf1/soctf1.blue	soctf1		1	0			2026
1233	res:/Model/Ship/soct/soctf2/soctf2.blue	soctf2		1	0			2026
1234	res:/Model/Ship/DarkAmarr/DaC1/DaC1.blue	DaC1		1	0			2026
1235	res:/Model/Ship/DarkAmarr/DaF1/DaF1.blue	DaF1		1	0			2026
1236	res:/Model/Ship/Sansha/sc1/sc1.blue	sc1		1	0			2026
1237	res:/Model/Ship/Sansha/sf1/sf1.blue	sf1		1	0			2026
1238	res:/Model/Ship/Sansha/sf2/sf2.blue	sf2		1	0			2026
1239	res:/Model/Ship/Minmatar/mt2/mt2.blue	mt2		1	0			2026
1240	res:/Model/Ship/Minmatar/Mf8/mf8.blue	mf8		1	0			2025
1241	res:/Model/Lensflare/blueSun1.blue	blueSun1		1	0			\N
1242	res:/Model/Lensflare/hazypink.blue	hazypink		1	0			\N
1243	res:/Model/Lensflare/orangesun.blue	orangesun		1	0			\N
1244	res:/Model/Lensflare/pinksmallsun.blue	pinksmallsun		1	0			\N
1245	res:/Model/Lensflare/radiatingorange.blue	radiatingorange		1	0			\N
1246	res:/Model/Lensflare/smallblue.blue	smallblue		1	0			\N
1247	res:/Model/Lensflare/smallYellow.blue	smallYellow		1	0			\N
1248	res:/Model/Lensflare/tinywhite.blue	tinywhite		1	0			\N
1249	res:/Model/Station/Amarr/as4/as4.blue	Amarr Citadel		1	0		res:/Sound/Station/Station07.blue	\N
1250	res:/Model/Station/Caldari/c_modular/c_m1.blue	c_m1		1	0		res:/Sound/Station/stationFlame.blue	\N
1251	res:/Model/Station/Caldari/c_modular/c_m2.blue	c_m2		1	0		res:/Sound/Station/stationFlame.blue	\N
1252	res:/Model/Station/Gallente/gs3/gs3.blue	gs3		1	0		res:/Sound/Station/Station16.blue	\N
1253	res:/Model/Station/Gallente/gs4/gs4.blue	gs4		1	0		res:/Sound/Station/Station08.blue	\N
1254	res:/Model/Station/Gallente/gs5/gs5.blue	gs5		1	0		res:/Sound/Station/Station08.blue	\N
1255	res:/Model/Station/Gallente/gs6/gs6.blue	gs6		1	0		res:/Sound/Station/Station02.blue	\N
1256	res:/Model/Station/Gallente/gs7/gs7.blue	gs7		1	0		res:/Sound/Station/Station12.blue	\N
1257	res:/Model/Station/Gallente/gs8/gs8.blue	gs8		1	0		res:/Sound/Station/Station19.blue	\N
1258	res:/Model/Jumpgate/Caldari/cj1/cj1.blue	cj1		1	0			\N
1259	res:/Model/Jumpgate/Gallente/gj1/gj1.blue	gj1		1	0			\N
1260	res:/Model/Jumpgate/Gallente/gj2/gj2.blue	gj2		1	0			\N
1261	res:/Model/Jumpgate/Gallente/gj3/gj3.blue	gj3		1	0			\N
1262	res:/Model/Jumpgate/Minmatar/MJ1/mj1.blue	mj1		1	0			\N
1263	res:/Model/Jumpgate/Minmatar/mj3/mj3.blue	mj3		1	0			\N
1264	res:/Model/Ship/Jove/jc5/jc5.blue	Jove Cruiser 5		1	0			2025
1265	res:/Model/WorldObject/Omnya/omnya.blue	omnya		1	0			\N
1266	res:/Model/WorldObject/Relic/relic.blue	relic		1	0			\N
1267	res:/Model/Station/Caldari/cs5/cs5.blue	Caldari Station 5		1	0		res:/Sound/Station/Station15.blue	\N
1268	res:/Model/WorldObject/Asteroid/blue_ruby.blue	blue_ruby		1	0			\N
1269	res:/Model/WorldObject/Asteroid/cyan_ruby.blue	cyan_ruby		1	0	23_09		\N
1270	res:/Model/WorldObject/Asteroid/glimmer_asteroid.blue	glimmer_asteroid		1	0	23_12		\N
1271	res:/Model/WorldObject/Asteroid/gold_asteroid.blue	gold_asteroid		1	0	23_13		\N
1272	res:/Model/WorldObject/Asteroid/gold_studlaberg.blue	gold_studlaberg		1	0	23_07		\N
1273	res:/Model/WorldObject/Asteroid/green_ruby.blue	green_ruby		1	0	23_06		\N
1274	res:/Model/WorldObject/Asteroid/green_studlaberg.blue	green_studlaberg		1	0	23_14		\N
1275	res:/Model/WorldObject/Asteroid/hrafntinna_studlaberg.blue	hrafntinna_studlaberg		1	0	23_08		\N
1276	res:/Model/WorldObject/Asteroid/molten_asteroid.blue	molten_asteroid		1	0			\N
1277	res:/Model/WorldObject/Asteroid/ruby_asteroid.blue	ruby_asteroid		1	0	23_05		\N
1278	res:/Model/WorldObject/Asteroid/silver_asteroid.blue	silver_asteroid		1	0			\N
1279	res:/Model/WorldObject/Asteroid/silver_studlaberg.blue	silver_studlaberg		1	0	23_11		\N
1280	res:/Model/WorldObject/Asteroid/sisteroid.blue	sisteroid		1	0			\N
1281	res:/Model/WorldObject/Asteroid/studlaberg_asteroid.blue	studlaberg_asteroid		1	0			\N
1282	res:/Model/WorldObject/Asteroid/blue_studlaberg.blue	Blue Studlaberg Asteroid		1	0	23_10		\N
1283		Unknown		1	0	12_04		\N
1284		Unknown		1	0	12_06		\N
1285	res:/Model/Turret/Ammo/p4.blue	Depleted Uranium S		1	0	14_02		\N
1286	res:/Model/Turret/Ammo/p8.blue	EMP S		1	0	14_03		\N
1287	res:/Model/Turret/Ammo/p6.blue	Fusion S		1	0	14_04		\N
1288	res:/Model/Turret/Ammo/p2.blue	Nuclear S		1	0	14_05		\N
1289	res:/Model/Turret/Ammo/p7.blue	Phased plasma S		1	0	14_06		\N
1290	res:/Model/Turret/Ammo/p3.blue	Photon S		1	0	14_07		\N
1291	res:/Model/Turret/Ammo/p5.blue	Titanium Sabot S		1	0	14_08		\N
1292	res:/Model/Turret/Ammo/p1.blue	Carbonized Lead M		1	0	14_09		\N
1293	res:/Model/Turret/Ammo/p4.blue	Depleted Uranium M		1	0	14_10		\N
1294	res:/Model/Turret/Ammo/p8.blue	EMP M		1	0	14_11		\N
1295	res:/Model/Turret/Ammo/p6.blue	Fusion M		1	0	14_12		\N
1296	res:/Model/Turret/Ammo/p2.blue	Nuclear M		1	0	14_13		\N
1297	res:/Model/Turret/Ammo/p7.blue	Phased plasma M		1	0	14_14		\N
1298	res:/Model/Turret/Ammo/p3.blue	Photon M		1	0	14_15		\N
1299	res:/Model/Turret/Ammo/p5.blue	Titanium Sabot M		1	0	14_16		\N
1300	res:/Model/Turret/Ammo/p1.blue	Carbonized Lead L		1	0	15_01		\N
1301	res:/Model/Turret/Ammo/p4.blue	Depleted Uranium L		1	0	15_02		\N
1302	res:/Model/Turret/Ammo/p8.blue	EMP L		1	0	15_03		\N
1303	res:/Model/Turret/Ammo/p6.blue	Fusion L		1	0	15_04		\N
1304	res:/Model/Turret/Ammo/p2.blue	Nuclear L		1	0	15_05		\N
1305	res:/Model/Turret/Ammo/p7.blue	Phased Plasma L		1	0	15_06		\N
1306	res:/Model/Turret/Ammo/p3.blue	Photon L		1	0	15_07		\N
1307	res:/Model/Turret/Ammo/p5.blue	Titanium Sabot L		1	0	15_08		\N
1308	res:/Model/Turret/Ammo/p1.blue	Carbonized Lead S		1	0	14_01		\N
1309	res:/Model/Station/Caldari/c_modular/c_m3.blue	Caldari Modular station 3		1	0		res:/Sound/Station/stationFlame.blue	\N
1310	res:/Model/Turret/Ammo/h3.blue	Iridium Charge S		1	0	15_10		\N
1311	res:/Model/Turret/Ammo/h1.blue	Iron Charge S		1	0	15_11		\N
1312	res:/Model/Turret/Ammo/h4.blue	Lead Charge S		1	0	15_12		\N
1313	res:/Model/Turret/Ammo/h7.blue	Plutonium Charge S		1	0	15_13		\N
1314	res:/Model/Turret/Ammo/h5.blue	Thorium Charge S		1	0	15_14		\N
1315	res:/Model/Turret/Ammo/h2.blue	Tungsten Charge S		1	0	15_15		\N
1316	res:/Model/Turret/Ammo/h6.blue	Uranium Charge S		1	0	15_16		\N
1317	res:/Model/Turret/Ammo/h8.blue	Antimatter Charge M		1	0	16_01		\N
1318	res:/Model/Turret/Ammo/h3.blue	Iridium Charge M		1	0	16_02		\N
1319	res:/Model/Turret/Ammo/h1.blue	Iron Charge M		1	0	16_03		\N
1320	res:/Model/Turret/Ammo/h4.blue	Lead Charge M		1	0	16_04		\N
1321	res:/Model/Turret/Ammo/h7.blue	Plutonium Charge M		1	0	16_05		\N
1322	res:/Model/Turret/Ammo/h5.blue	Thorium Charge M		1	0	16_06		\N
1323	res:/Model/Turret/Ammo/h2.blue	Tungsten Charge M		1	0	16_07		\N
1324	res:/Model/Turret/Ammo/h6.blue	Uranium Charge M		1	0	16_08		\N
1325	res:/Model/Turret/Ammo/h8.blue	Antimatter Charge L		1	0	16_09		\N
1326	res:/Model/Turret/Ammo/h3.blue	Iridium Charge L		1	0	16_10		\N
1327	res:/Model/Turret/Ammo/h1.blue	Iron Charge L		1	0	16_11		\N
1328	res:/Model/Turret/Ammo/h4.blue	Lead Charge L		1	0	16_12		\N
1329	res:/Model/Turret/Ammo/h7.blue	Plutonium Charge L		1	0	16_13		\N
1330	res:/Model/Turret/Ammo/h5.blue	Thorium Charge L		1	0	16_14		\N
1331	res:/Model/Turret/Ammo/h2.blue	Tungsten Charge L		1	0	16_15		\N
1332	res:/Model/Turret/Ammo/h6.blue	Uranium Charge L		1	0	16_16		\N
1333	res:/Model/Missile/Missile_Bloodclaw.blue	Unknown	Small FOF kinetic	1	0	20_01		\N
1334	res:/Model/Missile/Missile_Flameburst.blue	Unknown	small thermal FOF	1	0	20_05		\N
1335	res:/Model/Missile/Missile_pirahna.blue	Unknown	small explosive FOF	1	0	20_09		\N
1336	res:/Model/Missile/Missile_Sabretooth.blue	Unknown	small EM FOF	1	0	20_13		\N
1337	res:/Model/Missile/Missile_widowmaker.blue	Unknown	medium thermal FOF	1	0	20_07		\N
1338	res:/Model/Missile/Missile_Havoc.blue	Unknown	medium explosive FOF	1	0	20_11		\N
1339	res:/Model/Missile/Missile_Thunderbolt.blue	Unknown	medium EM FOF	1	0	20_15		\N
1340	res:/Model/Missile/Missile_Deathbringer.blue	Unknown	medium kinetic FOF	1	0	20_03		\N
1341	res:/Model/Missile/Missile_wrath.blue	Unknown	large kinetic FOF	1	0	21_01		\N
1342	res:/Model/Missile/Missile_Cataclysm.blue	Unknown	large thermal FOF	1	0	21_05		\N
1343	res:/Model/Missile/Missile_Devastator.blue	Unknown	large explosive FOF	1	0	21_09		\N
1344	res:/Model/Missile/Missile_Paradise.blue	Unknown	large EM FOF	1	0	21_13		\N
1345	res:/Model/Missile/Small/MissileSFire.blue	Unknown	Assault missile launcher	1	0	12_16		\N
1346	res:/Model/Missile/Missile_Juggenaut.blue	Unknown	Kinetic Torpedo	1	0	21_02		\N
1347	res:/Model/Missile/Missile_Inferno.blue	Unknown	Thermal Torpedo	1	0	21_06		\N
1348	res:/Model/Missile/Missile_Bane.blue	Unknown	Explosive Torpedo	1	0	21_10		\N
1349	res:/Model/Missile/Missile_Mjolnir.blue	Unknown	EM Torpedo	1	0	21_14		\N
1350	res:/Model/Missile/Missile_Thorn.blue	Unknown	kinetic rocket	1	0	21_03		\N
1351	res:/Model/Missile/Missile_Foxfire.blue	Unknown	Thermal rocket	1	0	21_07		\N
1352	res:/Model/Missile/Missile_Gremlin.blue	Unknown	em rocket	1	0	21_15		\N
1353	res:/Model/Missile/Missile_Phalanx.blue	Unknown	explosive rocket	1	0	21_11		\N
1354	res:/Scene/Bhole/bhole.blue	Black hole system		1	0			\N
1355	res:/Scene/EVE/eve6.blue	EVE system		1	0			\N
1356	res:/Model/WorldObject/Asteroid/asteroid_1.blue	Unknown	Scordite ore	1	0	23_15		\N
1357		Unknown	Carbon	1	0	24_03		\N
1358		Unknown	Silicone	1	0	24_04		\N
1359		Unknown	Rocket fuel	1	0	24_05		\N
1360		Unknown	Coolant	1	0	24_06		\N
1361		Unknown	Guidance System	1	0	24_07		\N
1362		Unknown	Consumer Electronics	1	0	24_08		\N
1363		Unknown	Super Conductors	1	0	24_09		\N
1364		Unknown	Transmitter	1	0	24_10		\N
1365		Unknown	Miniature Electronics	1	0	24_11		\N
1366		Unknown	Small arms	1	0	24_12		\N
1367		Unknown	Planetary Vehicles	1	0	24_13		\N
1368		Unknown	Robotics	1	0	24_14		\N
1369		Unknown	Spirits	1	0	24_15		\N
1370		Unknown	Tobacco	1	0	24_16		\N
1371		Unknown	Construction Blocks	1	0	06_05		\N
1372	res:/Model/Ship/Concord/polf1/polf1.blue	Polaris Frigate		1	0			2026
1373	res:/Model/Station/Amarr/as6/as6.blue	Ammar Station 6		1	0		res:/Sound/Station/Station07.blue	\N
1374	res:/Model/Station/Amarr/as5/as5.blue	Ammar Station 5		1	0		res:/Sound/Station/Station07.blue	\N
1375	res:/Model/Ship/Concord/polf1/polf2_centurion.blue	Polaris Centurion		1	0			2026
1376	res:/Model/Ship/Concord/polf1/polf3_legatus.blue	Polaris Legatus		1	0			2026
1377	res:/Model/WorldObject/Asteroid/green_ruby.blue	Green Ruby 2 ( Gneiss )	Gneiss	1	0	25_01		\N
1378		Unknown	Charisma	1	0	22_01		\N
1379		Unknown	Willpower	1	0	22_02		\N
1380		Unknown	Intelligence	1	0	22_03		\N
1381		Unknown	Memory	1	0	22_04		\N
1382		Unknown	Perception	1	0	22_05		\N
1383		Unknown	Armor Attribute	1	0	22_06		\N
1384		Unknown	Shield attribute	1	0	22_07		\N
1385		Unknown	Kinetic damage	1	0	22_09		\N
1386		Unknown	Thermal damage	1	0	22_10		\N
1387		Unknown	Explosive damage	1	0	22_11		\N
1388		Unknown	EM damage	1	0	22_12		\N
1389		Unknown	speed	1	0	22_13		\N
1390		Unknown	radius	1	0	22_14		\N
1391		Unknown	range	1	0	22_15		\N
1392		Unknown	duration	1	0	22_16		\N
1393		Unknown	kinetic armor	1	0	22_17		\N
1394		Unknown	thermal armor	1	0	22_18		\N
1395		Unknown	explosive armor	1	0	22_19		\N
1396		Unknown	EM armor	1	0	22_20		\N
1397		Unknown	ROF	1	0	22_21		\N
1398		Unknown	tracking speed	1	0	22_22		\N
1399		Unknown	accuracy	1	0	22_23		\N
1400		Unknown	power attribute	1	0	22_08		\N
1401		Unknown	agility	1	0	22_24		\N
1402	res:/Model/Station/concord/Con_HQ.blue	Concord Home Base		1	0		res:/Sound/Station/Station02.blue	\N
1403	res:/Model/Station/Angel/angS1.blue	Serpentis Station		1	0		res:/Sound/Station/Station03.blue	\N
1404	res:/Model/Station/Angel/angS2.blue	Heaven Station		1	0		res:/Sound/Station/Station05.blue	\N
1405		Unknown	cpu	1	0	12_07		\N
1406		Unknown	frozen longlimb roes	1	0	25_02		\N
1407	res:/Model/WorldObject/Wrecks/MS_Tradepost.blue	MS_Tradepost		1	0			\N
1408	res:/Model/WorldObject/Wrecks/as_Hub.blue	as_Hub		1	0			\N
1409	res:/Model/WorldObject/Wrecks/as_Millitary.blue	as_Millitary		1	0			\N
1410	res:/Model/WorldObject/Wrecks/AS_Mining.blue	AS_Mining		1	0			\N
1411	res:/Model/WorldObject/Wrecks/AS_Research.blue	AS_Research		1	0			\N
1412	res:/Model/WorldObject/Wrecks/as_Tradepost.blue	as_Tradepost		1	0			\N
1413	res:/Model/WorldObject/Wrecks/cs1.blue	cs1		1	0			\N
1414	res:/Model/WorldObject/Wrecks/cs2.blue	cs2		1	0			\N
1415	res:/Model/WorldObject/Wrecks/cs3.blue	cs3		1	0			\N
1416	res:/Model/WorldObject/Wrecks/cs4.blue	cs4		1	0			\N
1417	res:/Model/WorldObject/Wrecks/gs1.blue	gs1		1	0			\N
1418	res:/Model/WorldObject/Wrecks/gs2.blue	gs2		1	0			\N
1419	res:/Model/WorldObject/Wrecks/gs3.blue	gs3		1	0			\N
1420	res:/Model/WorldObject/Wrecks/gs4.blue	gs4		1	0			\N
1421	res:/Model/WorldObject/Wrecks/gs5.blue	gs5		1	0			\N
1422	res:/Model/WorldObject/Wrecks/gs6.blue	gs6		1	0			\N
1423	res:/Model/WorldObject/Wrecks/gs7.blue	gs7		1	0			\N
1424	res:/Model/WorldObject/Wrecks/gs8.blue	gs8		1	0			\N
1425	res:/Model/WorldObject/Wrecks/MS_Hub.blue	MS_Hub		1	0			\N
1426	res:/Model/WorldObject/Wrecks/MS_Industry.blue	MS_Industry		1	0			\N
1427	res:/Model/WorldObject/Wrecks/MS_Millitary.blue	MS_Millitary		1	0			\N
1428	res:/Model/WorldObject/Wrecks/MS_Mining.blue	MS_Mining		1	0			\N
1429	res:/Model/WorldObject/Wrecks/MS_Research.blue	MS_Research		1	0			\N
1430	res:/Model/WorldObject/Wrecks/MS_Standard.blue	MS_Standard		1	0			\N
1431	res:/Model/WorldObject/Wrecks/MS_Tradepost.blue	MS_Tradepost		1	0			\N
1432		Unknown	Gunnery	1	0	26_01		\N
1433		Unknown	Operations	1	0	26_02		\N
1434		Unknown	Science	1	0	26_03		\N
1435		Unknown	Business	1	0	26_04		\N
1436		Unknown	Engineering	1	0	27_01		\N
1437		Unknown	Industry	1	0	27_02		\N
1438		Unknown	Bloodlines	1	0	27_03		\N
1439		Unknown	Caldari race logo	1	0	19_01		\N
1440		Unknown	Minmatar race logo	1	0	19_02		\N
1441		Unknown	Gallente race logo	1	0	19_03		\N
1442		Unknown	Amarr race logo	1	0	19_04		\N
1443		Unknown	ship icon	1	0	09_05		\N
1444		Unknown	command	1	0	25_04		\N
1445		Unknown	Jumpdrive	1	0	03_07		\N
1446		Unknown	gear	1	0	09_16		\N
1447		Unknown	Imperial Academy	1	0	c_42_3		\N
1448		Unknown	Hedion University	1	0	c_43_1		\N
1449		Unknown	Royal Amarr Institute	1	0	c_39_4		\N
1450		Unknown	Republic Military School	1	0	c_43_2		\N
1451		Unknown	Republic University	1	0	c_43_3		\N
1452		Unknown	State War Academy	1	0	c_42_1		\N
1453		Unknown	Science & Trade Institute	1	0	c_10_2		\N
1454		Unknown	Federal Navy Academy	1	0	c_42_4		\N
1455		Unknown	School of Applied Knowledge	1	0	c_10_1		\N
1456		Unknown	University of Caille	1	0	c_39_1		\N
1457		Unknown	Center for Advanced Studies	1	0	c_41_4		\N
1458		Unknown	Pator Tech School	1	0	c_43_4		\N
1459		Unknown	physics	1	0	25_05		\N
1460		Unknown	applied science	1	0	25_06		\N
1461		Unknown	Biology	1	0	25_07		\N
1462		Unknown	Marketing	1	0	25_08		\N
1463		Unknown	Management	1	0	25_09		\N
1464		Unknown	Public Relations	1	0	25_10		\N
1465				1	0	c_7_4		\N
1466				1	0	c_41_3		\N
1467				1	0	c_22_2		\N
1468				1	0	c_22_1		\N
1469				1	0	c_23_1		\N
1470				1	0	c_22_4		\N
1471				1	0	c_21_2		\N
1472				1	0	c_23_2		\N
1473				1	0	c_21_3		\N
1474				1	0	c_23_3		\N
1475				1	0	c_21_4		\N
1476				1	0	c_22_3		\N
1477				1	0	c_23_4		\N
1478				1	0	c_21_1		\N
1479				1	0	c_14_3		\N
1480				1	0	c_15_2		\N
1481				1	0	c_14_2		\N
1482				1	0	c_19_4		\N
1483				1	0	c_16_1		\N
1484				1	0	c_18_3		\N
1485				1	0	c_17_2		\N
1486				1	0	c_19_1		\N
1487				1	0	c_17_4		\N
1488				1	0	c_16_2		\N
1489				1	0	c_13_2		\N
1490				1	0	c_15_4		\N
1491				1	0	c_17_3		\N
1492				1	0	c_13_3		\N
1493				1	0	c_39_4		\N
1494				1	0	c_18_4		\N
1495				1	0	c_14_4		\N
1496				1	0	c_17_1		\N
1497				1	0	c_18_2		\N
1498				1	0	c_16_3		\N
1499				1	0	c_15_1		\N
1500				1	0	c_16_4		\N
1501				1	0	c_18_1		\N
1502				1	0	c_12_1		\N
1503				1	0	c_13_1		\N
1504				1	0	c_12_3		\N
1505				1	0	c_12_2		\N
1506				1	0	c_12_4		\N
1507				1	0	c_15_3		\N
1508				1	0	c_13_4		\N
1509				1	0	c_19_2		\N
1510				1	0	c_33_1		\N
1511				1	0	c_33_3		\N
1512				1	0	c_26_1		\N
1513				1	0	c_31_3		\N
1514				1	0	c_28_2		\N
1515				1	0	c_27_3		\N
1516				1	0	c_34_3		\N
1517				1	0	c_32_3		\N
1518				1	0	c_29_4		\N
1519				1	0	c_25_4		\N
1520				1	0	c_25_2		\N
1521				1	0	c_38_2		\N
1522				1	0	c_25_3		\N
1523				1	0	c_31_2		\N
1524				1	0	c_32_1		\N
1525				1	0	c_32_4		\N
1526				1	0	c_33_2		\N
1527				1	0	c_30_1		\N
1528				1	0	c_31_4		\N
1529				1	0	c_32_2		\N
1530				1	0	c_25_1		\N
1531				1	0	c_39_1		\N
1532				1	0	c_30_2		\N
1533				1	0	c_30_4		\N
1534				1	0	c_29_1		\N
1535				1	0	c_29_2		\N
1536				1	0	c_29_3		\N
1537				1	0	c_10_3		\N
1538				1	0	c_31_1		\N
1539				1	0	c_35_2		\N
1540				1	0	c_24_3		\N
1541				1	0	c_26_3		\N
1542				1	0	c_35_3		\N
1543				1	0	c_28_3		\N
1544				1	0	c_34_2		\N
1545				1	0	c_27_4		\N
1546				1	0	c_14_1		\N
1547				1	0	c_36_2		\N
1548				1	0	c_3_4		\N
1549				1	0	c_24_1		\N
1550				1	0	c_19_3		\N
1551				1	0	c_38_1		\N
1552				1	0	c_24_2		\N
1553				1	0	c_4_1		\N
1554				1	0	c_24_4		\N
1555				1	0	c_35_4		\N
1556				1	0	c_40_2		\N
1557				1	0	c_28_4		\N
1558				1	0	c_40_4		\N
1559				1	0	c_26_4		\N
1560				1	0	c_26_2		\N
1561				1	0	c_27_1		\N
1562				1	0	c_28_1		\N
1563				1	0	c_27_2		\N
1564				1	0	c_3_2		\N
1565				1	0	c_40_3		\N
1566				1	0	c_39_3		\N
1567				1	0	c_11_4		\N
1568				1	0	c_11_2		\N
1569				1	0	c_11_3		\N
1570				1	0	c_35_1		\N
1571				1	0	c_41_1		\N
1572				1	0	c_11_1		\N
1573				1	0	c_33_4		\N
1574				1	0	c_40_1		\N
1575				1	0	c_36_3		\N
1576				1	0	c_36_1		\N
1577				1	0	c_34_4		\N
1578				1	0	c_34_1		\N
1579				1	0	c_36_4		\N
1580				1	0	c_41_2		\N
1581				1	0	c_1_3		\N
1582				1	0	c_8_1		\N
1583				1	0	c_1_4		\N
1584				1	0	c_4_4		\N
1585				1	0	c_38_3		\N
1586				1	0	c_39_2		\N
1587				1	0	c_3_3		\N
1588				1	0	c_3_1		\N
1589				1	0	c_6_2		\N
1590				1	0	c_10_4		\N
1591				1	0	c_9_4		\N
1592				1	0	c_7_2		\N
1593				1	0	c_1_1		\N
1594				1	0	c_5_4		\N
1595				1	0	c_2_4		\N
1596				1	0	c_5_3		\N
1597				1	0	c_6_1		\N
1598				1	0	c_2_1		\N
1599				1	0	c_2_3		\N
1600				1	0	c_5_2		\N
1601				1	0	c_9_1		\N
1602				1	0	c_7_3		\N
1603				1	0	c_10_3		\N
1604				1	0	c_8_4		\N
1605				1	0	c_9_2		\N
1606				1	0	c_9_3		\N
1607				1	0	c_4_2		\N
1608				1	0	c_5_1		\N
1609				1	0	c_8_2		\N
1610				1	0	c_7_1		\N
1611				1	0	c_8_3		\N
1612				1	0	c_4_3		\N
1613				1	0	c_37_3		\N
1614				1	0	c_1_2		\N
1615				1	0	c_2_2		\N
1616				1	0	c_6_3		\N
1617				1	0	c_37_2		\N
1618				1	0	c_37_1		\N
1619				1	0	c_38_4		\N
1620				1	0	c_6_4		\N
1621				1	0	c_37_4		\N
1622				1	0	c_10_1		\N
1623				1	0	c_10_2		\N
1624				1	0	c_20_3		\N
1625				1	0	c_20_1		\N
1626				1	0	c_20_4		\N
1627				1	0	c_20_2		\N
1628			Amarr Bloodline	1	0	28_01		\N
1629			Gallente Bloodline	1	0	28_02		\N
1630		Unknown	Intaki Bloodline	1	0	28_03		\N
1631			Civire Bloodline	1	0	28_04		\N
1632			Ni-Kunni Bloodline	1	0	29_01		\N
1633			Deiteis Bloodline	1	0	29_02		\N
1634			Sebiestor Bloodline	1	0	29_03		\N
1635			Brutor Bloodline	1	0	29_04		\N
1637	res:/Model/Station/DarkAmaar/das_O.blue	Dark Amarr Station O		1	0		res:/Sound/Station/Station03.blue	\N
1638	res:/Model/Station/DarkAmaar/das_h.blue	Dark Amarr Station H		1	0		res:/Sound/Station/Station03.blue	\N
1639		Unknown	Tracking Disrupter	1	0	05_07		\N
1640		Unknown	Tracking enhancer	1	0	05_14		\N
1641			Liberal Holders	1	0	30_01		\N
1642		Unknown	Wealthy Commoners	1	0	30_02		\N
1643			Religious Reclaimers	1	0	30_03		\N
1644			Free Merchants	1	0	30_04		\N
1645			Border Runners	1	0	31_03		\N
1646			Navy Veterans	1	0	res:/UI/Icon/Mapped/icon30_06.blue		\N
1647			Entrepreneurs	1	0	30_05		\N
1648			Mercs	1	0	30_08		\N
1649			Dissenters	1	0	30_07		\N
1650			Merchandisers	1	0	30_13		\N
1651			Scientists	1	0	30_12		\N
1652			Tube Child	1	0	31_05		\N
1653			Activists	1	0	31_07		\N
1654			Miners	1	0	30_14		\N
1655			Immigrants	1	0	30_09		\N
1656			Artists	1	0	31_06		\N
1657			Diplomats	1	0	31_08		\N
1658			Reborn	1	0	30_11		\N
1659			Tinkerers	1	0	30_10		\N
1660			Traders	1	0	31_02		\N
1661			Rebels	1	0	31_04		\N
1662			Workers	1	0	31_01		\N
1663			Tribal Traditionalists	1	0	30_15		\N
1664			Slave Child	1	0	30_16		\N
1665		Unknown		1	0	05_06		\N
1666		Unknown	General ammunition icon (ChargeSize etc.)	1	0	05_02		\N
1667		Unknown	enclosed Turret	1	0	04_05		\N
1668		Unknown	Capacitor	1	0	01_05		\N
1669	res:/Model/WorldObject/Cloud/DarkCloud.blue	DarkCloud		1	0			\N
1670	res:/Model/WorldObject/Cloud/DarkGreenCloud.blue	DarkGreenCloud		1	0			\N
1671	res:/Model/WorldObject/Cloud/DustCloud.blue	DustCloud		1	0			\N
1672	res:/Model/WorldObject/Cloud/Ionloud.blue	Ionloud		1	0			\N
1673	res:/Model/WorldObject/Cloud/SparkCloud.blue	SparkCloud		1	0			\N
1674	res:/Model/WorldObject/Comet/cometToxic.blue	cometToxic		1	0			\N
1675	res:/Model/WorldObject/Comet/cometfire.blue	cometfire		1	0			\N
1676	res:/Model/WorldObject/Comet/cometgold.blue	cometgold		1	0			\N
1677	res:/Model/WorldObject/Comet/cometdark.blue	cometdark		1	0			\N
1678	res:/Model/WorldObject/Comet/comet.blue	comet		1	0			\N
1679	res:/Model/WorldObject/Capsule2/capsule2.blue	Capsule 2		1	0			\N
1680	res:/Model/Sentry/DamageDampener/DamageDampener.blue	DamageDampener		1	0			\N
1681	res:/Model/Sentry/Dronehive/DroneHive2.blue	DroneHive2		1	0			2024
1682	res:/Model/Sentry/Dronehive/Dronehive1.blue	Dronehive1		1	0			2024
1683	res:/Model/Sentry/MissilePad/MLPad.blue	MLPad		1	0			\N
1684	res:/Model/Sentry/PowerGenerator/PowerGenerator.blue	PowerGenerator		1	0			\N
1685	res:/Model/Sentry/ShieldDepo/ShieldDepo.blue	Shield Depo		1	0			\N
1686	res:/Model/WorldObject/Cloud/DarkGreyCloudS.blue	DarkGreyCloudS		1	0			\N
1687	res:/Model/WorldObject/Cloud/DarkGreyTurbulentCloudS.blue	DarkGreyTurbulentCloudS		1	0			\N
1688	res:/Model/WorldObject/Cloud/ElectricCloudS.blue	ElectricCloudS		1	0			\N
1689	res:/Model/WorldObject/Cloud/FireCloudS.blue	FireCloudS		1	0			\N
1690	res:/Model/WorldObject/Cloud/PlasmaCloudS.blue	PlasmaCloudS		1	0			\N
1691	res:/Model/WorldObject/BatteryColumn/batteryColumn.blue	battery Column		1	0			\N
1692	res:/Model/WorldObject/Monolith/monolith.blue	Monolith		1	0			\N
1693	res:/Model/WorldObject/Coral/coral.blue	Coral		1	0			\N
1694	res:/Model/WorldObject/Debris/debris.blue	debris		1	0			\N
1695	res:/Model/WorldObject/Debris/theRing.blue	theRing		1	0			\N
1696	res:/Model/WorldObject/Debris/debris1.blue	debris1		1	0			\N
1697	res:/Model/WorldObject/Debris/debris2.blue	debris2		1	0			\N
1698	res:/Model/WorldObject/Debris/debris3.blue	debris3		1	0			\N
1699	res:/Model/WorldObject/Debris/debris4.blue	debris4		1	0			\N
1700			Bookmark	1	0	09_01		\N
1701	res:/Model/WorldObject/Cloud/Debrisstorm.blue	Debrisstorm		1	0			\N
1702	res:/Model/WorldObject/Cloud/Meteorstorm.blue	Meteorstorm		1	0			\N
1703	res:/Model/outposts/AO_Refining.blue	AO_Refining		1	0			\N
1704	res:/Model/outposts/AO_repair.blue	AO_repair		1	0			\N
1705	res:/Model/outposts/AO_Tactical.blue	AO_Tactical		1	0			\N
1706	res:/Model/outposts/CO_Refining.blue	CO_Refining		1	0			\N
1707	res:/Model/outposts/CO_Repair.blue	CO_Repair		1	0			\N
1708	res:/Model/outposts/CO_Tactical.blue	CO_Tactical		1	0			\N
1709	res:/Model/outposts/MO_Refining.blue	MO_Refining		1	0			\N
1710	res:/Model/outposts/MO_Repair.blue	MO_Repair		1	0			\N
1711	res:/Model/outposts/MO_Tactical.blue	MO_Tactical		1	0			\N
1712	res:/Model/Station/Gallente/go1/go1.blue	go1		1	0		res:/Sound/Station/Station02.blue	\N
1713	res:/Model/Drydock/Drydock_Gallente.blue	Drydock_Gallente		1	0			\N
1714	res:/Model/Drydock/Drydock_Amarr.blue	Drydock_Amarr		1	0			\N
1715	res:/Model/Drydock/Drydock_Minmatar.blue	Drydock_Minmatar		1	0			\N
1716	res:/Model/Drydock/Drydock_Caldari.blue	Drydock_Caldari		1	0			\N
1717	res:/Model/WorldObject/miningpost/miningpost.blue	miningpost		1	0			\N
1718	res:/Model/Ship/Gallente/gb1/gb1_infested.blue	gb1_infested		1	0			2027
1719	res:/Model/WorldObject/Harvester/harvester01.blue	Harvester		1	0			\N
1720	res:/Model/Missile/Missile_Bladestorm.blue	Missile_Bladestorm		1	0	27_04		\N
1721	res:/Model/Missile/Missile_Firestorm.blue	Missile_Firestorm		1	0	34_01		\N
1722	res:/Model/Missile/Missile_Thunderstorm.blue	Missile_Thunderstorm		1	0	34_02		\N
1723	res:/Model/Missile/Missile_Hellstorm.blue	Missile_Hellstorm		1	0	27_09		\N
1724		Unknown	Research Facility Icon	1	0	33_02		\N
1725	res:/Model/WorldObject/Sail_charger/sail_charger.blue	sail_charger		1	0			\N
1726	res:/Model/WorldObject/Mine/mine.blue	mine		1	0			\N
1727	res:/Model/WorldObject/Ball_and_pillars/ball_and_pillars.blue	ball_and_pillars		1	0			\N
1728	res:/Model/Ship/AmarrNavy/ac1_AmarrNavy.blue	ac1_AmarrNavy		1	0			2026
1729	res:/Model/Ship/AmarrNavy/ac2_AmarrNavy.blue	ac2_AmarrNavy		1	0			2026
1730	res:/Model/Ship/AmarrNavy/ac3_AmarrNavy.blue	ac3_AmarrNavy		1	0			2026
1731	res:/Model/Ship/AmarrNavy/ac4_AmarrNavy.blue	ac4_AmarrNavy		1	0			2026
1732	res:/Model/Ship/AmarrNavy/af1_AmarrNavy.blue	af1_AmarrNavy		1	0			2025
1733	res:/Model/Ship/AmarrNavy/af2_AmarrNavy.blue	af2_AmarrNavy		1	0			2025
1734	res:/Model/Ship/AmarrNavy/af3_AmarrNavy.blue	af3_AmarrNavy		1	0			2025
1735	res:/Model/Ship/AmarrNavy/af4_AmarrNavy.blue	af4_AmarrNavy		1	0			2025
1736	res:/Model/Ship/AmarrNavy/af5_AmarrNavy.blue	af5_AmarrNavy		1	0			2025
1737	res:/Model/Ship/AmarrNavy/af6_AmarrNavy.blue	af6_AmarrNavy		1	0			2025
1738	res:/Model/Ship/Ammatar/ac1_Ammatar.blue	ac1_Ammatar		1	0			2026
1739	res:/Model/Ship/Ammatar/ac2_Ammatar.blue	ac2_Ammatar		1	0			2026
1740	res:/Model/Ship/Ammatar/ac3_Ammatar.blue	ac3_Ammatar		1	0			2026
1741	res:/Model/Ship/Ammatar/ac4_Ammatar.blue	ac4_Ammatar		1	0			2026
1742	res:/Model/Ship/Ammatar/af1_Ammatar.blue	af1_Ammatar		1	0			2025
1743	res:/Model/Ship/Ammatar/af2_Ammatar.blue	af2_Ammatar		1	0			2025
1744	res:/Model/Ship/Ammatar/af3_Ammatar.blue	af3_Ammatar		1	0			2025
1745	res:/Model/Ship/Ammatar/af4_Ammatar.blue	af4_Ammatar		1	0			2025
1746	res:/Model/Ship/Ammatar/af5_Ammatar.blue	af5_Ammatar		1	0			2025
1747	res:/Model/Ship/Ammatar/af6_Ammatar.blue	af6_Ammatar		1	0			2025
1748	res:/Model/Ship/Ardishapur/ac1_Sarum.blue	ac1_Sarum		1	0			2026
1749	res:/Model/Ship/Ardishapur/ac2_Sarum.blue	ac2_Sarum		1	0			2026
1750	res:/Model/Ship/Ardishapur/ac3_Sarum.blue	ac3_Sarum		1	0			2026
1751	res:/Model/Ship/Ardishapur/ac4_Sarum.blue	ac4_Sarum		1	0			2026
1752	res:/Model/Ship/Ardishapur/af1_Sarum.blue	af1_Sarum		1	0			2025
1753	res:/Model/Ship/Ardishapur/af2_Sarum.blue	af2_Sarum		1	0			2025
1754	res:/Model/Ship/Ardishapur/af3_Sarum.blue	af3_Sarum		1	0			2025
1755	res:/Model/Ship/Ardishapur/af4_Sarum.blue	af4_Sarum		1	0			2025
1756	res:/Model/Ship/Ardishapur/af5_Sarum.blue	af5_Sarum		1	0			2025
1757	res:/Model/Ship/Ardishapur/af6_Sarum.blue	af6_Sarum		1	0			2025
1758	res:/Model/Ship/Bloodraider/ac1_Bloodraider.blue	ac1_Bloodraider		1	0			2026
1759	res:/Model/Ship/Bloodraider/ac2_Bloodraider.blue	ac2_Bloodraider		1	0			2026
1760	res:/Model/Ship/Bloodraider/ac3_Bloodraider.blue	ac3_Bloodraider		1	0			2026
1761	res:/Model/Ship/Bloodraider/ac4_Bloodraider.blue	ac4_Bloodraider		1	0			2026
1762	res:/Model/Ship/Bloodraider/af1_Bloodraider.blue	af1_Bloodraider		1	0			2025
1763	res:/Model/Ship/Bloodraider/af2_Bloodraider.blue	af2_Bloodraider		1	0			2025
1764	res:/Model/Ship/Bloodraider/af3_Bloodraider.blue	af3_Bloodraider		1	0			2025
1765	res:/Model/Ship/Bloodraider/af4_Bloodraider.blue	af4_Bloodraider		1	0			2025
1766	res:/Model/Ship/Bloodraider/af5_Bloodraider.blue	af5_Bloodraider		1	0			2025
1767	res:/Model/Ship/Bloodraider/af6_Bloodraider.blue	af6_Bloodraider		1	0			2025
1768	res:/Model/Ship/Bloods/gf1_Bloods.blue	gf1_Bloods		1	0			2025
1769	res:/Model/Ship/Bloods/gf2_Bloods.blue	gf2_Bloods		1	0			2025
1770	res:/Model/Ship/Bloods/gf3_Bloods.blue	gf3_Bloods		1	0			2025
1771	res:/Model/Ship/Bloods/gf4_Bloods.blue	gf4_Bloods		1	0			2025
1772	res:/Model/Ship/Bloods/gf5_Bloods.blue	gf5_Bloods		1	0			2025
1773	res:/Model/Ship/Bloods/gf6_Bloods.blue	gf6_Bloods		1	0			2025
1774	res:/Model/Ship/Bloods/gf7_Bloods.blue	gf7_Bloods		1	0			2025
1775	res:/Model/Ship/Brutor/Mc1_mnavy.blue	Mc1_mnavy		1	0			2026
1776	res:/Model/Ship/Brutor/Mc2_mnavy.blue	Mc2_mnavy		1	0			2026
1777	res:/Model/Ship/Brutor/Mc3_mnavy.blue	Mc3_mnavy		1	0			2026
1778	res:/Model/Ship/Brutor/Mc4_mnavy.blue	Mc4_mnavy		1	0			2026
1779	res:/Model/Ship/Brutor/Mf1_mnavy.blue	Mf1_mnavy		1	0			2025
1780	res:/Model/Ship/Brutor/Mf2_mnavy.blue	Mf2_mnavy		1	0			2025
1781	res:/Model/Ship/Brutor/Mf3_mnavy.blue	Mf3_mnavy		1	0			2025
1782	res:/Model/Ship/Brutor/Mf4_mnavy.blue	Mf4_mnavy		1	0			2025
1783	res:/Model/Ship/Brutor/Mf6_mnavy.blue	Mf6_mnavy		1	0			2025
1784	res:/Model/Ship/CaldariNavy/cc1_Cnavy.blue	cc1_Cnavy		1	0			2026
1785	res:/Model/Ship/CaldariNavy/cc2_Cnavy.blue	cc2_Cnavy		1	0			2026
1786	res:/Model/Ship/CaldariNavy/cc3_Cnavy.blue	cc3_Cnavy		1	0			2026
1787	res:/Model/Ship/CaldariNavy/cc4_Cnavy.blue	cc4_Cnavy		1	0			2026
1788	res:/Model/Ship/CaldariNavy/cf2_Cnavy.blue	cf2_Cnavy		1	0			2025
1789	res:/Model/Ship/CaldariNavy/cf4_Cnavy.blue	cf4_Cnavy		1	0			2025
1790	res:/Model/Ship/CaldariNavy/cf5_Cnavy.blue	cf5_Cnavy		1	0			2025
1791	res:/Model/Ship/CaldariNavy/cf6_Cnavy.blue	cf6_Cnavy		1	0			2025
1792	res:/Model/Ship/CaldariNavy/cf7_Cnavy.blue	cf7_Cnavy		1	0			2025
1793	res:/Model/Ship/CaldariNavy/cf9_Cnavy.blue	cf9_Cnavy		1	0			2025
1794	res:/Model/Ship/Crips/gf1_Crips.blue	gf1_Crips		1	0			2025
1795	res:/Model/Ship/Crips/gf2_Crips.blue	gf2_Crips		1	0			2025
1796	res:/Model/Ship/Crips/gf3_Crips.blue	gf3_Crips		1	0			2025
1797	res:/Model/Ship/Crips/gf4_Crips.blue	gf4_Crips		1	0			2025
1798	res:/Model/Ship/Crips/gf5_Crips.blue	gf5_Crips		1	0			2025
1799	res:/Model/Ship/Crips/gf6_Crips.blue	gf6_Crips		1	0			2025
1800	res:/Model/Ship/Crips/gf7_Crips.blue	gf7_Crips		1	0			2025
1801	res:/Model/Ship/GNavy/gc1_GallenteNavy.blue	gc1_GallenteNavy		1	0			2026
1802	res:/Model/Ship/GNavy/gc2_GallenteNavy.blue	gc2_GallenteNavy		1	0			2026
1803	res:/Model/Ship/GNavy/gc3_GallenteNavy.blue	gc3_GallenteNavy		1	0			2026
1804	res:/Model/Ship/GNavy/gc4_GallenteNavy.blue	gc4_GallenteNavy		1	0			2026
1805	res:/Model/Ship/GNavy/gf1_GallenteNavy.blue	gf1_GallenteNavy		1	0			2025
1806	res:/Model/Ship/GNavy/gf2_GallenteNavy.blue	gf2_GallenteNavy		1	0			2025
1807	res:/Model/Ship/GNavy/gf3_GallenteNavy.blue	gf3_GallenteNavy		1	0			2025
1808	res:/Model/Ship/GNavy/gf4_GallenteNavy.blue	gf4_GallenteNavy		1	0			2025
1809	res:/Model/Ship/GNavy/gf5_GallenteNavy.blue	gf5_GallenteNavy		1	0			2025
1810	res:/Model/Ship/GNavy/gf6_GallenteNavy.blue	gf6_GallenteNavy		1	0			2025
1811	res:/Model/Ship/GNavy/gf7_GallenteNavy.blue	gf7_GallenteNavy		1	0			2025
1812	res:/Model/Ship/Guardians/gc1_Crips.blue	gc1_Crips		1	0			2026
1813	res:/Model/Ship/Guardians/gc2_Crips.blue	gc2_Crips		1	0			2026
1814	res:/Model/Ship/Guardians/gc3_Crips.blue	gc3_Crips		1	0			2026
1815	res:/Model/Ship/Guardians/gc4_Crips.blue	gc4_Crips		1	0			2026
1816	res:/Model/Ship/Guardians/gf1_Crips.blue	gf1_Crips		1	0			2025
1817	res:/Model/Ship/Guardians/gf2_Crips.blue	gf2_Crips		1	0			2025
1818	res:/Model/Ship/Guardians/gf3_Crips.blue	gf3_Crips		1	0			2025
1819	res:/Model/Ship/Guardians/gf4_Crips.blue	gf4_Crips		1	0			2025
1820	res:/Model/Ship/Guardians/gf5_Crips.blue	gf5_Crips		1	0			2025
1821	res:/Model/Ship/Guardians/gf6_Crips.blue	gf6_Crips		1	0			2025
1822	res:/Model/Ship/Guardians/gf7_Crips.blue	gf7_Crips		1	0			2025
1823	res:/Model/Ship/Guristas/cc1_guristas.blue	cc1_guristas		1	0			2026
1824	res:/Model/Ship/Guristas/cc2_guristas.blue	cc2_guristas		1	0			2026
1825	res:/Model/Ship/Guristas/cc3_guristas.blue	cc3_guristas		1	0			2026
1826	res:/Model/Ship/Guristas/cc4_guristas.blue	cc4_guristas		1	0			2026
1827	res:/Model/Ship/Guristas/cf2_guristas.blue	cf2_guristas		1	0			2025
1828	res:/Model/Ship/Guristas/cf4_guristas.blue	cf4_guristas		1	0			2025
1829	res:/Model/Ship/Guristas/cf5_guristas.blue	cf5_guristas		1	0			2025
1830	res:/Model/Ship/Guristas/cf6_guristas.blue	cf6_guristas		1	0			2025
1831	res:/Model/Ship/Guristas/cf7_guristas.blue	cf7_guristas		1	0			2025
1832	res:/Model/Ship/Guristas/cf9_guristas.blue	cf9_guristas		1	0			2025
1833	res:/Model/Ship/IntakiSyndicate/gc1_IntakiSyndicate.blue	gc1_IntakiSyndicate		1	0			2026
1834	res:/Model/Ship/IntakiSyndicate/gc2_IntakiSyndicate.blue	gc2_IntakiSyndicate		1	0			2026
1835	res:/Model/Ship/IntakiSyndicate/gc3_IntakiSyndicate.blue	gc3_IntakiSyndicate		1	0			2026
1836	res:/Model/Ship/IntakiSyndicate/gc4_IntakiSyndicate.blue	gc4_IntakiSyndicate		1	0			2026
1837	res:/Model/Ship/IntakiSyndicate/gf1_IntakiSyndicate.blue	gf1_IntakiSyndicate		1	0			2025
1838	res:/Model/Ship/IntakiSyndicate/gf2_IntakiSyndicate.blue	gf2_IntakiSyndicate		1	0			2025
1839	res:/Model/Ship/IntakiSyndicate/gf3_IntakiSyndicate.blue	gf3_IntakiSyndicate		1	0			2025
1840	res:/Model/Ship/IntakiSyndicate/gf4_IntakiSyndicate.blue	gf4_IntakiSyndicate		1	0			2025
1841	res:/Model/Ship/IntakiSyndicate/gf5_IntakiSyndicate.blue	gf5_IntakiSyndicate		1	0			2025
1842	res:/Model/Ship/IntakiSyndicate/gf6_IntakiSyndicate.blue	gf6_IntakiSyndicate		1	0			2025
1843	res:/Model/Ship/IntakiSyndicate/gf7_IntakiSyndicate.blue	gf7_IntakiSyndicate		1	0			2025
1844	res:/Model/Ship/Kaalakiota/cc1_Mordus.blue	cc1_Mordus		1	0			2026
1845	res:/Model/Ship/Kaalakiota/cc2_Mordus.blue	cc2_Mordus		1	0			2026
1846	res:/Model/Ship/Kaalakiota/cc3_Mordus.blue	cc3_Mordus		1	0			2026
1847	res:/Model/Ship/Kaalakiota/cc4_Mordus.blue	cc4_Mordus		1	0			2026
1848	res:/Model/Ship/Kaalakiota/cf2_Mordus.blue	cf2_Mordus		1	0			2025
1849	res:/Model/Ship/Kaalakiota/cf4_Mordus.blue	cf4_Mordus		1	0			2025
1850	res:/Model/Ship/Kaalakiota/cf5_Mordus.blue	cf5_Mordus		1	0			2025
1851	res:/Model/Ship/Kaalakiota/cf6_Mordus.blue	cf6_Mordus		1	0			2025
1852	res:/Model/Ship/Kaalakiota/cf7_Mordus.blue	cf7_Mordus		1	0			2025
1853	res:/Model/Ship/Kaalakiota/cf9_Mordus.blue	cf9_Mordus		1	0			2025
1854	res:/Model/Ship/Khanid/ac1_Khanid.blue	ac1_Khanid		1	0			2026
1855	res:/Model/Ship/Khanid/ac2_Khanid.blue	ac2_Khanid		1	0			2026
1856	res:/Model/Ship/Khanid/ac3_Khanid.blue	ac3_Khanid		1	0			2026
1857	res:/Model/Ship/Khanid/ac4_Khanid.blue	ac4_Khanid		1	0			2026
1858	res:/Model/Ship/Khanid/af1_Khanid.blue	af1_Khanid		1	0			2025
1859	res:/Model/Ship/Khanid/af2_Khanid.blue	af2_Khanid		1	0			2025
1860	res:/Model/Ship/Khanid/af3_Khanid.blue	af3_Khanid		1	0			2025
1861	res:/Model/Ship/Khanid/af4_Khanid.blue	af4_Khanid		1	0			2025
1862	res:/Model/Ship/Khanid/af5_Khanid.blue	af5_Khanid		1	0			2025
1863	res:/Model/Ship/Khanid/af6_Khanid.blue	af6_Khanid		1	0			2025
1864	res:/Model/Ship/Kor-Azor/ac1_Sarum.blue	ac1_Sarum		1	0			2026
1865	res:/Model/Ship/Kor-Azor/ac2_Sarum.blue	ac2_Sarum		1	0			2026
1866	res:/Model/Ship/Kor-Azor/ac3_Sarum.blue	ac3_Sarum		1	0			2026
1867	res:/Model/Ship/Kor-Azor/ac4_Sarum.blue	ac4_Sarum		1	0			2026
1868	res:/Model/Ship/Kor-Azor/af1_Sarum.blue	af1_Sarum		1	0			2025
1869	res:/Model/Ship/Kor-Azor/af2_Sarum.blue	af2_Sarum		1	0			2025
1870	res:/Model/Ship/Kor-Azor/af3_Sarum.blue	af3_Sarum		1	0			2025
1871	res:/Model/Ship/Kor-Azor/af4_Sarum.blue	af4_Sarum		1	0			2025
1872	res:/Model/Ship/Kor-Azor/af5_Sarum.blue	af5_Sarum		1	0			2025
1873	res:/Model/Ship/Kor-Azor/af6_Sarum.blue	af6_Sarum		1	0			2025
1874	res:/Model/Ship/LaiDai/cc1_Mordus.blue	cc1_Mordus		1	0			2026
1875	res:/Model/Ship/LaiDai/cc2_Mordus.blue	cc2_Mordus		1	0			2026
1876	res:/Model/Ship/LaiDai/cc3_Mordus.blue	cc3_Mordus		1	0			2026
1877	res:/Model/Ship/LaiDai/cc4_Mordus.blue	cc4_Mordus		1	0			2026
1878	res:/Model/Ship/LaiDai/cf2_Mordus.blue	cf2_Mordus		1	0			2025
1879	res:/Model/Ship/Mordus/cf4_Mordus.blue	cf4_Mordus		1	0			\N
1880	res:/Model/Ship/LaiDai/cf5_Mordus.blue	cf5_Mordus		1	0			2025
1881	res:/Model/Ship/LaiDai/cf6_Mordus.blue	cf6_Mordus		1	0			2025
1882	res:/Model/Ship/LaiDai/cf7_Mordus.blue	cf7_Mordus		1	0			2025
1883	res:/Model/Ship/LaiDai/cf9_Mordus.blue	cf9_Mordus		1	0			2025
1884	res:/Model/Ship/MNavy/Mc1_mnavy.blue	Mc1_mnavy		1	0			2026
1885	res:/Model/Ship/MNavy/Mc2_mnavy.blue	Mc2_mnavy		1	0			2026
1886	res:/Model/Ship/MNavy/Mc3_mnavy.blue	Mc3_mnavy		1	0			2026
1887	res:/Model/Ship/MNavy/Mc4_mnavy.blue	Mc4_mnavy		1	0			2026
1888	res:/Model/Ship/MNavy/Mf1_mnavy.blue	Mf1_mnavy		1	0			2025
1889	res:/Model/Ship/MNavy/Mf2_mnavy.blue	Mf2_mnavy		1	0			2025
1890	res:/Model/Ship/MNavy/Mf3_mnavy.blue	Mf3_mnavy		1	0			2025
1891	res:/Model/Ship/MNavy/Mf4_mnavy.blue	Mf4_mnavy		1	0			2025
1892	res:/Model/Ship/MNavy/Mf6_mnavy.blue	Mf6_mnavy		1	0			2025
1893	res:/Model/Ship/Mordus/cc1_Mordus.blue	cc1_Mordus		1	0			2026
1894	res:/Model/Ship/Mordus/cc2_Mordus.blue	cc2_Mordus		1	0			2026
1895	res:/Model/Ship/Mordus/cc3_Mordus.blue	cc3_Mordus		1	0			2026
1896	res:/Model/Ship/Mordus/cc4_Mordus.blue	cc4_Mordus		1	0			2026
1897	res:/Model/Ship/Mordus/cf2_Mordus.blue	cf2_Mordus		1	0			2025
1898	res:/Model/Ship/Mordus/cf4_Mordus.blue	cf4_Mordus		1	0			2025
1899	res:/Model/Ship/Mordus/cf5_Mordus.blue	cf5_Mordus		1	0			2025
1900	res:/Model/Ship/Mordus/cf6_Mordus.blue	cf6_Mordus		1	0			2025
1901	res:/Model/Ship/Mordus/cf7_Mordus.blue	cf7_Mordus		1	0			2025
1902	res:/Model/Ship/Mordus/cf9_Mordus.blue	cf9_Mordus		1	0			2025
1903	res:/Model/Ship/Quafe/gc1_Crips.blue	gc1_Crips		1	0			2026
1904	res:/Model/Ship/Quafe/gc2_Crips.blue	gc2_Crips		1	0			2026
1905	res:/Model/Ship/Quafe/gc3_Crips.blue	gc3_Crips		1	0			2026
1906	res:/Model/Ship/Quafe/gc4_Crips.blue	gc4_Crips		1	0			2026
1907	res:/Model/Ship/Quafe/gf1_Crips.blue	gf1_Crips		1	0			2025
1908	res:/Model/Ship/Quafe/gf2_Crips.blue	gf2_Crips		1	0			2025
1909	res:/Model/Ship/Quafe/gf3_Crips.blue	gf3_Crips		1	0			2025
1910	res:/Model/Ship/Quafe/gf4_Crips.blue	gf4_Crips		1	0			2025
1911	res:/Model/Ship/Quafe/gf5_Crips.blue	gf5_Crips		1	0			2025
1912	res:/Model/Ship/Quafe/gf6_Crips.blue	gf6_Crips		1	0			2025
1913	res:/Model/Ship/Quafe/gf7_Crips.blue	gf7_Crips		1	0			2025
1914	res:/Model/Ship/Sarum/ac1_Sarum.blue	ac1_Sarum		1	0			2026
1915	res:/Model/Ship/Sarum/ac2_Sarum.blue	ac2_Sarum		1	0			2026
1916	res:/Model/Ship/Sarum/ac3_Sarum.blue	ac3_Sarum		1	0			2026
1917	res:/Model/Ship/Sarum/ac4_Sarum.blue	ac4_Sarum		1	0			2026
1918	res:/Model/Ship/Sarum/af1_Sarum.blue	af1_Sarum		1	0			2025
1919	res:/Model/Ship/Sarum/af2_Sarum.blue	af2_Sarum		1	0			2025
1920	res:/Model/Ship/Sarum/af3_Sarum.blue	af3_Sarum		1	0			2025
1921	res:/Model/Ship/Sarum/af4_Sarum.blue	af4_Sarum		1	0			2025
1922	res:/Model/Ship/Sarum/af5_Sarum.blue	af5_Sarum		1	0			2025
1923	res:/Model/Ship/Sarum/af6_Sarum.blue	af6_Sarum		1	0			2025
1924	res:/Model/Ship/Sebiestor/Mc1_mnavy.blue	Mc1_mnavy		1	0			2026
1925	res:/Model/Ship/Sebiestor/Mc2_mnavy.blue	Mc2_mnavy		1	0			2026
1926	res:/Model/Ship/Sebiestor/Mc3_mnavy.blue	Mc3_mnavy		1	0			2026
1927	res:/Model/Ship/Sebiestor/Mc4_mnavy.blue	Mc4_mnavy		1	0			2026
1928	res:/Model/Ship/Sebiestor/Mf1_mnavy.blue	Mf1_mnavy		1	0			2025
1929	res:/Model/Ship/Sebiestor/Mf2_mnavy.blue	Mf2_mnavy		1	0			2025
1930	res:/Model/Ship/Sebiestor/Mf3_mnavy.blue	Mf3_mnavy		1	0			2025
1931	res:/Model/Ship/Sebiestor/Mf4_mnavy.blue	Mf4_mnavy		1	0			2025
1932	res:/Model/Ship/Sebiestor/Mf6_mnavy.blue	Mf6_mnavy		1	0			2025
1933	res:/Model/Ship/Tash-Murkon/ac1_Sarum.blue	ac1_Sarum		1	0			2026
1934	res:/Model/Ship/Tash-Murkon/ac2_Sarum.blue	ac2_Sarum		1	0			2026
1935	res:/Model/Ship/Tash-Murkon/ac3_Sarum.blue	ac3_Sarum		1	0			2026
1936	res:/Model/Ship/Tash-Murkon/ac4_Sarum.blue	ac4_Sarum		1	0			2026
1937	res:/Model/Ship/Tash-Murkon/af1_Sarum.blue	af1_Sarum		1	0			2025
1938	res:/Model/Ship/Tash-Murkon/af2_Sarum.blue	af2_Sarum		1	0			2025
1939	res:/Model/Ship/Tash-Murkon/af3_Sarum.blue	af3_Sarum		1	0			2025
1940	res:/Model/Ship/Tash-Murkon/af4_Sarum.blue	af4_Sarum		1	0			2025
1941	res:/Model/Ship/Tash-Murkon/af5_Sarum.blue	af5_Sarum		1	0			2025
1942	res:/Model/Ship/Tash-Murkon/af6_Sarum.blue	af6_Sarum		1	0			2025
1943	res:/Model/Ship/Thukker/Mc1_mnavy.blue	Mc1_mnavy		1	0			2026
1944	res:/Model/Ship/Thukker/Mc2_mnavy.blue	Mc2_mnavy		1	0			2026
1945	res:/Model/Ship/Thukker/Mc3_mnavy.blue	Mc3_mnavy		1	0			2026
1946	res:/Model/Ship/Thukker/Mc4_mnavy.blue	Mc4_mnavy		1	0			2026
1947	res:/Model/Ship/Thukker/Mf1_mnavy.blue	Mf1_mnavy		1	0			2025
1948	res:/Model/Ship/Thukker/Mf2_mnavy.blue	Mf2_mnavy		1	0			2025
1949	res:/Model/Ship/Thukker/Mf3_mnavy.blue	Mf3_mnavy		1	0			2025
1950	res:/Model/Ship/Thukker/Mf4_mnavy.blue	Mf4_mnavy		1	0			2025
1951	res:/Model/Ship/Thukker/Mf6_mnavy.blue	Mf6_mnavy		1	0			2025
1952	res:/Model/Ship/Wiyrkomi/cc1_Mordus.blue	cc1_Mordus		1	0			2026
1953	res:/Model/Ship/Wiyrkomi/cc2_Mordus.blue	cc2_Mordus		1	0			2026
1954	res:/Model/Ship/Wiyrkomi/cc3_Mordus.blue	cc3_Mordus		1	0			2026
1955	res:/Model/Ship/Wiyrkomi/cc4_Mordus.blue	cc4_Mordus		1	0			2026
1956	res:/Model/Ship/Wiyrkomi/cf2_Mordus.blue	cf2_Mordus		1	0			2025
1957	res:/Model/Ship/Wiyrkomi/cf4_Mordus.blue	cf4_Mordus		1	0			2025
1958	res:/Model/Ship/Wiyrkomi/cf5_Mordus.blue	cf5_Mordus		1	0			2025
1959	res:/Model/Ship/Wiyrkomi/cf6_Mordus.blue	cf6_Mordus		1	0			2025
1960	res:/Model/Ship/Wiyrkomi/cf7_Mordus.blue	cf7_Mordus		1	0			2025
1961	res:/Model/Ship/Wiyrkomi/cf9_Mordus.blue	cf9_Mordus		1	0			2025
1962	res:/Model/Ship/Amarr/AF4/af4_Khanid.blue	af4_Khanid		1	0			2025
1963	res:/Model/Ship/Brutor/Mf5_mnavy.blue	Mf5_mnavy		1	0			2025
1964	res:/Model/Ship/Thukker/Mf5_mnavy.blue	Mf5_mnavy		1	0			2025
1965	res:/Model/Ship/MNavy/Mf5_mnavy.blue	Mf5_mnavy		1	0			2025
1966	res:/Model/Ship/Sebiestor/Mf5_mnavy.blue	Mf5_mnavy		1	0			2025
1967	res:/Model/Ship/Mordus/cf1_Mordus.blue	cf1_Mordus		1	0			2025
1968	res:/Model/Ship/Guristas/cf1_guristas.blue	cf1_guristas		1	0			2025
1969	res:/Model/Ship/Wiyrkomi/cf1_Mordus.blue	cf1_Mordus		1	0			2025
1970	res:/Model/Ship/LaiDai/cf1_Mordus.blue	cf1_Mordus		1	0			2025
1971	res:/Model/Ship/CaldariNavy/cf1_Cnavy.blue	cf1_Cnavy		1	0			2025
1972	res:/Model/Ship/Kaalakiota/cf1_Mordus.blue	cf1_Mordus		1	0			2025
1973	res:/Model/Ship/Brutor/Mf8_mnavy.blue	Mf8_mnavy		1	0			2025
1974	res:/Model/Ship/Sebiestor/Mf8_mnavy.blue	Mf8_mnavy		1	0			2025
1975	res:/Model/Ship/Thukker/Mf8_mnavy.blue	Mf8_mnavy		1	0			2025
1976	res:/Model/Ship/MNavy/Mf8_mnavy.blue	Mf8_mnavy		1	0			2025
1977	res:/Model/WorldObject/Cloud/gaseousSuperlight.blue	gaseousSuperlight		1	0			\N
1978	res:/Model/WorldObject/Cloud/longWispyOrange.blue	longWispyOrange		1	0			\N
1979	res:/Model/WorldObject/Cloud/yellowOval.blue	yellowOval		1	0			\N
1980	res:/Model/WorldObject/Cloud/dustyBrownStreak.blue	dustyBrownStreak		1	0			\N
1981	res:/Model/WorldObject/Cloud/gaseouscloudLight.blue	gaseouscloudLight		1	0			\N
1982	res:/Model/WorldObject/Cloud/wispyAqua.blue	wispyAqua		1	0			\N
1983	res:/Model/WorldObject/Cloud/cloud1.blue	cloud1		1	0			\N
1984	res:/Model/WorldObject/Cloud/greenDusty.blue	greenDusty		1	0			\N
1985	res:/Model/WorldObject/Cloud/cloud2.blue	cloud2		1	0			\N
1986	res:/Model/WorldObject/Cloud/aquaPuff.blue	aquaPuff		1	0			\N
1987	res:/Model/WorldObject/Cloud/gaseuoscloud.blue	gaseuoscloud		1	0			\N
1988	res:/Model/WorldObject/Cloud/dustybrown.blue	dustybrown		1	0			\N
1989	res:/Model/WorldObject/Cloud/greenGasesCloud.blue	greenGasesCloud		1	0			\N
1990	res:/Model/WorldObject/Asteroid_station1/asteroid_station1.blue	asteroid_station1		1	0			\N
1991	res:/Model/WorldObject/Asteroid_station2/asteroid_station2.blue	asteroid_station2		1	0			\N
1992	res:/Model/WorldObject/Asteroid_station3/asteroid_station3.blue	asteroid_station3		1	0			\N
1993	res:/Model/WorldObject/Asteroid_station4/asteroid_station4.blue	asteroid_station4		1	0			\N
1994	res:/Model/WorldObject/Asteroid_station5/asteroid_station5.blue	asteroid_station5		1	0			\N
1997	res:/Model/WorldObject/Asteroid_station6/asteroid_station6.blue	asteroid_station6		1	0			\N
1998	res:/Model/WorldObject/Asteroid_station7/asteroid_station7.blue	asteroid_station7		1	0			\N
1999	res:/Model/WorldObject/Asteroid_station8/asteroid_station8.blue	asteroid_station8		1	0			\N
2000	res:/Model/WorldObject/Asteroid_station9/asteroid_station9.blue	asteroid_station9		1	0			\N
2001	res:/Model/WorldObject/rocky/rocky_curved.blue	rocky_curved		1	0			\N
2002	res:/Model/WorldObject/rocky/rocky_small1.blue	rocky_small1		1	0			\N
2003	res:/Model/WorldObject/rocky/rocky_small2.blue	rocky_small2		1	0			\N
2004	res:/Model/WorldObject/rocky/rocky_small3.blue	rocky_small3		1	0			\N
2005	res:/Model/WorldObject/rocky/rocky_small4.blue	rocky_small4		1	0			\N
2006	res:/Model/WorldObject/rocky/rocky_straight.blue	rocky_straight		1	0			\N
2007	res:/Model/WorldObject/tank/Tank.blue	Tank		1	0			\N
2008	res:/Model/Station/Jove/js2/js2.blue	Jove Station II		1	0		res:/Sound/Station/Station03.blue	\N
2009	res:/Model/WorldObject/cloud/planetary/WorkinProgress.blue	WorkinProgress		1	0			\N
2010	res:/Model/WorldObject/cloud/planetary/blueGasSubtle.blue	blueGasSubtle		1	0			\N
2011	res:/Model/WorldObject/cloud/planetary/blueishhalpsheregas.blue	blueishhalpsheregas		1	0			\N
2012	res:/Model/WorldObject/cloud/planetary/circlywhite.blue	circlywhite		1	0			\N
2013	res:/Model/WorldObject/cloud/planetary/circularradiantDust.blue	circularradiantDust		1	0			\N
2014	res:/Model/WorldObject/cloud/planetary/clawyHalfsphere.blue	clawyHalfsphere		1	0			\N
2015	res:/Model/WorldObject/cloud/planetary/cloudyWhiteCircle.blue	cloudyWhiteCircle		1	0			\N
2016	res:/Model/WorldObject/cloud/planetary/dustyGreyBrownCircly.blue	dustyGreyBrownCircly		1	0			\N
2017	res:/Model/WorldObject/cloud/planetary/dustyHalfsphere.blue	dustyHalfsphere		1	0			\N
2018	res:/Model/WorldObject/cloud/planetary/greyCloudySphere.blue	greyCloudySphere		1	0			\N
2019	res:/Model/WorldObject/cloud/planetary/greyengulfingRotated.blue	greyengulfingRotated		1	0			\N
2020	res:/Model/WorldObject/cloud/planetary/puffyclaw.blue	puffyclaw		1	0			\N
2021	res:/Model/WorldObject/cloud/planetary/whiteEngulfing.blue	whiteEngulfing		1	0			\N
2022	res:/Model/WorldObject/cloud/planetary/whiteEngulfing2.blue	whiteEngulfing2		1	0			\N
2023	res:/Model/Effect/Explosion/entityExplode_extralarge.blue	entityExplode_extralarge		1	0			\N
2024	res:/Model/Effect/Explosion/entityExplode_tiny.blue	entityExplode_tiny		1	0			\N
2025	res:/Model/Effect/Explosion/entityExplode_small.blue	entityExplode_small		1	0			\N
2026	res:/Model/Effect/Explosion/entityExplode_medium.blue	entityExplode_medium		1	0			\N
2027	res:/Model/Effect/Explosion/entityExplode_large.blue	entityExplode_large		1	0			\N
2028		Unknown	Caldari sensors	1	0	22_25		\N
2029		Unknown	Gallente sensors	1	0	22_26		\N
2030		Unknown	Minmatar sensors	1	0	22_27		\N
2031		Unknown	Amarr sensors	1	0	22_28		\N
2032	res:/Model/Effect2/Smartbomb/Smartbomb_EMP.blue	Smartbomb_EMP		1	0	03_04		\N
2033	res:/Model/Effect2/Smartbomb/Smartbomb_Graviton.blue	Smartbomb_Graviton		1	0	03_04		\N
2034	res:/Model/Effect2/Smartbomb/Smartbomb_Photon.blue	Smartbomb_Photon		1	0	03_04		\N
2035	res:/Model/Effect2/Smartbomb/Smartbomb_plasma.blue	Smartbomb_plasma		1	0	03_04		\N
2036		Unknown	Insurance station service	1	0	33_04		\N
2037		Unknown	Jovian trinary data	1	0	34_05		\N
2038		Unknown	Data chip	1	0	34_06		\N
2039		Unknown	Security box	1	0	34_07		\N
2040		Unknown	Dogtags	1	0	34_08		\N
2041		Unknown	Religious artifact	1	0	34_09		\N
2042		Unknown	Battery cartridge	1	0	34_10		\N
2043	res:/Model/Ship/Gallente/gsh1/gsh1.blue	Gallente Shuttle		1	0			\N
2044	res:/Model/Ship/Amarr/ashuttle/Ash1.blue	Amarr Shuttle		1	0			\N
2045	res:/Model/Ship/Minmatar/M_shuttle/MSH1.blue	Minmatar Shuttle		1	0			\N
2046	res:/Model/WorldObject/Billboard/billboard.blue cle311	Billboard - Caldari		1	0			\N
2047	res:/Model/WorldObject/cathedral/cathedral01.blue	cathedral01		1	0			\N
2048	res:/Model/WorldObject/cathedral/cathedral02.blue	cathedral02		1	0			\N
2049	res:/Model/WorldObject/cathedral/cathedral03.blue	cathedral03		1	0			\N
2050	res:/Model/WorldObject/cathedral/cathedral04.blue	cathedral04		1	0			\N
2051	res:/Model/WorldObject/cathedral/cathedral05.blue	cathedral05		1	0			\N
2052		Unknown	Ship upgrade	1	0	34_11		\N
2053		Unknown	Perception implant (ocular filter)	1	0	34_12		\N
2054		Unknown	Willpower implant (neural boost)	1	0	34_15		\N
2055		Unknown	Charisma booster	1	0	31_09		\N
2056		Unknown	Willpower booster	1	0	31_10		\N
2057		Unknown	Intelligence booster	1	0	31_11		\N
2058		Unknown	Memory booster	1	0	31_12		\N
2059		Unknown	Perception booster	1	0	31_13		\N
2060		Unknown	Charisma implant (social adaptation chip)	1	0	31_14		\N
2061		Unknown	Memory implant (Memory augmentation)	1	0	31_15		\N
2062		Unknown	Intelligence implant (Cybernetic subprocessor)	1	0	31_16		\N
2063	res:/Model/WorldObject/BarrenAsteroid/barrenasteroid.blue	barrenasteroid		1	0			\N
2064	res:/Model/WorldObject/TurnipRock/turnip.blue	turnip		1	0			\N
2065		Steel plates		1	0	01_10		\N
2066		Energized Plating		1	0	34_16		\N
2067	res:/Scene/Hangar/Concord.blue	Concrord Hangar		1	0			\N
2068	res:/Model/WorldObject/ParticleResearchRing/ring.blue	ring		1	0			\N
2069	res:/Model/WorldObject/ParticleResearchRing/researchring.blue	researchring		1	0		res:/Sound/Station/Station09.blue	\N
2070	res:/Texture/Landmark/A33colonialruins.jpg	A33colonialruin		1	0			\N
2071	res:/Texture/Landmark/amarr.jpg	amar		1	0			\N
2072	res:/Texture/Landmark/caldari.jpg	caldar		1	0			\N
2073	res:/Texture/Landmark/cityofgod.jpg	cityofgo		1	0			\N
2074	res:/Texture/Landmark/Curse.jpg	Curs		1	0			\N
2075	res:/Texture/Landmark/emperor.jpg	empero		1	0			\N
2076	res:/Texture/Landmark/galente.jpg	galent		1	0			\N
2077	res:/Texture/Landmark/ginnungagap.jpg	ginnungaga		1	0			\N
2078	res:/Texture/Landmark/golgothanfields.jpg	golgothanfield		1	0			\N
2079	res:/Texture/Landmark/jove.jpg	jov		1	0			\N
2080	res:/Texture/Landmark/khanidkingdom.jpg	khanidkingdo		1	0			\N
2081	res:/Texture/Landmark/minmatar.jpg	minmata		1	0			\N
2082	res:/Texture/Landmark/myridianstrip.jpg	myridianstri		1	0			\N
2083	res:/Texture/Landmark/outerring.jpg	outerrin		1	0			\N
2084	res:/Texture/Landmark/pointofnoreturn.jpg	pointofnoretur		1	0			\N
2085	res:/Texture/Landmark/serpentscoil.jpg	serpentscoi		1	0			\N
2086	res:/Texture/Landmark/stain.jpg	stai		1	0			\N
2087	res:/Texture/Landmark/thesyndicate.jpg	thesyndicat		1	0			\N
2088	res:/Texture/Landmark/traumark.jpg	traumar		1	0			\N
2089	res:/Texture/Landmark/venal.jpg	vena		1	0			\N
2090	res:/Model/WorldObject/Cargobox/SecureG_Cargo.blue	SecureG_Cargo		1	0	27_05		\N
2091	res:/Model/WorldObject/Cargobox/SecureH_Cargo.blue	SecureH_Cargo		1	0	27_05		\N
2092	res:/Model/WorldObject/Cargobox/SecureC_Cargo.blue	SecureC_Cargo		1	0	27_05		\N
2093		Cross of the Sacred Throne Order		1	0	35_05		\N
2094		Enlightened Soul Silver Shield		1	0	35_06		\N
2095		Onyx Heart of Valor		1	0	35_07		\N
2096		Aidonis Honorary Fellow Medallion		1	0	35_09		\N
2100		Liberty tattoo of the Minmatar nation		1	0	35_08		\N
2101	mim121	Deep Core Miner		1	0	35_01		\N
2102	res:/Model/WorldObject/Asteroid/molten_asteroid.blue	Mercoxit		1	0	35_11		\N
2103		Morphite		1	0	35_02		\N
2104		Shield Booster Amplifier		1	0	35_15		\N
2105		Secondary Power Core		1	0	35_14		\N
2106		Cloaking device		1	0	35_12		\N
2107	res:/Model/Ship/Amarr/at5.blue	Avatar	The Amarr emperors Titan	1	0			\N
2108	res:/Model/Ship/Amarr_MarkII/ab1_Sarum.blue	ab1_Sarum		1	0			\N
2109	res:/Model/Ship/Amarr_MarkII/ab2_Sarum.blue	ab2_Sarum		1	0			\N
2110	res:/Model/Ship/Amarr_MarkII/ac1_Sarum.blue	ac1_Sarum		1	0			\N
2111	res:/Model/Ship/Amarr_MarkII/ac2_Sarum.blue	ac2_Sarum		1	0			\N
2112	res:/Model/Ship/Amarr_MarkII/ac3_Sarum.blue	ac3_Sarum		1	0			\N
2113	res:/Model/Ship/Amarr_MarkII/ac4_Sarum.blue	ac4_Sarum		1	0			\N
2114	res:/Model/Ship/Amarr_MarkII/af1_Sarum.blue	af1_Sarum		1	0			\N
2115	res:/Model/Ship/Amarr_MarkII/af2_Sarum.blue	af2_Sarum		1	0			\N
2116	res:/Model/Ship/Amarr_MarkII/af3_Sarum.blue	af3_Sarum		1	0			\N
2117	res:/Model/Ship/Amarr_MarkII/af4_Sarum.blue	af4_Sarum		1	0			\N
2118	res:/Model/Ship/Amarr_MarkII/af5_Sarum.blue	af5_Sarum		1	0			\N
2119	res:/Model/Ship/Amarr_MarkII/af6_Sarum.blue	af6_Sarum		1	0			\N
2120	res:/Model/Ship/Amarr_MarkII/ai1_Sarum.blue	ai1_Sarum		1	0			\N
2121	res:/Model/Ship/Bloodraider/ab1_Bloodraider.blue	ab1_Bloodraider		1	0			\N
2122	res:/Model/Ship/Bloodraider/ab2_Bloodraider.blue	ab2_Bloodraider		1	0			\N
2123	res:/Model/Ship/Caldari_markII/cb1_Cnavy.blue	cb1_Cnavy		1	0			\N
2124	res:/Model/Ship/Caldari_markII/cb2_Cnavy.blue	cb2_Cnavy		1	0			\N
2125	res:/Model/Ship/Caldari_markII/cc1_Cnavy.blue	cc1_Cnavy		1	0			\N
2126	res:/Model/Ship/Caldari_markII/cc2_Cnavy.blue	cc2_Cnavy		1	0			\N
2127	res:/Model/Ship/Caldari_markII/cc3_Cnavy.blue	cc3_Cnavy		1	0			\N
2128	res:/Model/Ship/Caldari_markII/cc4_Cnavy.blue	cc4_Cnavy		1	0			\N
2129	res:/Model/Ship/Caldari_markII/cf1_Cnavy.blue	cf1_Cnavy		1	0			\N
2130	res:/Model/Ship/Caldari_markII/cf2_Cnavy.blue	cf2_Cnavy		1	0			\N
2131	res:/Model/Ship/Caldari_markII/cf4_Cnavy.blue	cf4_Cnavy		1	0			\N
2132	res:/Model/Ship/Caldari_markII/cf5_Cnavy.blue	cf5_Cnavy		1	0			\N
2133	res:/Model/Ship/Caldari_markII/cf6_Cnavy.blue	cf6_Cnavy		1	0			\N
2134	res:/Model/Ship/Caldari_markII/cf7_Cnavy.blue	cf7_Cnavy		1	0			\N
2135	res:/Model/Ship/Caldari_markII/cf9_Cnavy.blue	cf9_Cnavy		1	0			\N
2136	res:/Model/Ship/Caldari_markII/ci1_Cnavy.blue	ci1_Cnavy		1	0			\N
2137	res:/Model/Ship/Caldari_markII/ci2_Cnavy.blue	ci2_Cnavy		1	0			\N
2138	res:/Model/Ship/Gallente_MarkII/gb1_GallenteNavy.blue	gb1_GallenteNavy		1	0			\N
2139	res:/Model/Ship/Gallente_MarkII/gb2_GallenteNavy.blue	gb2_GallenteNavy		1	0			\N
2140	res:/Model/Ship/Gallente_MarkII/gc1_GallenteNavy.blue	gc1_GallenteNavy		1	0			\N
2141	res:/Model/Ship/Gallente_MarkII/gc2_GallenteNavy.blue	gc2_GallenteNavy		1	0			\N
2142	res:/Model/Ship/Gallente_MarkII/gc3_GallenteNavy.blue	gc3_GallenteNavy		1	0			\N
2143	res:/Model/Ship/Gallente_MarkII/gc4_GallenteNavy.blue	gc4_GallenteNavy		1	0			\N
2144	res:/Model/Ship/Gallente_MarkII/gf1_GallenteNavy.blue	gf1_GallenteNavy		1	0			\N
2145	res:/Model/Ship/Gallente_MarkII/gf2_GallenteNavy.blue	gf2_GallenteNavy		1	0			\N
2146	res:/Model/Ship/Gallente_MarkII/gf3_GallenteNavy.blue	gf3_GallenteNavy		1	0			\N
2147	res:/Model/Ship/Gallente_MarkII/gf4_GallenteNavy.blue	gf4_GallenteNavy		1	0			\N
2148	res:/Model/Ship/Gallente_MarkII/gf5_GallenteNavy.blue	gf5_GallenteNavy		1	0			\N
2149	res:/Model/Ship/Gallente_MarkII/gf6_GallenteNavy.blue	gf6_GallenteNavy		1	0			\N
2150	res:/Model/Ship/Gallente_MarkII/gf7_GallenteNavy.blue	gf7_GallenteNavy		1	0			\N
2151	res:/Model/Ship/Gallente_MarkII/gi1_GallenteNavy.blue	gi1_GallenteNavy		1	0			\N
2152	res:/Model/Ship/Gallente_MarkII/gi2_GallenteNavy.blue	gi2_GallenteNavy		1	0			\N
2153	res:/Model/Ship/Gallente_MarkII/gi3_GallenteNavy.blue	gi3_GallenteNavy		1	0			\N
2154	res:/Model/Ship/Gallente_MarkII/gi4_GallenteNavy.blue	gi4_GallenteNavy		1	0			\N
2155	res:/Model/Ship/Gallente_MarkII/gi5_GallenteNavy.blue	gi5_GallenteNavy		1	0			\N
2156	res:/Model/Ship/Guardians/gb1_Crips.blue	gb1_Crips		1	0			\N
2157	res:/Model/Ship/Guardians/gb2_Crips.blue	gb2_Crips		1	0			\N
2158	res:/Model/Ship/Guristas/cb1_guristas.blue	cb1_guristas		1	0			\N
2159	res:/Model/Ship/Guristas/cb2_guristas.blue	cb2_guristas		1	0			\N
2160	res:/Model/Ship/Minmatar_MarkII/Mb1_mnavy.blue	Mb1_mnavy		1	0			\N
2161	res:/Model/Ship/Minmatar_MarkII/Mb2_mnavy.blue	Mb2_mnavy		1	0			\N
2162	res:/Model/Ship/Minmatar_MarkII/Mc1_mnavy.blue	Mc1_mnavy		1	0			\N
2163	res:/Model/Ship/Minmatar_MarkII/Mc2_mnavy.blue	Mc2_mnavy		1	0			\N
2164	res:/Model/Ship/Minmatar_MarkII/Mc3_mnavy.blue	Mc3_mnavy		1	0			\N
2165	res:/Model/Ship/Minmatar_MarkII/Mc4_mnavy.blue	Mc4_mnavy		1	0			\N
2166	res:/Model/Ship/Minmatar_MarkII/Mf1_mnavy.blue	Mf1_mnavy		1	0			\N
2167	res:/Model/Ship/Minmatar_MarkII/Mf2_mnavy.blue	Mf2_mnavy		1	0			\N
2168	res:/Model/Ship/Minmatar_MarkII/Mf3_mnavy.blue	Mf3_mnavy		1	0			\N
2169	res:/Model/Ship/Minmatar_MarkII/Mf4_mnavy.blue	Mf4_mnavy		1	0			\N
2170	res:/Model/Ship/Minmatar_MarkII/Mf5_mnavy.blue	Mf5_mnavy		1	0			\N
2171	res:/Model/Ship/Minmatar_MarkII/Mf6_mnavy.blue	Mf6_mnavy		1	0			\N
2172	res:/Model/Ship/Minmatar_MarkII/Mf8_mnavy.blue	Mf8_mnavy		1	0			\N
2173	res:/Model/Ship/Minmatar_MarkII/Mi1_mnavy.blue	Mi1_mnavy		1	0			\N
2174	res:/Model/Ship/Minmatar_MarkII/Mi2_mnavy.blue	Mi2_mnavy		1	0			\N
2175	res:/Model/Ship/Minmatar_MarkII/Mi3_mnavy.blue	Mi3_mnavy		1	0			\N
2176		Unknown	Pax Amarria book icon	1	0	35_04		\N
2177		Unknown	Magpulse Thruster	1	0	37_01		\N
2178		Unknown	Ion Thruster	1	0	37_02		\N
2179		Unknown	Plasma Thruster	1	0	37_03		\N
2180		Unknown	Fusion Thruster	1	0	37_04		\N
2181		Unknown	Gravimetric Sensor Cluster	1	0	37_05		\N
2182		Unknown	Magnetometric Sensor Cluster	1	0	37_06		\N
2183		Unknown	Ladar Sensor Cluster	1	0	37_07		\N
2184		Unknown	Radar Sensor Cluster	1	0	37_08		\N
2185		Unknown	Quantum Microprocessor	1	0	37_09		\N
2186		Unknown	Photon Microprocessor	1	0	37_10		\N
2187		Unknown	Nanomechanical Microprocessor	1	0	37_11		\N
2188		Unknown	Nanoelectrical Microprocessor	1	0	37_12		\N
2189		Unknown	Trimorphite Armor Plate	1	0	37_13		\N
2190		Unknown	Carbonite Armor Plate	1	0	37_14		\N
2191		Unknown	Ceramite Composite Armor Plate	1	0	37_15		\N
2192		Unknown	Rolled Mexalite Armor Plate	1	0	37_16		\N
2193		Unknown	Graviton Reactor Unit	1	0	39_01		\N
2194		Unknown	Fusion Reactor Unit	1	0	39_02		\N
2195		Unknown	Nuclear Reactor Unit	1	0	39_03		\N
2196		Unknown	Antimatter Reactor Unit	1	0	39_04		\N
2197		Unknown	Scalar Capacitor Unit	1	0	39_05		\N
2198		Unknown	Oscillator Capacitor Unit	1	0	39_06		\N
2199		Unknown	Electrolytic Capacitor Unit	1	0	39_07		\N
2200		Unknown	Tesseract Capacitor Unit	1	0	39_08		\N
2201		Unknown	Sustained Shield Emitter	1	0	39_09		\N
2202		Unknown	Pulse Shield Emitter	1	0	39_10		\N
2203		Unknown	Deflection Shield Emitter	1	0	39_11		\N
2204		Unknown	Linear Shield Emitter	1	0	39_12		\N
2205		Unknown	Sarum Badge of Acknowledgement	1	0	39_13		\N
2206		Unknown	Ardishapur Trophy of Divine Grace	1	0	39_14		\N
2207		Unknown	Kador Banner of Royality	1	0	39_15		\N
2208		Unknown	Kor-Azor Scroll of Acknowledgement	1	0	39_16		\N
2209		Unknown	Tash-Murkon Amulet of Success	1	0	40_01		\N
2210		Unknown	Glossy Mineral Compound	1	0	40_02		\N
2211		Unknown	Plush Mineral Compound	1	0	40_03		\N
2212		Unknown	Sheen Mineral Composite	1	0	40_04		\N
2213		Unknown	Motley Mineral Composite	1	0	40_05		\N
2214		Unknown	Opulent Mineral Composite	1	0	40_06		\N
2215		Unknown	Dark Mineral Compound	1	0	40_07		\N
2216		Unknown	Lustering Alloy	1	0	40_08		\N
2217		Unknown	Precious Alloy	1	0	40_09		\N
2218		Unknown	Lucent Mineral Compound	1	0	40_10		\N
2219		Unknown	Condensed Alloy	1	0	40_11		\N
2220		Unknown	Gleaming Alloy	1	0	40_12		\N
2221		Unknown	Crystal Mineral Compound	1	0	40_13		\N
2222		Unknown	HyperNet Uplink (research tool)	1	0	40_14		\N
2223		Unknown	Molecular Sequencer (Duplication Tool)	1	0	40_15		\N
2224		Unknown	Data Extractor (Reverse Engineered BP research tool)	1	0	40_16		\N
2225		Unknown	Database Uplink (BP research tool)	1	0	41_01		\N
2226		Unknown	Microassembler Array (manufacturing tool)	1	0	41_02		\N
2227		Unknown	Superconductor Rails	1	0	41_05		\N
2228		Unknown	Electrothermal Combustion Chamber	1	0	41_07		\N
2229		Unknown	Graviton Pulse Generator	1	0	41_09		\N
2230		Unknown	Plasma Pulse Generator	1	0	41_10		\N
2231		Unknown	Nuclear Pulse Generator	1	0	41_11		\N
2232		Unknown	EMP Pulse Generator	1	0	41_12		\N
2233		Unknown	Particle Accelerator Chamber	1	0	41_06		\N
2234		Unknown	Laser Focusing Crystal	1	0	41_08		\N
2235	res:/Model/Ship/Amarr/afx/afx_v2.blue	afx_v2		1	0			\N
2236	res:/Model/Ship/Amarr/afx/afx_v1.blue	afx_v1		1	0			\N
2237	res:/Model/Ship/Amarr/ab1/ab1_v2.blue	Amarr Battleship 2 special		1	0			\N
2238	res:/Model/Ship/Amarr/ab2/ab2_v2.blue	Amarr battleship 2 special2		1	0			\N
2239	res:/Model/Ship/Amarr/ab1/ab1_v2.blue	ab1_v2		1	0			\N
2240	res:/Model/Ship/Amarr/ab2/ab2_v2.blue	ab2_v2		1	0			\N
2241	res:/Model/Ship/Amarr/afx/afx_v2.blue	afx_v2		1	0			\N
2242	res:/Model/Ship/Amarr/afx/afx_v1.blue	afx_v1		1	0			\N
2243		Unknown	Company Shares	1	0	27_13		\N
2244		Unknown	Coffee commodity	1	0	41_03		\N
2245	ase421	a		1	0			\N
2246	"GatlingPulseLaser2	"GatlingPulseL		1	0			\N
2247	ase121	a		1	0			\N
2248		icon13_13		1	0	13_13		\N
2249	GatlingPulseLaser2 ase121 res:/UI/Icon/Mapped/icon13_13.blue	icon13_13		1	0			\N
2250	csh121	75mmGatlingRail		1	0	13_05		\N
2251	ase131	GatlingPulseLaser		1	0	13_13		\N
2252	ase231	dual light pulse laser		1	0	13_13		\N
2253	ase331	DualLightBeamLaser		1	0	13_09		\N
2254	ase431	MediumPulseLaser		1	0	13_13		\N
2255	ase531	MediumBeamLaser		1	0	13_09		\N
2256	ame131	QuadLightBeamLaser		1	0	13_10		\N
2257	ame231	FocusedMediumPulseLaser		1	0	13_14		\N
2258	ame331	FocusedMediumBeamLaser		1	0	13_10		\N
2259	ame431	HeavyPulseLaser		1	0	13_14		\N
2260	ame531	HeavyBeamLaser		1	0	13_10		\N
2261	ale131	DualHeavyPulseLaser		1	0	13_15		\N
2262	ale231	DualHeavyBeamLaser		1	0	13_11		\N
2263	ale331	MegaPulseLaser		1	0	13_15		\N
2264	ale431	MegaBeamLaser		1	0	13_11		\N
2265	ale531	ThacyonBeamLaser		1	0	13_11		\N
2266	glh531	IonBlasterCannon	Caldari	1	0	13_03		\N
2267	clh431	425mmRailgun	Caldari	1	0	13_07		\N
2268	glh331	NeutronBlasterCannon		1	0	13_03		\N
2269	clh231	Dual250mmRailgun		1	0	13_07		\N
2270	glh131	DualHeavyIonBlaster		1	0	13_03		\N
2271	cmh531	250mmRailgun		1	0	13_06		\N
2272	gmh431	HeavyIonBlaster		1	0	13_02		\N
2273	gmh331	HeavyNeutronBlaster		1	0	13_02		\N
2274	cmh231	Dual150mmRailgun		1	0	13_06		\N
2275	gmh131	HeavyElectronBlaster		1	0	13_02		\N
2276	csh531	150mmRailgun		1	0	13_05		\N
2277	gsh431	LightNeutronBlaster	Caldari	1	0	13_01		\N
2278	gsh331	LightIonBlaster	Caldari	1	0	13_01		\N
2279	gsh231	LightElectronBlaster	Caldari	1	0	13_01		\N
2280	mlp531	LargeArtilleryRocket		1	0	12_15		\N
2281	mlp431	1200mmArtilleryCannon		1	0	12_15		\N
2282	mlp331	800mmArtilleryCannon		1	0	12_15		\N
2283	mlp231	Dual650mmArtilleryCannon		1	0	12_15		\N
2284	mlp131	Dual425mmRailgun		1	0	12_11		\N
2285	mmp531	MediumArtilleryRocket		1	0	12_14		\N
2286	mmp431	650mmArtilleryCannon		1	0	12_14		\N
2287	mmp331	425mmAutoCannon		1	0	12_10		\N
2288	mmp231	220mmVulcanAutoCannon		1	0	12_10		\N
2289	mmp131	Dual80mmAutoCannon		1	0	12_10		\N
2290	msp531	SmallArtilleryRocket		1	0	12_13		\N
2291	msp431	250mmLightArtilleryCannon		1	0	12_13		\N
2292	msp331	200mmAutoCannon		1	0	12_09		\N
2293	msp231	150mmLightAutoCannon		1	0	12_09		\N
2294	msp131	125mmGatlingAutoCannon		1	0	12_09		\N
2295	res:/Model/Ship/Sansha/sb1/sb1.blue	Sansha's Battleship		1	0			\N
2296	res:/Model/Deployables/ControlTower/Amarr/amct1.blue	amct1		1	0			\N
2297	res:/Model/Deployables/ControlTower/Gallente/gmct1.blue	gmct1		1	0			\N
2298	res:/Model/Deployables/MobileHangar/Small/dmh1.blue	dmh1		1	0			\N
2299	res:/Model/Deployables/MobileRefinery/Medium/dmr2.blue	dmr2		1	0			\N
2300	res:/Model/Deployables/MobileRefinery/Small/Refinery_S_Online.blue	dmr1		1	0			\N
2301	res:/Model/Deployables/MobileStorage/Medium/dms2.blue	dms2		1	0			\N
2302		Unknown	DNA	1	0	25_15		\N
2303	res:/Scene/Hangar/Serpentis.blue	Hangar,Angel		1	0			\N
2304		Unknown	Crash-test dummies, commodity	1	0	41_04		\N
2305	res:/Model/Jumpgate/Cult/CultJg2.blue	Smuggler Stargate		1	0			\N
2306	res:/Model/Station/Cult/CultS2.blue	CultS2		1	0		res:/Sound/Station/Station03.blue	\N
2307	res:/Model/Station/Cult/CultS1.blue	CultS1		1	0		res:/Sound/Station/Station03.blue	\N
2308	res:/Model/Station/Cult/CultS3.blue	CultS3		1	0		res:/Sound/Station/Station03.blue	\N
2309	res:/Model/WorldObject/WarpDisruptor.blue	Warp Disruptor		1	0	36_15		\N
2310		Unknown	Angel Bronze Dog Tags	1	0	41_15		\N
2311		Unknown	Angel Silver Dog Tags	1	0	41_16		\N
2312		Unknown	Angel Gold Dog Tags	1	0	42_01		\N
2313		Unknown	Angel Platinum Dog Tags	1	0	42_02		\N
2314		Unknown	Angel Crystal Dog Tags	1	0	42_03		\N
2315		Unknown	Blood Raider Bronze Dog Tags	1	0	42_04		\N
2316		Unknown	Blood Raider Silver Dog Tags	1	0	42_05		\N
2317		Unknown	Blood Raider Gold Dog Tags	1	0	42_06		\N
2318		Unknown	Blood Raider Platinum Dog Tags	1	0	42_07		\N
2319		Unknown	Blood Raider Crystal Dog Tags	1	0	42_08		\N
2320		Unknown	Serpentis Bronze Dog Tags	1	0	42_09		\N
2321		Unknown	Serpentis Silver Dog Tags	1	0	42_10		\N
2322		Unknown	Serpentis Gold Dog Tags	1	0	42_11		\N
2323		Unknown	Serpentis Platinum Dog Tags	1	0	42_12		\N
2324		Unknown	Serpentis Crystal Dog Tags	1	0	42_13		\N
2325		Unknown	Guristas Bronze Dog Tags	1	0	42_14		\N
2326		Unknown	Guristas Silver Dog Tags	1	0	42_15		\N
2327		Unknown	Guristas Gold Dog Tags	1	0	42_16		\N
2328		Unknown	Guristas Platinum Dog Tags	1	0	43_01		\N
2329		Unknown	Guristas Crystal Dog Tags	1	0	43_02		\N
2330		Unknown	Sansha Bronze Dog Tags	1	0	43_03		\N
2331		Unknown	Sansha Silver Dog Tags	1	0	43_04		\N
2332		Unknown	Sansha Gold Dog Tags	1	0	43_05		\N
2333		Unknown	Sansha Platinum Dog Tags	1	0	43_06		\N
2334		Unknown	Sansha Crystal Dog Tags	1	0	43_07		\N
2335		Unknown	Angel Ship Log	1	0	43_08		\N
2336		Unknown	Blood Raider Ship Log	1	0	43_09		\N
2337		Unknown	Serpentis Ship Log	1	0	43_10		\N
2338		Unknown	Guristas Ship Log	1	0	43_11		\N
2339		Unknown	Sansha Ship Log	1	0	43_12		\N
2340		Unknown	Munitions Commodity	1	0	43_13		\N
2341	res:/Model/WorldObject/Warpgate/wg1.blue	WarpGate		1	0			\N
2342	res:/Model/WorldObject/ForceField/ForceField_ThermalS.blue	ForceField_ThermalS		1	0			\N
2343	res:/Model/WorldObject/ForceField/ForceField_ThermalM.blue	ForceField_ThermalM		1	0			\N
2344	res:/Model/WorldObject/ForceField/ForceField_ThermalL.blue	ForceField_ThermalL		1	0			\N
2345	res:/Model/WorldObject/ForceField/ForceField_KineticS.blue	ForceField_KineticS		1	0			\N
2346	res:/Model/WorldObject/ForceField/ForceField_KineticM.blue	ForceField_KineticM		1	0			\N
2347	res:/Model/WorldObject/ForceField/ForceField_KineticL.blue	ForceField_KineticL		1	0			\N
2348	res:/Model/WorldObject/ForceField/ForceField_ExposiveS.blue	ForceField_ExposiveS		1	0			\N
2349	res:/Model/WorldObject/ForceField/ForceField_ExplosiveM.blue	ForceField_ExplosiveM		1	0			\N
2350	res:/Model/WorldObject/ForceField/ForceField_ExplosiveL.blue	ForceField_ExplosiveL		1	0			\N
2351	res:/Model/WorldObject/ForceField/ForceField_EmS.blue	ForceField_EmS		1	0			\N
2352	res:/Model/WorldObject/ForceField/ForceField_EmM.blue	ForceField_EmM		1	0			\N
2353	res:/Model/WorldObject/ForceField/ForceField_EmL.blue	ForceField_EmL		1	0			\N
2354	res:/Model/Ship/Gallente/gb2/gb2_special.blue	Megathron Special Edition		1	0			\N
2355		Unknown	Starmap icon	1	0	07_04		\N
2356	res:/Model/Battlestation/GuardianL.blue	GuardianL		1	0			\N
2357	res:/Model/Battlestation/AngelL2.blue	AngelL2		1	0			\N
2358	res:/Model/Battlestation/AngelS.blue	AngelS		1	0			\N
2359	res:/Model/Battlestation/BloodraiderL.blue	BloodraiderL		1	0			\N
2360	res:/Model/Battlestation/BloodraiderS.blue	BloodraiderS		1	0			\N
2361	res:/Model/Battlestation/GuardianS.blue	GuardianS		1	0			\N
2362	res:/Model/Battlestation/GuristasS.blue	GuristasS		1	0			\N
2363	res:/Model/Battlestation/SanshaS.blue	SanshaS		1	0			\N
2364	res:/Model/Battlestation/SanshaL.blue	SanshaL		1	0			\N
2365	res:/Model/Battlestation/AngelL.blue	AngelL		1	0			\N
2366	res:/Model/Deployables/AssemblyArray/Large/AssemblyArray.blue	Large Assembly Array		1	0			\N
2367	res:/Model/WorldObject/Drill/Drill.blue	Abandoned Drill		1	0			\N
2368	res:/Model/WorldObject/Walkway/DebrisWalkway.blue	Debris Walkway		1	0			\N
2369	res:/Model/WorldObject/Billboard_old/Billboard_old.blue	Billboard_old		1	0			\N
2370	res:/Model/Deployables/ControlTower/Caldari/cmct1.blue	cmct1		1	0			\N
2371	res:/Model/Deployables/ControlTower/Minmatar/Minmatar_Tower_Online.blue	Minmatar_Tower_Online		1	0			\N
2372	res:/Model/Deployables/MobileArmory/Small_Armory.blue	Small_Armory		1	0			\N
2373	res:/Model/Deployables/MobileLaboratory/SLAB.blue	Mobile Laboratory		1	0			\N
2374	res:/Model/Deployables/MobilePowerCore/SMPC.blue	Mobile Power Core		1	0			\N
2375	res:/Model/Deployables/MobileSensor/S_Sensor_Platform_Online.blue	Mobile Sensor Dampener		1	0			\N
2376	res:/Model/Deployables/MobileStorage/Small/SmS.blue	Small Mobile Storage		1	0			\N
2377	res:/Model/Deployables/MobileFactory/SMF.blue	Small Field Assembly Array		1	0			\N
2378	res:/Model/Deployables/MoonHarvester/Small/dmoonh1.blue	Mobile Moon Harvester		1	0			\N
2379	res:/Model/Deployables/Sentry/MobileMissileSentry1.blue	Mobile Missile Sentry		1	0			\N
2380	res:/Model/Deployables/ShieldGenerator/Small/dsg1.blue	Mobile Shield Generator		1	0			\N
2382	res:/Model/Ship/Caldari/cbc1/cbc1.blue	cbc1		1	0			\N
2383	res:/Model/Ship/Gallente/gbc1/gbc1.blue	gbc1		1	0			\N
2384	res:/Model/Ship/Minmatar/MBC1/MBC1.blue	MBC1		1	0			\N
2385	res:/Model/Ship/Amarr/ABC1/ABC1.blue	ABC1		1	0			\N
2386	res:/Model/Ship/Caldari/cbc1/cbc1.blue	cbc1		1	0			\N
2387	res:/Model/Ship/Amarr/ADE1/ADE1.blue	ADE1		1	0			\N
2388	res:/Model/Ship/Caldari/CDE1/CDE1.blue	CDE1		1	0			\N
2389	res:/Model/Ship/Gallente/gdes1/gdes1.blue	gdes1		1	0			\N
2390	res:/Model/Ship/Minmatar/Mde1/MDE1.blue	MDE1		1	0			\N
2391	res:/Model/WorldObject/Nanobuilder/nanobuilder.blue	Simple Nano Assembly Package		1	0			\N
2392	res:/Model/dropship/Dropship.blue	Dropship		1	0			\N
2393	res:/Model/Deployables/Forcefield/posForcefield.blue	POS Forcefield		1	0			\N
2394	res:/Model/WorldObject/Spawn_Containers/Ammo_Container/Ammo_Container.blue	Ammo_Container		1	0			\N
2395	res:/Model/WorldObject/Spawn_Containers/Armor_Container/Armor_Container.blue	Armor_Container		1	0			\N
2396	res:/Model/WorldObject/Spawn_Containers/Electronic_Container/Electronic_Container.blue	Electronic_Container		1	0			\N
2397	res:/Model/WorldObject/Spawn_Containers/Mineral_Container/Mineral_Container.blue	Mineral_Container		1	0			\N
2398	res:/Model/WorldObject/Spawn_Containers/Rgd_Container/rgd_Container.blue	rgd_Container		1	0			\N
2399	res:/Model/WorldObject/Spawn_Containers/Weapon_container/weapon_container.blue	weapon_container		1	0			\N
2400	res:/Model/WorldObject/AmarrCathedral/cathedral.blue	cathedral		1	0			\N
2401	res:/Model/WorldObject/AmarrCathedral/cathedralBlood.blue	cathedralBlood		1	0			\N
2402	res:/Model/WorldObject/Asteroid_station12/asteroid_station12.blue	asteroid_station12		1	0			\N
2403	res:/Model/WorldObject/CargoRig/CargoRig.blue	CargoRig		1	0			\N
2404	res:/Model/WorldObject/Chapel/chapel.blue	chapel		1	0			\N
2405	res:/Model/WorldObject/Chapel/chapelBlood.blue	chapelBlood		1	0			\N
2406	res:/Model/WorldObject/Drone_Superstructure2/Drone_Structure2.blue	Drone_Structure2		1	0			\N
2407	res:/Model/WorldObject/Drone_Superstructures/Drone_structure1.blue	Drone_structure1		1	0			\N
2408	res:/Model/WorldObject/GB2Construct/gb2construct.blue	gb2construct		1	0			\N
2409	res:/Model/WorldObject/Helipad/helipad_01.blue	helipad_01		1	0			\N
2410	res:/Model/WorldObject/RDStation/rd_station.blue	rd_station		1	0			\N
2411	res:/Model/WorldObject/RuinedStargate/gj3ruined.blue	gj3ruined		1	0			\N
2412	res:/Model/WorldObject/Solarharvester/SolarHarvester.blue	SolarHarvester		1	0			\N
2413	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_Sentry.blue	AmarrWall_Sentry		1	0			\N
2414	res:/Model/WorldObject/Defenses/Angel/AngelWall_Sentry.blue	AngelWall_Sentry		1	0			\N
2415	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_Sentry.blue	BloodraiderWall_Sentry		1	0			\N
2416	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_Sentry.blue	CaldariWall_Sentry		1	0			\N
2417	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_Sentry.blue	GallenteWall_Sentry		1	0			\N
2418	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Sentry.blue	GuristaWall_Sentry		1	0			\N
2419	res:/Model/WorldObject/Defenses/Minmatar/MimatarWall_Sentry.blue	MimatarWall_Sentry		1	0			\N
2420	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_Sentry.blue	SanshaWall_Sentry		1	0			\N
2421	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_Sentry.blue	SerpentisWall_Sentry		1	0			\N
2422	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_Bunker.blue	AmarrWall_Bunker		1	0			\N
2423	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_Elevator.blue	AmarrWall_Elevator		1	0			\N
2424	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_Junction.blue	AmarrWall_Junction		1	0			\N
2425	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_Lookout.blue	AmarrWall_Lookout		1	0			\N
2426	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_X.blue	AmarrWall_X		1	0			\N
2427	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_XZ.blue	AmarrWall_XZ		1	0			\N
2428	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_Z.blue	AmarrWall_Z		1	0			\N
2429	res:/Model/WorldObject/Defenses/Amarr/AmarrWall_ZX.blue	AmarrWall_ZX		1	0			\N
2430	res:/Model/WorldObject/Defenses/Amarr/AmarrWalls_MBattery.blue	AmarrWalls_MBattery		1	0			\N
2431	res:/Model/WorldObject/Defenses/Angel/AngelWall_Bunker.blue	AngelWall_Bunker		1	0			\N
2432	res:/Model/WorldObject/Defenses/Angel/AngelWall_Elevator.blue	AngelWall_Elevator		1	0			\N
2433	res:/Model/WorldObject/Defenses/Angel/AngelWall_Junction.blue	AngelWall_Junction		1	0			\N
2434	res:/Model/WorldObject/Defenses/Angel/AngelWall_Lookout.blue	AngelWall_Lookout		1	0			\N
2435	res:/Model/WorldObject/Defenses/Angel/AngelWall_MBattery.blue	AngelWall_MBattery		1	0			\N
2436	res:/Model/WorldObject/Defenses/Angel/AngelWall_X.blue	AngelWall_X		1	0			\N
2437	res:/Model/WorldObject/Defenses/Angel/AngelWall_XZ.blue	AngelWall_XZ		1	0			\N
2438	res:/Model/WorldObject/Defenses/Angel/AngelWall_Z.blue	AngelWall_Z		1	0			\N
2439	res:/Model/WorldObject/Defenses/Angel/AngelWall_ZX.blue	AngelWall_ZX		1	0			\N
2440	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_Bunker.blue	BloodraiderWall_Bunker		1	0			\N
2441	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_Elevator.blue	BloodraiderWall_Elevator		1	0			\N
2442	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_Junction.blue	BloodraiderWall_Junction		1	0			\N
2443	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_Lookout.blue	BloodraiderWall_Lookout		1	0			\N
2444	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_MBattery.blue	BloodraiderWall_MBattery		1	0			\N
2445	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_X.blue	BloodraiderWall_X		1	0			\N
2446	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_XZ.blue	BloodraiderWall_XZ		1	0			\N
2447	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_Z.blue	BloodraiderWall_Z		1	0			\N
2448	res:/Model/WorldObject/Defenses/Bloodraider/BloodraiderWall_ZX.blue	BloodraiderWall_ZX		1	0			\N
2449	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_Elevator.blue	CaldariWall_Elevator		1	0			\N
2450	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_Junction.blue	CaldariWall_Junction		1	0			\N
2451	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_Lookout.blue	CaldariWall_Lookout		1	0			\N
2452	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_MBattery.blue	CaldariWall_MBattery		1	0			\N
2453	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_X.blue	CaldariWall_X		1	0			\N
2454	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_XZ.blue	CaldariWall_XZ		1	0			\N
2455	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_Z.blue	CaldariWall_Z		1	0			\N
2456	res:/Model/WorldObject/Defenses/Caldari/CaldariWall_ZX.blue	CaldariWall_ZX		1	0			\N
2457	res:/Model/WorldObject/Defenses/Caldari/GuristaWall_Bunker.blue	GuristaWall_Bunker		1	0			\N
2458	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_Bunker.blue	GallenteWall_Bunker		1	0			\N
2459	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_Elevator.blue	GallenteWall_Elevator		1	0			\N
2460	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_Junction.blue	GallenteWall_Junction		1	0			\N
2461	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_Lookout.blue	GallenteWall_Lookout		1	0			\N
2462	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_MBattery.blue	GallenteWall_MBattery		1	0			\N
2463	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_X.blue	GallenteWall_X		1	0			\N
2464	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_XZ.blue	GallenteWall_XZ		1	0			\N
2465	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_Z.blue	GallenteWall_Z		1	0			\N
2466	res:/Model/WorldObject/Defenses/Gallente/GallenteWall_ZX.blue	GallenteWall_ZX		1	0			\N
2467	res:/Model/WorldObject/Defenses/Guristas/GuristasWall_GreatWall.blue	GuristasWall_GreatWall		1	0			\N
2468	res:/Model/WorldObject/Defenses/Guristas/GuristasWall_MBattery.blue	GuristasWall_MBattery		1	0			\N
2469	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Bunker.blue	GuristaWall_Bunker		1	0			\N
2470	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Bunker.blue	GuristaWall_Bunker		1	0			\N
2471	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Elevator.blue	GuristaWall_Elevator		1	0			\N
2472	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Junction.blue	GuristaWall_Junction		1	0			\N
2473	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Lookout.blue	GuristaWall_Lookout		1	0			\N
2474	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_X.blue	GuristaWall_X		1	0			\N
2475	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_XZ.blue	GuristaWall_XZ		1	0			\N
2476	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_Z.blue	GuristaWall_Z		1	0			\N
2477	res:/Model/WorldObject/Defenses/Guristas/GuristaWall_ZX.blue	GuristaWall_ZX		1	0			\N
2478	res:/Model/WorldObject/Defenses/Minmatar/MinmatarlWall_ZX.blue	MinmatarlWall_ZX		1	0			\N
2479	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_Bunker.blue	MinmatarWall_Bunker		1	0			\N
2480	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_Elevator.blue	MinmatarWall_Elevator		1	0			\N
2481	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_Junction.blue	MinmatarWall_Junction		1	0			\N
2482	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_Lookout.blue	MinmatarWall_Lookout		1	0			\N
2483	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_MBattery.blue	MinmatarWall_MBattery		1	0			\N
2484	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_X.blue	MinmatarWall_X		1	0			\N
2485	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_XZ.blue	MinmatarWall_XZ		1	0			\N
2486	res:/Model/WorldObject/Defenses/Minmatar/MinmatarWall_Z.blue	MinmatarWall_Z		1	0			\N
2487	res:/Model/WorldObject/Defenses/Sansha/SanshaiWall_Z.blue	SanshaiWall_Z		1	0			\N
2488	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_Bunker.blue	SanshaWall_Bunker		1	0			\N
2489	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_Elevator.blue	SanshaWall_Elevator		1	0			\N
2490	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_Junction.blue	SanshaWall_Junction		1	0			\N
2491	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_Lookout.blue	SanshaWall_Lookout		1	0			\N
2492	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_MBattery.blue	SanshaWall_MBattery		1	0			\N
2493	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_X.blue	SanshaWall_X		1	0			\N
2494	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_XZ.blue	SanshaWall_XZ		1	0			\N
2495	res:/Model/WorldObject/Defenses/Sansha/SanshaWall_ZX.blue	SanshaWall_ZX		1	0			\N
2496	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_Bunker.blue	SerpentisWall_Bunker		1	0			\N
2497	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_Elevator.blue	SerpentisWall_Elevator		1	0			\N
2498	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_Junction.blue	SerpentisWall_Junction		1	0			\N
2499	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_Lookout.blue	SerpentisWall_Lookout		1	0			\N
2500	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_MBattery.blue	SerpentisWall_MBattery		1	0			\N
2501	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_X.blue	SerpentisWall_X		1	0			\N
2502	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_XZ.blue	SerpentisWall_XZ		1	0			\N
2503	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_Z.blue	SerpentisWall_Z		1	0			\N
2504	res:/Model/WorldObject/Defenses/Serpentis/SerpentisWall_ZX.blue	SerpentisWall_ZX		1	0			\N
2505	res:/Model/WorldObject/RadioTelescope/RadioTelescope.blue	RadioTelescope		1	0			\N
2506	res:/Model/Ship/Eom/af3_EoM.blue	af3_EoM		1	0			\N
2507	res:/Model/Ship/Eom/af6_EoM.blue	af6_EoM		1	0			\N
2508	res:/Model/Ship/Eom/ab1_EoM.blue	ab1_EoM		1	0			\N
2509	res:/Model/Ship/Eom/ab2_EoM.blue	ab2_EoM		1	0			\N
2510	res:/Model/Ship/Eom/ac1_EoM.blue	ac1_EoM		1	0			\N
2511	res:/Model/Ship/Eom/ac2_EoM.blue	ac2_EoM		1	0			\N
2512		Unknown	ISK (InterStellar Kredits)	1	0	07_12		\N
2513	res:/Model/WorldObject/BloodSportArena/BloodsportArena.blue	BloodsportArena		1	0			\N
2514	res:/Model/WorldObject/HabitatModule/habitat_brothel.blue	habitat_brothel		1	0			\N
2515	res:/Model/WorldObject/HabitatModule/habitat_living.blue	habitat_living		1	0			\N
2516	res:/Model/WorldObject/HabitatModule/habitat_narcotics.blue	habitat_narcotics		1	0			\N
2517	res:/Model/WorldObject/HabitatModule/habitat_casino.blue	habitat_casino		1	0			\N
2518	res:/Model/WorldObject/HabitatModule/habitat_pleasure.blue	habitat_pleasure		1	0			\N
2519	res:/Model/WorldObject/HabitatModule/habitat_police.blue	habitat_police		1	0			\N
2520	res:/Model/WorldObject/HabitatModule/habitat_prison.blue	habitat_prison		1	0			\N
2521	res:/Model/WorldObject/HabitatModule/habitat_roadhouse.blue	habitat_roadhouse		1	0			\N
2522	res:/Model/Ship/ORE/Ore_L.blue	Ore_L		1	0			\N
2523	res:/Model/Ship/ORE/Ore_M.blue	Ore_M		1	0			\N
2524	res:/Model/Ship/ORE/Ore_S.blue	Ore_S		1	0			\N
2525	res:/Model/Effect/GasHarvester.blue	GasHarvester		1	0			\N
2526	res:/Model/Effect/IceHarvester.blue	IceHarvester		1	0	49_06		\N
2527	res:/Model/Effect/Megaminer.blue	Megaminer		1	0	49_05		\N
2528		Unknown	Luxury vehicles	1	0	45_09		\N
2529		Unknown	Scrapmetal commodity	1	0	45_10		\N
2530		Unknown	Cruise launcher	1	0	45_11		\N
2531		Unknown	Ballistic Control System (for missile launchers)	1	0	45_12		\N
2532		Unknown	Red star medal	1	0	45_13		\N
2533		Unknown	Bronze moon medal	1	0	45_14		\N
2534		Unknown	Silver world medal	1	0	45_15		\N
2535		Unknown	Gold sun medal	1	0	45_16		\N
2536		Unknown	Civilian (male)	1	0	46_01		\N
2537		Unknown	Civilian (female)	1	0	46_02		\N
2538		Unknown	VIP	1	0	46_03		\N
2539		Unknown	Tourist	1	0	46_04		\N
2540		Unknown	Marine	1	0	46_05		\N
2541		Unknown	Slave	1	0	46_06		\N
2542		Unknown	Refugee / Homeless person	1	0	46_07		\N
2543		Unknown	Lap dancer / Prostitute	1	0	46_08		\N
2544		Unknown	Mercenary	1	0	46_09		\N
2545		Unknown	Convict / Prisoner	1	0	46_10		\N
2546		Unknown	Slaver (man with shackles)	1	0	46_11		\N
2547		Unknown	Minmatar Light Marine	1	0	46_13		\N
2548		Unknown	Caldari Light Marine	1	0	46_14		\N
2549		Unknown	Amarr Light Marine	1	0	46_15		\N
2550		Unknown	Gallente Light Marine	1	0	46_16		\N
2551		Unknown	Genetically engineered livestock	1	0	43_14		\N
2552		Unknown	Concord badge	1	0	43_15		\N
2553		Unknown	Severed head (soaked in formaldehyde)	1	0	43_16		\N
2554	res:/Model/WorldObject/Asteroid/Ice/Blueice.blue	Blueice		1	0	51_05		\N
2555	res:/Model/WorldObject/Asteroid/Ice/ClacialMass.blue	ClacialMass		1	0	51_04		\N
2556	res:/Model/WorldObject/Asteroid/Ice/ClearIcicle.blue	ClearIcicle		1	0	51_02		\N
2557	res:/Model/WorldObject/Asteroid/Ice/Darkglitter.blue	Darkglitter		1	0	51_03		\N
2558	res:/Model/WorldObject/Asteroid/Ice/Gelidus.blue	Gelidus		1	0	51_06		\N
2559	res:/Model/WorldObject/Asteroid/Ice/Glarecrust.blue	Glarecrust		1	0	51_01		\N
2560	res:/Model/WorldObject/Asteroid/Ice/Krystallos.blue	Krystallos		1	0	51_09		\N
2561	res:/Model/WorldObject/Asteroid/Ice/WhiteGlaze.blue	WhiteGlaze		1	0	51_08		\N
2562		Unknown	Ship Equipment	1	0	12_03		\N
2563		CharacterIcon		1	0	02_16		\N
2564		Unknown	StarbaseIcon	1	0	40_14		\N
2565	res:/Model/Station/Drone/Hive1.blue	Hive1		1	0			\N
2566	res:/Model/Station/Drone/Hive2.blue	Hive2		1	0			\N
2567		Unknown	Cadmium	1	0	47_01		\N
2568		Unknown	Caesium	1	0	47_02		\N
2569		Unknown	Chromium.	1	0	47_03		\N
2570		Unknown	Cobalt	1	0	47_04		\N
2571		Unknown	Dysprosium	1	0	47_05		\N
2572		Unknown	Hafnium	1	0	47_06		\N
2573		Unknown	Mercury	1	0	47_07		\N
2574		Unknown	Neodymium	1	0	47_08		\N
2575		Unknown	Platinium	1	0	47_09		\N
2576		Unknown		1	0	47_10		\N
2577		Unknown	Scandium	1	0	47_11		\N
2578		Unknown	Technetium	1	0	47_12		\N
2579		Unknown	Thulium	1	0	47_13		\N
2580		Unknown	Tungsten	1	0	47_14		\N
2581		Unknown	Vanadium	1	0	47_15		\N
2582		Unknown	Titanium	1	0	47_16		\N
2583	res:/Model/WorldObject/defenses/drone/DroneWall_Bunker.blue	DroneWall_Bunker		1	0			\N
2584	res:/Model/WorldObject/defenses/drone/DroneWall_Elevator.blue	DroneWall_Elevator		1	0			\N
2585	res:/Model/WorldObject/defenses/drone/DroneWall_Junction.blue	DroneWall_Junction		1	0			\N
2586	res:/Model/WorldObject/defenses/drone/DroneWall_Lookout.blue	DroneWall_Lookout		1	0			\N
2587	res:/Model/WorldObject/defenses/drone/DroneWall_MBattery.blue	DroneWall_MBattery		1	0			\N
2588	res:/Model/WorldObject/defenses/drone/DroneWall_X.blue	DroneWall_X		1	0			\N
2589	res:/Model/WorldObject/defenses/drone/DroneWall_XZ.blue	DroneWall_XZ		1	0			\N
2590	res:/Model/WorldObject/defenses/drone/DroneWall_Z.blue	DroneWall_Z		1	0			\N
2591	res:/Model/WorldObject/defenses/drone/DroneWall_ZX.blue	DroneWall_ZX		1	0			\N
2592	res:/Model/WorldObject/defenses/drone/DroneWallSentry.blue	DroneWallSentry		1	0			\N
2593	res:/Model/Deployables/finalDeployables/Amarr_Tower_Final.blue	Amarr_Tower_Final		1	0			\N
2594	res:/Model/Deployables/finalDeployables/Gallente_Tower_Final.blue	Gallente_Tower_Final		1	0			\N
2595	res:/Model/Deployables/finalDeployables/Hangar_Final.blue	Hangar_Final		1	0			\N
2596	res:/Model/Deployables/finalDeployables/Refinery_Final.blue	Refinery_Final		1	0			\N
2597	res:/Model/Deployables/finalDeployables/Storage_Final.blue	Storage_Final		1	0			\N
2598	res:/Model/Deployables/finalDeployables/Silo_Final.blue	Silo_Final		1	0			\N
2599	res:/Model/Deployables/finalDeployables/Caldari_Tower_Final.blue	Caldari_Tower_Final		1	0			\N
2600	res:/Model/Deployables/finalDeployables/Minmatar_Tower_Final.blue	Minmatar_Tower_Final		1	0			\N
2601	res:/Model/Deployables/finalDeployables/Storage_Final.blue	Storage_Final		1	0			\N
2602	res:/Model/Deployables/finalDeployables/Harvester_final.blue	Harvester_final		1	0			\N
2603	res:/Model/Deployables/finalDeployables/MissileSentry_final.blue	MissileSentry_final		1	0			\N
2604	res:/Model/Deployables/finalDeployables/MissileSentry_final.blue	MissileSentry_final		1	0			\N
2605	res:/Model/Deployables/finalDeployables/DeltaReactor_Final.blue	DeltaReactor_Final		1	0			\N
2606	res:/Model/Deployables/finalDeployables/Harvester_final.blue	Harvester_final		1	0			\N
2607	res:/Model/Deployables/finalDeployables/Harvester_final.blue	Harvester_final		1	0			\N
2608	res:/Model/Deployables/finalDeployables/Smagnetometric_Final.blue	LAB_Final		1	0			\N
2609	res:/Model/Deployables/finalDeployables/SLadar_Final.blue	LAB_Final		1	0			\N
2610	res:/Model/Deployables/finalDeployables/SGravimetric_Final.blue	LAB_Final		1	0			\N
2611	res:/Model/Deployables/finalDeployables/SRadar_Final.blue	LAB_Final		1	0			\N
2612	res:/Model/Deployables/finalDeployables/SStasiweb_final.blue	SStasiweb_final		1	0			\N
2613	res:/Model/Deployables/finalDeployables/SDampener_final.blue	SDampener_final		1	0			\N
2614	res:/Model/Deployables/finalDeployables/SWarpScambler_final.blue	SWarpScambler_final		1	0			\N
2615	res:/Model/Deployables/finalDeployables/SWarpScambler_final.blue	SWarpScambler_final		1	0			\N
2616	res:/Model/Deployables/finalDeployables/ShieldHardener_Final.blue	ShieldHardener_Final		1	0			\N
2617	res:/Model/Deployables/finalDeployables/ShieldHardener_Final.blue	ShieldHardener_Final		1	0			\N
2618	res:/Model/Deployables/finalDeployables/ShieldHardener_Final.blue	ShieldHardener_Final		1	0			\N
2619	res:/Model/Deployables/finalDeployables/ShieldHardener_Final.blue	ShieldHardener_Final		1	0			\N
2620	res:/Model/Deployables/finalDeployables/Hangar_Final.blue	Hangar_Final		1	0			\N
2621	res:/Model/Deployables/finalDeployables/SLadar_final.blue	SLadar_final		1	0			\N
2622	res:/Model/Deployables/finalDeployables/MissileSentry_final.blue	MissileSentry_final		1	0			\N
2623	res:/Model/Deployables/finalDeployables/LAB_Final.blue	LAB_Final		1	0			\N
2624	res:/Model/Deployables/finalDeployables/Silo_Final.blue	Silo_Final		1	0			\N
2625	res:/Model/Deployables/Shipyard/Shipyard.blue	Shipyard		1	0			\N
2626	res:/Model/Deployables/Shipyard/Shipyard_Dark.blue	Shipyard_Dark		1	0			\N
2627	res:/Model/Deployables/Shipyard/Shipyard_Dirty.blue	Shipyard_Dirty		1	0			\N
2628	res:/Model/Missile/Missile_Purgatory.blue	Missile_Purgatory		1	0	21_06		\N
2629	res:/Model/Missile/Missile_Doom.blue	Missile_Doom		1	0	21_10		\N
2630	res:/Model/Missile/Missile_Thor.blue	Missile_Thor		1	0	21_14		\N
2631	res:/Model/Missile/Missile_Rift.blue	Missile_Rift		1	0	21_02		\N
2632	res:/Model/ship/factionPC/BloodraiderF.blue	BloodraiderF		1	0			\N
2633	res:/Model/ship/factionPC/CaldariNF.blue	CaldariNF		1	0			\N
2634	res:/Model/ship/factionPC/GallenteNF.blue	GallenteNF		1	0			\N
2635	res:/Model/ship/factionPC/MinmatarNF.blue	MinmatarNF		1	0			\N
2636	res:/Model/ship/factionPC/BloodraiderC.blue	BloodraiderC		1	0			\N
2637	res:/Model/ship/factionPC/CaldariNC.blue	CaldariNC		1	0			\N
2638	res:/Model/ship/factionPC/CaldariNBS.blue	CaldariNBS		1	0			\N
2639	res:/Model/ship/factionPC/MinmatarNC.blue	MinmatarNC		1	0			\N
2640	res:/Model/ship/factionPC/SanshaF.blue	SanshaF		1	0			\N
2641	res:/Model/ship/factionPC/SanshaBS.blue	SanshaBS		1	0			\N
2642	res:/Model/ship/factionPC/MinmatarNBS.blue	MinmatarNBS		1	0			\N
2643	res:/Model/ship/factionPC/SanshaC.blue	SanshaC		1	0			\N
2644	res:/Model/ship/factionPC/BloodraiderBS.blue	BloodraiderBS		1	0			\N
2645		Arkonor Mining Cr		1	0	48_14		\N
2646		Bistot Mining Cr		1	0	48_13		\N
2647		Crokite Mining Cr		1	0	48_12		\N
2648		Dark Ochre Mining Cr		1	0	48_11		\N
2649		Gneiss Mining Cr		1	0	48_10		\N
2650		Hedbergite Mining Cr		1	0	48_09		\N
2651		Hemorphite Mining Cr		1	0	48_08		\N
2652		Jaspet Mining Cr		1	0	48_07		\N
2653		Kernite Mining Cr		1	0	48_06		\N
2654		Mercoxit Mining Cr		1	0	48_16		\N
2655		Omber Mining Cr		1	0	48_05		\N
2656		Plagioclase Mining Cr		1	0	48_04		\N
2657		Pyroxeres Mining Cr		1	0	48_03		\N
2658		Scordite Mining Cr		1	0	48_02		\N
2659		Spodumain Mining Cr		1	0	48_15		\N
2660		Veldspar Mining Cr		1	0	48_01		\N
2661		Phe		1	0	50_01		\N
2662		Syl		1	0	50_02		\N
2663	res:/Model/Missile/Missile_Paradise.blue	Survey		1	0	50_03		\N
2664		Com		1	0	50_04		\N
2665		Srea		1	0	50_05		\N
2666		Crea		1	0	50_06		\N
2667		Evap		1	0	50_07		\N
2668		Athmos		1	0	50_08		\N
2669		Hydroc		1	0	50_09		\N
2670		Sili		1	0	50_10		\N
2671		calcu		1	0	49_01		\N
2672		notepad		1	0	49_02		\N
2673		Note		1	0	49_03		\N
2674		Notes		1	0	49_04		\N
2675	stripminer	strip		1	0			\N
2676	iceminer	ice		1	0			\N
2677		probelauncher		1	0	49_07		\N
2678		ferrogel		1	0	49_08		\N
2679		gmetal		1	0	49_09		\N
2680		mmetal		1	0	49_10		\N
2681		cmetal		1	0	49_11		\N
2682		ametal		1	0	49_12		\N
2683	fermionic	ferm		1	0	49_13		\N
2684		Fulleride		1	0	49_14		\N
2685		synaptic		1	0	49_15		\N
2686		nanotrnasistors		1	0	49_16		\N
2687		ice1		1	0	51_01		\N
2688		ice2		1	0	51_02		\N
2689		Ice3		1	0	51_03		\N
2690		ice4		1	0	51_04		\N
2691		ice5		1	0	51_05		\N
2692		ice6		1	0	51_06		\N
2693		ice7		1	0	51_07		\N
2694		ice8		1	0	51_08		\N
2695		ice9		1	0	51_09		\N
2696		Strontium		1	0	51_10		\N
2697		ozone		1	0	51_11		\N
2698		Heavy water		1	0	51_12		\N
2699		helium iso		1	0	51_13		\N
2700		hydrogen iso		1	0	51_14		\N
2701		Oxigen ISo		1	0	51_15		\N
2702		nitrogen iso		1	0	51_16		\N
2703		Unknown	BluePrintBackdrop	1	0	09_15		\N
2704	res:/Model/Missile/Probe_Omni.blue	Omni Probe		1	0	40_14		\N
2705		Unknown	Red Cross Medal	1	0	50_16		\N
2706	res:/Model/WorldObject/Astrofarm/AstroFarm.blue	AstroFarm		1	0			\N
2707	res:/Model/WorldObject/Astrofarm/HumanFarm.blue	HumanFarm		1	0			\N
2708	res:/Model/WorldObject/Enviroments/ENV_Vulcan.blue	Volcanic Enviroment		1	0			\N
2709	res:/Model/Ship/Caldari_markII/ci2_Smuggler.blue	Unknown	Caldari elite industrial 1	1	0			\N
2710	res:/Model/Ship/Amarr_MarkII/ai2_Armored.blue	Amarr_MarkII\\ai2_Armored	Amarr elite industrial 2	1	0			\N
2711	res:/Model/Ship/Gallente_MarkII\\gi2_Smuggler.blue	Gallente_MarkII\\gi2_Smuggler	Gallente elite industrial 1	1	0			\N
2712	res:/Model/Ship/Gallente_MarkII\\gi4_Armored.blue	Gallente_MarkII\\gi4_Armored	Gallente elite industrial 2	1	0			\N
2713	res:/Model/Ship/Minmatar_MarkII\\mi2_Armored.blue	Minmatar_MarkII\\mi2_Armored	Minmatar elite industrial 2	1	0			\N
2714	res:/Model/Ship/Minmatar_MarkII\\mi2_Smuggler.blue	Minmatar_MarkII\\mi2_Smuggler	Minmatar elite industrial 1	1	0			\N
2715	res:/Model/Ship/Amarr/Ai3/Ai3.blue	Unknown	Amarr industrial 1	1	0			\N
2716	res:/Model/Ship/Amarr_MarkII/Ai3_Smuggler.blue	Unknown	Amarr elite industrial, smuggler.	1	0			\N
2717	res:/Model/WorldObject/Enviroments/ENV_Argon.blue	ENV_Argon		1	0			\N
2718	res:/Model/WorldObject/Enviroments/ENV_Dust_Devil.blue	ENV_Dust_Devil		1	0			\N
2719	res:/Model/WorldObject/Enviroments/ENV_ElectricStorm.blue	ENV_ElectricStorm		1	0			\N
2720	res:/Model/WorldObject/Enviroments/ENV_GhostWorld.blue	ENV_GhostWorld		1	0			\N
2721	res:/Model/WorldObject/Enviroments/ENV_Heaven.blue	ENV_Heaven		1	0			\N
2722	res:/Model/WorldObject/Enviroments/ENV_Hell.blue	ENV_Hell		1	0			\N
2723	res:/Model/WorldObject/Enviroments/ENV_Icefield.blue	ENV_Icefield		1	0			\N
2724	res:/Model/WorldObject/Enviroments/ENV_Krypton.blue	ENV_Krypton		1	0			\N
2725	res:/Model/WorldObject/Enviroments/ENV_Noir.blue	ENV_Noir		1	0			\N
2726	res:/Model/WorldObject/Enviroments/ENV_Poison.blue	ENV_Poison		1	0			\N
2727	res:/Model/WorldObject/Enviroments/ENV_Radon.blue	ENV_Radon		1	0			\N
2728	res:/Model/WorldObject/Enviroments/ENV_RainyDay.blue	ENV_RainyDay		1	0			\N
2729	res:/Model/WorldObject/Enviroments/ENV_Storm.blue	ENV_Storm		1	0			\N
2730	res:/Model/WorldObject/Enviroments/ENV_Vulcan.blue	ENV_Vulcan		1	0			\N
2731	res:/Model/WorldObject/Enviroments/ENV_Xenon.blue	ENV_Xenon		1	0			\N
2732		Unknown	Bioscanner/Asteroid Scanner	1	0	03_12		\N
2733		Unknown	Caldari propulsion jamming strength	1	0	22_49		\N
2734		Unknown	Gallente propulsion jamming strength	1	0	22_50		\N
2735		Unknown	Minmatar Propulsion Jamming Strength	1	0	22_51		\N
2736		Unknown	Amarr propulsion jamming strength	1	0	22_52		\N
2737	res:/Model/Ship/Minmatar/Mfr1/mfr1.blue	mfr1		1	0			\N
2738	res:/Model/Ship/Amarr/AFR1/afr1.blue	afr1		1	0			\N
2739	res:/Model/Ship/Gallente/gfr1/gfr1.blue	gfr1		1	0			\N
2740	res:/Model/Ship/Caldari/CFR1/Cfr1.blue	Cfr1		1	0			\N
2741	res:/Model/Face/fullbody_char/corpses/corpseMale123.blue	Unknown	Corpse commodity	1	0	11_05		\N
2742	res:/Model/Sentry/Beacon/JumpBeacon.blue	Cynosural_Field		1	0			\N
2743	res:/Model/Ship/Amarr\\ADN1\\ADN1.blue	Unknown	Amarr Dreadnought	1	0			\N
2744	res:/Model/Ship/Gallente\\gdr1\\gdr1.blue	Unknown	Gallente Dreadnought	1	0			\N
2745	ahe111	SiegeBeamLaser		1	0	13_02		\N
2746	ahe221	SiegePulseLaser		1	0	13_02		\N
2747	chh221	SiegeIonBlaster		1	0	13_02		\N
2748	ghh111	SiegeRailgun		1	0	13_02		\N
2749	mhp111	siegeAutocannon		1	0	13_02		\N
2750	mhp221	SiegeArtillery		1	0	13_02		\N
2751	res:/Model/Deployables/MobileBattleplatform/Battleplatform_Energy.blue	Battleplatform_Energy		1	0			\N
2752	res:/Model/Deployables/MobileBattleplatform/Battleplatform_Hybrid.blue	Battleplatform_Hybrid		1	0			\N
2753	res:/Model/Deployables/MobileBattleplatform/Battleplatform_Projectile.blue	Battleplatform_Projectile		1	0			\N
2754		Unknown	Safe deposit box	1	0	07_13		\N
2755	res:/Model/Ship/Minmatar/mdr/mdr1.blue	Minmatar Dreadnaught	Minmatar Dreadnaught	1	0			\N
2756		Unknown	Joint Harvesting corporation logo	1	0	c_15_4		\N
2757	res:/Model/outposts/Amarr/FactoryOutpost.blue	Unknown		1	0			\N
2758	res:/Model/outposts/minmatar/serviceOutpost.blue	Unknown	Minmatar Service Outpost	1	0			\N
2759	res:/Model/Ship/FactionPC/ConcordRenegadeB.blue	ConcordRenegadeB		1	0			\N
2760	res:/Model/Ship/FactionPC/ConcordRenegadeC.blue	ConcordRenegadeC		1	0			\N
2761	res:/Model/Ship/FactionPC/ConcordRenegadeF.blue	ConcordRenegadeF		1	0			\N
2762		Unknown	Brutor Tribe logo icon	1	0	c_20_2		\N
2763	res:/Model/Drone/New_Acolyte.blue	Unknown		1	0			\N
2764	res:/Model/Drone/New_Acolyte2.blue	Unknown		1	0			\N
2765	res:/Model/Drone/New_Berserker2.blue	Unknown		1	0			\N
2766	res:/Model/Drone/New_Hammerhead2.blue	Unknown		1	0			\N
2767	res:/Model/Drone/New_hobgoblin.blue	Unknown		1	0			\N
2768	res:/Model/Drone/New_Hornet2.blue	Unknown		1	0			\N
2769	res:/Model/Drone/New_Infiltrator2.blue	Unknown		1	0			\N
2770	res:/Model/Drone/New_wespa2.blue	Unknown		1	0			\N
2771	res:/Model/Drone/New_wespa.blue	Unknown		1	0			\N
2772	res:/Model/Drone/New_Valkyrie.blue	Unknown		1	0			\N
2773	res:/Model/Drone/New_Infiltrator.blue	Unknown		1	0			\N
2774	res:/Model/Drone/New_Hammerhead.blue	Unknown		1	0			\N
2775	res:/Model/Drone/New_Wespa2.blue	Unknown		1	0			\N
2776	res:/Model/Drone/New_Vespa.blue	Unknown		1	0			\N
2777	res:/Model/Drone/New_Hammerhead.blue	Unknown		1	0			\N
2778	res:/Model/Drone/New_infiltrator.blue	Unknown		1	0			\N
2779	res:/Model/Drone/New_hammerhead.blue	Unknown		1	0			\N
2780	res:/Model/Drone/New_Valkyrie.blue	Unknown		1	0			\N
2781	res:/Model/Station/Caldari/cs1/cs1_small.blue	Station	Station: Caldari 1, Small version to be used for complexes.	1	0		res:/Sound/Station/Station01.blue	\N
2782	res:/Model/Station/Gallente/gs4/gs4_small.blue	gs4	Gallente station, small version to be used for complexes	1	0		res:/Sound/Station/Station08.blue	\N
2783	res:/Model/outposts/go2_trade/go2_trade.blue	Unknown	Gallente Administration Outpost	1	0			\N
2784	res:/Model/outposts/Caldari/co2_research.blue	Unknown	Caldari Research Outpost	1	0			\N
2785	res:/Model/outposts/Amarr/FactoryOutpost.blue	Unknown	Amarr Factory Outpost	1	0			\N
2786	res:/Model/Ship/Caldari\\Cdr1\\CDR1.blue	Unknown	Caldari Dreadnought	1	0			\N
2787	res:/Model/Station/Bloodraider/Blood_as4.blue	Blood_as4		1	0			\N
2788	res:/Model/Station/Bloodraider/Blood_as5.blue	Blood_as5		1	0			\N
2789	res:/Model/Station/Bloodraider/Blood_as6.blue	Blood_as6		1	0			\N
2790	res:/Model/Worldobject/Defenses/Guristas/GuristaWall_NetWorkNode.blue	GuristaWall_NetWorkNode		1	0			\N
2791	res:/Model/Worldobject/Defenses/Guristas/GuristaWall_StasisVault.blue	GuristaWall_StasisVault		1	0			\N
2792	res:/Model/Worldobject/Defenses/Angel/AngelWall_NetWorkNode.blue	AngelWall_NetWorkNode		1	0			\N
2793	res:/Model/Worldobject/Defenses/Angel/AngelWall_StasisVault.blue	AngelWall_StasisVault		1	0			\N
2794	res:/Model/Ship/FactionPC/SebiestorBC1.blue	SebiestorBC1		1	0			\N
2795	res:/Model/Ship/FactionPC/BloodraiderBC1.blue	BloodraiderBC1		1	0			\N
2796	res:/Model/Ship/FactionPC/BloodraiderDEblue.blue	BloodraiderDEblue		1	0			\N
2797	res:/Model/Ship/FactionPC/BrutorBS.blue	BrutorBS		1	0			\N
2798	res:/Model/Ship/FactionPC/DuvolleBC1.blue	DuvolleBC1		1	0			\N
2799	res:/Model/Ship/FactionPC/DuvolleBS1.blue	DuvolleBS1		1	0			\N
2800	res:/Model/Ship/FactionPC/DuvolleDE1.blue	DuvolleDE1		1	0			\N
2801	res:/Model/Ship/FactionPC/KalakkiotaBC1.blue	KalakkiotaBC1		1	0			\N
2802	res:/Model/Ship/FactionPC/KalakkiotaDE1.blue	KalakkiotaDE1		1	0			\N
2803	res:/Model/Ship/FactionPC/KhanidB.blue	KhanidB		1	0			\N
2804	res:/Model/Ship/FactionPC/KhanidBC1.blue	KhanidBC1		1	0			\N
2805	res:/Model/Ship/FactionPC/KhanidDE1.blue	KhanidDE1		1	0			\N
2806	res:/Model/Ship/FactionPC/LaiDaiBS2.blue	LaiDaiBS2		1	0			\N
2807	res:/Model/Ship/FactionPC/MordusBC1.blue	MordusBC1		1	0			\N
2808	res:/Model/Ship/FactionPC/MordusDE1.blue	MordusDE1		1	0			\N
2809	res:/Model/Ship/FactionPC/RodinBC1.blue	RodinBC1		1	0			\N
2810	res:/Model/Ship/FactionPC/RodinBS1.blue	RodinBS1		1	0			\N
2811	res:/Model/Ship/FactionPC/RodinDE1.blue	RodinDE1		1	0			\N
2812	res:/Model/Ship/FactionPC/SanshaF.blue	SanshaF		1	0			\N
2813	res:/Model/Ship/FactionPC/SebiestorBS1.blue	SebiestorBS1		1	0			\N
2814	res:/Model/Ship/FactionPC/SebiestorDE1.blue	SebiestorDE1		1	0			\N
2815	res:/Model/Ship/FactionPC/ThukkerBC1.blue	ThukkerBC1		1	0			\N
2816	res:/Model/Ship/FactionPC/ThukkerDE1.blue	ThukkerDE1		1	0			\N
2817	res:/Model/Ship/FactionPC/ViziamBC1.blue	ViziamBC1		1	0			\N
2818	res:/Model/Drone/Acolyte1.blue	Acolyte1		1	0			\N
2819	res:/Model/Drone/Berserker1.blue	Berserker1		1	0			\N
2820	res:/Model/Drone/hammerhead1.blue	hammerhead1		1	0			\N
2821	res:/Model/Drone/Hobgoblin1.blue	Hobgoblin1		1	0			\N
2822	res:/Model/Drone/Hornet1.blue	Hornet1		1	0			\N
2823	res:/Model/Drone/Ogre1.blue	Ogre1		1	0			\N
2824	res:/Model/Drone/Praeator1.blue	Praeator1		1	0			\N
2825	res:/Model/Drone/Wasp1.blue	Wasp1		1	0			\N
2826	res:/Model/Drone/Warrior1.blue	Warrior1		1	0			\N
2827		Unknown	XL Carbonized Lead Ammo	1	0	52_01		\N
2828		Unknown	XL Depleted Uranium Ammo	1	0	52_02		\N
2829		Unknown	XL EMP Ammo	1	0	52_03		\N
2830		Unknown	XL Fusion Ammo	1	0	52_04		\N
2831		Unknown	XL Nuclear (explosive) Ammo	1	0	52_05		\N
2832		Unknown	XL Phased Plasma Ammo	1	0	52_06		\N
2833		Unknown	XL Proton (Photon) Ammo	1	0	52_07		\N
2834		Unknown	XL Titanium Sabot Ammo	1	0	52_08		\N
2835		Unknown	Aura's (Ship computer) Face	1	0	52_09		\N
2836	chh221	Unknown	Siege Blaster Cannon	1	0	52_10		\N
2837	ahe111	Unknown	Siege Beam Laser	1	0	52_11		\N
2838	mhp111	Unknown	Siege Autocannon	1	0	52_12		\N
2839		Unknown	Siege (XL) Missile Launcher	1	0	52_13		\N
2840	ghh111	Unknown	Siege Railgun	1	0	52_14		\N
2841	ahe221	Unknown	Siege Pulse Laser	1	0	52_15		\N
2842	mhp221	Unknown	Siege Artillery (XL)	1	0	52_16		\N
2843		Unknown	XL Antimatter Charge	1	0	53_01		\N
2844		Unknown	XL Iridium Charge	1	0	53_02		\N
2845		Unknown	XL Iron Charge	1	0	53_03		\N
2846		Unknown	XL Lead Charge	1	0	53_04		\N
2847		Unknown	XL Plutonium Charge	1	0	53_05		\N
2848		Unknown	XL Thorium Charge	1	0	53_06		\N
2849		Unknown	XL Tungsten Charge	1	0	53_07		\N
2850		Unknown	XL Uranium Charge	1	0	53_08		\N
2851		Unknown	Siege Mode Module	1	0	53_09		\N
2852		Unknown	Drill (mission item)	1	0	53_10		\N
2853		Unknown	Treasure Map (Electronic)	1	0	53_11		\N
2854		Unknown	Cattle (moo!)	1	0	53_12		\N
2855		Unknown	Corpse icon	1	0	53_13		\N
2856		Unknown	Codebreaker Module	1	0	53_14		\N
2857		Unknown	Analyzer Module (ancient artifact scanner)	1	0	53_15		\N
2858		Unknown	Leadership Module	1	0	53_16		\N
2859		Unknown	Capital Propulsion Engine	1	0	54_01		\N
2860		Unknown	Capital Turret Hardpoint	1	0	54_02		\N
2861		Unknown	Capital Sensor Array	1	0	54_03		\N
2862		Unknown	Capital Armor Plates	1	0	54_04		\N
2863		Unknown	Capital Capacitor Battery	1	0	54_05		\N
2864		Unknown	Capital Power Generator	1	0	54_06		\N
2865		Unknown	Capital Shield Generator	1	0	54_07		\N
2866		Unknown	Capital Jump Drive	1	0	54_08		\N
2867		Unknown	Capital Cargo Bay	1	0	54_09		\N
2868		Unknown	Capital Drone Bay	1	0	54_10		\N
2869		Unknown	Capital Computer System	1	0	54_11		\N
2870		Unknown	Capital Construction Parts	1	0	54_12		\N
2871		Unknown	Capital Siege Array	1	0	54_13		\N
2872		Unknown	Capital Launcher Hardpoint	1	0	54_14		\N
2873		Unknown	Station Mission Network	1	0	54_15		\N
2874		Unknown	Station Office Center	1	0	54_16		\N
2875		Unknown	Station Construction Parts	1	0	55_01		\N
2876		Unknown	Station Hangar Array	1	0	55_02		\N
2877		Unknown	Station Storage Bay	1	0	55_03		\N
2878		Unknown	Station Laboratory	1	0	55_04		\N
2879		Unknown	Station Factory	1	0	55_05		\N
2880		Unknown	Station Repair Facility	1	0	55_06		\N
2881		Unknown	Station Reprocessing Plant	1	0	55_07		\N
2882		Unknown	Station Docking Array	1	0	55_08		\N
2883		Unknown	Station Market Network	1	0	55_09		\N
2884		Unknown	Station Medical Center	1	0	55_10		\N
2885		Unknown	Modern Data	1	0	55_11		\N
2886		Unknown	Ancient Data	1	0	55_12		\N
2887		Unknown	Modern Devices	1	0	55_13		\N
2888		Unknown	Modern Spare Parts	1	0	55_14		\N
2889		Unknown	Ancient Relics	1	0	55_15		\N
2890		Unknown	Ancient Mechanical Parts	1	0	55_16		\N
2891		Unknown	Scientist	1	0	46_12		\N
2892	res:/Model/WorldObject/Capsule/Capsule_1000x	HugeCapsule		1	0	02_14		\N
2893		Unknown	Skull and crossbones icon	1	0	04_16		\N
2894	res:/Model/Ship/Minmatar/mca1/mca1.blue	mca1	Minmatar Mothership	1	0			\N
2895	res:/Model/Ship/IntakiSyndicate/gde1_IntakiSyndicate.blue	gde1_IntakiSyndicate		1	0			\N
2896	res:/Model/Ship/Sarum/ade1_Sarum.blue	ade1_Sarum		1	0			\N
2897	res:/Model/WorldObject/TurnipRock/turnipWhite.blue	Unknown	White and silvery turnip-shaped asteroid	1	0			\N
2898	res:/Model/WorldObject/Asteroid_Station_Dark/ast_station_dark.blue	Unknown	Dark and spiky asteroid station	1	0			\N
2899	res:/Model/Fighter/Amarr/Afighter1.blue	Amarr Fighter		1	0			\N
2900	res:/Model/WorldObject/CrystalAsteroid/ClovenAsteroid.blue	Unknown	A large grey cloven asteroid.	1	0			\N
2901	res:/Model/WorldObject/CrystalAsteroid/ClovenAsteroid_Red.blue	Unknown	A large reddish-brown cloven asteroid.	1	0			\N
2902	res:/Model/WorldObject/CrystalAsteroid/CrystalAsteroid_Blue.blue	Unknown	Broken asteroid with blue crystals.	1	0			\N
2903	res:/Model/WorldObject/CrystalAsteroid/CrystalAsteroid_Clear.blue	Unknown	Broken asteroid with metallic crystals.	1	0			\N
2904	res:/Model/WorldObject/CrystalAsteroid/CrystalAsteroid_Orange.blue	Unknown	Broken asteroid with orange crystals	1	0			\N
2905	res:/Model/ship/Amarr/aca2/aca2.blue	AmarrCarrier		1	0			\N
2906	res:/Model/Ship/Minmatar/mt1/mt1.blue	Unknown	Minmatar Titan	1	0			\N
2907	res:/Model/WorldObject/Warpgate/Wormhole.blue	WarpWormhole		1	0			\N
2908		Unknown	Official Document	1	0	07_03		\N
2909	res:/Model/Ship/Gallente/gms1/gms1.blue	Unknown	Gallente mothership	1	0			\N
2910	res:/Model/Ship/Amarr/At1/AT1.blue	Amarr Titan		1	0			\N
2911	res:/Model/Ship/Amarr/ACA1/ACA1.blue	Amarr Carrier		1	0			\N
2912	res:/Model/Ship/FactionPC/BrutorBC1.blue	BrutorBC1		1	0			\N
2913	res:/Model/Ship/FactionPC/BrutorDE1.blue	BrutorDE1		1	0			\N
2914	res:/Model/Ship/FactionPC/ConcordRenegadeB.blue	ConcordRenegadeB		1	0			\N
2915	res:/Model/Ship/FactionPC/ConcordRenegadeC.blue	ConcordRenegadeC		1	0			\N
2916	res:/Model/Ship/FactionPC/ConcordRenegadeF.blue	ConcordRenegadeF		1	0			\N
2917	res:/Model/Ship/FactionPC/GuardianBC1.blue	GuardianBC1		1	0			\N
2918	res:/Model/Ship/FactionPC/GuardianDE1.blue	GuardianDE1		1	0			\N
2919	res:/Model/Ship/FactionPC/GuristasBC1.blue	GuristasBC1		1	0			\N
2920	res:/Model/Ship/FactionPC/GuristasDE1.blue	GuristasDE1		1	0			\N
2921	res:/Model/Ship/FactionPC/ThukkerBC1.blue	ThukkerBC1		1	0			\N
2922	res:/Model/Ship/FactionPC/ThukkerDE1.blue	ThukkerDE1		1	0			\N
2923	res:/Model/Ship/FactionPC/ThukkerF1.blue	ThukkerF1		1	0			\N
2924	res:/Model/Ship/FactionPC/ThukkerF5.blue	ThukkerF5		1	0			\N
2925	res:/Model/Ship/IntakiSyndicate/gbc1_IntakiSyndicate.blue	gbc1_IntakiSyndicate		1	0			\N
2926	res:/Model/Ship/Sarum/ABC1_Sarum.blue	ABC1_Sarum		1	0			\N
2927	res:/Model/WorldObject/Ammatar_Battlestation/ammbs1.blue	Unknown	Ammatar Station 1 (intended as a battlestation)	1	0			\N
2928	res:/Model/ship/Caldari/cms1/cms1.blue	Unknown	Caldari Mothership	1	0			\N
2929	res:/Model/Ship/Minmatar/mca2/mca2.blue	Unknown	Minmatar carrier	1	0			\N
2930	res:/Model/ship/Caldari/ct2/Ct2.blue	Unknown	Caldari Titan	1	0			\N
2931	res:/Model/ship/Caldari/cca1/cca1.blue	Unknown	Caldari carrier	1	0			\N
2932	res:/Model/Ship/Gallente/gca2/gca2.blue	Unknown	Gallente Carrier	1	0			\N
2933	res:/Model/WorldObject/Cloud/DebrisstormFlat.blue	DebrisCloudFlat		1	0			\N
2934	IonStorm	Ion		1	0	56_02		\N
2935	MissileStrike	MissileS		1	0	56_02		\N
2936	Singularity	Singul		1	0	56_02		\N
2937	Sunburst	Sun		1	0	56_02		\N
2938	res:/Model/Ship/ORE/OreL_II.blue	OreL_II		1	0			\N
2939	res:/Model/Ship/ORE/OreM_II.blue	OreM_II		1	0			\N
2940	res:/Model/Ship/ORE/OreS_II.blue	OreS_II		1	0			\N
2941	res:/Model/WorldObject/wsign/wsign.blue	Unknown	wsign	1	0			\N
2942	res:/Model/Ship/Gallente/gt2/gt2.blue	Unknown	Gallente Titan	1	0			\N
2943	res:/Model/Missile/Missile_Snowstorm.blue	Snowball	Snowball missile	1	0	57_04		\N
2944	res:/Model/Deployables/FinalDeployables/AssemblyArray_Final.blue	AssemblyArray_Final		1	0			\N
2945	res:/Model/Deployables/FinalDeployables/Shipyard_Final.blue	Shipyard_Final		1	0			\N
2946	res:/Model/Deployables/FinalDeployables/Small_Academy_Final.blue	Small_Academy_Final		1	0			\N
2947	res:/Model/Drone/New_AcolyteX1.blue	New_AcolyteX1		1	0			\N
2948	res:/Model/Drone/New_AcolyteX2.blue	New_AcolyteX2		1	0			\N
2949	res:/Model/Drone/New_BerserkerX1.blue	New_BerserkerX1		1	0			\N
2950	res:/Model/Drone/New_BerserkerX2.blue	New_BerserkerX2		1	0			\N
2951	res:/Model/Drone/New_HammerheadX1.blue	New_HammerheadX1		1	0			\N
2952	res:/Model/Drone/New_HammerheadX2.blue	New_HammerheadX2		1	0			\N
2953	res:/Model/Drone/New_hobgoblinX1.blue	New_hobgoblinX1		1	0			\N
2954	res:/Model/Drone/New_hobgoblinX2.blue	New_hobgoblinX2		1	0			\N
2955	res:/Model/Drone/New_HornetX1.blue	New_HornetX1		1	0			\N
2956	res:/Model/Drone/New_HornetX2.blue	New_HornetX2		1	0			\N
2957	res:/Model/Drone/New_InfiltratorX1.blue	New_InfiltratorX1		1	0			\N
2958	res:/Model/Drone/New_InfiltratorX2.blue	New_InfiltratorX2		1	0			\N
2959	res:/Model/Drone/New_OgreX1.blue	New_OgreX1		1	0			\N
2960	res:/Model/Drone/New_OgreX2.blue	New_OgreX2		1	0			\N
2961	res:/Model/Drone/New_PraeatorX1.blue	New_PraeatorX1		1	0			\N
2962	res:/Model/Drone/New_PraeatorX2.blue	New_PraeatorX2		1	0			\N
2963	res:/Model/Drone/New_ValkyrieX1.blue	New_ValkyrieX1		1	0			\N
2964	res:/Model/Drone/New_ValkyrieX2.blue	New_ValkyrieX2		1	0			\N
2965	res:/Model/Drone/New_WarriorX1.blue	New_WarriorX1		1	0			\N
2966	res:/Model/Drone/New_WarriorX2.blue	New_WarriorX2		1	0			\N
2967	res:/Model/Drone/New_WaspX1.blue	New_WaspX1		1	0			\N
2968	res:/Model/Drone/New_WaspX2.blue	New_WaspX2		1	0			\N
2969	res:/Model/Drone/New_wespaX1.blue	New_wespaX1		1	0			\N
2970	res:/Model/Drone/New_wespaX2.blue	New_wespaX2		1	0			\N
2971		Unknown	Stealth module icon	1	0	36_13		\N
2972	res:/Model/Fighter/Gallente/Gfighter1.blue	Unknown	Gallente Fighter	1	0			\N
2973	res:/Model/Fighter/Minmatar/mfi.blue	Unknown	Minmatar Fighter	1	0			\N
2974		Unknown	Ballistic Control System (heat thingamajig)	1	0	36_16		\N
2975	res:/Model/Fighter/caldari/Cfighter1.blue	Unknown	Caldari Fighter	1	0			\N
2976	res:/Model/Deployables/Titanyard/Titanyard.blue	Unknown	Capitalship Construction Shipyard	1	0			\N
2977	res:/Model/Deployables/Titanyard/Titanyard.blue	Superconstructor	Builds big mother fuckers	1	0			\N
2978	res:/Model/Drone/BlasterSentry.blue	BlasterSentry		1	0			\N
2979	res:/Model/Drone/CannonSentry.blue	CannonSentry		1	0			\N
2980	res:/Model/Drone/LaserSentry.blue	LaserSentry		1	0			\N
2981	res:/Model/Drone/RailgunSentry.blue	RailgunSentry		1	0			\N
2982	res:/Model/WorldObject/Amholydome/amholydome.blue	Unknown	Ammatar Holy Dome Ruins	1	0			\N
2983		Unknown	Target Painter	1	0	56_01		\N
2984		Unknown	Superweapon	1	0	56_02		\N
2985		Unknown	Jump Portal Module	1	0	56_03		\N
2986		Unknown	Tractor Beam	1	0	56_04		\N
2987		Unknown	Drone Command Module	1	0	56_05		\N
2988		Unknown	Drone Navigation Module	1	0	56_06		\N
2989		Unknown	Drone Range Link Module	1	0	56_07		\N
2990		Unknown	Probe Launcher	1	0	56_08		\N
2991		Unknown	Personal Armor	1	0	56_09		\N
2992		Unknown	Doll	1	0	56_10		\N
2993		Unknown	F.O.N. Protest Banner	1	0	56_11		\N
2994		Unknown	White Chip (1)	1	0	56_12		\N
2995		Unknown	Red Chip (5)	1	0	56_13		\N
2996		Unknown	Blue Chip (10)	1	0	56_14		\N
2997		Unknown	Green Chip (25)	1	0	56_15		\N
2998		Unknown	56_16	1	0	Black Chip (100)		\N
2999		Unknown	Purple Chip (500)	1	0	57_01		\N
3000		Unknown	Gold Chip (1000)	1	0	57_02		\N
3001		Unknown	CONCORD Pilot's License (intended for 28 days)	1	0	57_03		\N
3002		Unknown	Snowballs	1	0	57_04		\N
3003		Unknown	Starbase Charter (Minmatar)	1	0	57_06		\N
3004		Unknown	Starbase Charter (Caldari)	1	0	57_07		\N
3005		Unknown	Starbase Charter (Gallente)	1	0	57_08		\N
3006		Unknown	Manufacturing & Research (All activities)	1	0	57_09		\N
3007		Unknown	Manufacturing	1	0	57_10		\N
3008		Unknown	Material Research	1	0	57_11		\N
3009		Unknown	Time Efficiency Research	1	0	57_12		\N
3010		Unknown	Blueprint Copying	1	0	57_13		\N
3011		Unknown	Item Duplicating	1	0	57_14		\N
3012		Unknown	Reverse Engineering	1	0	57_15		\N
3013		Unknown	Technology Research	1	0	57_16		\N
3014	res:/Model/Ship/Booster/booster_.blue2.blue	booster_.blue2		1	0			\N
3015	res:/Model/Ship/Booster/booster_green2.blue	booster_green2		1	0			\N
3016	res:/Model/Ship/Booster/booster_red2.blue	booster_red2		1	0			\N
3017	res:/Model/Ship/Booster/booster_yellow2.blue	booster_yellow2		1	0			\N
3018	res:/Model/Effect/WarpDisruptorBubble.blue	Warp Disruptor Bubble		1	0	34_01		\N
3019		Unknown	Capital Clone Bay	1	0	58_01		\N
3020	res:/Model/Ship/Caldari_markII/ci3_Armored.blue	Unknown	Caldari Elite Industrial 2	1	0			\N
3021		Unknown	Vherokior Logo icon	1	0	59_01		\N
3022		Unknown	Achura Logo icon	1	0	59_02		\N
3023		Unknown	Khanid Logo icon	1	0	59_03		\N
3024		Unknown	Jin-Mei Logo icon	1	0	59_04		\N
3025		Unknown	Ancestry icon for Achura: Inventors	1	0	58_02		\N
3026		Unknown	Ancestry icon for Achura: Stargazers	1	0	58_03		\N
3027		Unknown	Ancestry icon for Achura: Monks	1	0	58_04		\N
3028		Unknown	Ancestry icon for Jin-Mei: Sang Do Caste	1	0	58_05		\N
3029		Unknown	Ancestry icon for Jin-Mei: Saan Go Caste	1	0	58_06		\N
3030		Unknown	Ancestry icon for Jin-Mei: Jing Ko Caste	1	0	58_07		\N
3031		Unknown	Ancestry icon for Khanid: Cyber Knights	1	0	58_09		\N
3032		Unknown	Ancestry icon for Khanid: Unionists	1	0	58_10		\N
3033		Unknown	Ancestry icon for Khanid: Zealots	1	0	58_11		\N
3034		Unknown	Ancestry icon for Vherokior: Mystics	1	0	58_14		\N
3035		Unknown	Ancestry icon for Vherokior: Retailers	1	0	58_15		\N
3036		Unknown	Ancestry icon for Vherokior: Drifters	1	0	58_13		\N
3037	res:/Model/Ship/Amarr/ab3/ab3.blue	tier 3 amarr		1	0			\N
3038		Unknown	News Service Icon	1	0	17_03		\N
\.


--
-- Name: eveGraphics eveGraphics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."eveGraphics"
    ADD CONSTRAINT "eveGraphics_pkey" PRIMARY KEY ("graphicID");


--
-- PostgreSQL database dump complete
--

\unrestrict 1vVnet9fIDvHcZvUoAl9HRDX4Oy5ubmXNQ75Nn5I51VorX9bBrvxFTKzAsb4V2x

