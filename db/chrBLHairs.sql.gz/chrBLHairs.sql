--
-- PostgreSQL database dump
--

\restrict vKIHMACdPkHECmqwVgj2ZyyjycmkURdwcH2GnuGBFGnhntScp15fwh4iOosDUqf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLHairs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLHairs" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "hairID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLHairs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLHairs" ("bloodlineID", gender, "hairID", npc) FROM stdin;
1	0	2	0
1	0	4	0
1	0	10	0
1	0	12	0
1	0	13	0
1	0	20	0
1	0	75	0
1	0	82	0
1	0	83	0
1	0	90	0
1	0	91	0
1	0	92	0
1	0	93	0
1	1	1	0
1	1	2	0
1	1	3	0
1	1	4	0
1	1	10	0
1	1	14	0
1	1	87	0
1	1	94	0
1	1	95	0
1	1	96	0
1	1	97	0
1	1	98	0
2	0	1	0
2	0	2	0
2	0	3	0
2	0	4	0
2	0	29	0
2	0	73	0
2	0	74	0
2	0	75	0
2	0	76	0
2	0	77	0
2	0	78	0
2	0	79	0
2	0	80	0
2	0	81	0
2	1	1	0
2	1	2	0
2	1	3	0
2	1	4	0
2	1	5	0
2	1	10	0
2	1	11	0
2	1	12	0
2	1	13	0
2	1	14	0
2	1	16	0
2	1	20	0
2	1	28	0
2	1	82	0
2	1	83	0
2	1	84	0
2	1	85	0
2	1	86	0
2	1	87	0
2	1	88	0
2	1	89	0
3	0	1	0
3	0	2	0
3	0	3	0
3	0	4	0
3	0	5	0
3	0	10	0
3	0	11	0
3	0	12	0
3	0	13	0
3	0	14	0
3	0	16	0
3	0	20	0
3	0	21	0
3	0	22	0
3	0	23	0
3	0	24	0
3	0	25	0
3	0	26	0
3	0	27	0
3	0	28	0
3	0	29	0
3	0	30	0
3	1	2	0
3	1	4	0
3	1	5	0
3	1	10	0
3	1	11	0
3	1	12	0
3	1	13	0
3	1	16	0
3	1	30	0
3	1	31	0
3	1	32	0
3	1	33	0
3	1	34	0
3	1	35	0
3	1	36	0
3	1	37	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	0	9	0
4	1	1	0
4	1	2	0
4	1	4	0
4	1	5	0
4	1	9	0
4	1	10	0
4	1	11	0
4	1	12	0
4	1	13	0
4	1	14	0
4	1	15	0
4	1	16	0
4	1	17	0
4	1	18	0
4	1	19	0
5	0	38	0
5	0	39	0
5	0	40	0
5	0	41	0
5	0	42	0
5	0	43	0
5	0	44	0
5	0	45	0
5	0	46	0
5	0	47	0
5	0	48	0
5	0	49	0
5	1	16	0
5	1	47	0
5	1	50	0
5	1	51	0
5	1	52	0
5	1	53	0
5	1	54	0
6	0	1	0
6	0	2	0
6	0	19	0
6	0	55	0
6	0	56	0
6	0	57	0
6	0	58	0
6	0	59	0
6	0	60	0
6	0	61	0
6	0	62	0
6	0	63	0
6	0	64	0
6	0	65	0
6	0	66	0
6	1	16	0
6	1	67	0
6	1	68	0
6	1	69	0
6	1	70	0
6	1	71	0
6	1	72	0
7	0	1	0
7	0	2	0
7	0	3	0
7	0	4	0
7	0	5	0
7	0	11	0
7	0	12	0
7	0	13	0
7	0	14	0
7	0	81	0
7	0	99	0
7	0	100	0
7	0	101	0
7	0	102	0
7	0	103	0
7	0	104	0
7	0	105	0
7	0	106	0
7	1	1	0
7	1	2	0
7	1	3	0
7	1	4	0
7	1	10	0
7	1	12	0
7	1	13	0
7	1	42	0
7	1	82	0
7	1	83	0
7	1	107	0
7	1	108	0
7	1	109	0
7	1	110	0
7	1	111	0
7	1	112	0
7	1	113	0
7	1	114	0
7	1	115	0
7	1	116	0
7	1	117	0
7	1	118	0
7	1	119	0
7	1	120	0
7	1	121	0
7	1	122	0
8	0	1	0
8	0	2	0
8	0	3	0
8	0	4	0
8	0	5	0
8	0	10	0
8	0	11	0
8	0	12	0
8	0	13	0
8	0	14	0
8	0	20	0
8	0	82	0
8	0	83	0
8	0	90	0
8	0	91	0
8	0	123	0
8	0	124	0
8	0	125	0
8	0	126	0
8	0	127	0
8	0	128	0
8	1	1	0
8	1	2	0
8	1	3	0
8	1	4	0
8	1	5	0
8	1	10	0
8	1	11	0
8	1	12	0
8	1	13	0
8	1	14	0
8	1	20	0
8	1	46	0
8	1	82	0
8	1	129	0
8	1	130	0
8	1	131	0
11	0	133	0
11	0	134	0
11	0	135	0
11	0	136	0
11	0	137	0
11	0	174	0
11	0	175	0
11	0	176	0
11	0	177	0
11	0	178	0
11	0	179	0
11	0	180	0
11	1	190	0
11	1	191	0
11	1	192	0
11	1	193	0
11	1	194	0
11	1	195	0
11	1	196	0
11	1	197	0
11	1	198	0
11	1	199	0
12	0	90	0
12	0	91	0
12	0	123	0
12	0	134	0
12	0	135	0
12	0	136	0
12	0	137	0
12	0	138	0
12	0	139	0
12	0	140	0
12	0	141	0
12	0	149	0
12	0	163	0
12	0	172	0
12	0	173	0
12	1	16	0
12	1	206	0
12	1	207	0
12	1	208	0
12	1	209	0
12	1	210	0
12	1	211	0
12	1	212	0
12	1	213	0
12	1	214	0
12	1	215	0
12	1	216	0
13	0	133	0
13	0	134	0
13	0	135	0
13	0	163	0
13	0	164	0
13	0	165	0
13	0	166	0
13	0	167	0
13	0	179	0
13	0	180	0
13	0	181	0
13	0	182	0
13	0	183	0
13	0	184	0
13	0	185	0
13	0	186	0
13	0	187	0
13	0	188	0
13	0	189	0
13	1	199	0
13	1	217	0
13	1	218	0
13	1	219	0
13	1	220	0
13	1	221	0
13	1	222	0
13	1	223	0
13	1	224	0
13	1	225	0
13	1	226	0
13	1	227	0
13	1	228	0
13	1	229	0
14	0	1	0
14	0	2	0
14	0	3	0
14	0	4	0
14	0	5	0
14	0	6	0
14	0	8	0
14	0	9	0
14	0	168	0
14	0	169	0
14	0	170	0
14	0	171	0
14	1	16	0
14	1	23	0
14	1	200	0
14	1	201	0
14	1	202	0
14	1	203	0
14	1	204	0
14	1	205	0
\.


--
-- Name: chrBLHairs chrBLHairs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLHairs"
    ADD CONSTRAINT "chrBLHairs_pkey" PRIMARY KEY ("bloodlineID", gender, "hairID");


--
-- PostgreSQL database dump complete
--

\unrestrict vKIHMACdPkHECmqwVgj2ZyyjycmkURdwcH2GnuGBFGnhntScp15fwh4iOosDUqf

