--
-- PostgreSQL database dump
--

\restrict hZeSYlbpADCRULNUWiov8yaemHzsJKVdCEasfYauRBSOlifQRcLQ4nb6P5yVxcB

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invBlueprints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invBlueprints" (
    "itemID" integer NOT NULL,
    copy smallint DEFAULT 0 NOT NULL,
    "materialLevel" integer DEFAULT 0 NOT NULL,
    "productivityLevel" integer DEFAULT 0 NOT NULL,
    "licensedProductionRunsRemaining" integer DEFAULT '-1'::integer NOT NULL
);


--
-- Name: TABLE "invBlueprints"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."invBlueprints" IS 'MADE: what research and copying have done to one blueprint item. A blueprint without a row is an original at level 0 (the client''s own default, manufacturing.py GetSubContent).';


--
-- Name: COLUMN "invBlueprints".copy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."invBlueprints".copy IS 'PROVEN: 1 for a copy; copies cannot be researched or copied (RamCannotResearchABlueprintCopy, RamCannotCopyABlueprintCopy).';


--
-- Name: COLUMN "invBlueprints"."materialLevel"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."invBlueprints"."materialLevel" IS 'PROVEN: the M.E. a material research job raises by its runs (manufacturing.py ShowJobDetails, End M.E.).';


--
-- Name: COLUMN "invBlueprints"."productivityLevel"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."invBlueprints"."productivityLevel" IS 'PROVEN: the P.E. a time research job raises by its runs (manufacturing.py ShowJobDetails, End P.E.).';


--
-- Name: COLUMN "invBlueprints"."licensedProductionRunsRemaining"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."invBlueprints"."licensedProductionRunsRemaining" IS 'PROVEN: -1 for an original; a copy''s runs left, used up by manufacturing (RamTooManyProductionRuns).';


--
-- Data for Name: invBlueprints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invBlueprints" ("itemID", copy, "materialLevel", "productivityLevel", "licensedProductionRunsRemaining") FROM stdin;
\.


--
-- Name: invBlueprints invBlueprints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invBlueprints"
    ADD CONSTRAINT "invBlueprints_pkey" PRIMARY KEY ("itemID");


--
-- PostgreSQL database dump complete
--

\unrestrict hZeSYlbpADCRULNUWiov8yaemHzsJKVdCEasfYauRBSOlifQRcLQ4nb6P5yVxcB

