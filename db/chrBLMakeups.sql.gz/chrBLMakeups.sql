--
-- PostgreSQL database dump
--

\restrict CTNAvHP9H00eFJeIi8CQKL6ege5ht2OKLI7jrGnbYrKr10B49gptbeZcQDqLzef

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLMakeups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLMakeups" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "makeupID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLMakeups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLMakeups" ("bloodlineID", gender, "makeupID", npc) FROM stdin;
1	0	1	0
1	0	2	0
1	0	3	0
1	0	4	0
1	0	5	0
1	0	6	0
1	0	7	0
1	0	8	0
1	0	9	0
1	0	16	0
1	0	20	0
1	0	21	0
1	0	35	0
1	0	37	0
1	0	38	0
1	0	39	0
1	0	40	0
1	0	44	0
1	0	45	0
1	0	47	0
1	0	48	0
1	0	49	0
1	0	50	0
1	0	51	0
2	0	1	0
2	0	2	0
2	0	4	0
2	0	5	0
2	0	6	0
2	0	7	0
2	0	8	0
2	0	9	0
2	0	16	0
2	0	20	0
2	0	21	0
2	0	35	0
2	0	36	0
2	0	37	0
2	0	38	0
2	0	39	0
2	0	40	0
2	0	41	0
2	0	42	0
2	0	43	0
2	0	44	0
2	0	45	0
2	0	46	0
3	0	1	0
3	0	2	0
3	0	3	0
3	0	4	0
3	0	5	0
3	0	6	0
3	0	7	0
3	0	8	0
3	0	9	0
3	0	10	0
3	0	11	0
3	0	12	0
3	0	13	0
3	0	14	0
3	0	16	0
3	0	18	0
3	0	19	0
3	0	20	0
3	0	21	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	0	9	0
4	0	10	0
4	0	11	0
4	0	12	0
4	0	13	0
4	0	14	0
4	0	15	0
4	0	16	0
4	0	17	0
4	0	18	0
4	0	19	0
5	0	16	0
5	0	22	0
5	0	23	0
5	0	24	0
5	0	25	0
5	0	26	0
5	0	27	0
5	0	28	0
5	0	29	0
5	0	30	0
5	0	31	0
5	0	32	0
5	0	33	0
5	0	34	0
6	0	1	0
6	0	2	0
6	0	3	0
6	0	4	0
6	0	7	0
6	0	8	0
6	0	9	0
6	0	20	0
6	0	21	0
6	0	35	0
7	0	1	0
7	0	2	0
7	0	3	0
7	0	4	0
7	0	5	0
7	0	6	0
7	0	7	0
7	0	8	0
7	0	9	0
7	0	16	0
7	0	19	0
7	0	20	0
7	0	21	0
7	0	22	0
7	0	35	0
7	0	37	0
7	0	38	0
7	0	39	0
7	0	40	0
7	0	42	0
7	0	43	0
7	0	44	0
7	0	45	0
7	0	47	0
7	0	48	0
7	0	49	0
7	0	50	0
7	0	51	0
7	0	52	0
7	0	53	0
7	0	54	0
7	0	55	0
7	0	56	0
7	0	57	0
7	0	58	0
7	0	59	0
8	0	1	0
8	0	2	0
8	0	3	0
8	0	4	0
8	0	6	0
8	0	9	0
8	0	16	0
8	0	19	0
8	0	21	0
8	0	22	0
8	0	35	0
8	0	37	0
8	0	38	0
8	0	39	0
8	0	40	0
8	0	42	0
8	0	43	0
8	0	44	0
8	0	45	0
8	0	47	0
8	0	48	0
8	0	49	0
8	0	50	0
8	0	51	0
8	0	52	0
8	0	53	0
8	0	54	0
8	0	55	0
8	0	56	0
8	0	57	0
8	0	58	0
8	0	59	0
11	0	19	0
11	0	66	0
11	0	69	0
11	0	70	0
11	0	71	0
11	0	72	0
11	0	73	0
11	0	74	0
11	0	75	0
12	0	2	0
12	0	3	0
12	0	5	0
12	0	8	0
12	0	9	0
12	0	16	0
12	0	21	0
12	0	35	0
12	0	37	0
12	0	38	0
13	0	16	0
13	0	60	0
13	0	61	0
13	0	62	0
13	0	63	0
13	0	64	0
13	0	65	0
13	0	66	0
13	0	76	0
14	0	16	0
14	0	22	0
14	0	23	0
14	0	25	0
14	0	27	0
14	0	29	0
14	0	30	0
14	0	32	0
14	0	67	0
14	0	68	0
\.


--
-- Name: chrBLMakeups chrBLMakeups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLMakeups"
    ADD CONSTRAINT "chrBLMakeups_pkey" PRIMARY KEY ("bloodlineID", gender, "makeupID");


--
-- PostgreSQL database dump complete
--

\unrestrict CTNAvHP9H00eFJeIi8CQKL6ege5ht2OKLI7jrGnbYrKr10B49gptbeZcQDqLzef

