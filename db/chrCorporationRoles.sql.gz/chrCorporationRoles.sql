--
-- PostgreSQL database dump
--

\restrict eXieagX12pUdOMl6bopXd33iUBkpfDQXcIAME57MXau1BcONvoyTcyMma6ms9dN

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrCorporationRoles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrCorporationRoles" (
    "characterID" integer DEFAULT 0 NOT NULL,
    corprole bigint DEFAULT 0 NOT NULL,
    "rolesAtAll" bigint DEFAULT 0 NOT NULL,
    "rolesAtBase" bigint DEFAULT 0 NOT NULL,
    "rolesAtHQ" bigint DEFAULT 0 NOT NULL,
    "rolesAtOther" bigint DEFAULT 0 NOT NULL,
    "grantableRoles" bigint DEFAULT 0 NOT NULL,
    "grantableRolesAtHQ" bigint DEFAULT 0 NOT NULL,
    "grantableRolesAtBase" bigint DEFAULT 0 NOT NULL,
    "grantableRolesAtOther" bigint DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "chrCorporationRoles".corprole; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrCorporationRoles".corprole IS 'DERIVED CACHE, not input: common/script/sys/sessions.py:658-674 recomputes it on every session change from rolesAtAll | (rolesAtHQ|rolesAtBase|rolesAtOther) depending on whether session.stationid equals hqID or baseID.';


--
-- Name: COLUMN "chrCorporationRoles"."rolesAtAll"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrCorporationRoles"."rolesAtAll" IS 'Roles held everywhere. Goes on the wire as `roles`: sessions.py:2698 assigns si.roles to session rolesAtAll, and corp_dlg_edit_member.py:76 reads member.roles.';


--
-- Name: COLUMN "chrCorporationRoles"."grantableRoles"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrCorporationRoles"."grantableRoles" IS 'Roles this member may grant to others, anywhere. PROOF: bco_members.py:130, corp_dlg_edit_member.py:77.';


--
-- Name: COLUMN "chrCorporationRoles"."grantableRolesAtHQ"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrCorporationRoles"."grantableRolesAtHQ" IS 'Grantable roles at the corp HQ station. PROOF: bco_members.py:131, corp_dlg_edit_member.py:80.';


--
-- Name: COLUMN "chrCorporationRoles"."grantableRolesAtBase"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrCorporationRoles"."grantableRolesAtBase" IS 'Grantable roles at the member''s base station. PROOF: bco_members.py:132, corp_dlg_edit_member.py:82.';


--
-- Name: COLUMN "chrCorporationRoles"."grantableRolesAtOther"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrCorporationRoles"."grantableRolesAtOther" IS 'Grantable roles anywhere else. PROOF: bco_members.py:133, corp_dlg_edit_member.py:84.';


--
-- Data for Name: chrCorporationRoles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrCorporationRoles" ("characterID", corprole, "rolesAtAll", "rolesAtBase", "rolesAtHQ", "rolesAtOther", "grantableRoles", "grantableRolesAtHQ", "grantableRolesAtBase", "grantableRolesAtOther") FROM stdin;
\.


--
-- Name: chrCorporationRoles chrCorporationRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrCorporationRoles"
    ADD CONSTRAINT "chrCorporationRoles_pkey" PRIMARY KEY ("characterID");


--
-- PostgreSQL database dump complete
--

\unrestrict eXieagX12pUdOMl6bopXd33iUBkpfDQXcIAME57MXau1BcONvoyTcyMma6ms9dN

