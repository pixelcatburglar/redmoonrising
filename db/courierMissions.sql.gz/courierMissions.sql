--
-- PostgreSQL database dump
--

\restrict cT1S9miczGrgjxksgpo8HMJkuW5H0oVtpG36rfjsP7HBnj0nmzAmvxSceOd6Atz

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: courierMissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."courierMissions" (
    "missionID" integer NOT NULL,
    kind smallint DEFAULT 0 NOT NULL,
    state smallint DEFAULT 0 NOT NULL,
    "availabilityID" integer,
    "inOrder" smallint DEFAULT 0 NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "issuerID" integer,
    "assigneeID" integer,
    "acceptFee" double precision DEFAULT 0 NOT NULL,
    "acceptorID" integer,
    "dateIssued" bigint DEFAULT 0 NOT NULL,
    "dateExpires" bigint DEFAULT 0 NOT NULL,
    "dateAccepted" bigint DEFAULT 0 NOT NULL,
    "dateCompleted" bigint DEFAULT 0 NOT NULL,
    "totalReward" double precision DEFAULT 0 NOT NULL,
    tracking smallint DEFAULT 0 NOT NULL,
    "pickupStationID" integer,
    "craterID" integer,
    "dropStationID" integer,
    volume double precision DEFAULT 0 NOT NULL,
    "pickupSolarSystemID" integer,
    "pickupRegionID" integer,
    "dropSolarSystemID" integer,
    "dropRegionID" integer,
    price double precision DEFAULT 0 NOT NULL,
    "typeID" integer,
    "regionID" integer,
    "solarsystemID" integer,
    "stationID" integer
);


--
-- Name: COLUMN "courierMissions".kind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions".kind IS 'INFERRED discriminator between a courier mission and an escrow listing; both live in this table and both are accepted by missionMgr.AcceptCourierMission (missionentry.py:149/198/244).';


--
-- Name: COLUMN "courierMissions".state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions".state IS 'INFERRED. Filter for missionMgr.GetMyCourierMissions / GetAvailableCourierMissions / GetAvailableEscrows; the client instead decides by `rec.acceptorID is None` (base_missions.py:617) and dateExpires (base_missions.py:549).';


--
-- Name: COLUMN "courierMissions".description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions".description IS 'PROVEN: base_missions.py:559 `description = mission.description or ''''` -- so NULL/empty is tolerated -- and rendered as the escrow row''s last column.';


--
-- Name: COLUMN "courierMissions"."issuerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."issuerID" IS 'PROVEN: base_missions.py:564 info.names[mission.issuerID] (column header "creator"); missionentry.py:75 and base_missions.py:608 compare it to eve.session.charid to choose CANCEL vs CLAIM.';


--
-- Name: COLUMN "courierMissions"."assigneeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."assigneeID" IS 'PROVEN and NULLABLE: base_missions.py:560-562 `assignee = ''available to all''; if mission.assigneeID: assignee = info.names[mission.assigneeID]`; missionentry.py:143 blocks closing an assigned escrow.';


--
-- Name: COLUMN "courierMissions"."acceptFee"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."acceptFee" IS 'PROVEN: base_missions.py:574 and :577 -- the collateral the acceptor puts up (header "collateral").';


--
-- Name: COLUMN "courierMissions"."acceptorID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."acceptorID" IS 'PROVEN and NULLABLE: base_missions.py:616 `elif entry.sr.node.rec.acceptorID is None:` decides whether the ACCEPT button is shown; missionentry.py:81 the same.';


--
-- Name: COLUMN "courierMissions"."dateIssued"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."dateIssued" IS 'Windows FILETIME. bigint, not the shipped int.';


--
-- Name: COLUMN "courierMissions"."dateExpires"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."dateExpires" IS 'Windows FILETIME. Read by base_missions.py:549 (mission.dateExpires - now) and missionentry.py:236 (util.FmtDate on the same difference).';


--
-- Name: COLUMN "courierMissions"."dateAccepted"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."dateAccepted" IS 'Windows FILETIME. bigint, not the shipped int.';


--
-- Name: COLUMN "courierMissions"."dateCompleted"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."dateCompleted" IS 'Windows FILETIME. bigint, not the shipped int.';


--
-- Name: COLUMN "courierMissions"."totalReward"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."totalReward" IS 'PROVEN: base_missions.py:574 util.FmtISK(mission.totalReward - mission.acceptFee) under the header "reward".';


--
-- Name: COLUMN "courierMissions"."craterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."craterID" IS 'INFERRED: the entity.itemID of the crate holding the goods. missionMgr.GetManifest(escrowID) lists its contents -- missionentry.py:101 and :213 read item.typeID, item.copy and item.bpRuns off those rows, which is entity + entity_attributes.';


--
-- Name: COLUMN "courierMissions".volume; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions".volume IS 'PROVEN: base_missions.py:574 util.FmtAmt(mission.volume) (header "volume"); also the maxVolume filter argument of GetAvailableCourierMissions (base_missions.py:546).';


--
-- Name: COLUMN "courierMissions".price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions".price IS 'Escrow claim price in ISK. PROOF: base_missions.py:564 util.FmtISK(mission.price, sign='''') and missionentry.py:236 util.FmtISK(self.sr.node.rec.price).';


--
-- Name: COLUMN "courierMissions"."typeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."typeID" IS 'INFERRED (icon/typeID of the escrowed goods). Read as rec.typeID in client/script/ui/station/missions/base_missions.py.';


--
-- Name: COLUMN "courierMissions"."regionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."regionID" IS 'Region of an escrow listing. PROOF: missionentry.py:135 eve.LocalSvc(''map'').SetInterest(self.sr.node.rec.regionID).';


--
-- Name: COLUMN "courierMissions"."solarsystemID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."solarsystemID" IS 'Solar system of an escrow listing. LOWER-CASE s is deliberate -- missionentry.py:136 reads rec.solarsystemID; header names are matched by exact string.';


--
-- Name: COLUMN "courierMissions"."stationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."courierMissions"."stationID" IS 'Station an escrow''s goods sit in. PROOF: base_missions.py:563 info.names[mission.stationID]. (Serving it as an alias of "pickupStationID" is also valid; the physical column exists so escrows need not overload the courier columns.)';


--
-- Name: courierMissions_missionID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."courierMissions_missionID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: courierMissions_missionID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."courierMissions_missionID_seq" OWNED BY public."courierMissions"."missionID";


--
-- Name: SEQUENCE "courierMissions_missionID_seq"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public."courierMissions_missionID_seq" IS 'Also allocates escrow IDs: missionentry.py:149 and :244 both call missionMgr.AcceptCourierMission() with rec.escrowID while :198 calls it with rec.missionID, so escrowID and missionID share one key space (INFERRED from the shared method, strongly).';


--
-- Name: courierMissions missionID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."courierMissions" ALTER COLUMN "missionID" SET DEFAULT nextval('public."courierMissions_missionID_seq"'::regclass);


--
-- Data for Name: courierMissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."courierMissions" ("missionID", kind, state, "availabilityID", "inOrder", description, "issuerID", "assigneeID", "acceptFee", "acceptorID", "dateIssued", "dateExpires", "dateAccepted", "dateCompleted", "totalReward", tracking, "pickupStationID", "craterID", "dropStationID", volume, "pickupSolarSystemID", "pickupRegionID", "dropSolarSystemID", "dropRegionID", price, "typeID", "regionID", "solarsystemID", "stationID") FROM stdin;
\.


--
-- Name: courierMissions_missionID_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."courierMissions_missionID_seq"', 1, false);


--
-- Name: courierMissions courierMissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."courierMissions"
    ADD CONSTRAINT "courierMissions_pkey" PRIMARY KEY ("missionID");


--
-- Name: couriermissions_acceptor_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX couriermissions_acceptor_ix ON public."courierMissions" USING btree ("acceptorID", state);


--
-- Name: INDEX couriermissions_acceptor_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.couriermissions_acceptor_ix IS 'GetMyCourierMissions -- what I have accepted (base_missions.py:94, journal.py:141).';


--
-- Name: couriermissions_assignee_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX couriermissions_assignee_ix ON public."courierMissions" USING btree ("assigneeID", state);


--
-- Name: INDEX couriermissions_assignee_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.couriermissions_assignee_ix IS 'Escrow "assigned to me" filter (base_missions.py:543 passes eve.session.charid as the 5th argument of GetAvailableEscrows).';


--
-- Name: couriermissions_issuer_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX couriermissions_issuer_ix ON public."courierMissions" USING btree ("issuerID");


--
-- Name: INDEX couriermissions_issuer_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.couriermissions_issuer_ix IS 'What I have issued -- base_missions.py:608 compares rec.issuerID to session.charid to offer CANCEL.';


--
-- Name: couriermissions_pickup_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX couriermissions_pickup_ix ON public."courierMissions" USING btree ("pickupStationID", "dateExpires");


--
-- Name: INDEX couriermissions_pickup_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.couriermissions_pickup_ix IS 'GetAvailableCourierMissions filtered by station (base_missions.py:540 stationID = eve.session.stationid), with the expiry sweep riding along.';


--
-- Name: couriermissions_region_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX couriermissions_region_ix ON public."courierMissions" USING btree ("pickupRegionID", "dateExpires");


--
-- Name: INDEX couriermissions_region_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.couriermissions_region_ix IS 'The same query filtered by region (base_missions.py:538).';


--
-- PostgreSQL database dump complete
--

\unrestrict cT1S9miczGrgjxksgpo8HMJkuW5H0oVtpG36rfjsP7HBnj0nmzAmvxSceOd6Atz

