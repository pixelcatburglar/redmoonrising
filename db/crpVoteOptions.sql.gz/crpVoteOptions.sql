--
-- PostgreSQL database dump
--

\restrict kdlQGlBAGlCAAbXNWRTDa8vdvC7u5udm8nyt0grF8Z2fkZpeCye8rDbib6Co1TP

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpVoteOptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpVoteOptions" (
    "voteCaseID" integer NOT NULL,
    "optionID" integer NOT NULL,
    "optionText" text DEFAULT ''::text NOT NULL,
    parameter integer,
    parameter1 integer,
    parameter2 integer
);


--
-- Name: TABLE "crpVoteOptions"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."crpVoteOptions" IS 'The choices on a vote. Serves corpRegistry.GetVoteCaseOptions(corpID, voteCaseID) (bco_voting.py:60). option.votesFor is COMPUTED per query (count of crpVotes), never stored -- corp_ui_votes.py:1202 sums it.';


--
-- Name: COLUMN "crpVoteOptions"."voteCaseID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVoteOptions"."voteCaseID" IS 'PROVEN: GetVoteCaseOptions is called with voteCase.voteCaseID (corp_ui_votes.py:327, :409, :1106, :1198).';


--
-- Name: COLUMN "crpVoteOptions"."optionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVoteOptions"."optionID" IS 'PROVEN: corp_ui_votes.py:1127 `if option.optionID == votedFor` and :1135 passes it to InsertVote as the 3rd argument (voteValue).';


--
-- Name: COLUMN "crpVoteOptions"."optionText"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVoteOptions"."optionText" IS 'PROVEN: corp_ui_votes.py:1126, :1132, :1205 text = option.optionText.';


--
-- Name: COLUMN "crpVoteOptions".parameter; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVoteOptions".parameter IS 'PROVEN, POLYMORPHIC: for voteWar/voteKickMember/voteCEO it is an ownerID -- corp_ui_votes.py:1145 cfg.eveowners.Get(option.parameter); for voteItemLockdown/voteItemUnlock it is an itemID -- :1152 dict[''itemID''] = option.parameter, :331 voteCaseIDByItemToUnlockID[option.parameter].';


--
-- Name: COLUMN "crpVoteOptions".parameter1; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVoteOptions".parameter1 IS 'PROVEN: a typeID for the item-lock vote types -- corp_ui_votes.py:1151 cfg.invtypes.Get(option.parameter1).typeName.';


--
-- Name: COLUMN "crpVoteOptions".parameter2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpVoteOptions".parameter2 IS 'PROVEN: a locationID for the item-lock vote types -- corp_ui_votes.py:1151 cfg.evelocations.Get(option.parameter2).locationName.';


--
-- Data for Name: crpVoteOptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpVoteOptions" ("voteCaseID", "optionID", "optionText", parameter, parameter1, parameter2) FROM stdin;
\.


--
-- Name: crpVoteOptions crpVoteOptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpVoteOptions"
    ADD CONSTRAINT "crpVoteOptions_pkey" PRIMARY KEY ("voteCaseID", "optionID");



--
-- PostgreSQL database dump complete
--

\unrestrict kdlQGlBAGlCAAbXNWRTDa8vdvC7u5udm8nyt0grF8Z2fkZpeCye8rDbib6Co1TP

