--
-- PostgreSQL database dump
--

\restrict 9YPbq1x3HJcK2VoaVijbw3hCnVdoN7qBmi29vxeqKOQPtPhMn6EaNsIs7Tae1m8

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: botGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."botGroups" (
    "ownerID" integer NOT NULL,
    kind smallint NOT NULL,
    "regionID" integer
);


--
-- Name: TABLE "botGroups"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."botGroups" IS 'MADE: the corporations and alliances the bot simulation runs (bots::politics). A corporation or alliance not listed belongs to players.';


--
-- Name: COLUMN "botGroups".kind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."botGroups".kind IS 'MADE: corporations 1 industrial, 2 combat; alliances 11 null-sec, 12 pirate, 13 industrial.';


--
-- Name: COLUMN "botGroups"."regionID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."botGroups"."regionID" IS 'MADE: an alliance''s home region, where its members live and work.';


--
-- Name: botGroups botGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."botGroups"
    ADD CONSTRAINT "botGroups_pkey" PRIMARY KEY ("ownerID");


--
-- PostgreSQL database dump complete
--

\unrestrict 9YPbq1x3HJcK2VoaVijbw3hCnVdoN7qBmi29vxeqKOQPtPhMn6EaNsIs7Tae1m8

