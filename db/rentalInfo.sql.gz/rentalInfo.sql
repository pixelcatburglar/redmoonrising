--
-- PostgreSQL database dump
--

\restrict CW0e3wWLg6akueo7sdthAHSnCZQ4OqAPlXnPgdefPX76bIXxXGBcXJWP3smuGsk

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: rentalInfo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."rentalInfo" (
    "stationID" integer DEFAULT 0 NOT NULL,
    "slotNumber" integer DEFAULT 0 NOT NULL,
    "renterID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    "rentPeriodInDays" integer DEFAULT 0 NOT NULL,
    "periodCost" double precision DEFAULT 0 NOT NULL,
    "billID" integer DEFAULT 0 NOT NULL,
    "balanceDueDate" bigint DEFAULT 0 NOT NULL,
    discontinue smallint DEFAULT 0 NOT NULL,
    "publiclyAvailable" smallint DEFAULT 0 NOT NULL,
    "startDate" bigint DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "rentalInfo"."balanceDueDate"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."rentalInfo"."balanceDueDate" IS 'Windows FILETIME of the next rent bill. bigint, not the shipped int; rendered by corp_ui_accounts.py through util.FmtDate.';


--
-- Name: COLUMN "rentalInfo"."startDate"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."rentalInfo"."startDate" IS 'Windows FILETIME the rental began. PROOF: corp_ui_accounts.py:154-156 reads item.startDate and passes it to util.FmtDate.';


--
-- Data for Name: rentalInfo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."rentalInfo" ("stationID", "slotNumber", "renterID", "typeID", "rentPeriodInDays", "periodCost", "billID", "balanceDueDate", discontinue, "publiclyAvailable", "startDate") FROM stdin;
\.


--
-- Name: rentalInfo rentalInfo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."rentalInfo"
    ADD CONSTRAINT "rentalInfo_pkey" PRIMARY KEY ("stationID", "slotNumber");


--
-- Name: rentalinfo_renter_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX rentalinfo_renter_ix ON public."rentalInfo" USING btree ("renterID");


--
-- Name: INDEX rentalinfo_renter_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.rentalinfo_renter_ix IS 'corpRegistry.GetRentalDetailsCorp / GetRentalDetailsPlayer and corpmgr.GetItemsRented all filter on the renter.';


--
-- PostgreSQL database dump complete
--

\unrestrict CW0e3wWLg6akueo7sdthAHSnCZQ4OqAPlXnPgdefPX76bIXxXGBcXJWP3smuGsk

