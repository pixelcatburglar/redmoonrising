--
-- PostgreSQL database dump
--

\restrict ujFQxpX3h6xtSeDLQ27OOAWnk7Kg1pph9K3MW0UYqWUzgbElZ8CraErP6v7WhfR

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrAgentLoyalty; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrAgentLoyalty" (
    "characterID" integer NOT NULL,
    "agentID" integer NOT NULL,
    "loyaltyPoints" integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "chrAgentLoyalty"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."chrAgentLoyalty" IS 'Loyalty points a character holds with an agent. Read through the agent moniker: infosvc.py:1421-1422 details.loyaltyPoints, and agents.py:285 out-of-band from DoAction. GRANULARITY (per agent vs per agent corp) is INFERRED from the agent-scoped moniker.';


--
-- Name: COLUMN "chrAgentLoyalty"."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentLoyalty"."characterID" IS 'INFERRED as a column: the call carries no character argument; the server scopes on session.charid.';


--
-- Name: COLUMN "chrAgentLoyalty"."agentID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentLoyalty"."agentID" IS 'INFERRED as a column: it is the moniker''s bind key (moniker.GetAgent(agentID, stationID), agents.py:74), not a row field.';


--
-- Name: COLUMN "chrAgentLoyalty"."loyaltyPoints"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentLoyalty"."loyaltyPoints" IS 'PROVEN as a wire field: infosvc.py:1422 str(details.loyaltyPoints) on the agent info window, agents.py:286 in the agent dialogue. Falsy-tolerant -- infosvc.py:1421 and agents.py:285 both skip it when 0/absent.';


--
-- Data for Name: chrAgentLoyalty; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrAgentLoyalty" ("characterID", "agentID", "loyaltyPoints") FROM stdin;
\.


--
-- Name: chrAgentLoyalty chrAgentLoyalty_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrAgentLoyalty"
    ADD CONSTRAINT "chrAgentLoyalty_pkey" PRIMARY KEY ("characterID", "agentID");


--
-- PostgreSQL database dump complete
--

\unrestrict ujFQxpX3h6xtSeDLQ27OOAWnk7Kg1pph9K3MW0UYqWUzgbElZ8CraErP6v7WhfR

