--
-- PostgreSQL database dump
--

\restrict fln0YyLLK9lsGenyY4wTdMDeX6Jcyxtp2CrI6hEQaqYpZUjNUHe7QDhGdoRL1h1

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.schema_migrations IS 'Applied-migration ledger. One row per file in db/migrations, keyed by file name. Server-internal: never crosses the wire.';


--
-- Name: COLUMN schema_migrations.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schema_migrations.name IS 'Migration file name, e.g. 0002_id_sequences.sql. Server-internal (no client read).';


--
-- Name: COLUMN schema_migrations.checksum; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schema_migrations.checksum IS 'FNV-1a 64-bit hex digest of the file bytes at apply time; the runner refuses to start if a already-applied file changed. Server-internal.';


--
-- Name: COLUMN schema_migrations.applied_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schema_migrations.applied_at IS 'Wall clock of application. Server-internal -- this is the one timestamp in the database that is NOT a Windows FILETIME, because no client ever sees it.';


--
-- Name: COLUMN schema_migrations.duration_ms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.schema_migrations.duration_ms IS 'How long the file took, for spotting the slow ones. Server-internal.';


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (name, checksum, applied_at, duration_ms) FROM stdin;
\.


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (name);


--
-- PostgreSQL database dump complete
--

\unrestrict fln0YyLLK9lsGenyY4wTdMDeX6Jcyxtp2CrI6hEQaqYpZUjNUHe7QDhGdoRL1h1

