--
-- PostgreSQL database dump
--

\restrict LKJRwawYC707VgUTU4urq3IBhXCTc9FobZPa1bz3qmBi2vfGW5coPDX7MtUcFSZ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channelsStatic; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."channelsStatic" (
    "channelID" integer NOT NULL,
    "ownerID" integer DEFAULT 0 NOT NULL,
    "displayName" text,
    motd text,
    "comparisonKey" text,
    memberless smallint DEFAULT 0 NOT NULL,
    password text,
    "mailingList" smallint DEFAULT 0 NOT NULL,
    cspa smallint DEFAULT 0 NOT NULL,
    temporary smallint DEFAULT 0 NOT NULL,
    mode smallint DEFAULT 0 NOT NULL,
    subscribed smallint DEFAULT 0 NOT NULL,
    "estimatedMemberCount" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: channelsStatic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."channelsStatic" ("channelID", "ownerID", "displayName", motd, "comparisonKey", memberless, password, "mailingList", cspa, temporary, mode, subscribed, "estimatedMemberCount") FROM stdin;
1	1	Help\\Rookie Help	rookie MOTD	rookiehelp	1	\N	0	100	0	3	0	7777
2	1	Help\\Help	help MOTD	help	1	\N	0	100	0	3	0	6666
1000044	1000044	\N	\N	\N	1	\N	1	127	0	1	1	1252
1000115	1000115	\N	\N	\N	1	\N	1	127	0	1	1	1252
30001407	30001407	\N	\N	\N	1	\N	1	127	0	1	1	1252
\.


--
-- Name: channelsStatic channelsStatic_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."channelsStatic"
    ADD CONSTRAINT "channelsStatic_pkey" PRIMARY KEY ("channelID");


--
-- PostgreSQL database dump complete
--

\unrestrict LKJRwawYC707VgUTU4urq3IBhXCTc9FobZPa1bz3qmBi2vfGW5coPDX7MtUcFSZ

