--
-- PostgreSQL database dump
--

\restrict 5GITAEpfYeMkigeQ0fKWNA6bWHQr4NYj0UwVz5c8zBvZapNfk5JKR4KEJMjkYgg

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: droneState; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."droneState" (
    "droneID" integer DEFAULT 0 NOT NULL,
    "solarSystemID" integer DEFAULT 0 NOT NULL,
    "ownerID" integer DEFAULT 0 NOT NULL,
    "controllerID" integer DEFAULT 0 NOT NULL,
    "activityState" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    "controllerOwnerID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: droneState; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."droneState" ("droneID", "solarSystemID", "ownerID", "controllerID", "activityState", "typeID", "controllerOwnerID") FROM stdin;
\.


--
-- Name: droneState droneState_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."droneState"
    ADD CONSTRAINT "droneState_pkey" PRIMARY KEY ("droneID");


--
-- PostgreSQL database dump complete
--

\unrestrict 5GITAEpfYeMkigeQ0fKWNA6bWHQr4NYj0UwVz5c8zBvZapNfk5JKR4KEJMjkYgg

