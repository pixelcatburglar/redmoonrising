--
-- PostgreSQL database dump
--

\restrict CdGovDsOMEc65E2KitdxXVKFn5sb7l84NufMLwrK5lvVSEnEzMlEec9rhETYb5b

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtAgentTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtAgentTypes" (
    "agentTypeID" integer NOT NULL,
    "agentType" text
);


--
-- Data for Name: agtAgentTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtAgentTypes" ("agentTypeID", "agentType") FROM stdin;
1	NonAgent
2	BasicAgent
3	TutorialAgent
4	ResearchAgent
5	CONCORDAgent
6	GenericStorylineMissionAgent
7	StorylineMissionAgent
8	EventMissionAgent
\.


--
-- Name: agtAgentTypes agtAgentTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtAgentTypes"
    ADD CONSTRAINT "agtAgentTypes_pkey" PRIMARY KEY ("agentTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict CdGovDsOMEc65E2KitdxXVKFn5sb7l84NufMLwrK5lvVSEnEzMlEec9rhETYb5b

