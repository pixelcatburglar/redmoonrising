--
-- PostgreSQL database dump
--

\restrict 4lGRvlvrOslV7fVVmFihLWbtiiDFm7CJ1665CtcXNvt1Lfg85qkWFd1ggU97ChC

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrMissionState; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrMissionState" (
    "characterID" integer DEFAULT 0 NOT NULL,
    "missionID" integer DEFAULT 0 NOT NULL,
    "missionState" smallint DEFAULT 0 NOT NULL,
    "expirationTime" bigint DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "chrMissionState"."missionState"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrMissionState"."missionState" IS 'PROVEN, tuple position 0 of a GetMyJournalDetails mission entry (journal.py:266). journal.py:268 treats states 0 and 1 as "Not Accepted" and anything else as "Accepted".';


--
-- Name: COLUMN "chrMissionState"."expirationTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrMissionState"."expirationTime" IS 'Windows FILETIME, tuple position 5. PROVEN: journal.py:270-283 compares it to blue.os.GetTime() + WEEK / + DAY and formats it with util.FmtDate / util.FmtTimeInterval; 0 means "undefined expiration date" (journal.py:277).';


--
-- Data for Name: chrMissionState; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrMissionState" ("characterID", "missionID", "missionState", "expirationTime") FROM stdin;
\.


--
-- Name: chrMissionState chrMissionState_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrMissionState"
    ADD CONSTRAINT "chrMissionState_pkey" PRIMARY KEY ("characterID", "missionID");


--
-- Name: chrMissionState_missionID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chrMissionState_missionID_idx" ON public."chrMissionState" USING btree ("missionID");


--
-- Name: chrmissionstate_char_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chrmissionstate_char_ix ON public."chrMissionState" USING btree ("characterID", "missionState");


--
-- Name: INDEX chrmissionstate_char_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.chrmissionstate_char_ix IS 'agentMgr.GetMyJournalDetails builds the mission list per character and the UI splits on missionState (journal.py:268).';


--
-- PostgreSQL database dump complete
--

\unrestrict 4lGRvlvrOslV7fVVmFihLWbtiiDFm7CJ1665CtcXNvt1Lfg85qkWFd1ggU97ChC

