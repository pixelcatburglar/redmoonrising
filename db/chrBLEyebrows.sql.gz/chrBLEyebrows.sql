--
-- PostgreSQL database dump
--

\restrict xGWbyg1alQeZeW5gmEp1XorCnUMy5x7P7O888UMhsKe8hYZLNrVIqoTR3UdOMnQ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrBLEyebrows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrBLEyebrows" (
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    gender integer DEFAULT 0 NOT NULL,
    "eyebrowsID" integer DEFAULT 0 NOT NULL,
    npc integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrBLEyebrows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrBLEyebrows" ("bloodlineID", gender, "eyebrowsID", npc) FROM stdin;
1	0	1	0
1	0	2	0
1	0	3	0
1	0	4	0
1	0	5	0
1	0	6	0
1	0	7	0
1	0	8	0
1	0	9	0
1	0	10	0
1	0	11	0
1	0	14	0
1	0	16	0
1	1	1	0
1	1	2	0
1	1	3	0
1	1	4	0
1	1	5	0
1	1	6	0
1	1	7	0
1	1	8	0
1	1	14	0
1	1	29	0
1	1	30	0
1	1	31	0
1	1	32	0
1	1	33	0
1	1	34	0
1	1	35	0
2	0	1	0
2	0	3	0
2	0	4	0
2	0	7	0
2	0	8	0
2	0	9	0
2	0	10	0
2	0	11	0
2	1	1	0
2	1	2	0
2	1	4	0
2	1	5	0
2	1	6	0
2	1	7	0
2	1	8	0
2	1	9	0
2	1	10	0
2	1	11	0
2	1	12	0
2	1	16	0
2	1	27	0
2	1	28	0
3	0	1	0
3	0	2	0
3	0	4	0
3	0	8	0
3	0	9	0
3	0	10	0
3	0	11	0
3	0	12	0
3	0	13	0
3	0	16	0
3	1	1	0
3	1	2	0
3	1	4	0
3	1	5	0
3	1	6	0
3	1	7	0
3	1	8	0
3	1	9	0
3	1	10	0
3	1	11	0
3	1	12	0
3	1	13	0
3	1	17	0
3	1	18	0
4	0	1	0
4	0	2	0
4	0	3	0
4	0	4	0
4	0	5	0
4	0	6	0
4	0	7	0
4	0	8	0
4	0	9	0
4	0	10	0
4	0	11	0
4	0	12	0
4	0	13	0
4	1	1	0
4	1	2	0
4	1	3	0
4	1	6	0
4	1	7	0
4	1	8	0
4	1	9	0
4	1	14	0
4	1	15	0
5	0	19	0
5	0	20	0
5	0	21	0
5	0	22	0
5	0	23	0
5	0	24	0
5	0	25	0
5	0	26	0
5	1	1	0
5	1	3	0
5	1	4	0
5	1	5	0
5	1	6	0
5	1	7	0
5	1	8	0
5	1	10	0
5	1	11	0
6	0	4	0
6	0	7	0
6	0	8	0
6	0	9	0
6	0	10	0
6	0	11	0
6	1	2	0
6	1	3	0
6	1	4	0
6	1	8	0
6	1	9	0
6	1	10	0
6	1	11	0
7	0	1	0
7	0	2	0
7	0	3	0
7	0	6	0
7	0	8	0
7	0	9	0
7	0	10	0
7	0	11	0
7	0	15	0
7	0	16	0
7	0	36	0
7	0	37	0
7	1	1	0
7	1	2	0
7	1	4	0
7	1	5	0
7	1	6	0
7	1	7	0
7	1	8	0
7	1	9	0
7	1	10	0
7	1	11	0
7	1	16	0
8	0	1	0
8	0	3	0
8	0	4	0
8	0	8	0
8	0	9	0
8	0	10	0
8	0	11	0
8	0	14	0
8	0	16	0
8	0	36	0
8	0	37	0
8	1	1	0
8	1	2	0
8	1	3	0
8	1	4	0
8	1	6	0
8	1	7	0
8	1	8	0
8	1	9	0
8	1	10	0
8	1	11	0
8	1	14	0
8	1	15	0
8	1	16	0
8	1	36	0
8	1	37	0
11	0	35	0
11	0	38	0
11	0	40	0
11	0	41	0
11	0	42	0
11	0	43	0
11	0	44	0
11	0	45	0
11	0	46	0
11	1	47	0
11	1	48	0
11	1	49	0
11	1	50	0
12	0	1	0
12	0	4	0
12	0	5	0
12	0	6	0
12	0	7	0
12	0	35	0
12	0	40	0
12	0	41	0
12	0	42	0
12	1	49	0
12	1	65	0
12	1	66	0
12	1	67	0
12	1	68	0
12	1	69	0
12	1	70	0
12	1	71	0
12	1	72	0
12	1	73	0
12	1	74	0
12	1	75	0
12	1	76	0
13	0	35	0
13	0	38	0
13	0	40	0
13	0	41	0
13	0	42	0
13	0	43	0
13	0	44	0
13	0	45	0
13	0	46	0
13	1	51	0
13	1	55	0
13	1	56	0
13	1	62	0
13	1	77	0
13	1	78	0
13	1	79	0
13	1	80	0
13	1	81	0
13	1	82	0
14	0	1	0
14	0	4	0
14	0	5	0
14	0	6	0
14	0	7	0
14	0	8	0
14	0	20	0
14	0	23	0
14	0	24	0
14	0	25	0
14	0	26	0
14	0	39	0
14	1	51	0
14	1	52	0
14	1	53	0
14	1	54	0
14	1	55	0
14	1	56	0
14	1	57	0
14	1	58	0
14	1	59	0
14	1	60	0
14	1	61	0
14	1	62	0
14	1	63	0
14	1	64	0
\.


--
-- Name: chrBLEyebrows chrBLEyebrows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrBLEyebrows"
    ADD CONSTRAINT "chrBLEyebrows_pkey" PRIMARY KEY ("bloodlineID", gender, "eyebrowsID");


--
-- PostgreSQL database dump complete
--

\unrestrict xGWbyg1alQeZeW5gmEp1XorCnUMy5x7P7O888UMhsKe8hYZLNrVIqoTR3UdOMnQ

