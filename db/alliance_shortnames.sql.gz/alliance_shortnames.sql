--
-- PostgreSQL database dump
--

\restrict JVmmTdcHHZZZbuxZJlSeUyyMYQv2EmJs4Rai6Tjl3GxZBUYxeJCEeNKXlGP5ghU

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alliance_shortnames; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alliance_shortnames (
    "allianceID" integer DEFAULT 0 NOT NULL,
    "shortName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: alliance_shortnames; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alliance_shortnames ("allianceID", "shortName") FROM stdin;
\.


--
-- Name: alliance_shortnames alliance_shortnames_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alliance_shortnames
    ADD CONSTRAINT alliance_shortnames_pkey PRIMARY KEY ("allianceID");


--
-- PostgreSQL database dump complete
--

\unrestrict JVmmTdcHHZZZbuxZJlSeUyyMYQv2EmJs4Rai6Tjl3GxZBUYxeJCEeNKXlGP5ghU

