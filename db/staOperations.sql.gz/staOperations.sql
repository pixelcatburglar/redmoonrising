--
-- PostgreSQL database dump
--

\restrict FeMEx8wxOAmwKtgFFfEsmjqSEqQH7ZGutQHiLyrFOUq1aXqpilg6pWjvvJcHTk3

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: staOperations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."staOperations" (
    "activityID" integer,
    "operationID" integer NOT NULL,
    "operationName" text,
    description text,
    fringe integer,
    corridor integer,
    hub integer,
    border integer,
    ratio integer,
    "caldariStationTypeID" integer,
    "minmatarStationTypeID" integer,
    "amarrStationTypeID" integer,
    "gallenteStationTypeID" integer,
    "joveStationTypeID" integer
);


--
-- Data for Name: staOperations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."staOperations" ("activityID", "operationID", "operationName", description, fringe, corridor, hub, border, ratio, "caldariStationTypeID", "minmatarStationTypeID", "amarrStationTypeID", "gallenteStationTypeID", "joveStationTypeID") FROM stdin;
1	1	Plantation	Makes livestock and grain that is shipped to food processing units.	70	20	10	0	65	1531	2499	1930	3866	3865
1	2	Food Packaging	Makes food that is shipped to warehouses.	0	20	50	30	20	4024	2497	1928	3866	3865
1	3	Warehouse	Stores products and shifts goods to external retailers or production corporations.	0	50	0	50	15	1531	2501	1929	3870	3865
2	4	Foundry	Mines minerals from asteroid belts/clouds.	90	10	0	0	30	1529	2499	1930	3867	3865
2	5	Production Plant	Molds finished construction pieces.	25	15	50	10	50	1529	2497	1928	3867	3865
2	6	Warehouse	Stores product and freights goods to production corps.	0	50	0	50	20	1531	2501	1929	3870	3865
3	7	Mining Outpost	Mines minerals from asteroid belts/clouds.	90	10	0	0	65	4023	2499	1930	3865	3865
3	8	Refinery	Refines the minerals, making purified ingots and rock materials.	0	10	45	45	15	4024	2497	1928	3867	3865
3	9	Mineral Reserve	Stores product and freights goods to production corps.	0	50	0	50	20	4023	2501	1929	3865	3865
4	10	Reprocessing Facility	Extracts chemicals from asteroid belts/clouds.	90	10	0	0	10	4023	2499	1930	3867	3865
4	11	Chemical Refinery	Refines the harvested chemicals, making bottled products.	0	10	90	0	80	1529	2497	1928	3867	3865
4	12	Chemical Storage	Stores products and shifts goods to production corporations.	0	50	0	50	10	1531	2501	1929	3870	3865
5	13	Testing Facilities	Makes plans and blueprints that are shipped to Assembly Plant.	90	10	0	0	20	54	2500	1931	3869	3865
5	14	Assembly Plant	Produces weapons and ammunition that are shipped for storage.	0	10	60	30	55	1529	2498	1927	3867	3865
5	15	Logistic Support	Stores product and freights goods to external retailers.	0	50	0	50	25	1530	2501	1929	3868	3865
6	16	Biotech Research Center	Harvests resources from a planet.	70	30	0	0	20	54	2499	1930	3869	3865
6	17	Biotech Production	Produces Biotech products.	0	10	45	45	70	1529	2497	1928	3867	3865
6	18	Biohazard Containment Facility	Stores and recycles materials classified as biohazards.	50	50	0	0	10	54	2501	1929	3869	3865
7	19	Research Center	Makes plans and blueprints that are shipped to Factory.	70	30	0	0	10	54	2500	1931	3869	3865
7	20	Factory	Produces finished hi-tech products.	0	10	50	40	80	1529	2497	1928	3867	3865
7	21	Warehouse	Stores product and freights goods to external retailers.	0	50	0	50	10	1531	2501	1929	3870	3865
8	22	Development Studio	Produces entertainment material that is shipped to Publisher.	0	10	45	45	80	1531	2496	1931	56	3865
8	23	Publisher	Stores and multiplies the enertainment material and ships it to retailers.	0	10	80	10	20	3872	2496	1926	57	3865
9	24	Shipyard	Produces starships that are shipped for storage in Storage Bay.	0	10	90	0	80	1530	2498	1927	3868	3865
9	25	Storage Bay	Stores ships before freighting them to retailers.	0	50	0	50	20	3872	2502	1929	3870	3865
10	26	Storage	Stores cargo for other corps before shipping it to retailers.	25	25	25	25	100	1531	2501	1929	3870	3865
11	27	Warehouse	Stores products and freights goods to retail center.	40	25	10	25	70	1531	2501	1929	3870	3865
11	28	Retail Center	Sells goods from warehouses to consumers, and to service stations.	0	10	45	45	30	1531	2496	1926	57	3865
12	29	Warehouse	Stores products and freights goods to Trading Post.	50	25	0	25	50	1531	2501	1929	3870	3865
12	30	Trading Post	Sells wares received from production corps.	0	15	35	50	50	1531	2502	1932	3868	3865
13	31	Bureau Offices	Delivers reports and provides information concerning the Bureau's field.	0	10	45	45	40	1529	2496	1926	56	3865
14	32	Academy	Studies issues within the administration system and produces personnel.	50	50	0	0	20	1529	2502	9857	57	3865
14	33	Bureau	Delivers reports and publishes rules and manifestos concerning the Bureau's field.	0	15	40	45	70	1531	2502	1932	56	3865
14	34	Treasury	Stores data and kredit sheets for the Bureau to work with.	100	0	0	0	10	1530	2498	1927	3868	3865
17	35	Depository	Works as a bank.	0	10	85	5	70	1529	2502	1932	57	3865
17	36	Vault	Stores data and kredit sheets for the Bank to work with.	100	0	0	0	30	1530	2501	1927	3868	3865
18	37	School	Produces personell and sells skill packages.	0	0	50	50	100	1529	2500	1931	57	3865
19	38	Factory		0	10	45	45	80	4024	2497	1928	3867	3865
19	39	Warehouse		0	50	0	50	20	1531	2501	1929	3870	3865
15	40	Tribunal	Courts where judicial matters are judged	0	0	50	50	40	1530	2496	9857	3868	3865
15	41	Accounting	Accounting and audit firms	30	30	20	20	30	1529	2500	1931	57	3865
15	42	Law School		50	30	10	10	30	3871	2502	1929	56	3865
13	43	Archives	Stores administrative documents and data.	70	30	0	0	30	1529	2500	1931	57	3865
13	44	Information Center	Distributes administrative information to the public.	0	0	50	50	30	3872	2502	1926	57	3865
20	45	Manufacturing		0	0	0	0	0	\N	\N	\N	\N	\N
20	46	Refining		0	0	0	0	0	\N	\N	\N	\N	\N
20	47	Cloning		0	0	0	0	0	\N	\N	\N	\N	\N
20	48	Caldari Research Outpost		0	0	0	0	0	\N	\N	\N	\N	\N
20	49	Amarr Factory Outpost		0	0	0	0	0	\N	\N	\N	\N	\N
20	50	Gallente Administrative Outpost		0	0	0	0	0	\N	\N	\N	\N	\N
20	51	Minmatar Service Outpost		0	0	0	0	0	\N	\N	\N	\N	\N
\.


--
-- Name: staOperations staOperations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."staOperations"
    ADD CONSTRAINT "staOperations_pkey" PRIMARY KEY ("operationID");


--
-- PostgreSQL database dump complete
--

\unrestrict FeMEx8wxOAmwKtgFFfEsmjqSEqQH7ZGutQHiLyrFOUq1aXqpilg6pWjvvJcHTk3

