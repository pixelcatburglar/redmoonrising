--
-- PostgreSQL database dump
--

\restrict TkiU8WZz3Fv1SYm4hoz8H3rCaGL1FBOe7iIKl4j0z0nVnncfrggIwbEc1BmJQuZ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."billTypes" (
    "billTypeID" integer DEFAULT 0 NOT NULL,
    "billTypeName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: billTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."billTypes" ("billTypeID", "billTypeName", description) FROM stdin;
1	Market Fine	
2	Rental Bill	
3	Broker Bill	
4	War Bill	
5	Alliance Maintainance Bill	
\.


--
-- Name: billTypes billTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."billTypes"
    ADD CONSTRAINT "billTypes_pkey" PRIMARY KEY ("billTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict TkiU8WZz3Fv1SYm4hoz8H3rCaGL1FBOe7iIKl4j0z0nVnncfrggIwbEc1BmJQuZ

