--
-- PostgreSQL database dump
--

\restrict qcFPiMb5WM4W3lqsXCTYSICOkfFK3vDyRRoyIamWL8irTv839lyUrgoXzukistR

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eveEncyclTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."eveEncyclTypes" (
    "encyclopediaTypeID" integer DEFAULT 0 NOT NULL,
    "encyclopediaTypeName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: eveEncyclTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."eveEncyclTypes" ("encyclopediaTypeID", "encyclopediaTypeName") FROM stdin;
\.


--
-- Name: eveEncyclTypes eveEncyclTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."eveEncyclTypes"
    ADD CONSTRAINT "eveEncyclTypes_pkey" PRIMARY KEY ("encyclopediaTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict qcFPiMb5WM4W3lqsXCTYSICOkfFK3vDyRRoyIamWL8irTv839lyUrgoXzukistR

