--
-- PostgreSQL database dump
--

\restrict WikDU6X0AtSpnbRFMzRl5puXJ9XqssxBgtasdMWWDHvPUrPZf0sssmje2q4dUNP

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramCompletedStatuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramCompletedStatuses" (
    "completedStatusID" integer DEFAULT 0 NOT NULL,
    "completedStatusName" text DEFAULT ''::text NOT NULL,
    "completedStatusText" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: ramCompletedStatuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramCompletedStatuses" ("completedStatusID", "completedStatusName", "completedStatusText") FROM stdin;
0	Failed	
1	Delivered	
2	Aborted	
3	GM aborted	
4	Unanchored	
5	Destroyed	
\.


--
-- Name: ramCompletedStatuses ramCompletedStatuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramCompletedStatuses"
    ADD CONSTRAINT "ramCompletedStatuses_pkey" PRIMARY KEY ("completedStatusID");


--
-- PostgreSQL database dump complete
--

\unrestrict WikDU6X0AtSpnbRFMzRl5puXJ9XqssxBgtasdMWWDHvPUrPZf0sssmje2q4dUNP

