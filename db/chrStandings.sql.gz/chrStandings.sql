--
-- PostgreSQL database dump
--

\restrict p5Sb4hOI0UJ3eFGTbCYW1cdSJQ5TF18V0efXYdVFfCyWoraqTL56W14qfil1ume

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrStandings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrStandings" (
    "characterID" integer DEFAULT 0 NOT NULL,
    "toID" integer DEFAULT 0 NOT NULL,
    standing double precision DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "chrStandings"."toID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrStandings"."toID" IS 'PROVEN: standingsvc.py:163 indexes charstandings on ''toID''.';


--
-- Name: COLUMN "chrStandings".standing; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrStandings".standing IS 'PROVEN: read as .standing off a row of the charstandings rowset (standingsvc.py:188). character -> anyone.';


--
-- Data for Name: chrStandings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrStandings" ("characterID", "toID", standing) FROM stdin;
\.


--
-- Name: chrStandings chrStandings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrStandings"
    ADD CONSTRAINT "chrStandings_pkey" PRIMARY KEY ("characterID", "toID");


--
-- Name: chrstandings_to_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chrstandings_to_ix ON public."chrStandings" USING btree ("toID");


--
-- Name: INDEX chrstandings_to_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.chrstandings_to_ix IS 'Reverse of the PK (characterID, toID): "who has set a standing towards me".';


--
-- PostgreSQL database dump complete
--

\unrestrict p5Sb4hOI0UJ3eFGTbCYW1cdSJQ5TF18V0efXYdVFfCyWoraqTL56W14qfil1ume

