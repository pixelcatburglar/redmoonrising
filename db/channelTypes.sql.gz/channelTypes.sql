--
-- PostgreSQL database dump
--

\restrict 3vSL0yDhMqh3adRFoyYma0AbRAmbunfS6T7DlboLzjuTdMce6QY7EjPYcnG7ZaG

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channelTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."channelTypes" (
    "channelTypeID" integer DEFAULT 0 NOT NULL,
    "channelTypeName" text DEFAULT ''::text NOT NULL,
    "defaultName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: channelTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."channelTypes" ("channelTypeID", "channelTypeName", "defaultName") FROM stdin;
\.


--
-- Name: channelTypes channelTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."channelTypes"
    ADD CONSTRAINT "channelTypes_pkey" PRIMARY KEY ("channelTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict 3vSL0yDhMqh3adRFoyYma0AbRAmbunfS6T7DlboLzjuTdMce6QY7EjPYcnG7ZaG

