--
-- PostgreSQL database dump
--

\restrict bhE6g92SwU6X9pgq0KbgPL3xP7LejKThhMShlh33vmjslgypcSLllnoET7eXTff

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramInstallationTypeDefaultContents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramInstallationTypeDefaultContents" (
    "installationTypeID" integer DEFAULT 0 NOT NULL,
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "UIGroupingID" integer DEFAULT 0 NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    "costInstall" double precision DEFAULT 0 NOT NULL,
    "costPerHour" double precision DEFAULT 0 NOT NULL,
    "restrictionMask" integer DEFAULT 0 NOT NULL,
    "discountPerGoodStandingPoint" double precision DEFAULT 0 NOT NULL,
    "surchargePerBadStandingPoint" double precision DEFAULT 0 NOT NULL,
    "minimumStanding" double precision DEFAULT 0 NOT NULL,
    "minimumCharSecurity" double precision DEFAULT 0 NOT NULL,
    "minimumCorpSecurity" double precision DEFAULT 0 NOT NULL,
    "maximumCharSecurity" double precision DEFAULT 0 NOT NULL,
    "maximumCorpSecurity" double precision DEFAULT 0 NOT NULL
);


--
-- Data for Name: ramInstallationTypeDefaultContents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramInstallationTypeDefaultContents" ("installationTypeID", "assemblyLineTypeID", "UIGroupingID", quantity, "costInstall", "costPerHour", "restrictionMask", "discountPerGoodStandingPoint", "surchargePerBadStandingPoint", "minimumStanding", "minimumCharSecurity", "minimumCorpSecurity", "maximumCharSecurity", "maximumCorpSecurity") FROM stdin;
\.


--
-- Name: ramInstallationTypeDefaultContents ramInstallationTypeDefaultContents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramInstallationTypeDefaultContents"
    ADD CONSTRAINT "ramInstallationTypeDefaultContents_pkey" PRIMARY KEY ("installationTypeID");


--
-- Name: ramInstallationTypeDefaultContents_assemblyLineTypeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ramInstallationTypeDefaultContents_assemblyLineTypeID_idx" ON public."ramInstallationTypeDefaultContents" USING btree ("assemblyLineTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict bhE6g92SwU6X9pgq0KbgPL3xP7LejKThhMShlh33vmjslgypcSLllnoET7eXTff

