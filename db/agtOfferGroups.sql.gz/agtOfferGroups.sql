--
-- PostgreSQL database dump
--

\restrict ChozRXS4UqCoZCtroM4SSk3HP9ZAyLgZKJ3jfcGirDBfqdGJtpPB1FI7nSZIfrn

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtOfferGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtOfferGroups" (
    "corporationID" integer DEFAULT 0 NOT NULL,
    "divisionID" integer DEFAULT 0 NOT NULL,
    level integer DEFAULT 0 NOT NULL,
    "offerID" integer
);


--
-- Data for Name: agtOfferGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtOfferGroups" ("corporationID", "divisionID", level, "offerID") FROM stdin;
\.


--
-- Name: agtOfferGroups agtOfferGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtOfferGroups"
    ADD CONSTRAINT "agtOfferGroups_pkey" PRIMARY KEY ("corporationID", "divisionID", level);


--
-- Name: agtOfferGroups_divisionID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtOfferGroups_divisionID_idx" ON public."agtOfferGroups" USING btree ("divisionID");


--
-- Name: agtOfferGroups_offerID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtOfferGroups_offerID_idx" ON public."agtOfferGroups" USING btree ("offerID");


--
-- PostgreSQL database dump complete
--

\unrestrict ChozRXS4UqCoZCtroM4SSk3HP9ZAyLgZKJ3jfcGirDBfqdGJtpPB1FI7nSZIfrn

