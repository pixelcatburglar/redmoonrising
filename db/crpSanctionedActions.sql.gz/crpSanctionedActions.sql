--
-- PostgreSQL database dump
--

\restrict dUrBB3qo6lIrTgVH3LixIwKREXuiwhQRK9fc8JbTDUPapBwr5aQSNvuCARVd9IX

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpSanctionedActions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpSanctionedActions" (
    "voteCaseID" integer NOT NULL,
    "corporationID" integer NOT NULL,
    "timeActioned" bigint,
    "actedUpon" smallint DEFAULT 0 NOT NULL,
    "inEffect" smallint DEFAULT 0 NOT NULL,
    reason text DEFAULT ''::text NOT NULL
);


--
-- Name: TABLE "crpSanctionedActions"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."crpSanctionedActions" IS 'Passed votes awaiting or in force. Serves corpRegistry.GetSanctionedActionsByCorporation / UpdateSanctionedAction / ExecuteActions. Push: OnSanctionedActionChanged(corpID, voteCaseID, change) (bco_sanctionedActions.py:45). The returned row must JOIN crpVoteCases/crpVoteOptions -- corp_ui_votes.py:320-321 reads .voteType and .parameter off it.';


--
-- Name: COLUMN "crpSanctionedActions"."voteCaseID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpSanctionedActions"."voteCaseID" IS 'PROVEN: the index key of the returned IndexRowset (bco_sanctionedActions.py:34 util.IndexRowset(rowset.header, rowset.lines, ''voteCaseID'')) and the 1st arg of UpdateSanctionedAction.';


--
-- Name: COLUMN "crpSanctionedActions"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpSanctionedActions"."corporationID" IS 'PROVEN: GetSanctionedActionsByCorporation(corporationID) (bco_sanctionedActions.py:32).';


--
-- Name: COLUMN "crpSanctionedActions"."timeActioned"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpSanctionedActions"."timeActioned" IS 'INFERRED. Windows FILETIME the action was executed by ExecuteActions.';


--
-- Name: COLUMN "crpSanctionedActions"."actedUpon"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpSanctionedActions"."actedUpon" IS 'INFERRED 0/1. Whether ExecuteActions has already run this one.';


--
-- Name: COLUMN "crpSanctionedActions"."inEffect"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpSanctionedActions"."inEffect" IS 'PROVEN 0/1: bco_sanctionedActions.py:36-38 filters `row.inEffect == inEffect`, corp_ui_votes.py:320 tests it, and it is the 2nd arg of UpdateSanctionedAction (bco_sanctionedActions.py:41).';


--
-- Name: COLUMN "crpSanctionedActions".reason; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpSanctionedActions".reason IS 'PROVEN as an argument: 3rd arg of UpdateSanctionedAction (bco_sanctionedActions.py:41). No client read.';


--
-- Data for Name: crpSanctionedActions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpSanctionedActions" ("voteCaseID", "corporationID", "timeActioned", "actedUpon", "inEffect", reason) FROM stdin;
\.


--
-- Name: crpSanctionedActions crpSanctionedActions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpSanctionedActions"
    ADD CONSTRAINT "crpSanctionedActions_pkey" PRIMARY KEY ("voteCaseID");


--
-- Name: crpsanctioned_corp_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crpsanctioned_corp_ix ON public."crpSanctionedActions" USING btree ("corporationID", "inEffect");


--
-- Name: INDEX crpsanctioned_corp_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.crpsanctioned_corp_ix IS 'GetSanctionedActionsByCorporation(corporationID, inEffect) (bco_sanctionedActions.py:32-38).';



--
-- PostgreSQL database dump complete
--

\unrestrict dUrBB3qo6lIrTgVH3LixIwKREXuiwhQRK9fc8JbTDUPapBwr5aQSNvuCARVd9IX

