--
-- PostgreSQL database dump
--

\restrict A1weS9T0lteVyFMWI6fFqeOaJOPBoa1zYlEYaY2S4Kg72dlCvG3ERyhQdUke6Qe

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrAccessories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrAccessories" (
    "accessoryID" integer DEFAULT 0 NOT NULL,
    "accessoryName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrAccessories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrAccessories" ("accessoryID", "accessoryName") FROM stdin;
1	None
2	None2
3	Sunglasses black
4	Sunglasses brown
5	Sunglasses green
6	Sunglasses shiny
7	Bone pierce
8	Iron pierce
9	Necklace
10	Necklace green emerald
11	Red stone
12	Cheekpins
13	Metal pins
14	Pindevil
15	Transparent mask
16	Sunglasses
17	smooth mask
18	mask
19	Grey metal mask
20	Goatee
21	Desert Mask
\.


--
-- Name: chrAccessories chrAccessories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrAccessories"
    ADD CONSTRAINT "chrAccessories_pkey" PRIMARY KEY ("accessoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict A1weS9T0lteVyFMWI6fFqeOaJOPBoa1zYlEYaY2S4Kg72dlCvG3ERyhQdUke6Qe

