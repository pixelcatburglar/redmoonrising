--
-- PostgreSQL database dump
--

\restrict yHeKv4wyLYR9sWT3rV5UmrrHgwcEszoxjKMFldMAfA9h3Z5TD9X1JNpdvXRLMgz

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eveStatistics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."eveStatistics" (
    "statisticID" integer DEFAULT 0 NOT NULL,
    "statisticName" text DEFAULT ''::text NOT NULL,
    "statisticType" integer DEFAULT 0 NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "orderID" integer DEFAULT 0 NOT NULL,
    "graphicID" integer
);


--
-- Data for Name: eveStatistics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."eveStatistics" ("statisticID", "statisticName", "statisticType", description, "orderID", "graphicID") FROM stdin;
1	Death Count	1		0	\N
2	Player Kills	1		0	\N
3	Police Kills	1		0	\N
4	Civilian Kills	1		0	\N
5	Pirate Kills	1		0	\N
6	Druglord Kills	1		0	\N
\.


--
-- Name: eveStatistics eveStatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."eveStatistics"
    ADD CONSTRAINT "eveStatistics_pkey" PRIMARY KEY ("statisticID");


--
-- PostgreSQL database dump complete
--

\unrestrict yHeKv4wyLYR9sWT3rV5UmrrHgwcEszoxjKMFldMAfA9h3Z5TD9X1JNpdvXRLMgz

