--
-- PostgreSQL database dump
--

\restrict peoXiXXBFqYtCzlXBlYTbu6zYcJWORpNvGY0qG8scI6MbZo9YJswdRq6AmfxyBJ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramALTypeCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramALTypeCategory" (
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "activityID" integer DEFAULT 0 NOT NULL,
    "categoryID" integer DEFAULT 0 NOT NULL,
    "timeMultiplier" double precision DEFAULT 0 NOT NULL,
    "materialMultiplier" double precision DEFAULT 0 NOT NULL
);


--
-- Data for Name: ramALTypeCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramALTypeCategory" ("assemblyLineTypeID", "activityID", "categoryID", "timeMultiplier", "materialMultiplier") FROM stdin;
2	5	6	5	5
2	5	7	1	1
2	5	8	1	1
2	5	18	1	1
3	7	7	1	1
5	5	9	1	1
6	1	2	1	1
6	1	4	1	1
6	1	5	1	1
6	1	7	1	1
6	1	8	1	1
6	1	17	1	1
6	1	18	1	1
6	1	20	1	1
6	1	22	1	1
7	4	9	1	1
8	3	9	1	1
11	4	6	1	1
11	4	7	1	1
11	4	8	1	1
11	4	18	1	1
12	3	6	1	1
12	3	7	1	1
12	3	8	1	1
12	3	18	1	1
13	1	6	1	1
13	1	7	1	1
13	1	8	1	1
13	1	18	1	1
23	1	2	1	1
23	1	4	1	1
23	1	5	1	1
23	1	7	1	1
23	1	17	1	1
23	1	20	1	1
23	1	22	1	1
24	1	2	1	1
24	1	4	1	1
24	1	5	1	1
24	1	7	1	1
24	1	20	1	1
24	1	22	1	1
25	1	8	1	1
28	4	9	1	1
29	3	9	1	1
30	5	9	1	1
31	1	2	1	1
31	1	4	1	1
31	1	5	1	1
31	1	7	1	1
31	1	8	1	1
31	1	17	1	1
31	1	18	1	1
31	1	20	1	1
31	1	22	1	1
32	4	9	1	1
33	3	9	1	1
34	5	9	1	1
35	1	2	1	1
35	1	4	1	1
35	1	5	1	1
35	1	7	1	1
35	1	8	1	1
35	1	17	1	1
35	1	18	1	1
35	1	20	1	1
35	1	22	1	1
36	8	6	1	1
36	8	7	1	1
36	8	8	1	1
\.


--
-- Name: ramALTypeCategory ramALTypeCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramALTypeCategory"
    ADD CONSTRAINT "ramALTypeCategory_pkey" PRIMARY KEY ("assemblyLineTypeID", "categoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict peoXiXXBFqYtCzlXBlYTbu6zYcJWORpNvGY0qG8scI6MbZo9YJswdRq6AmfxyBJ

