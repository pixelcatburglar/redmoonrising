--
-- PostgreSQL database dump
--

\restrict vq49MdsaEpEHmNxlepOIy6AnoqwTpF7RLxvMf8eBKbclQc1UgR6gioCPoJG7Z4g

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: posLinks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."posLinks" (
    "sourceID" integer NOT NULL,
    "typeID" integer NOT NULL,
    "destinationID" integer NOT NULL
);


--
-- Name: TABLE "posLinks"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."posLinks" IS 'Starbase production links: what each structure passes on, and to which structure (posMgr.LinkResourceForTower).';


--
-- Data for Name: posLinks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."posLinks" ("sourceID", "typeID", "destinationID") FROM stdin;
\.


--
-- Name: posLinks posLinks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."posLinks"
    ADD CONSTRAINT "posLinks_pkey" PRIMARY KEY ("sourceID", "typeID");


--
-- PostgreSQL database dump complete
--

\unrestrict vq49MdsaEpEHmNxlepOIy6AnoqwTpF7RLxvMf8eBKbclQc1UgR6gioCPoJG7Z4g

