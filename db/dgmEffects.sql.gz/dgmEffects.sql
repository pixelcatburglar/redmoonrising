--
-- PostgreSQL database dump
--

\restrict 8T27MLJ1whzAut7mz2Rv8cDI7D2rsKiLYPblSDXm4A0uYCczYebx51UwVYuUbY2

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dgmEffects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."dgmEffects" (
    "effectID" integer NOT NULL,
    "effectName" text,
    "effectCategory" integer,
    "preExpression" integer,
    "postExpression" integer,
    description text,
    guid text,
    "graphicID" integer,
    "isOffensive" integer,
    "isAssistance" integer,
    "durationAttributeID" integer,
    "trackingSpeedAttributeID" integer,
    "dischargeAttributeID" integer,
    "rangeAttributeID" integer,
    "falloffAttributeID" integer,
    "disallowAutoRepeat" integer,
    published integer,
    "displayName" text,
    "isWarpSafe" integer,
    "rangeChance" integer,
    "electronicChance" integer,
    "propulsionChance" integer,
    distribution integer,
    "sfxName" text,
    "npcUsageChanceAttributeID" integer,
    "npcActivationChanceAttributeID" integer,
    "fittingUsageChanceAttributeID" integer
);


--
-- Data for Name: dgmEffects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."dgmEffects" ("effectID", "effectName", "effectCategory", "preExpression", "postExpression", description, guid, "graphicID", "isOffensive", "isAssistance", "durationAttributeID", "trackingSpeedAttributeID", "dischargeAttributeID", "rangeAttributeID", "falloffAttributeID", "disallowAutoRepeat", published, "displayName", "isWarpSafe", "rangeChance", "electronicChance", "propulsionChance", distribution, "sfxName", "npcUsageChanceAttributeID", "npcActivationChanceAttributeID", "fittingUsageChanceAttributeID") FROM stdin;
4	shieldBoosting	1	183	131		effects.ShieldBoosting	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	0	\N	\N	\N	\N
7	speedBoost	1	3517	3518		effects.SpeedBoost	\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
9	missileLaunching	2	114	89	Launches a missile	effects.MissileDeployment	\N	1	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
10	targetAttack	2	115	89	Combat	effects.Laser	\N	1	0	51	160	6	54	158	0	1		0	0	0	0	2	\N	\N	\N	\N
11	loPower	0	131	131	Requires a low power slot.		295	0	0	\N	\N	\N	\N	\N	0	1	Low power	0	0	0	0	\N	\N	\N	\N	\N
12	hiPower	0	131	131	Requires a high power slot.		293	0	0	\N	\N	\N	\N	\N	0	1	High power	0	0	0	0	\N	\N	\N	\N	\N
13	medPower	0	131	131	Requires a medium power slot.		294	0	0	\N	\N	\N	\N	\N	0	1	Medium power	0	0	0	0	\N	\N	\N	\N	\N
16	online	1	633	400	this is the online effect		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
17	mining	2	3134	184	mining of ore	effects.Mining	\N	0	0	73	\N	\N	54	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
18	shieldTransfer	2	185	89	Boosts the shield of the target ship by draining the doers ships shield.	effects.ShieldTransfer	\N	0	1	73	\N	6	87	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
21	shieldCapacityBonusOnline	4	199	201	Increases maximum shield capacity.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
22	maxVelocityBonus	4	205	206	Enhances the maximum speed of the ship.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
23	scaleModuleHP	0	211	212	Scales hit points of all fitted modules.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
25	capacitorCapacityBonus	4	227	228			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
26	structureRepair	1	131	233		effects.StructureRepair	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	\N	\N	\N	\N	\N
27	armorRepair	1	131	236	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	0	\N	\N	\N	\N
29	modifyTargetSpeed	2	3489	3491		effects.ModifyTargetSpeed	\N	0	0	73	\N	6	54	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
31	energyTransfer	2	131	258		effects.EnergyTransfer	\N	0	1	73	\N	6	91	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
32	energyVampire	2	270	131	Steals power from the target.	effects.EnergyVampire	\N	1	0	73	\N	\N	91	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
34	projectileFired	2	115	131		effects.ProjectileFired	\N	1	0	51	160	6	54	158	0	1		0	0	0	0	2	\N	\N	\N	\N
36	energyDestabilization	2	286	131	Drains power from the target.	effects.EnergyDestabilization	\N	1	0	73	\N	6	98	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
38	empWave	1	288	131	Triggering of an EMP wave being broadcast into space.	effects.EMPWave	\N	1	0	73	\N	6	99	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
39	warpScramble	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	73	\N	6	54	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
40	launcherFitted	0	373	319			\N	0	0	\N	\N	\N	\N	0	0	1		0	0	0	0	\N	\N	\N	\N	\N
42	turretFitted	0	379	305	This is just a test. Ehmm. If your'e reading this in an error message, your ship probably doesn't have any turret slot left.		\N	0	0	\N	\N	\N	\N	0	0	1		0	0	0	0	\N	\N	\N	\N	\N
46	shipScan	2	131	402	Scans the energy status, cargo and hardware of a given ship.	effects.ShipScan	\N	0	0	73	\N	6	125	510	0	1		0	0	0	0	0	\N	\N	\N	\N
47	cargoScan	2	131	403	Scan the cargo of a targeted ship.	effects.CargoScan	\N	0	0	73	\N	6	126	509	0	1		0	0	0	0	\N	\N	\N	\N	\N
48	powerBooster	1	404	131	Consumes power booster charges to increase the available power in the capacitor.		\N	0	0	73	\N	\N	\N	\N	0	1		1	0	0	0	\N	\N	\N	\N	\N
49	modifyShieldResonance	1	431	434		effects.ModifyShieldResonance	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	2	\N	\N	\N	\N
50	modifyShieldRechargeRate	4	439	440			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
51	modifyPowerRechargeRate	4	443	444			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
53	ecmBurst	1	471	131		effects.ECMBurst	\N	1	0	73	\N	6	142	158	0	1		0	1	1	0	2	\N	\N	\N	\N
54	targetPassively	2	472	131	Targets an object without letting it know.		\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
55	targetHostiles	1	131	473	Target all hostile ships within range (if electronics can handle it).		\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
56	powerOutputMultiply	4	477	478			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
57	shieldCapacityMultiply	4	485	486			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
58	capacitorCapacityMultiply	4	483	484			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
59	cargoCapacityMultiply	4	490	491			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
60	structureHPMultiply	4	494	495			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
61	agilityBonus	0	500	501			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
62	maxPassengersBonus	0	506	507			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
63	armorHPMultiply	4	509	510			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
64	armorResonanceMultiply	4	529	532			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
67	miningLaser	2	3134	184	Mining of ore.	effects.Laser	\N	0	0	73	\N	6	54	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
70	agilityMultiply	0	566	567	Scale the agility of a ship.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
73	repairCostMultiply	0	578	579			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
81	surveyScan	1	131	602	Scanning an asteroid to determine any helpful information.	effects.SurveyScan	\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
82	corporationMemberLimitBonus	0	609	610	Modify the maximum number of members a character is capable of managing in a corporation.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
87	cpuUsageMultiply	0	638	639	Scales amount of CPU used by module(s).		\N	0	0	\N	\N	\N	\N	1	0	1		0	0	0	0	\N	\N	\N	\N	\N
88	miningDurationMultiply	0	646	647	Scales the mining duration of a mining laser module.		\N	0	0	\N	\N	\N	\N	1	0	1		0	0	0	0	\N	\N	\N	\N	\N
89	projectileWeaponSpeedMultiply	4	654	655	Scale the projectile weapon firing speed.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
91	energyWeaponDamageMultiply	4	668	671	Scales the damage done by all fitted energy weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
92	projectileWeaponDamageMultiply	4	667	670	Scales the damage done by all fitted projectile weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
93	hybridWeaponDamageMultiply	4	669	672	Scales the damage done by all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
95	energyWeaponSpeedMultiply	4	681	683	Scales the rate of fire of all fitted energy weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
96	hybridWeaponSpeedMultiply	4	682	684	Scales the rate of fire of all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
97	turretWeaponAccuracyMultiply	0	703	705	Scale the accuracy of all fitted turret weapons.		\N	0	0	\N	\N	\N	\N	1	0	1		0	0	0	0	\N	\N	\N	\N	\N
100	hybridWeaponAccuracyMultiply	0	698	701	Scales the accuracy of all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	1	0	1		0	0	0	0	\N	\N	\N	\N	\N
101	useMissiles	1	131	131	The ammunition loaded into this item defines its operation.		\N	0	0	51	\N	6	\N	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
102	mineLaying	1	114	131	Drops a mine in space.		\N	1	0	\N	\N	\N	\N	1	0	1		0	0	0	0	\N	\N	\N	\N	\N
103	defenderMissileLaunching	1	706	131	Drops a defender missile in space to go do its thing.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
104	fofMissileLaunching	1	707	131	Launches an FOF missile.  Auto targets at someone hostile to you.		\N	1	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
105	shieldResonanceMultiplyOnline	4	431	434			\N	0	0	\N	\N	\N	\N	1	0	1		0	0	0	0	\N	\N	\N	\N	\N
106	miningAmountMultiply	0	715	716	Scales the amount mined by all fitted mining lasers.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
107	characterMissileDamageMultiply	0	721	722	Increases the damage scaling done to missiles damage for missiles launched by the character.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
109	turretWeaponCapacitorNeedMultiply	0	743	745	Scales the capacitor need for all the fitted turret weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1	turretWeaponCapacitorMultiply	0	0	0	0	\N	\N	\N	\N	\N
110	characterBlueprintResearchTimeBonus	0	750	751	Modifies the aptitude the character has for researching blueprints by a given percentage.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
111	characterBlueprintManufactureTimeBonus	0	756	757	Modifies the aptitude the character has for manufacturing from blueprints by a given percentage.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
112	characterCharismaSkillTrainingTimeBonus	0	778	779	Modifies the speed at which skills with charisma as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
113	characterIntelligenceSkillTrainingTimeBonus	0	780	781	Modifies the speed at which skills with intelligence as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
114	characterMemorySkillTrainingTimeBonus	0	782	783	Modifies the speed at which skills with memory as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
115	characterPerceptionSkillTrainingTimeBonus	0	785	784	Modifies the speed at which skills with perception as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
116	characterWillpowerSkillTrainingTimeBonus	0	786	787	Modifies the speed at which skills with willpower as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
117	scanStrengthBonusOnline	4	832	835	Modifies the various electronics scan strengths.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
118	electronicAttributeModifyOnline	4	846	847	Modifies the targeting range of a ship and also the maximum number of targets that its electronics can lock and also how long it takes to lock targets.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
120	turretWeaponRangeTrackingSpeedMultiplyOnline	4	884	885	Scales the range and tracking speed of turret weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
121	scanStrengthBonusActivate	1	832	835	Boosts some of the scan strengths for the period of activation.	effects.ScanStrengthBonusActivate	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	\N	\N	\N	\N	\N
123	turretWeaponRangeTrackingSpeedMultiplyActivate	1	884	885	Modifies maximum turret weapon range and tracking speed for the length of the duration.	effects.TurretWeaponRangeTrackingSpeedMultiplyActivate	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	\N	\N	\N	\N	\N
124	scanStrengthBonusTarget	2	956	903	Modifies the scanning strengths of a targeted object.	effects.ScanStrengthBonusTarget	\N	0	1	73	\N	6	\N	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
126	turretWeaponRangeTrackingSpeedMultiplyTarget	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.TurretWeaponRangeTrackingSpeedMultiplyTarget	\N	0	1	73	\N	6	54	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
127	torpedoLaunching	1	114	131		effects.TorpedoDeployment	\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
130	cheatTeleDock	2	1018	131	Automatically docks at the targeted station.		\N	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
131	cheatTeleGate	2	1019	131	Automatically invokes the destination of the target stargate.		\N	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
132	skillEffect	0	1071	1070	masks skill level onto skill modules.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
146	damageMultiplierSkillBonus	0	1167	1168	Boost of damageMultiplier by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1	DamageBonus	0	0	0	0	\N	\N	\N	\N	\N
150	gallenteFrigateSkillBoostCpuskillBonus	0	1158	1159	Boost of CpuskillBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
152	skillBoostDamageMultiplierBonus	0	1167	1168	Boost of damageMultiplierBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1	SkillBoostDamageMultiplierBonus	0	0	0	0	\N	\N	\N	\N	\N
157	largeHybridTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringLargeHybridTurret	0	1188	1189	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
159	mediumEnergyTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringMediumEnergyTurret	0	1200	1201	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
160	mediumHybridTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringMediumHybridTurret	0	1206	1207	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
161	mediumProjectileTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringMediumProjectileTurret	0	1212	1213	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
162	largeEnergyTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringLargeEnergyTurret	0	1174	1175	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
163	rapidFiringSkillBoostRofBonus	0	1217	1218	Boost of rofBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
167	sharpshooterSkillBoostRangeSkillBonus	0	1241	1242	Boost of rangeSkillBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
172	smallEnergyTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringSmallEnergyTurret	0	1266	1267	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
173	smallHybridTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringSmallHybridTurret	0	1272	1273	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
174	smallProjectileTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringSmallProjectileTurret	0	1278	1279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
175	dronesSkillBoostSpeedBonus	0	1282	1283	Boost of speedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
187	caldariCruiserSkillBoostCcTRangeBonus	0	1331	1332	Boost of ccTRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
189	caldariFrigateSkillBoostCfTRangeBonus	0	1338	1339	Boost of cfTRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
199	minmatarBattleshipSkillBoostMMaxVelocityBonus	0	1375	1376	Boost of mMaxVelocityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
204	signatureAnalysisSkillBoostScanspeedBonus	0	1403	1404	Boost of scanspeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
205	signatureAnalysisScanspeedBonusPostPercentScanSpeedLocationShip	0	1407	1408	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Targeting Speed Bonus	0	0	0	0	\N	\N	\N	\N	\N
206	longRangeTargetingSkillBoostMaxTargetRangeBonus	0	1412	1413	Boost of MaxTargetRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
208	propulsionJammingSkillBoostDurationBonus	0	1423	1424	Boost of durationBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
209	propulsionJammingDurationBonusPostPercentDurationLocationShipModulesRequiringPropulsionJamming	0	1429	1430	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
210	sensorLinkingDurationBonusPostPercentDurationLocationShipModulesRequiringSensorLinking	0	1435	1436	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
211	sensorUpgradesSkillBoostCpuNeedBonus	0	1440	1441	Boost of cpuNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
212	sensorUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringSensorUpgrades	0	1446	1447	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	CPU need reduction	0	0	0	0	\N	\N	\N	\N	\N
213	targetingSkillBoostMaxTargetBonus	0	1451	1452	Boost of maxTarget Bonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
214	targetingMaxTargetBonusModAddMaxLockedTargetsLocationChar	0	1453	1454	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
215	weaponDisruptionDurationBonusPostPercentDurationLocationShipModulesRequiringWeaponDisruption	0	1459	1460	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Duration Bonus	0	0	0	0	\N	\N	\N	\N	\N
216	electronicWarfareSkillBoostDurationBonus	0	1464	1465	Boost of DurationBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
218	engineeringSkillBoostPowerOutputBonus	0	1475	1476	Boost of PowerOutputBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
220	energyManagementSkillBoostCapRechargeBonus	0	1482	1483	Boost of CapRechargeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
222	navigationSkillBoostVelocityBonus	0	1491	1492	Boost of velocityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
223	navigationVelocityBonusPostPercentMaxVelocityLocationShip	0	1494	1495	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Velocity Bonus	0	0	0	0	\N	\N	\N	\N	\N
225	accerationControlSkillBoostCapNeedBonus	0	1504	1505	Boost of capNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
227	accerationControlCapNeedBonusPostPercentCapacitorNeedLocationShipGroupAfterburner	0	1516	1517	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor need reduction	0	0	0	0	\N	\N	\N	\N	\N
228	accerationControlSkillBoostSpeedFBonus	0	1521	1522	Boost of speedFBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
230	afterburnerDurationBonusPostPercentDurationLocationShipModulesRequiringAfterburner	0	1531	1532	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
232	evasiveManuveringSkillBoostAgilityBonus	0	1541	1542	Boost of agilityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
234	warpdriveoperationSkillBoostWarpCapacitorNeedBonus	0	1549	1550	Boost of warpCapacitorNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
235	warpdriveoperationWarpCapacitorNeedBonusPostPercentWarpCapacitorNeedLocationShip	0	1553	1554	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
236	energyEmmisionSystemsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringEnergyEmmisionSystems	0	1559	1560	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor Need Reduction	0	0	0	0	\N	\N	\N	\N	\N
239	corporationManagementSkillBoostCorporationMemberBonus	0	1574	1575	Boost of corporationMemberBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
242	accerationControlSpeedFBonusPostPercentSpeedFactorLocationShipGroupAfterburner	0	1587	1588	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Aterburner Velocity Bonus	0	0	0	0	\N	\N	\N	\N	\N
243	highSpeedManuveringSkillBoostCapacitorNeedMultiplier	0	1591	1592	Boost of capacitorNeedMultiplier by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
244	highSpeedManuveringCapacitorNeedMultiplierPostPercentCapacitorNeedLocationShipModulesRequiringHighSpeedManuvering	0	1597	1598	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
246	sensorUpgradesSkillBoostPowerNeedBonus	0	1614	1615	Boost of PowerNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
251	hullUpgradesSkillBoostHullHpBonus	0	1631	1632	Boost of hullHpBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
253	shadowBarrageDmgMultiplierWithDamageMultiplierPostPercentBarrageDmgMutator	0	1645	1646	Set barrageDmgMultiplier to damageMultiplier modified (PostPercent) by BarrageDmgMutator		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
898	shipMissileKineticDamageCF	0	4119	4120	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
254	shadowBarrageFalloffWithFalloffPostPercentBarrageFalloffMutator	0	1657	1658	Set barrageFalloff to falloff modified (PostPercent) by barrageFalloffMutator		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
263	barrage	2	1659	1104	Barrage Attack, Attack with barrageDmgMultiplier as a damage multiplier	effects.Barrage	\N	1	0	51	160	6	54	328	0	1	Barrage Attack	0	0	0	0	0	\N	\N	\N	\N
267	amarrCruiserSkillBoostPowerOutputBonus	0	1676	1677	Boost of powerOutputBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
270	hullUpgradesSkillBoostArmorHpBonus	0	1689	1690	Boost of armorHpBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
271	hullUpgradesArmorHpBonusPostPercentHpLocationShip	0	1691	1692	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Armor Hp Bonus	0	0	0	0	\N	\N	\N	\N	\N
272	repairSystemsDurationBonusPostPercentDurationLocationShipModulesRequiringRepairSystems	0	1697	1698	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
273	shieldUpgradesPowerNeedBonusPostPercentPowerLocationShipModulesRequiringShieldUpgrades	0	1703	1704	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Power need reduction	0	0	0	0	\N	\N	\N	\N	\N
274	energyManagementSkillBoostCapacitorBonus	0	1707	1708	Boost of capacitorBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
277	tacticalshieldManipulationSkillBoostUniformityBonus	0	1721	1722	Boost of uniformityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
279	shieldEmmisionSystemsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringShieldEmmisionSystems	0	1732	1733	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor need Bonus	0	0	0	0	\N	\N	\N	\N	\N
280	shieldManagementSkillBoostShieldCapacityBonus	0	1737	1738	Boost of shieldCapacityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
283	shieldoperationSkillBoostRechargeratebonus	0	1751	1752	Boost of rechargeratebonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
287	controlledBurstsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringGunnery	0	1774	1775	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor Need Reductin	0	0	0	0	\N	\N	\N	\N	\N
288	skillBoostTrackingSpeedMultiplier	0	1782	1783	Boost of trackingSpeedMultiplier by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
289	motionPredictionTrackingSpeedMultiplierPostPercentTrackingSpeedLocationShipModulesRequiringGunnery	0	1786	1787	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Tracking speed bonus	0	0	0	0	\N	\N	\N	\N	\N
290	sharpshooterRangeSkillBonusPostPercentMaxRangeLocationShipModulesRequiringGunnery	0	1790	1791	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Range Bonus	0	0	0	0	\N	\N	\N	\N	\N
297	skillBoostFalloffBonus	0	1806	1807	Boost of falloffBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
298	surgicalStrikeFalloffBonusPostPercentFalloffLocationShipModulesRequiringGunnery	0	1810	1811	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Falloff Bonus	0	0	0	0	\N	\N	\N	\N	\N
301	empathySkillBoostCharismaBonus	0	1824	1825	Boost of charismaBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
302	empathyCharismaBonusModAddCharismaLocationChar	0	1826	1827	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Charisma Bonus	0	0	0	0	\N	\N	\N	\N	\N
303	instantRecallSkillBoostMemoryBonus	0	1830	1831	Boost of memoryBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
304	instantRecallMemoryBonusModAddMemoryLocationChar	0	1832	1833	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
305	analyticalMindSkillBoostIntelligenceBonus	0	1836	1837	Boost of intelligenceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
306	analyticalMindIntelligenceBonusModAddIntelligenceLocationChar	0	1838	1839	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Inteligence bonus	0	0	0	0	\N	\N	\N	\N	\N
307	ironWillSkillBoostWillpowerBonus	0	1842	1843	Boost of willpowerBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
308	ironWillWillpowerBonusModAddWillpowerLocationChar	0	1844	1845	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Willpower bonus	0	0	0	0	\N	\N	\N	\N	\N
309	spatialAwarenessSkillBoostPerceptionBonus	0	1848	1849	Boost of perceptionBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
310	spatialAwarenessPerceptionBonusModAddPerceptionLocationChar	0	1850	1851	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Preception bonus	0	0	0	0	\N	\N	\N	\N	\N
312	signatureAnalysisMaxTargetRangeBonusPostPercentMaxTargetRangeLocationShip	0	1857	1858	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
315	dronesSkillBoostMaxActiveDroneBonus	0	1872	1873	Boost of maxActiveDroneBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
316	dronesMaxActiveDroneBonusModAddMaxActiveLocationChar	0	1876	1877	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dronesMaxActiveDroneBonusModAddMaxActiveDronesLocationChar	0	0	0	0	\N	\N	\N	\N	\N
317	amarrTechSkillBoostAmarrTechMutator	0	1894	1895	Boost of amarrTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
318	amarrTechAmarrTechMutatorPostPercentAmarrTechTimePercentLocationChar	0	1898	1899	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Amarr tech skill bonus	0	0	0	0	\N	\N	\N	\N	\N
319	caldariTechSkillBoostCaldariTechMutator	0	1903	1904	Boost of caldariTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
320	caldariTechCaldariTechMutatorPostPercentCaldariTechTimePercentLocationChar	0	1907	1908	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Caldari tech production bonus	0	0	0	0	\N	\N	\N	\N	\N
321	gallenteTechSkillBoostGallenteTechMutator	0	1912	1913	Boost of gallenteTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
322	gallenteTechGallenteTechMutatorPostPercentGallenteTechTimePercentLocationChar	0	1916	1917	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Gallente Tech time	0	0	0	0	\N	\N	\N	\N	\N
325	minmatarTechSkillBoostMinmatarTechMutator	0	1930	1931	Boost of minmatarTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
326	minmatarTechMinmatarTechMutatorPostPercentMinmatarTechTimePercentLocationChar	0	1934	1935	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Minmatar tech bonus	0	0	0	0	\N	\N	\N	\N	\N
331	refineryEfficiencySkillBoostRefiningYieldMutator	0	1959	1960	Boost of refiningYieldMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
334	cSOTrainingSkillBoostResearchGangSizeBonus	0	1995	1996	Boost of researchGangSizeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
335	cSOTrainingResearchGangSizeBonusModAddMaxResearchGangSizeShip	0	1999	2000	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
336	battleshipConstructionSkillBoostBattleshipConstructionTimeBonus	0	2004	2005	Boost of battleshipConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
337	battleshipConstructionBattleshipConstructionTimeBonusPostPercentBattleshipConstructionTimeChar	0	2008	2009	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Battleship Construction Time	0	0	0	0	\N	\N	\N	\N	\N
338	cruiserConstructionSkillBoostCruiserConstructionTimeBonus	0	2013	2014	Boost of cruiserConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
339	cruiserConstructionCruiserConstructionTimeBonusPostPercentCruiserConstructionTimeChar	0	2017	2018	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
340	frigateConstructionSkillBoostFrigateConstructionTimeBonus	0	2022	2023	Boost of frigateConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
341	frigateConstructionFrigateConstructionTimeBonusPostPercentFrigateConstructionTimeChar	0	2026	2027	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
342	industrialConstructionSkillBoostIndustrialConstructionTimeBonus	0	2031	2032	Boost of industrialConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
343	industrialConstructionIndustrialConstructionTimeBonusPostPercentIndustrialConstructionTimeChar	0	2035	2036	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
344	connectionsSkillBoostConnectionBonusMutator	0	2040	2041	Boost of connectionBonusMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
346	criminalConnectionsSkillBoostCriminalConnectionsMutator	0	2049	2050	Boost of criminalConnectionsMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
348	diplomacySkillBoostDiplomacyMutator	0	2058	2059	Boost of diplomacyMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
349	diplomacyDiplomacyMutatorModAddDiplomacyBonusChar	0	2062	2063	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
350	fasttalkSkillBoostFastTalkMutator	0	2067	2068	Boost of fastTalkMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
352	fasttalkFastTalkMutatorPostPercentFastTalkPercentageChar	0	2074	2075	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
353	ethnicRelationsSkillBoostNonRaceCorporationMembersBonus	0	2081	2082	Boost of nonRaceCorporationMembersBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
354	ethnicRelationsNonRaceCorporationMembersBonusPostPercentMaxNonRaceCorporationMembersChar	0	2085	2086	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
355	ethnicRelationsNonRaceCorporationMembersBonusModAddMaxNonRaceCorporationMembersChar	0	2088	2089	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
356	assaultFormationDamageMultiplierBonusPostPercentDamageMultiplierGangShipModulesRequiringGunnery	0	2092	2093	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
357	battleFormationSkillBoostTrackingBonus	0	2097	2098	Boost of trackingBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
358	battleFormationTrackingBonusPostPercentTrackingSpeedGangShipModulesRequiringGunnery	0	2101	2102	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
359	convoyFormationMaxVelocityBonusPostPercentMaxVelocityGangShips	0	2105	2106	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
368	gallenteFrigateSkillBoostCpuOutputBonus	0	2157	2158	Boost of cpu OutputBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
373	heavyDroneOperationSkillBoostHeavyDroneDamageBonus	0	2174	2175	Boost of heavyDroneDamageBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
374	heavyDroneOperationHeavyDroneDamageBonusPostPercentHeavyDroneDamagePercentChar	0	2178	2179	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
389	astrogeologySkillBoostMiningAmountBonus	0	2232	2233	Boost of miningAmountBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
391	astrogeologyMiningAmountBonusPostPercentMiningAmountLocationShipModulesRequiringMining	0	2240	2241	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
392	mechanicHullHpBonusPostPercentHpShip	0	2242	2243	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
394	navigationVelocityBonusPostPercentMaxVelocityShip	0	2248	2249	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
395	evasiveManeuveringAgilityBonusPostPercentAgilityShip	0	2250	2251	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
396	energyGridUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringEnergyGridUpgrades	0	2256	2257	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
397	electronicsCpuOutputBonusPostPercentCpuOutputLocationShipGroupComputer	0	2258	2259	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
399	connectionsConnectionBonusMutatorModAddConnectionsBonusChar	0	2269	2270	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
402	criminalConnectionsCriminalConnectionsMutatorModAddCriminalConnectionsBonusChar	0	2278	2279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
403	negotiationSkillBoostNegotiationBonus	0	2283	2284	Boost of NegotiationBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
404	negotiationNegotiationBonusPostPercentNegotiationPercentageChar	0	2287	2288	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
406	socialSkillBoostSocialMutator	0	2296	2297	Boost of socialMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
407	socialSocialMutatorPostPercentSocialBonusChar	0	2300	2301	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
408	largeProjectileTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringLargeProjectileTurret	0	2306	2307	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
412	industrySkillBoostManufacturingTimeBonus	0	2323	2324	Boost of manufacturingTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
413	gunnerySkillBoostTurretSpeeBonus	0	2328	2329	Boost of TurretSpeeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
414	gunneryTurretSpeeBonusPostPercentSpeedLocationShipModulesRequiringGunnery	0	2330	2331	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
415	tradeSkillBoostTradePremiumBonus	0	2339	2340	Boost of tradePremiumBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
416	tradeTradePremiumBonusPostPercentTradePremiumChar	0	2343	2344	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
417	smugglingSkillBoostSmugglingChanceBonus	0	2348	2349	Boost of smugglingChanceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
425	industryManufacturingTimeBonusPostPercentManufactureTimeMultiplierChar	0	2379	2380	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
428	productionEfficiencySkillBoostManufactureCostBonus	0	2393	2394	Boost of manufactureCostBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
429	productionEfficiencyManufactureCostBonusPostPercentManufactureCostMultiplierChar	0	2395	2396	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
430	scienceSkillBoostCopySpeedBonus	0	2400	2401	Boost of CopySpeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
431	scienceCopySpeedBonusPostPercentCopySpeedPercentChar	0	2404	2405	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
432	researchSkillBoostBlueprintmanufactureTimeBonus	0	2409	2410	Boost of blueprintmanufactureTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
433	researchBlueprintmanufactureTimeBonusPostPercentProductionTimeResearchSpeedChar	0	2413	2414	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
435	refineryEfficiencyRefiningYieldMutatorPostPercentRefiningYieldPercentageChar	0	2421	2422	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
436	missileLauncherOperationSpeedBonusPostPercentSpeedLocationShipModulesRequiringMissileLauncherOperation	0	2429	2430	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
439	learningSkillBoostLearningBonus	0	2446	2447	Boost of learningBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
440	learningLearningBonusPostPercentIntelligenceChar	0	2449	2450	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
441	learningLearningBonusPostPercentWillpowerChar	0	2452	2453	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
442	learningLearningBonusPostPercentPerceptionChar	0	2455	2456	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
443	learningLearningBonusPostPercentCharismaChar	0	2458	2459	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
444	learningLearningBonusPostPercentMemoryChar	0	2461	2462	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
445	energyManagementCapacitorBonusPostPercentCapacityLocationShipGroupCapacitor	0	2468	2469	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
446	shieldManagementShieldCapacityBonusPostPercentCapacityLocationShipGroupShield	0	2472	2473	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
448	scoutDroneOperationSkillBoostDroneRangeBonus	0	2481	2482	Boost of droneRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
452	shipVelocityBonusMF	0	2497	2498	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
453	minmatarFrigateSkillLevelPreMulShipBonusMFShip	0	2500	2501	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
456	shipTargetRangeBonusMF	0	2511	2512	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
458	shipCargoBonusMF	0	2515	2516	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipCapacityBonusMF	0	0	0	0	\N	\N	\N	\N	\N
459	shipMiningBonusMF	0	2517	2518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
460	caldariFrigateSkillLevelPreMulShipBonusCFShip	0	2524	2525	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
462	shipHybridRangeBonusCF	0	2534	2535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
464	shipShieldCapBonusCF	0	2538	2539	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
466	shipTargetRangeBonusCF	0	2542	2543	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
468	gallenteFrigateSkillLevelPreMulShipBonusGFShip	0	2548	2549	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
469	shipMiningBonusGF	0	2550	2551	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
472	shipHybridTrackingBonusGf	0	2561	2562	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipHybridTrackingBonus	0	0	0	0	\N	\N	\N	\N	\N
474	shipTargetRangeBonusGF	0	2566	2567	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
476	amarrFrigateSkillLevelPreMulShipBonusAFShip	0	2573	2574	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
479	shipDroneRangeBonusGF	0	2581	2582	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
480	shipCargoBonusAF	0	2583	2584	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipCargoBonus	0	0	0	0	\N	\N	\N	\N	\N
481	metallurgySkillBoostMineralNeedResearchBonus	0	2588	2589	Boost of mineralNeedResearchBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
482	shipTargetingRangeBonusAF	0	2590	2591	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
485	energysystemsoperationCapRechargeBonusPostPercentRechargeRateLocationShipGroupCapacitor	0	2601	2602	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
486	shieldOperationRechargeratebonusPostPercentRechargeRateLocationShipGroupShield	0	2603	2604	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
490	engineeringPowerEngineeringOutputBonusPostPercentPowerOutputLocationShipGroupPowerCore	0	2616	2617	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
494	warpDriveOperationWarpCapacitorNeedBonusPostPercentWarpCapacitorNeedLocationShipGroupPropulsion	0	2636	2637	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
496	prototypingSkillBoostPrototypingBonus	0	2647	2648	Boost of prototypingBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
497	prototypingPrototypingBonusModAddPrototypingChanceChar	0	2654	2656	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
498	inventionSkillBoostInventionBonus	0	2655	2657	Boost of inventionBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
500	amarrCruiserSkillLevelPreMulShipBonusACShip	0	2668	2669	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
504	scoutDroneOperationDroneRangeBonusModAddDroneControlDistanceChar	0	2674	2675	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
506	fuelConservationCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringAfterburner	0	2690	2691	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
507	longRangeTargetingMaxTargetRangeBonusPostPercentMaxTargetRangeLocationShipGroupElectronic	0	2692	2693	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
508	shipPDmgBonusMF	0	2736	2737	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
509	shipCargoBonusCF	0	2738	2739	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
510	amarrFrigateSkillLevelPreMulShipBonus2AFShip	0	2743	2744	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
511	shipEnergyTCapNeedBonusAF	0	2747	2748	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
512	shipSHTDmgBonusGF	0	2751	2752	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
514	shipSETDmgBonusAF	0	2753	2754	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
516	shipTCapNeedBonusAC	0	2761	2762	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
517	gallenteCruiserSkillLevelPreMulShipBonusGCShip	0	2766	2767	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
520	caldariCruiserSkillLevelPreMulShipBonusCCShip	0	2777	2778	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
521	shipHRangeBonusCC	0	2783	2784	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
524	minmatarCruiserSkillLevelPreMulShipBonusMCShip	0	2802	2803	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
525	shipVelocityBonusMC	0	2804	2805	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
526	minmatarIndustrialSkillLevelPreMulShipBonusMIShip	0	2809	2810	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
527	shipVelocityBonusMI	0	2811	2812	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
529	shipCargoBonusAI	0	2818	2819	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
530	caldariIndustrialSkillLevelPreMulShipBonusCIShip	0	2823	2824	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
532	gallenteIndustrialSkillLevelPreMulShipBonusGIShip	0	2830	2831	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
533	shipPTrackingBonus	0	2833	2834	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
536	cpuMultiplierPostMulCpuOutputShip	4	2843	2844	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
537	droneBayBonus	4	2849	2850	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
538	amarrBattleshipSkillLevelPostMulShipBonusABShip	0	2852	2853	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
541	caldariBattleshipSkillLevelPreMulShipBonusCBShip	0	2859	2860	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
542	shipCapNeedBonusAB	0	2865	2866	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
545	shipBonusShieldBonusCB	0	2875	2876	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
548	minmatarBattleshipSkillLevelPreMulShipBonusMBShip	0	2886	2887	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
549	shipPTDmgBonusMB	0	2889	2890	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
550	shipHTDmgBonusGB	0	2893	2894	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipHTDmgBonus	0	0	0	0	\N	\N	\N	\N	\N
551	shipPTRangeBonusMB	0	2897	2898	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
553	shipHTTrackingBonusGB	0	2904	2905	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
556	caldariBattleshipSkillLevelPreMulShipBonus2CBShip	0	2916	2917	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
558	metallurgyMineralNeedResearchBonusPostPercentMineralNeedResearchSpeedChar	0	2924	2925	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
562	shipHTDmgBonusfixedGC	0	2940	2941	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShipHTDmgBonusfixedGC	0	0	0	0	\N	\N	\N	\N	\N
563	warpScrambleForEntity	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	0	0	505	\N	6	103	\N	0	1	Warp Scramble	0	0	0	0	1	\N	504	\N	\N
566	laboratoryOperationSkillLevelModAddMaxLaborotorySlotsChar	0	2951	2952	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
568	massProductionSkillLevelModAddManufactureSlotLimitChar	0	2958	2959	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
569	missileLaunchingForEntity	2	114	89			\N	1	0	506	\N	\N	\N	\N	0	1	missileLaunching	0	0	0	0	0	\N	\N	\N	\N
571	reverseEngineeringInventionBonusModAddReverseEngineeringChanceLocationChar	0	2970	2971	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
575	modifyTargetSpeed2	2	3489	3491		effects.ModifyTargetSpeed	\N	0	0	513	\N	515	514	\N	0	1	modifyTargetSpeed	0	0	0	0	2	\N	512	\N	\N
577	shieldResistanceEMBonus	1	2993	2994	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1	EM Shield	0	0	0	0	\N	\N	\N	\N	\N
578	shieldEXResistanceBonus	1	2997	2998	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1	Explosion Shield	0	0	0	0	\N	\N	\N	\N	\N
579	shieldTHResistanceBonus	1	3001	3002	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
580	shielKINResistanceBonus	1	3005	3006	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1	Kinetic Shield	0	0	0	0	\N	\N	\N	\N	\N
581	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringGunnery	0	3009	3010	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
582	rapidFiringRofBonusPostPercentSpeedLocationShipModulesRequiringGunnery	0	3011	3012	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
583	amarrIndustrialSkillLevelPreMulShipBonusAI2Ship	0	2816	2817	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
584	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringGunnery	0	3015	3016	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
586	decreaseTargetSpeed	2	3489	3491		effects.ModifyTargetSpeed	\N	1	0	73	\N	6	54	\N	0	1	Decrease Target Speed	0	0	0	0	\N	\N	\N	\N	\N
587	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipGroupEnergyWeapon	0	2968	2969	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
588	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipGroupProjectileWeapon	0	3023	3024	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
589	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipGroupHybridWeapon	0	3027	3028	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
590	energyPulseWeaponsDurationBonusPostPercentDurationLocationShipModulesRequiringEnergyPulseWeapons	0	3031	3032	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
592	targetArmorRepair	2	131	3038		effects.RemoteArmourRepair	\N	0	1	73	\N	6	54	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
594	armorExtender	4	3041	3042	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
595	armorHardening	1	529	532	Active armor resistance boost	effects.ArmorHardening	\N	0	0	73	\N	6	\N	\N	0	1	ArmorHardening	1	0	0	0	0	\N	\N	\N	\N
596	ammoInfluenceRange	0	3573	3574			\N	0	0	\N	\N	\N	\N	\N	0	0	ammoInfluence	0	0	0	0	\N	\N	\N	\N	\N
597	targetedEMResonanceMultiply	2	3050	3051	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1	TargetedEMResonanceMultiply	0	0	0	0	1	\N	\N	\N	\N
598	ammoSpeedMultiplier	0	3054	3055	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
599	ammoFallofMultiplier	0	3059	3060	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
600	ammoTrackingMultiplier	0	3063	3064	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
602	shipPTurretSpeedBonusMC	0	3069	3070	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
604	shipPTspeedBonusMB2	0	3076	3077	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
605	minmatarBattleshipSkillLevelPreMulShipBonusMB2Ship	0	3080	3081	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
607	cloaking	1	3908	3909		effects.Cloaking	\N	0	0	\N	\N	\N	\N	\N	0	1	Cloaking	0	0	0	0	2	\N	\N	\N	\N
609	turretWeaponRangeTrackingSpeedMultiplyTargetHostile	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	1		0	1	0	0	1	\N	\N	\N	\N
610	scanStrengthBonusTargetHostile	2	956	903	Modifies the scanning strengths of a targeted object.	effects.ScanStrengthBonusTarget	\N	1	0	73	\N	6	\N	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
611	gallenteBattleshipSkillLevelPreMulShipBonusGBShip	0	3094	3095	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
615	targetedKineticResonanceMultiply	2	3123	3124	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
616	targetedThermalResonanceMultiply	2	3127	3128	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1	TargetedThermalResonanceMultiply	0	0	0	0	1	\N	\N	\N	\N
617	targetedExplosiveResonanceMultiply	2	3131	3132	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1	TargetedExplosiveResonanceMultiply	0	0	0	0	1	\N	\N	\N	\N
621	deepCoreMiningSkillBoostDamageCloudChanceReduction	0	3148	3149	Boost of damageCloudChanceReduction by ModAdd of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
622	damageCloudChanceReduction	0	3151	3152	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
623	miningDroneOperationMiningAmountBonusPostPercentMiningDroneAmountPercentChar	0	3153	3154	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
624	standardMissilesSkillBoostMissileVelocityBonus	0	3158	3159	Boost of missileVelocityBonus  by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
626	shieldBoostAmplifierShieldOperation	4	3171	3172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
627	powerIncrease	4	3174	3175	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
628	thermicShieldCompensationSkillBoostResistanceBonus	0	3185	3186	Boost of resistanceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
638	shieldDefensiveOperationsShieldCapacityBonusPostPercentShieldCapacityGangShips	0	3218	3219	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
639	reconOperationsMaxTargetRangeBonusPostPercentMaxTargetRangeGangShips	0	3222	3223	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
643	chiefFieldEngineerCapacitorBonusPostPercentCapacitorCapacityGangShips	0	3238	3239	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
645	chiefEvasiveOperationOfficerAgilityBonusPostPercentAgilityGangShips	0	3242	3243	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
646	chiefStealthOperationOfficerSkillBoostSignatureRadiusBonus	0	3247	3248	Boost of signatureRadiusBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
647	chiefStealthOperationOfficerSignatureRadiusBonusPostPercentSignatureRadiusGangShips	0	3251	3252	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
648	shipSpecialityMining	0	3257	3258	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	deepCoreMiningCPUReduction	0	0	0	0	\N	\N	\N	\N	\N
649	anchorDrop	1	131	131	Anchoring this object in space.	effects.AnchorDrop	\N	0	0	556	\N	\N	\N	\N	0	1	anchoring	0	0	0	0	2	\N	\N	\N	\N
650	anchorLift	1	131	131		effects.AnchorLift	\N	0	0	556	\N	\N	\N	\N	0	1	unanchoring	0	0	0	0	2	\N	\N	\N	\N
651	cloakingSkillBoostCloakVelocityBonus	0	3262	3263	Boost of cloakVelocityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
653	shipSpecialityCloak	0	3272	3273	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShipSpecialityCloak	0	0	0	0	\N	\N	\N	\N	\N
656	shipCaprRechargeBonusAF2	0	3283	3284	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
657	agilityMultiplierEffect	4	3285	3286	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	AgilityMultiplierEffect	0	0	0	0	\N	\N	\N	\N	\N
658	missileVelocityBonusGeneric	0	3290	3291	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	MissileVelocityBonusGeneric	0	0	0	0	\N	\N	\N	\N	\N
660	missileEMDmgBonus	0	3300	3301	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
661	missileExplosiveDmgBonus	0	3305	3306	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
662	missileThermalDmgBonus	0	3310	3311	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
663	heavyMissilesSkillBoostMaxflightTimeBonus	0	3315	3316	Boost of max flightTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
668	missileKineticDmgBonus2	0	3338	3339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
669	shipLauncherspeedCB2	0	3341	3342	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
670	antiWarpScramblingPassive	4	2946	2947	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	antiWarpScrambling	0	0	0	0	\N	\N	\N	\N	\N
672	weaponUpgradesSkillBoostCpu	0	3350	3351	Boost of cpu by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
675	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringEnergyPulseWeapons	0	3359	3360	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
677	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringMissileLauncherOperation	0	3352	3353	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
682	gallenteBattleshipSkillLevelPreMulShipBonusGB2Ship	0	3380	3381	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
688	electronic2AttributeModifyOnline	4	3398	3399	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
698	signatureAnalysisSkillLevelPreMulScanResolutionBonusSelf	0	3425	3426	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
699	signatureAnalysisScanResolutionBonusPostPercentScanResolutionShip	0	3427	3428	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
703	interceptorsSkillLevelPreMulEliteBonusInterceptorShip	0	3451	3452	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
704	covertOpsSkillLevelPreMulEliteBonusCoverOpsShip	0	3455	3456	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
705	bombersSkillLevelPreMulEliteBonusBombersShip	0	3459	3460	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
706	covertOpsWarpResistance	0	3463	3464	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
707	bomberRocketRangeBonus	0	3469	3470	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
708	bomberLightsRangeBonus	0	3473	3474	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
709	interceptorSignatoreRadiusBonus	0	3475	3476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
710	speedBoostFactorCalculator	0	3500	3501	Aid to auto-calc this.	\N	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
712	speedBoostFactorCalculator2	0	3515	3516	Aid to auto-calc	\N	\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
713	stealthActive	1	3520	3521	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
716	sensorBoostTargeted	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	0	1	73	\N	6	\N	\N	0	1		0	0	0	0	1	\N	\N	\N	\N
720	sensorBoosterActive	1	3527	3528		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	1	sensorBoosterActivated	1	0	0	0	\N	\N	\N	\N	\N
721	miningCapBonus	0	3536	3537	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Reduces Mining laser activation power	0	0	0	0	\N	\N	\N	\N	\N
726	shipBonusCargo2GI	0	3547	3548	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
727	shipBonusCargoCI	0	3549	3550	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
728	shipBonusCargoMI	0	3551	3552	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
729	shipBonusVelocityGI	0	3553	3554	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
730	shipBonusVelocityCI	0	3569	3572	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
732	shipVelocityBonusAI	0	3557	3558	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShipVelocityBonusAI	0	0	0	0	\N	\N	\N	\N	\N
734	amarrBattleshipSkillLevelPreMulShipBonusAB2Ship	0	3565	3566	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
736	shipBonusCapCapAB	0	3567	3568	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
744	surveyScanspeedBonusPostPercentDurationLocationShipModulesRequiringElectronics	0	3587	3588	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
751	gallenteFrigateSkillLevelPreMulShipBonusGF2Ship	0	3610	3611	Automatically generated effect	gallenteFrigateSkillLevelPreMulShipBonusGF2Ship	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
754	shipHybridDamageBonusCF	0	3620	3621	Automatically generated effect	shipHybridDamageBonusCF	0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
757	shipETDamageAF	0	3628	3629	Automatically generated effect	shipETDamageAF	0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
758	shipETspeedBonusAF2	0	3633	3634	Automatically generated effect	shipETspeedBonusAF2	0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
760	shipMissileSpeedBonusCF	0	3645	3646	Automatically generated effect	shipMissileSpeedBonusCF	0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
761	caldariFrigateSkillLevelPreMulShipBonusCF2Ship	0	3649	3650	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
762	minmatarFrigateSkillLevelPreMulShipBonusMF2Ship	0	3653	3654	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
763	missileDMGBonus	4	3657	3658	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
765	leadershipEffect	0	3663	3664	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
767	evasiveTacticsCloakVelocityBonusModAddSpeedBoostFactorGangShipModulesRequiringCloaking	0	3667	3668	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
768	hypereuclideanNavigationCloakVelocityBonusModAddSpeedFactorLocationShipModulesRequiringCloaking	0	3670	3671	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
769	cloakingSkillBoostCloakCapacitorBonus	0	3675	3676	Boost of cloakCapacitorBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
771	cloakingCapacitorBonusPostPercentCapacitorCapacityMultiplierLocationShipModulesRequiringCloaking	0	3683	3684	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
775	capBoostAmplifier	4	3694	3695	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
781	missileBombardmentMaxVelocityBonusPostPercentMaxVelocityOwnerCharModulesRequiringMissileLauncherOperation	0	3721	3722	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
782	missileGuidanceAgilityBonusPostPercentAgilityOwnerCharModulesRequiringMissileLauncherOperation	0	3726	3727	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
784	missileBombardmentMaxFlightTimeBonusPostPercentExplosionDelayOwnerCharModulesRequiringMissileLauncherOperation	0	3728	3729	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
793	escortHullUpgradeCpu Bonus	0	3758	3759	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
796	escortShieldUpgradeCpu Bonus	0	3775	3776	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
797	caldariBattleshipSkillLevelPreMulShipBonusCB3Ship	0	3767	3768	Automatically generated effect	caldariBattleshipSkillLevelPreMulShipBonusCB3Ship	0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
800	droneDmgBonusSelf	0	3783	3784	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
802	shipDronesMaxGB	0	3785	3786	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
804	ammoInfluenceCapNeed	0	3797	3798	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
820	speedBoostPassive	4	3517	3518		effects.SpeedBoost	\N	0	0	\N	\N	\N	\N	\N	0	1	speedBoost	0	0	0	0	\N	\N	\N	\N	\N
834	ammoInfluenceCapRecharge	0	443	444	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
835	freightSkillBoostCargoCapacityBonus	0	3904	3905	Boost of cargoCapacityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
836	skillFreightBonus	0	3906	3907	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
837	sensorBoostTargetedHostile	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	1		0	1	0	0	1	\N	\N	\N	\N
838	ammoInfluenceShipVelocity	0	3908	3909	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
848	cloakingTargetingDelayBonusPostPercentCloakingTargetingDelayBonusForShipModulesRequiringCloaking	0	3924	3925	Applies the cloaking skill's reduction bonus to cloakingTargetingDelay time.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
850	cloakingSkillBoostCloakingTargetingDelayBonus	0	3928	3929	Applies cloaking skill's level to cloakingTargetingDelayBonus.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
854	cloakingScanResolutionMultiplier	0	3935	3408	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
855	warpNavigationSkillBoostWarpSBonus	0	3945	3946	Boost of WarpSBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
856	warpSkillSpeed	0	3949	3950	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	WarpSkillSpeed	0	0	0	0	\N	\N	\N	\N	\N
857	bountyHuntingSkillBoostBountySkillBonus	0	3957	3958	Boost of bountySkillBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
858	bountyhunterskill	0	3961	3962	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
859	advancedBountyHuntingSkillBoostBountySkillMultiplyer	0	3967	3968	Boost of bountySkillMultiplyer by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
860	advBountyhunterSkill	0	3971	3972	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
867	missileFlightTimeAndDamage	1	3996	3997	Adjusts missile flight time and damage.		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
874	shipProjectileOptimalBonuseMF2	0	4026	4027	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
875	shipLaserOptimalBonuseAF	0	4030	4031	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
876	shieldBoostingForEntities	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
878	armorRepairForEntities	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
881	implantEWcpuneed	0	4048	4049	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
882	shipHybridRangeBonusCF2	0	4052	4053	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
885	suicideBomb	1	288	233	Triggering of an EMP wave being broadcast into space.	effects.EMPWave	\N	1	0	73	\N	6	99	\N	0	1	empWave	0	0	0	0	2	\N	\N	\N	\N
887	shipETspeedBonusAB2	0	4066	4067	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
889	missileLauncherSpeedMultiplier	4	4069	4070	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
891	shipCruiseMissileVelocityBonusCB3	0	4081	4082	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
892	shipTorpedosVelocityBonusCB3	0	4087	4088	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
896	covertOpsCpuBonus1	0	4111	4112	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
897	covertOpsCpuMultplier1	0	4115	4116	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
899	shipMissileKineticDamageCC	0	4121	4122	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
900	shipDroneScoutThermalDamageGF2	0	4125	4126	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
901	onlineForStructures	1	131	131	this is the online effect for structures	effects.StructureOnline	\N	0	0	\N	\N	\N	\N	\N	0	1	online	0	0	0	0	\N	\N	\N	\N	\N
902	decloakWave	1	4129	131	Triggering of an EMP wave being broadcast into space.	effects.DecloakWave	\N	0	0	73	\N	6	651	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
903	ammoInfluenceSignatureRadius	0	4133	4134	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
904	ammoInfluenceShieldCapacity	0	4136	4137	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
907	shipLaserRofAC2	0	4152	4153	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
909	shipArmorHpAC2	0	4158	4159	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
912	shipMissileLauncherRofCC2	0	4164	4165	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
914	shipMiningYieldCC2	0	4170	4171	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
918	shipDronesMaxGC2	0	4184	4185	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
919	shipHybridTrackingGC2	0	4186	4187	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
923	shipMiningYieldMC2	0	4196	4197	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
925	shipProjectileOptimalMC2	0	4206	4207	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
926	amarrCruiserSkillLevelPreMulShipBonusAC2Ship	0	4214	4215	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
927	caldariCruiserSkillLevelPreMulShipBonusCC2Ship	0	4218	4219	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
928	gallenteCruiserSkillLevelPreMulShipBonusGC2Ship	0	4222	4223	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
929	minmatarCruiserSkillLevelPreMulShipBonusMC2Ship	0	4226	4227	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
930	shipCargoCapacityGC2	0	4228	4229	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
934	shipMaxVelocityMC2	0	4238	4239	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
939	shipShieldBoostCC2	0	4253	4254	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
952	boosterTimeBonus	0	4288	4289	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
953	biologyTimeBonus	0	4292	4293	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
958	shipArmorEmResistanceAC2	0	4256	4257	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
959	shipArmorExplosiveResistanceAC2	0	4259	4260	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
960	shipArmorKineticResistanceAC2	0	4262	4263	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
961	shipArmorThermalResistanceAC2	0	4265	4266	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
965	shipDronesMaxAC2	0	4312	4313	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
966	shipHybridOptimalRangeGC2	0	4316	4317	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
967	shipMwdLessCapNerfGC2	0	4320	4321	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
968	shipProjectileDmgMC2	0	4322	4323	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
969	smartbombEMBonus	4	4327	4328	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
970	smartbombKineticBonus	4	4331	4332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
971	smartbombThermalBonus	4	4335	4336	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
972	smartbombEXBonus	4	4339	4340	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
973	smartbombRangeBonus	4	4345	4346	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
980	cloakingWarpSafe	1	3908	3909		effects.Cloaking	\N	0	0	\N	\N	\N	\N	\N	0	1	Cloaking	1	0	0	0	2	\N	\N	\N	\N
983	droneHeavyControlUnitMultiplier	1	4372	4373			\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
985	shipHybridOptimalGF	0	4378	4379	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
987	gunshipSkillMultiplier1	0	4387	4388	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
988	gunshipSkillMultiplier2	0	4391	4392	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
989	eliteBonusGunshipHybridOptimal1	0	4393	4394	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
990	eliteBonusGunshipProjectileOptimal1	0	4395	4396	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
991	eliteBonusGunshipLaserOptimal1	0	4397	4398	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
996	eliteBonusGunshipHybridTracking2	0	4415	4416	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
997	eliteBonusGunshipProjectileTracking2	0	4417	4418	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
998	eliteBonusGunshipProjectileFalloff2	0	4419	4420	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
999	eliteBonusGunshipShieldBoost2	0	4421	4422	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1001	eliteBonusGunshipCapRecharge2	0	4426	4427	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1002	eliteBonusGunshipDroneCapacity2	0	4428	4429	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1003	selfT2SmallLaserPulseDamageBonus	0	4434	4435	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1004	selfT2SmallLaserBeamDamageBonus	0	4440	4441	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1005	selfT2SmallHybridBlasterDamageBonus	0	4444	4445	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1006	selfT2SmallHybridRailDamageBonus	0	4450	4451	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1007	selfT2SmallProjectileACDamageBonus	0	4456	4457	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1008	selfT2SmallProjectileArtyDamageBonus	0	4462	4463	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1009	selfT2MediumLaserPulseDamageBonus	0	4468	4469	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1010	selfT2MediumLaserBeamDamageBonus	0	4474	4475	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1011	selfT2MediumHybridBlasterDamageBonus	0	4480	4481	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1012	selfT2MediumHybridRailDamageBonus	0	4486	4487	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1013	selfT2MediumProjectileACDamageBonus	0	4492	4493	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1014	selfT2MediumProjectileArtyDamageBonus	0	4498	4499	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1015	selfT2LargeLaserPulseDamageBonus	0	4504	4505	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1016	selfT2LargeLaserBeamDamageBonus	0	4510	4511	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1017	selfT2LargeHybridBlasterDamageBonus	0	4516	4517	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1018	selfT2LargeHybridRailDamageBonus	0	4522	4523	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1019	selfT2LargeProjectileACDamageBonus	0	4528	4529	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1020	selfT2LargeProjectileArtyDamageBonus	0	4534	4535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1021	eliteBonusGunshipHybridDmg2	0	4536	4537	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1022	anchorDropForStructures	1	131	131	Anchoring this object in space.	effects.AnchorDrop	\N	0	0	\N	\N	\N	\N	\N	0	1	anchoring	0	0	0	0	2	\N	\N	\N	\N
1023	anchorLiftForStructures	1	131	131		effects.AnchorLift	\N	0	0	\N	\N	\N	\N	\N	0	1	unanchoring	0	0	0	0	2	\N	\N	\N	\N
1024	shipMissileHeavyVelocityBonusCC2	0	4542	4543	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1025	shipMissileLightVelocityBonusCC2	0	4546	4547	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1030	remoteArmorSystemsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringRemoteArmorSystems	0	4566	4567	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1033	eliteBonusLogisticRemoteArmorRepairCapNeed1	0	4576	4577	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1034	eliteBonusLogisticRemoteArmorRepairCapNeed2	0	4578	4579	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1035	eliteBonusLogisticShieldTransferCapNeed2	0	4584	4585	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1036	eliteBonusLogisticShieldTransferCapNeed1	0	4586	4587	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1042	eliteBonusLogisticTrackingLinkBonus1	0	4604	4605			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1045	eliteBonusLogisticTrackingLinkBonus2	0	4610	4611			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1046	shipRemoteArmorRange1	0	4614	4615	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1047	shipRemoteArmorRange2	0	4616	4617	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1048	shipShieldTransferRange1	0	4620	4621	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1049	shipShieldTransferRange2	0	4622	4623	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1052	logisticSkillMultiplier1	0	4633	4634	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1053	logisticSkillMultiplier2	0	4637	4638	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1054	shipTrackingLinkRange1	0	4640	4641	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1055	shipTrackingLinkRange2	0	4642	4643	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1056	eliteBonusHeavyGunshipHybridOptimal1	0	4658	4659	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1057	eliteBonusHeavyGunshipProjectileOptimal1	0	4660	4661	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1058	eliteBonusHeavyGunshipLaserOptimal1	0	4664	4665	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1060	eliteBonusHeavyGunshipProjectileFallOff1	0	4670	4671	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1061	eliteBonusHeavyGunshipHybridDmg2	0	4672	4673	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1062	eliteBonusHeavyGunshipLaserDmg2	0	4674	4675	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1063	eliteBonusHeavyGunshipProjectileTracking2	0	4676	4677	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1066	eliteBonusHeavyGunshipDroneCapacity2	0	4686	4687	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1067	eliteBonusHeavyGunshipLauncherRof2	0	4688	4689	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1077	warshipSkillMultiplier2	0	4723	4724	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1079	warshipSkillMultiplier1	0	4730	4731	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1080	eliteBonusHeavyGunshipHybridFallOff1	0	4732	4733	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1081	eliteBonusHeavyGunshipHeavyMissileFlightTime1	0	4734	4735	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1082	eliteBonusHeavyGunshipLightMissileFlightTime1	0	4736	4737	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1084	eliteBonusHeavyGunshipDroneControlRange1	0	4740	4741	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1086	projectileFiredForEntities	2	115	131		effects.ProjectileFiredForEntities	\N	1	0	51	160	6	54	158	0	1	projectileFired	0	0	0	0	1	\N	\N	\N	\N
1087	eliteBonusHeavyGunshipProjectileDmg2	0	4750	4751	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1095	destroyerPenalityTurretROF	0	4789	4790	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1099	shipProjectileTrackingMF2	0	4801	4802	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1108	controlTowerAmarrLaserDMGBonus	0	4831	4832	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1109	battlecruiserSkillLevelPreMulShipBonusBC1Ship	0	4856	4857	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1110	shipProjectileRofMBC2	0	4858	4859	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1111	battlecruiserSkillLevelPreMulShipBonusBC2Ship	0	4862	4863	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1117	shipArmorThermResistanceABC1	0	4882	4883	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1118	shipArmorEMResistanceABC1	0	4884	4885	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1119	shipArmorExplosiveResistanceABC1	0	4886	4887	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1120	shipArmorKineticResistanceABC1	0	4888	4889	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1121	shipShieldEmResistanceCBC2	0	4890	4891	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1122	shipShieldExplosiveResistanceCBC2	0	4892	4893	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1123	shipShieldKineticResistanceCBC2	0	4894	4895	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1124	shipShieldThermalResistanceCBC2	0	4896	4897	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1125	shipLaserCapABC2	0	4900	4901	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1126	shipHybridDmgGBC1	0	4902	4903	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1129	structureUnanchorForced	2	131	131			\N	1	0	676	\N	\N	76	\N	0	1	Force Unanchor	0	0	0	0	2	\N	\N	\N	\N
1130	controlTowerAmarrLaserOptimalBonus	0	4922	4923	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1131	controlTowerSiloCapacityBonus	0	4928	4929	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1133	controlTowerMinmatarProjectileOptimalBonus	0	4938	4939	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1134	controlTowerMinmatarProjectileFallOffBonus	0	4942	4943	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1137	controlTowerMinmatarProjectileRofBonus	0	4958	4959	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1138	controlTowerMoonHarvesterCPUBonus	0	4966	4967	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1139	destroyerSkillLevelPreMulShipBonusDF2Ship	0	4973	4974	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1140	destroyerSkillLevelPreMulShipBonusDF1Ship	0	4977	4978	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1141	shipHybridTrackingGD2	0	4979	4980	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1143	shipLaserCapNeedAD1	0	4985	4986	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1144	shipLaserTrackingAD2	0	4987	4988	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1145	shipHybridRangeCD1	0	4989	4990	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1147	shipProjectileTrackingMD2	0	4995	4996	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1150	systemScan	1	131	131	Scan the solar system.		\N	0	0	73	\N	6	\N	\N	0	1	Analyzing Scans	0	0	0	0	\N	\N	\N	\N	\N
1152	controlTowerGallenteHybridDamageBonus	0	5017	5018	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1156	controlTowerTrackingArrayHybridOptimalBonus	4	5026	5027	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1157	controlTowerTrackingArrayLaserOptimalBonus	4	5028	5029	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1158	controlTowerTrackingArrayProjectileOptimalBonus	4	5030	5031	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1159	controlTowerTrackingArrayProjectileTrackingBonus	4	5034	5035	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1160	controlTowerTrackingArrayHybridTrackingBonus	4	5038	5039	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1161	controlTowerTrackingArrayLaserTrackingBonus	4	5040	5041	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1165	shipIceHarvesterCPUNeed	0	5063	5064	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1166	shipMinerCPUNeed	0	5067	5068	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1171	massFactor	0	5089	5090	Needed for all ships for speed boost of afterburners and microwarpdrives.		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1173	ammoInfluenceEntityFlyRange	0	5102	5103	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1176	accerationControlSkillAb&MwdSpeedBoost	0	5113	5114			\N	0	0	\N	\N	\N	\N	\N	0	0	accerationControlSkillAb	0	0	0	0	\N	\N	\N	\N	\N
1179	eliteBonusGunshipLaserDamage2	0	5121	5122	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1181	eliteBonusLogisticEnergyTransferCapNeed1	0	5133	5134	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1182	shipEnergyTransferRange1	0	5137	5138	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1183	eliteBonusLogisticEnergyTransferCapNeed2	0	5139	5140	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1184	shipEnergyTransferRange2	0	5141	5142	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1185	structureStealthEmitterArraySigDecrease	0	3277	3278	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1188	miningBargeSkillLevelPostMulShipBonusORE2Ship	0	5159	5160	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1190	iceHarvestCycleTimeModulesRequiringIceHarvesting	0	5165	5166	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1191	iceHarvestCycleTimeBonus	0	5169	5170	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1192	controlTowerCaldariEwTargetSwitchDelayBonus	0	5048	5049	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1193	shipHybridOptimalCBC1	0	5171	5172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1194	shipShieldBoostMBC1	0	5173	5174	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1195	shipArmorRepairingGBC2	0	5175	5176	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1197	shipMiningBonusORE2	0	5181	5182	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1198	shipHybridFallOffGD1	0	5185	5186	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1199	targetAttackForStructures	2	115	89	Combat	effects.ProjectileFiredForEntities	\N	1	0	51	160	6	54	158	0	1	targetAttack	0	0	0	0	2	\N	\N	\N	\N
1200	miningInfoMultiplier	0	5190	5191	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	MiningInfoMultiplier	0	0	0	0	\N	\N	\N	\N	\N
1201	shipMissileSpeedBonusAF	0	5192	5193	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1202	shipMissileEMDamage2AF	0	5194	5195	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1203	controlTowerCaldariMissileVelocityBonus	0	5200	5201	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1204	shipPTurretSpeedBonusGB	0	5204	5205	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1205	shipPDmgBonusMB	0	5208	5209	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1210	controlTowerCaldariMissileRofBonus	0	5228	5229	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1212	crystalMiningamountInfo2	0	5236	5237	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1213	shipProjectileTrackingGC2	0	5239	5240	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1214	shipBonusPirateSanshaLaserDamage	0	5241	5242	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1215	shipEnergyDrainAmountAF1	0	5247	5248	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1217	shipStasisRangeMF1	0	5255	5256	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1218	shipBonusPirateSmallHybridDmg	0	5257	5258	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1219	shipEnergyVampireTransferAmountBonusAB	0	5259	5260	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1220	shipEnergyVampireTransferAmountBonusAc	0	5261	5262	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipEnergyVampireTransferAmountBonusAB	0	0	0	0	\N	\N	\N	\N	\N
1221	shipStasisWebRangeBonusMB	0	5263	5264	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1222	shipStasisWebRangeBonusMC2	0	5265	5266	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1224	shipMWDCapBonusMC	0	5267	5268	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1226	shipMWDCapBonusMB	0	5269	5270	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1227	shipBonusPirateFrigateProjROF	0	5273	5274	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1228	shipProjectileTrackingGF	0	5275	5276	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1229	shipMWDCapBonusMF	0	5277	5278	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1230	shipMissileVelocityPirateFactionFrigate	0	5279	5280	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1231	shipBonusLaserCapPirateCruiser	0	5281	5282	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1232	shipProjectileRofPirateCruiser	0	5283	5284	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1233	shipHybridDmgPirateCruiser	0	5285	5286	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1234	shipMissileVelocityPirateFactionLight	0	5287	5288	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1235	shipMissileVelocityPirateFactionHeavy	0	5289	5290	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1236	shipMissileVelocityPirateFactionCruise	0	5291	5292	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1237	shipMissileVelocityPirateFactionTorp	0	5293	5294	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1238	shipLaserCapPirateBattleship	0	5297	5298	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1239	shipProjectileRofPirateBattleship	0	5299	5300	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1240	shipHybridDmgPirateBattleship	0	5301	5302	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1241	shipLauncherRofMF2	0	5304	5305	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1243	shipMissileExplosiveDamageMF1	0	5310	5311	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1244	smugglingModifier	0	5315	5316	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1252	shipProjectileDamageDF1	0	5329	5330	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1253	speedBoostMassAddition	1	5331	5332		effects.SpeedBoost	\N	0	0	73	\N	6	\N	\N	0	1	Speed Boost	0	0	0	0	\N	\N	\N	\N	\N
1254	speedBoostMassSigRad	1	5333	5334			\N	0	0	73	\N	6	\N	\N	0	1	Speed Boost	0	0	0	0	\N	\N	\N	\N	\N
1255	setBonusBloodraider	0	5342	5343	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1256	setBonusBloodraiderNosferatu	0	5346	5347	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1257	blackMarketTradingSkillBoostContrabandDetectionChanceBonus	0	5352	5353	Boost of contrabandDetectionChanceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1258	skillBoostContrabandDetectionChanceBonusEffect	0	5356	5357	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	SkillBoostContrabandDetectionChanceBonusEffect	0	0	0	0	\N	\N	\N	\N	\N
1259	testfuelConsumption	1	5360	5361	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	TESTfuelConsumption	0	0	0	0	\N	\N	\N	\N	\N
1260	testmassThrust	1	5364	5365	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	TESTmassThrust	0	0	0	0	\N	\N	\N	\N	\N
1261	setBonusSerpentis	0	5370	5371	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1262	setBonusSerpentis2	0	5376	5377	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1264	interceptor2HybridTracking	0	5381	5382	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1265	interceptor2MissileKineticDamage	0	5383	5384	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1266	interceptor2MissileVelocity	0	5385	5386	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1268	interceptor2LaserTracking	0	5389	5390	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1269	interceptor2ProjectileFallOff	0	5391	5392	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1270	interceptor2ProjectileTracking	0	5393	5394	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1271	newEwTestscanStrengthBonusTargetHostile	2	956	903	Modifies the scanning strengths of a targeted object.	effects.ScanStrengthBonusTarget	\N	1	0	73	\N	6	54	158	0	1		0	0	0	0	1	\N	\N	\N	\N
1272	newEwTestswarpScramble	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	73	\N	6	54	158	0	1		0	0	0	0	1	\N	\N	\N	\N
1273	newEwTestssensorBoostTargetedHostile	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	1		0	0	0	0	1	\N	\N	\N	\N
1274	newEwTeststurretWeaponRangeTrackingSpeedMultiplyTargetHostile	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.Target_paint	\N	1	0	73	\N	6	54	158	0	1		0	0	0	0	1	\N	\N	\N	\N
1275	newEwTestsdecreaseTargetSpeed	2	3489	3491		effects.ModifyTargetSpeed	\N	1	0	73	160	6	54	158	0	1	newEwTestsDecrease Target Speed	0	0	0	0	1	\N	\N	\N	\N
1278	interceptor2MissileEmDamage	0	5396	5397	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1279	interceptors2SkillLevelPreMulEliteBonusInterceptorShip	0	5400	5401	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1280	structuralAnalyzisSkillBoostRepairBonus	0	5406	5407	Boost of repairBonus by PostPercent of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1281	structuralAnalysisEffect	0	5408	5409	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1282	eliteIndustrial1SkillLevelPreMulEliteBonusEliteIndustrialShip	0	5415	5416	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1283	eliteIndustrial2SkillLevelPreMulEliteBonusEliteIndustrialShip	0	5419	5420	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1290	amarrIndustrialSkillLevelPreMulShipBonusAI22Ship	0	5442	5443	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1291	caldariIndustrialSkillLevelPreMulShipBonusCI2Ship	0	5446	5447	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1292	gallenteIndustrialSkillLevelPreMulShipBonusGI2Ship	0	5450	5451	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1293	minmatarIndustrialSkillLevelPreMulShipBonusMI2Ship	0	5454	5455	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1304	eliteIndustrialShieldBoostAmountElite1	0	5474	5475	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	eliteIndustrialShieldBoostAmountMI1	0	0	0	0	\N	\N	\N	\N	\N
1305	eliteIndustrialShieldBoostCapNeedElite2	0	5476	5477	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1306	eliteIndustrialArmorRepairAmountElite1	0	5478	5479	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1307	eliteIndustrialArmorRepairCapNeedElite1	0	5421	5422	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1308	eliteIndustrialArmorRepairDurationElite2	0	5425	5426	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1309	shipMissileThermDamageGallenteInterceptor2	0	5488	5489	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1318	ewSkillScanStrengthBonus	0	5526	5527			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1320	propulsionSkillFallOffBonus	0	5534	5535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1321	ewSkillScanStrengthBonusSkillLevel	0	5537	5538	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	ewSkillEwStrengthBonusSkillLevel	0	0	0	0	\N	\N	\N	\N	\N
1322	propulsionSkillMaxRangeBonus	0	5539	5540	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1329	propulsionSkillPropulsionStrengthBonus	0	5561	5562			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1330	propulsionSkillPropulsionStrengthBonusSkillLevel	0	5565	5566	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1335	amarrShipEwWeaponDisruptionAF1	0	5581	5582			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1339	gallenteShipEwSensorDampenGF2	0	5595	5596			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1343	gallenteShipEwSensorDampenGC2	0	5603	5604			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1350	caldariShipEwStrengthCB3	0	5617	5618			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1354	ewTestEffectRsd	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	1		0	1	0	0	1	\N	\N	\N	\N
1355	ewTestEffectWs	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	73	\N	6	54	158	0	1		0	1	0	1	2	\N	\N	\N	\N
1358	ewTestEffectJam	2	5643	5644	Automatically generated effect		0	1	0	73	\N	6	54	158	0	0		0	1	1	0	1	\N	\N	\N	\N
1360	ewSkillRsdCapNeedBonusSkillLevel	0	5649	5650	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1361	ewSkillTdCapNeedBonusSkillLevel	0	5653	5654	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1367	propulsionSkillStasisStrengthBonus	0	5678	5679	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1369	ewSkillTrackingDisruptionBonus	0	5682	5683			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1370	ewSkillTpCapNeedBonusSkillLevel	0	5686	5687	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1372	ewSkillEwCapNeedSkillLevel	0	5695	5696	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1373	ewSkillTargetPaintingStrengthBonusSkillLevel	0	5699	5700	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1376	ewSkillSignatureDampenBonus	0	5705	5706			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1384	antiWarpScramblingPropulsion	4	5730	5731			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1386	gangDamageBoost	1	2092	2093	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1387	leadershipCpuBonus	0	5743	5744	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	logisticsCPUReduction	0	0	0	0	\N	\N	\N	\N	\N
1388	gangShieldEnhance	1	3218	3219	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1389	gangSigRadBoost	1	3251	3252	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1390	stealthOnline	4	3520	3521	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1391	gangShieldBoostAmplifier	1	5754	5755	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1392	wingCommand	0	5761	5762	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1394	covertOpsStealthBomberCruiseLauncerPowerNeedBonus	0	5777	5778	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1395	shieldBoostAmplifierPassive	0	3171	3172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1396	covertOpsStealthBomberCruiseLauncerPowerNeedBonus1	0	5780	5781	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1397	setBonusGuristas	0	5786	5787	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1398	eliteBonusCoverOpsCruiseEmDmg1	0	5791	5792	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1399	eliteBonusCoverOpsCruiseThermalDmg1	0	5795	5796	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1400	eliteBonusCoverOpsCruiseExplosiveDmg1	0	5799	5800	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1401	eliteBonusCoverOpsCruiseLauncherPowerNeed1	0	5802	5803	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1402	eliteBonusCoverOpsCloakingVelocity2	0	5806	5807	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1403	shipMissileCruiseKineticDmgCF2	0	5810	5811	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1405	covertOpsSkillLevelPreMulEliteBonusCoverOpsShip2	0	5814	5815	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1407	eliteBonusCoverOpsScanProbeDuration2	0	5827	5828	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1409	systemScanDurationSkillAstrometrics	0	5833	5834	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1410	propulsionSkillCapNeedBonusSkillLevel	0	5657	5658	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1411	gangBonusSignature	1	5835	5836	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1	gangSignatureBoost	0	0	0	0	0	\N	\N	\N	\N
1412	shipBonusHybridOptimalCB	0	5837	5838	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1413	fixForMwdSigProblem1	1	5839	5840	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	fixForMwdSigProblem	0	0	0	0	\N	\N	\N	\N	\N
1414	fixForMwdSigProblem2	1	3517	3518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	fixForMwdSigProblem	0	0	0	0	\N	\N	\N	\N	\N
1415	fixForMwdSigProblem3	1	5841	5842	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1416	fixForMwdSigProblem4	1	5843	5844			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1417	speedBoostMassAddonSigMultiplyVelocityMultiply	1	5845	5846			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1418	hiddenLauncherDamageEffect	0	5849	5850	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1419	ewStabilizerRof	0	5852	5853	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1420	ewStabilizerStrLadar	0	5857	5858	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1421	ewStabilizerStrRadar	0	5860	5861	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1422	ewStabilizerStrMagnetometric	0	5863	5864	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1423	ewStabilizerStrGravimetric	0	5866	5867	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1424	ewStabilizerStrM&G	0	5868	5869			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1426	ewStabilizerStrR&L	0	5872	5873			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1427	ewStabilizerStr	0	5874	5875			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1428	caldariShipEwStrengthLadarCB	0	5876	5877	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1429	caldariShipEwStrengthRadarCB	0	5878	5879	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1430	caldariShipEwStrengthMagnetoCB	0	5880	5881	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1431	caldariShipEwStrengthGravimetricCB	0	5882	5883	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1432	caldariShipEwStrengthG&LCB	0	5884	5885			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1433	caldariShipEwStrengthM&RCB	0	5886	5887			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1434	caldariShipEwStrengthCB	0	5888	5889			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1436	missileEMdamage	1	5892	5893	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1437	missileTHERMdamage	1	5894	5895	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1438	missileKINdamage	1	5896	5897	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1439	missileEXPdamage	1	5898	5899	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1440	missileEMdamageOther	0	5903	5904	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1441	caldariShipEwOptimalRangeCB3	0	5907	5908	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1442	caldariShipEwOptimalRangeCC2	0	5909	5910	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1443	caldariShipEwCapacitorNeedCC	0	5911	5912	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1444	caldariShipEwOptimalRangeCF2	0	5913	5914	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1445	ewSkillRsdMaxRangeBonus	0	5915	5916	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1446	ewSkillTpMaxRangeBonus	0	5919	5920	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1448	ewSkillTdMaxRangeBonus	0	5929	5930	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1449	ewSkillRsdFallOffBonus	0	5933	5934	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1450	ewSkillTpFallOffBonus	0	5937	5938	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1451	ewSkillTdFallOffBonus	0	5941	5942	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1452	ewSkillEwMaxRangeBonus	0	5943	5944	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1453	ewSkillEwFallOffBonus	0	5947	5948	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1462	missileSkillAoeVelocityBonusStandard	0	5966	5967	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1463	missileSkillAoeVelocityBonusHeavy	0	5970	5971	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1464	missileSkillAoeVelocityBonusCruise	0	5974	5975	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1465	missileSkillAoeVelocityBonusHeavy&Cruise	0	5976	5977			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1467	missileSkillAoeVelocityBonusSkillLevel	0	5982	5983	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1468	missileSkillAoeCloudSizeBonusStandard	0	5988	5989	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1469	missileSkillAoeCloudSizeBonusHeavy	0	5992	5993	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1470	missileSkillAoeCloudSizeBonusCruise	0	5996	5997	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1471	missileSkillAoeCloudSizeBonusCruise&Heavy	0	5998	5999			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1472	missileSkillAoeCloudSizeBonus	0	6000	6001			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1473	missileSkillAoeCloudSizeBonusSkillLevel	0	6004	6005	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1479	siegeModuleGlobalVelocityMultiply	1	2308	2309	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1481	shipSkillAdvancedSpaceshipCommandAgilityBonus	0	6030	6031	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1482	contrabandMaskTemp	1	5356	5357	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	0	\N	\N	\N	\N
1483	contrabandMasking	1	6032	6033			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	0	\N	\N	\N	\N
1484	gangInterceptorBonusSignature	1	6042	6043	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1	gangInterceptorBonus	0	0	0	0	\N	\N	\N	\N	\N
1485	commandMultiplyer	0	6046	6047	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1486	commandMultiplier	0	6050	6051	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1487	gangInterceptorBonusVelocity	1	6054	6055	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1488	gangInterceptorBonusScanResolution	1	6058	6059	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1489	gangBonusVelocity	1	6061	6062	Automatically generated effect	effects.ShipScan	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1490	gangBonusTargetingSpeed	1	6063	6064	Automatically generated effect	effects.ShipScan	0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1491	squadronCommandSkillBoostRelayCPUBonus	0	6069	6070	Boost of relayCPUBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1492	squadronCpuRelayBonus	0	6072	6073	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	SquadronCpuRelayBonus	0	0	0	0	\N	\N	\N	\N	\N
1494	masterAndCommander	0	6079	6080	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1495	flagshipmultiRelayEffect	4	6083	6084	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	multiRelayEffect	0	0	0	0	\N	\N	\N	\N	\N
1496	relayActiveMultiplier	1	6087	6088	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1497	gangArmorRepairAmplifier	1	6091	6092	Automatically generated effect		0	0	1	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1498	masterAndCommander2	0	6076	6077	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1499	shieldOperationSkillBoostCapacitorNeedBonusSkillLevel	0	6097	6098	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	shieldOperationSkillBoostCapacitorNeedBonus	0	0	0	0	\N	\N	\N	\N	\N
1500	shieldOperationSkillBoostCapacitorNeedBonus	0	6099	6100	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1501	covertOpsStealthBomberCruiseMissileExplosionRadiusBonus	0	6102	6103	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1502	armorTankingGang	0	6106	6107	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1503	gangArmorEmHardering	1	6110	6111	Automatically generated effect		0	0	1	\N	\N	\N	\N	\N	0	1	GangArmorEmHardering	0	0	0	0	\N	\N	\N	\N	\N
1504	gangArmorEXPHardering	1	6114	6115	Automatically generated effect		0	0	1	\N	\N	\N	\N	\N	0	1	GangArmorEXPHardering	0	0	0	0	\N	\N	\N	\N	\N
1505	gangArmorThermaHardering	1	6118	6119	Automatically generated effect		0	0	1	\N	\N	\N	\N	\N	0	1	GangArmorThermaHardering	0	0	0	0	\N	\N	\N	\N	\N
1506	gangArmorKineticHardering	1	6122	6123	Automatically generated effect		0	1	0	\N	\N	\N	\N	\N	0	1	GangArmorKineticHardering	0	0	0	0	\N	\N	\N	\N	\N
1507	ewTargetPaint2	2	5659	5660	Automatically generated effect		0	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	\N	\N	\N	\N
1508	gangArmorEXPEMHardening	1	6124	6125			\N	0	1	\N	\N	\N	\N	\N	0	1	GangArmorEXPEMHardening	0	0	0	0	\N	\N	\N	\N	\N
1509	gangArmorThermKinHardening	1	6126	6127			\N	1	1	\N	\N	\N	\N	\N	0	1	GangArmorThermKinHardening	0	0	0	0	\N	\N	\N	\N	\N
1510	gangArmorHardening	1	6128	6129		effects.ElectronicAttributeModifyActivate	\N	1	1	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1511	siegeModuleShipWarpStatus	1	6132	6133	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1512	siegeModuleGlobalWarp&Velocity	1	6134	6135			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1513	siegeModuleGlobalScanLadarMultiply	1	6137	6138	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1515	siegeModuleGlobalScanGravimetricMultiply	1	6143	6144	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1516	siegeModuleGlobalScanRadarMultiply	1	6146	6147	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1517	siegeModuleGlobalScanMagnetometricMultiply	1	6149	6150	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1518	siegeModuleGlobalScanGravi&LadarMultiply	1	6151	6152			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1519	siegeModuleGlobalScanMagneto&RadarMultiply	1	6153	6154			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1522	siegeModuleGlobalScanStrengthsMultiply	1	6155	6156			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1523	siegeModuleGlobalWarp&Velocity&ScanStrength	1	6157	6158			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1524	gangShieldEMhardening	1	6161	6162	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	GangShieldEMhardening	0	0	0	0	\N	\N	\N	\N	\N
1525	gangShieldEXhardening	1	6165	6166	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangShieldEXhardening	0	0	0	0	\N	\N	\N	\N	\N
1527	gangShieldTHEhardening	1	6173	6174	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangShieldTHEhardening	0	0	0	0	\N	\N	\N	\N	\N
1528	gangShieldKINhardening	1	6175	6176	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangShieldKINhardening	0	0	0	0	\N	\N	\N	\N	\N
1529	siegeModuleShipScanRes	1	3398	3399	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1531	gangShieldKINTHEhardening	1	6179	6180			\N	0	0	\N	\N	\N	\N	\N	0	1	Hjörtur	0	0	0	0	\N	\N	\N	\N	\N
1533	gangGravECCMBonus	1	6185	6186	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangGravECCMBonus	0	0	0	0	\N	\N	\N	\N	\N
1534	gangLadarECCM	1	6189	6190	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangLadarECCM	0	0	0	0	\N	\N	\N	\N	\N
1535	gangRadarECCM	1	6193	6194	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangRadarECCM	0	0	0	0	\N	\N	\N	\N	\N
1536	gangMagECCM	1	6197	6198	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangMagECCM	0	0	0	0	\N	\N	\N	\N	\N
1537	gangGravMagECCM	1	6199	6200			\N	0	0	\N	\N	\N	\N	\N	0	1	GangGravMagECCM	0	0	0	0	\N	\N	\N	\N	\N
1538	gangLadarRadarECCM	1	6201	6202			\N	0	0	\N	\N	\N	\N	\N	0	1	GangLadarRadarECCM	0	0	0	0	\N	\N	\N	\N	\N
1539	gangECCM	1	6203	6204			\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1540	gangEwarRangeBoost	1	6207	6208	Automatically generated effect		0	0	1	73	\N	6	\N	\N	0	1	GangEwarRangeBoost	0	0	0	0	0	\N	\N	\N	\N
1541	squadronmultiplyer	0	6211	6212	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1542	squadronCommand	0	6219	6220	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1545	dreadnoughtAdvancedSpaceshipAgilityBonus	0	6231	6232	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1546	gangPropulsionJammingBoost	1	6235	6236	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	0	\N	\N	\N	\N
1547	gangShieldEXEMhardening	1	6237	6238			\N	0	0	\N	\N	\N	\N	\N	0	0	GangShieldEXEMhardening	0	0	0	0	\N	\N	\N	\N	\N
1548	gangShieldHardening	1	6239	6240		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1549	ewTargetPaint	2	3836	3837	Automatically generated effect	effects.TargetPaint	0	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	\N	\N	\N	\N
1550	ewSkillTargetPaintingStrengthBonus	0	5951	5952	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1551	minmatarShipEwTargetPainterMF2	0	5953	5954	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1552	siegeModuleGlobalWarp&Velocity&ScanRes	1	6244	6245			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1553	siegeModuleGlobalGunneryDamageMultiplier	1	3015	3016	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1554	siegeModuleGlobalGunneryTrackingMultiplier	1	6248	6249	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1555	siegeModuleGlobalGunneryRofMultiplier	1	1583	1584	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1557	siegeModuleGlobalMissileOperationRofMultiplier	1	2429	2430	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1558	siegeModuleGlobalMissileOperationDamageMultiplier	1	3657	3658	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1560	siegeModuleGlobalGunneryDamage&Rof	1	6254	6255			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1561	siegeModuleGlobalGunneryDamage&Rof&Tracking	1	6256	6257			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1562	siegeModuleGlobalMissileOperationDamage&RoF	1	6258	6259			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1566	siegeModuleGlobalMissileOperationVelocityMultiplier	1	6267	6268	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1569	siegeModuleModeOLD	1	6273	6274			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1570	siegeModuleGlobalMissileOperationAoeVelocity	1	6278	6279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1571	siegeModuleGlobalMissileOperationAoeFalloff	1	6282	6283	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1572	siegeModuleGlobalMissileOperationDamage&RoF&AoeVelocity	1	6284	6285			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1573	siegeModuleGlobalMissileOperationDamage&RoF&AoeVelocity&Falloff	1	6286	6287			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1574	siegeModuleGlobalCombinedGunnery&MissileOperation	1	6288	6289			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1575	siegeModuleMode	1	6290	6291			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1576	cynosuralGenerationBASE	1	131	131	Generates a Cynosural Field for the duration of this effect		\N	0	0	73	\N	\N	\N	\N	0	0	cynosuralGeneration	0	0	0	0	0	\N	\N	\N	\N
1577	angelsetbonus	0	6304	6305	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1579	setBonusSansha	0	6313	6314	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1580	cynosuralGenerationOLD	1	6315	6316			\N	0	0	73	\N	\N	\N	\N	0	0	cynosuralGeneration	0	0	0	0	\N	\N	\N	\N	\N
1581	jumpDriveSkillsRangeBonus	0	6321	6322	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1582	jumpDriveSkillsRangeBonusSkillLevel	0	6325	6326	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1583	jumpDriveSkillsDurationBonus	0	6331	6332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1584	jumpDriveSkillsDurationBonusSkillLevel	0	6335	6336	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1585	capitalTurretSkillLaserDamage	0	6338	6339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1586	capitalTurretSkillProjectileDamage	0	6344	6345	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1587	capitalTurretSkillHybridDamage	0	6350	6351	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1588	capitalLauncherSkillCitadelKineticDamage	0	6356	6357	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	capitalLauncherSkillCitadelDamage	0	0	0	0	\N	\N	\N	\N	\N
1590	missileSkillAoeVelocityBonus	0	6278	6279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1592	capitalLauncherSkillCitadelEmDamage	0	6365	6366	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1593	capitalLauncherSkillCitadelExplosiveDamage	0	6369	6370	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1594	capitalLauncherSkillCitadelThermalDamage	0	6373	6374	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1595	missileSkillWarheadUpgradesEmDamageBonus	0	6375	6376	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1596	missileSkillWarheadUpgradesExplosiveDamageBonus	0	6377	6378	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1597	missileSkillWarheadUpgradesKineticDamageBonus	0	6379	6380	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1601	siegeModuleGlobalMissileOperationEmDamage	1	6375	6376	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1602	siegeModuleGlobalMissileOperationExplosiveDamage	1	6377	6378	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1603	siegeModuleGlobalMissileOperationThermalDamage	1	6388	6389	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1604	siegeModuleGlobalMissileOperationKineticDamage	1	6379	6380	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1605	siegeModuleGlobalMissileOperationEm&ExplosiveDamage	1	6390	6391			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1606	siegeModuleGlobalMissileOperationKinetic&ThermalDamage	1	6392	6393			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1607	siegeModuleGlobalMissileOperationDamageBonus	1	6394	6395			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1608	siegeModuleGlobalMissileOperationDamageBonus&RoF	1	6396	6397			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1609	siegeModuleGlobalMissileOperationAoeVelocity&FallOff	1	6398	6399			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1610	siegeModuleGlobalMissileOperationCombinedNew	1	6400	6401			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1611	siegeModuleGlobalCombinedGunnery&MissileOperationNew	1	6402	6403			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1612	siegeModuleModeNew	1	6404	6405		effects.SiegeMode	\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1614	skillAdvancedSpaceshipAgilityBonus	0	6409	6410	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1615	shipAdvancedSpaceshipCommandAgilityBonus	0	6412	6413	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1616	skillCapitalShipsAdvancedAgility	0	6418	6419	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1617	shipCapitalAgilityBonus	0	6420	6421	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1618	dreadnoughtBoostShipBonusA1	0	6434	6435	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dreadnoughtBoostShipBonusA	0	0	0	0	\N	\N	\N	\N	\N
1619	dreadnoughtBoostShipBonusA2	0	6438	6439	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dreadnoughtBoostShipBonus	0	0	0	0	\N	\N	\N	\N	\N
1620	dreadnoughtBoostShipBonusC1	0	6442	6443	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1621	dreadnoughtBoostShipBonusC2	0	6446	6447	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1622	dreadnoughtBoostShipBonusG1	0	6450	6451	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1623	dreadnoughtBoostShipBonusG2	0	6454	6455	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1624	dreadnoughtBoostShipBonusM1	0	6458	6459	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1625	dreadnoughtBoostShipBonusM2	0	6462	6463	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1626	dreadnoughtShipBonusLaserCapNeedA1	0	6466	6467	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1627	dreadnoughtShipBonusLaserRofA2	0	6469	6470	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1628	dreadnoughtShipBonusLauncherRofC1	0	6471	6472	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1630	dreadnoughtShipBonusHybridDmgG1	0	6475	6476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1631	dreadnoughtShipBonusDroneControlAddG2	0	6477	6478	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1632	dreadnoughtShipBonusProjectileRofM1	0	6481	6482	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1633	dreadnoughtShipBonusLauncherRofM2	0	6483	6484	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1634	capitalShieldOperationSkillCapacitorNeedBonus	0	6489	6490	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1635	capitalRepairSystemsSkillDurationBonus	0	6495	6496	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1636	skillAdvancedWeaponUpgradesPowerNeedGunneryBonus	0	6499	6500	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1637	skillAdvancedWeaponUpgradesPowerNeedMissileOperationBonus	0	6503	6504	Automatically generated effect	skillAdvancedWeaponUpgradesPowerNeedMissileOperationBonus	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1638	skillAdvancedWeaponUpgradesPowerNeedBonus	0	6505	6506			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1640	gangEwarRangeBoost2	1	6207	6208	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1	GangEwarRangeBoost2	0	0	0	0	0	\N	\N	\N	\N
1641	gangArmorRepairAmplifier2	1	6091	6092	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1642	gangEwarRangeBoost3	1	6207	6208	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	GangEwarRangeBoost3	0	0	0	0	\N	\N	\N	\N	\N
1643	armoredWarfareMindlink	0	6517	6518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ArmoredWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1644	shirmishWarfareMindlink	0	6523	6524	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShirmishWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1645	siegeWarfareMindlink	0	6529	6530	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	SiegeWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1646	covertWarfareMindlink	0	6535	6536	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	CovertWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1647	ganGravMagECCMfixed	1	6537	6538			\N	0	0	\N	\N	\N	\N	\N	0	1	GanGravMagECCMfixed	0	0	0	0	\N	\N	\N	\N	\N
1648	gangECCMfixed	1	6539	6540		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	1	Gang ECCM	0	0	0	0	0	\N	\N	\N	\N
1649	skillCynosuralTheoryConsumptionQuantityBonus	0	6547	6548	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	skillConsumptionQuantityBonus	0	0	0	0	\N	\N	\N	\N	\N
1650	skillSiegeModuleConsumptionQuantityBonus	0	6553	6554	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1651	skillCynosural&SiegeConsumQuantityBonusSkillLevel	0	6557	6558	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1652	skillJumpDriveConsumptionAmountBonus	0	6561	6562	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	skilljumpDriveConsumptionAmountBonus	0	0	0	0	\N	\N	\N	\N	\N
1657	missileSkillWarheadUpgradesThermalDamageBonus	0	6388	6389	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1659	freighterA1SkillLevel	0	6590	6591	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusA1	0	0	0	0	\N	\N	\N	\N	\N
1660	freighterA2SkillLevel	0	6572	6573	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterCargoBonusA2	0	0	0	0	\N	\N	\N	\N	\N
1661	freighterC1SkillLevel	0	6594	6595	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusC1	0	0	0	0	\N	\N	\N	\N	\N
1663	freighterC2SkillLevel	0	6601	6602	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusG1	0	0	0	0	\N	\N	\N	\N	\N
1664	freighterG1SkillLevel	0	6605	6606	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusG1	0	0	0	0	\N	\N	\N	\N	\N
1665	freighterG2SkillLevel	0	6609	6610	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterCargoBonusG2	0	0	0	0	\N	\N	\N	\N	\N
1666	freighterM1SkillLevel	0	6613	6614	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusM1	0	0	0	0	\N	\N	\N	\N	\N
1667	freighterM2SkillLevel	0	6617	6618	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterCargoBonusM2	0	0	0	0	\N	\N	\N	\N	\N
1668	freighterCargoBonusA2	0	6576	6577	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1669	freighterCargoBonusC2	0	6619	6620	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1670	freighterCargoBonusG2	0	6621	6622	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1671	freighterCargoBonusM2	0	6623	6624	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1672	freighterMaxVelocityBonusA1	0	6574	6575	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1673	freighterMaxVelocityBonusC1	0	6625	6626	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1674	freighterMaxVelocityBonusG1	0	6627	6628	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1675	freighterMaxVelocityBonusM1	0	6629	6630	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1676	testfuelBoostShipSpeedActivation	1	6633	6634	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	TESTfuelBoostShipSpeedActivation	0	0	0	0	\N	\N	\N	\N	\N
1677	siegeModuleCapitalLaserDamage	1	6338	6339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	siegeModuleXlLaserDamage	0	0	0	0	\N	\N	\N	\N	\N
1678	siegeModuleCapitalLaserTracking	1	6636	6637	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1679	siegeModuleCapitalHybridTracking	1	6640	6641	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1680	siegeModuleCapitalHybridDamage	1	6350	6351	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1681	siegeModuleCapitalProjectileDamage	1	6344	6345	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1682	siegeModuleCapitalProjectileTracking	1	6644	6645	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1683	siegeModuleCapitalHybridDamage&Tracking	1	6646	6647			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1684	siegeModuleCapitalLaserDamage&Tracking	1	6648	6649			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1685	siegeModuleCapitalProjectileDamage&Tracking	1	6650	6651			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1686	siegeModuleCapitalHybrid&Laser	1	6652	6653			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1687	siegeModuleCapitalTurrets	1	6654	6655			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1688	siegeModuleCapitalMissileExplosiveDamage	1	6369	6370	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1689	siegeModuleCapitalMissileKineticDamage	1	6356	6357	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1690	siegeModuleCapitalMissileThermalDamage	1	6373	6374	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1691	siegeModuleCapitalMissileEmDamage	1	6365	6366	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1692	siegeModuleCapitalMissileKinetic&ThermalDamage	1	6656	6657			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1693	siegeModuleCapitalMissileEm&ExplosiveDamage	1	6658	6659			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1694	siegeModuleCapitalMissileDamage	1	6660	6661			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1695	siegeModuleCapitalMissileAoeVelocity	1	6664	6665	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1696	siegeModuleCapitalMissileAoeFallOff	1	6668	6669	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1697	siegeModuleCapitalMissileAoeVelocity&FallOff	1	6670	6671			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1698	siegeModuleCapitalMissiles	1	6672	6673			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1699	siegeModuleCapitalTurrets&Missiles	1	6674	6675			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1700	siegeModuleShipVelocity	1	6676	6677	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1704	siegeModuleCapitalArmorRepairAmount	1	6688	6689	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1706	siegeModuleCapitalShieldBoostAmount	1	6694	6695	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1707	siegeModuleCapitalShieldBoostDuration	1	6701	6702	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1709	siegeModuleCapitalArmorRepairDuration	1	6703	6704	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1710	siegeModuleCapitalArmorRepair	1	6705	6706			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1711	siegeModuleCapitalShieldBoost	1	6707	6708			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1712	siegeModuleCapitalDefenceBoost	1	6709	6710			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1713	siegeModuleFinalEffect	1	6711	6712			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1714	siegeModuleShipVelocityFixedDisplay	1	3488	3490	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1717	siegeModuleShip&Turret&Missiles	1	6713	6714			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1719	shieldBoostAmplifierCapital	4	6694	6695	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1720	shieldBoostAmplifier	4	6717	6718			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1721	dreadnoughtShipBonusMissileKineticDmgC2	0	6720	6721	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1722	jumpDriveSkillsCapacitorNeedBonus	0	6726	6727	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1723	jumpDriveSkillsCapacitorNeedBonusSkillLevel	0	6730	6731	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1724	siegeModuleShipWarp&Velocity	1	6732	6733			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1725	siegeModuleShip	1	6734	6735			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1726	siegeModuleCapitalDefence&Offense	1	6736	6737			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1727	siegeModuleEffect2dmg	1	6738	6739		effects.SiegeMode	\N	0	0	73	\N	\N	\N	\N	0	0	siegeModuleEffect	0	0	0	0	0	\N	\N	\N	\N
1728	cynosuralGenerationVelocity	1	6740	6741			\N	0	0	73	\N	\N	\N	\N	0	0	cynosuralGeneration	0	0	0	0	\N	\N	\N	\N	\N
1729	cynosuralGeneration	1	6742	6743			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1730	droneDmgBonus	0	6744	6745	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1731	testDroneShieldEffect	0	6750	6751	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	TestDroneShieldEffect	0	0	0	0	\N	\N	\N	\N	\N
1732	gangVelocityBoostAmplifier	0	6756	6757	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1733	gangVelocityBoostAmplifier2	1	6762	6763	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1736	gangAfterburnerBoost	1	6768	6769	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1	Gang Afterburner Boost	0	0	0	0	\N	\N	\N	\N	\N
1737	gangVelocityBoostAmplify	0	6770	6771			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1738	openSpawnContainer	2	131	131		effects.TargetScan	\N	0	0	73	\N	6	54	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1739	dataMiningSkillMultiplier	0	6778	6779	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1740	dataMiningSkillMultiplierFixed	0	6782	6783	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1741	siegeModuleEffect	1	6715	6716		effects.SiegeMode	\N	0	0	73	\N	\N	\N	\N	0	0	siegeModuleEffectfifft	0	0	0	0	0	\N	\N	\N	\N
1742	siegeModeShipVelocity&Warp	1	6784	6785			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1743	siegeModeShip	1	6786	6787			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1744	siegeModeShip&Defence	1	6788	6789			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1745	siegeModeEffect	1	6790	6791		effects.SiegeMode	\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1746	gangArmorRepairSpeedAmplifier	1	6794	6795	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1747	gangArmorRepairCapReducer	1	6798	6799	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1748	gangBonusSensorBoosterRange	1	6802	6803	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1749	entityScanStrengthBonusTarget	2	956	903	Modifies the scanning strengths of a targeted object.	effects.ScanStrengthBonusTarget	\N	0	0	73	\N	\N	\N	\N	0	1		0	0	1	0	1	\N	\N	\N	\N
1750	gangShieldBoostSpeed	1	6806	6807	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1751	gangShieldBoostCap	1	6810	6811	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1752	entityEwTestEffectJam	2	5643	5644	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
1753	gangSensorBoostRange3	1	6814	6815	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1754	gangMicrowarpdriveBoost	1	6818	6819	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1755	gangAbMwdFactorBoost	1	6820	6821			\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1756	skirmishWarfareVelocityBonus	0	6823	6824	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1757	missileSkillT2RocketLauncherRoF	0	6829	6830	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1758	missileSkillT2StandardLauncherRoF	0	6835	6836	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1760	missileSkillT2CruiseLauncherRoF	0	6845	6846	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1761	missileSkillT2HeavyLauncherRoF	0	6851	6852	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1762	missileSkillT2TorpedoLauncherRoF	0	6857	6858	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1763	missileSkillRapidLauncherRoF	0	6859	6860	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1764	missileSkillMissileProjectileVelocityBonus	0	6861	6862	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1765	missileSkillMissileProjectileVelocityBonusSkillLevel	0	6864	6865	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1767	shipBonusPirateSanshaLaserCap	0	6871	6872	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1769	shipShieldBoostCF	0	6877	6878	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1773	shipFalloffBonusGF	0	6892	6893	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1775	shipSensorLinkingRangeCF	0	6896	6897	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	ShipSensorLinkingRangeCF	0	0	0	0	\N	\N	\N	\N	\N
1776	shipSensorLinkingRangeMF	0	6898	6899	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	ShipSensorLinkingRangeMF	0	0	0	0	\N	\N	\N	\N	\N
1777	shipSensorLinkingRangeGF	0	6900	6901	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	ShipSensorLinkingRangeGF	0	0	0	0	\N	\N	\N	\N	\N
1778	shipCapUsePJammingCF	0	6902	6903	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1779	shipCapUsePJammingGF	0	6904	6905	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1780	shipCapUsePJammingMF	0	6906	6907	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1783	shipScanresBonusCF	0	6914	6915	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1784	shipScanresBonusMF	0	6916	6917	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1785	shipScanresBonusGF	0	6918	6919	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1786	shipScanresBonusAF	0	6920	6921	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1788	interdictorCpuBonus	0	6930	6931	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1789	amarrShipEwTrackingDisruptOptimalAC1	0	6937	6938	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1790	amarrShipEwTrackingDisruptTrackingAC1	0	6941	6942	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1791	amarrShipEwTrackingDisruptAC1	0	6943	6944			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1794	minmatarShipEwTargetPainterMC	0	6951	6952	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1796	shipRemoteArmorRepairerCapBonusAC	0	6955	6956	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1797	shipTrackingLinkBonusTrackingGC	0	6957	6958	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1798	shipTrackingLinkBonusRangeGC	0	6959	6960	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1799	shipBonusTrackingLinkGC	0	6961	6962		shipBonusTrackingLinkGC	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1800	shipFalloffBonusMF	0	6965	6966	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1802	shipMissileLightVelocityBonusCF2	0	6970	6971	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1803	shipMissileRocketVelocityBonusCF2	0	6972	6973	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1804	shipArmorEMResistanceAF1	0	6978	6979	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1805	shipArmorTHResistanceAF1	0	6980	6981	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1806	shipArmorKNResistanceAF1	0	6982	6983	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1807	shipArmorEXResistanceAF1	0	6984	6985	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1812	shipShieldEMResistanceCC2	0	6994	6995	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1813	shipShieldThermalResistanceCC2	0	6996	6997	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1814	shipShieldKineticResistanceCC2	0	6998	6999	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1815	shipShieldExplosiveResistanceCC2	0	7000	7001	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1816	shipShieldEMResistanceCF2	0	7002	7003	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1817	shipShieldThermalResistanceCF2	0	7004	7005	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1819	shipShieldKineticResistanceCF2	0	7008	7009	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1820	shipShieldExplosiveResistanceCF2	0	7010	7011	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1822	increaseGallenteNavyBonus	4	7021	7022	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1823	shipGallenteNavyBonus	0	7023	7024	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1824	increaseCaldariNavyBonus	4	7034	7035	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1825	increaseAmarrNavyBonus	4	7038	7039	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1826	increaseRepublicFleetBonus	4	7042	7043	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1828	shipAmarrNavyBonus	0	7047	7048	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1829	shipCaldariNavyBonus	0	7049	7050	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1830	shipRepublicFleetBonus	0	7051	7052	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1832	oreCompressionBonus	4	7069	7070	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1833	miningYieldGangBonus	0	7073	7074	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1835	miningYieldMultiply	4	7078	7079	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1837	minerCpuUsageMultiply	4	7085	7086	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1838	eliteBargeSkillMultiplier1	0	7094	7095	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1839	eliteBargeSkillMultiplier2	0	7098	7099	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1840	eliteBonusBargeMiningYield	0	7100	7101	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1841	eliteBonusMiningDroneYield	0	7102	7103	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1842	eliteBonusShipDronesMax	0	7104	7105	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1844	gangIceHarvestingYieldBonus	1	7112	7113	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1846	gangMiningCrystalYieldMultiplierBonus	1	7122	7123	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1848	miningForemanMindlink	0	7130	7131	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1849	miningBargeSkillLevelPostMulShipBonusORE3Ship	0	7136	7137	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1850	shipBonusIceHarvestingCycleTimeBarge3	0	7138	7139	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1851	selfRof	0	7140	7141	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	SelfRof	0	0	0	0	\N	\N	\N	\N	\N
1852	shipMiningBonusAF	0	7142	7143	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1853	shipMiningBonusCF	0	7144	7145	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1854	shipCargoBonusGF	0	7146	7147	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1855	shipBonusScanProbeDurationCF	0	7148	7149	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1856	shipBonusScanProbeDurationGF	0	7150	7151	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1857	shipBonusScanProbeDurationMF	0	7152	7153	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1858	iceMinerCpuUsageMultiply	4	7155	7156	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1862	shipMissileEMDamageCF	0	7171	7172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1863	shipMissileThermalDamageCF	0	7173	7174	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1864	shipMissileExplosiveDamageCF	0	7175	7176	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1865	shipMissileEMDamageMF2	0	7177	7178	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1866	shipMissileThermalDamageMF2	0	7179	7180	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1867	shipMissileKineticDamageMF2	0	7181	7182	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1868	shipMissileThermalDamageAF1	0	7183	7184	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1869	shipMissileKineticDamageAF1	0	7185	7186	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1870	shipMissileExplosiveDamageAF1	0	7187	7188	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1871	entityTargetJam	2	7210	7211	Automatically generated effect		0	1	0	929	\N	\N	936	953	0	0		0	0	1	0	\N	\N	\N	930	\N
1872	entityCapacitorDrain	2	270	131	Steals power from the target.	effects.EnergyVampire	\N	0	0	942	\N	\N	937	\N	0	0		0	0	0	0	\N	\N	\N	931	\N
1877	entityTrackingDisrupt	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.ElectronicAttributeModifyTarget	\N	0	0	944	\N	\N	940	951	0	1		0	1	0	0	1	\N	\N	933	\N
1878	entitySensorDampen	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	943	\N	\N	938	950	0	1		0	1	0	0	1	\N	\N	932	\N
1879	entityTargetPaint	2	3836	3837	Automatically generated effect		0	0	0	945	\N	\N	941	954	0	0		0	1	0	0	1	\N	\N	935	\N
1880	miningUpgradeCPUPenaltyReductionModulesRequiringMiningUpgrade	0	7167	7168	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1881	minerCpuUsageMultiplyPercent	4	7227	7228	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1882	miningYieldMultiplyPercent	4	2240	2241	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1885	shipCruiseLauncherROFBonus2CB	0	7234	7235	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1886	shipSiegeLauncherROFBonus2CB	0	7236	7237	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1893	caldariNavyModuleBonus	0	7258	7259	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1894	caldariNavyBonusHybridDamage	0	7265	7266	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1895	miningUpgradeCPUReductionBonus	0	7269	7270	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1896	eliteBargeBonusIceHarvestingCycleTimeBarge3	0	7271	7272	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1897	shieldCompensationSkillBoostHardeningBonus	0	7277	7278	Boost of hardeningBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1898	emShieldResonanceBonusRequiringTacShieldOps	1	7283	7284	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1899	explosiveShieldResonanceBonusRequiringTacShieldOps	1	7287	7288	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1900	kineticShieldResonanceBonusRequiringTacShieldOps	1	7291	7292	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1901	thermicShieldResonanceBonusRequiringTacShieldOps	1	7295	7296	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1902	testshieldBoostingEffectChance	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0	TESTshieldBoostingEffectChance	0	0	0	0	\N	\N	\N	959	\N
1903	caldariNavyModuleBonus2	0	7303	7304	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1904	caldariNavyBonusCPUEnhancerBonus	1	7307	7308	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1905	caldariNavyBonusShieldBooster	0	7311	7312	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1906	caldariNavyBonusMaxRange	0	7314	7315	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1907	amarrCruiserEnergySuckingMaxRangeBonus2	0	7318	7319	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1908	reconShipSkillMultiplier1	0	7325	7326	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1909	reconShipSkillMultiplier2	0	7329	7330	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1910	eliteBonusVampireDrainAmount2	0	7331	7332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1911	eliteReconBonusGravimetricStrength2	0	7335	7336	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1912	eliteReconBonusMagnetometricStrength2	0	7339	7340	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1913	eliteReconBonusRadarStrength2	0	7343	7344	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1914	eliteReconBonusLadarStrength2	0	7347	7348	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1915	eliteReconBonusKineticMissileDamage1	0	7349	7350	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1916	shipMissileHeavyVelocityBonusCC1	0	7351	7352	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1917	shipMissileLightVelocityBonusCC1	0	7353	7354	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1918	eliteReconBonusRofMissiles	0	7355	7356	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1919	eliteReconShipProjectileDamage1	0	7357	7358	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1920	eliteReconEnergyVampireRangeBonus1	0	7359	7360	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1921	eliteReconStasisWebBonus2	0	7361	7362	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1922	eliteReconJumpScramblerRangeBonus2	0	7367	7368	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1923	eliteReconHybridFalloffBonus1	0	7369	7370	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1924	passiveEmShieldResonanceBonusRequiringTacShieldOps	0	7378	7379	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	PassiveEmShieldResonanceBonusRequiringTacShieldOps	0	0	0	0	\N	\N	\N	\N	\N
1925	modifyPassiveEmShieldResonance	4	7380	7381	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1926	modifyShieldResonanceOnline	4	431	434			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1927	setKineticDamageResonanceMultiplier	1	7385	7386	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1928	modifyPassiveEmResonanceMultiplier	4	7393	7394	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1929	setActiveEmDamageResonanceMultiplier	1	7396	7397	Automatically generated effect		0	0	0	73	\N	317	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1933	setActiveKineticDamageResonanceMultiplier	1	7408	7409	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1934	setActiveThermalDamageResonanceMultiplier	1	7411	7412	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1935	setActiveExplosiveDamageResonanceMultiplier	1	7415	7416	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1936	setActiveEmExplosiveDamageResonanceMultiplier	1	7417	7418			\N	0	0	73	\N	317	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1937	setActiveEmExplosiveKineticDamageResonanceMultiplier	1	7419	7420			\N	0	0	73	\N	317	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1938	setActiveDamageResonanceMultiplier	1	7421	7422		effects.ModifyShieldResonance	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	2	\N	\N	\N	\N
1940	modifyPassiveThermalResonanceMultiplier	4	7426	7427	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1941	modifyPassiveKineticResonanceMultiplier	4	7428	7429	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1942	modifyPassiveExplosiveResonanceMultiplier	4	7431	7432	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1943	ammoEMResistOther	0	7435	7436	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	EM Resistance Modifier	0	0	0	0	\N	\N	\N	\N	\N
1944	passiveExplosiveShieldResonanceBonusRequiringTacShieldOps	0	7439	7440	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1945	passiveKineticShieldResonanceBonusRequiringTacShieldOps	0	7443	7444	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1946	passiveThermalShieldResonanceBonusRequiringTacShieldOps	0	7447	7448	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1947	passiveThermalShieldResonanceBonusRequiringShieldUpgrades	0	7451	7452	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1948	passiveEmShieldResonanceBonusRequiringShieldUpgrades	0	7455	7456	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1949	passiveExplosiveShieldResonanceBonusRequiringShieldUpgrades	0	7459	7460	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1950	passiveKineticShieldResonanceBonusRequiringShieldUpgrades	0	7463	7464	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1951	passiveEmArmorResonanceBonusRequiringHullUpgrades	0	7467	7468	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1952	passiveExplosiveArmorResonanceBonusRequiringHullUpgrades	0	7471	7472	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1953	passiveKineticArmorResonanceBonusRequiringHullUpgrades	0	7475	7476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1954	passiveThermalArmorResonanceBonusRequiringHullUpgrades	0	7479	7480	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1955	levelBoostForPrograms	1	7483	7484	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1	LevelBoostForPrograms	0	0	0	0	\N	\N	\N	\N	\N
1956	levelboostProgram	1	7486	7487	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1959	armorReinforcerMassAdd	4	5841	5842	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1960	addToSignatureRadius	0	3520	3521	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1962	signatureRadiusBonus	1	7501	7502	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1963	shipCargoBonusMF2	0	7503	7504	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
1964	shipBonusShieldTransferCapneed1	0	7505	7506	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1965	shipBonusEnergyTransferCapNeed1	0	7507	7508	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1966	shipBonusTrackingLinkBonusTrackingSpeedMultMC1	0	7509	7510	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1967	shipBonusTrackingLinkBonusMaxRangeMultMC1	0	7511	7512	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1968	shipBonusTrackingLinkMC1	0	7513	7514			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1969	shipBonusRemoteArmorRepairCapNeedGC1	0	7515	7516	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1970	damageControlArmorResistEm	4	7521	7522	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1972	damageControlArmorResistKinetic	4	7525	7526	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1973	damageControlArmorResistThermal	4	7527	7528	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1974	damageControlArmorResistExplosive	4	7529	7530	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1975	damageControlShieldResistEm	4	7532	7533	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1977	damageControlShieldResistExplosive	4	7535	7536	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1978	damageControlShieldResistKinetic	4	7538	7539	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1979	damageControlShieldResistThermal	4	7541	7542	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1980	damageControlHullResistEm	4	7543	7544	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1981	damageControlHullResistExplosive	4	7545	7546	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1982	damageControlHullResistKinetic	4	7547	7548	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1983	damageControlHullResistThermal	4	7549	7550	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1985	damageControlHullResistKinetic&Thermal	4	7553	7554			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1987	damageControlArmorResistEm&Explosive	4	7557	7558			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1988	damageControlArmorResistKinetic&Thermal	4	7559	7560			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1989	damageControlArmorResist	4	7561	7562			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1990	damageControlShieldResistKinetic&Thermal	4	7563	7564			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1991	damageControlShieldResistEm&Explosive	4	7565	7566			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1992	damageControlShieldResist	1	7567	7568			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1993	eliteReconShipBonusCynosuralDuration1	0	7572	7573	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1994	reconShipCpuMultiplier2	0	7574	7575	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1995	setActiveArmorDamageResonanceMultiplier	1	7421	7422			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1996	caldariShipEwCapacitorNeedCF2	0	7577	7578	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1999	shipBonusDroneEmDamageAC2	0	7586	7587	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2000	droneRangeBonusAdd	4	2674	2675	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2003	droneDamageMultiplierBonusPercent	4	7602	7603	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2004	droneSpeedMultiplierBonusMultiply	4	7606	7607	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2005	droneTrackingSpeedBonusMultiply	1	7610	7611	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2006	droneMaxRangeBonusMultiply	1	7614	7615	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2007	droneTrackingComputerMultiply	4	7616	7617		droneTrackingComputerMultiply	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2008	cynosuralDurationBonus	0	7618	7619	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2009	reconShipCpuMultiplier1	0	7620	7621	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2010	propulsionDroneJammingStrength	0	7626	7627	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2011	droneMaxVelocitySkillBonus	0	7630	7631	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2012	droneEntityCruiseSpeedBonus	0	7634	7635	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2013	droneMaxVelocityBonus	0	7638	7639	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2014	droneMaxRangeBonus	0	7641	7642	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2015	droneDurabilityShieldCapBonus	0	7645	7646	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2016	droneDurabilityArmorHPBonus	0	7649	7650	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2017	droneDurabilityHPBonus	0	7653	7654	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2018	damageRepairedSkillBonus	0	7658	7659	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2019	repairDroneShieldBonusBonus	0	7662	7663	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2020	repairDroneArmorDamageAmountBonus	0	7666	7667	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2021	scanStrengthBonusTargetNew	2	832	835	Boosts some of the scan strengths for the period of activation.	effects.ScanStrengthBonusActivate	\N	0	1	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2022	shipBonusDroneThermalDamageGC2	0	7670	7671	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2023	shipBonusDroneThermalDamageGB2	0	7672	7673	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2025	droneStructureHPBonus	0	7676	7677	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2026	droneShieldCapacityBonus	0	7678	7679	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2027	droneArmorHPBonus	0	7680	7681	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2029	addToSignatureRadius2	4	7686	7687	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2035	armorThermicResistanceBonusPostPercent	4	7713	7714	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2036	armorEmResistanceBonusPostPercent	4	7715	7716	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2037	armorExplosiveResistanceBonusPostPercent	4	7717	7718	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2038	armorKineticResistanceBonusPostPercent	4	7719	7720	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2039	modifyArmorResonanceKinThermPostPercent	4	7721	7722			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2040	modifyArmorResonanceEmExpPostPercent	4	7723	7724			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2041	modifyArmorResonancePostPercent	4	7725	7726			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2042	emArmorCompensationHardeningBonusRequiringHullUpgrades	0	7729	7730	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2043	explosiveArmorCompensationHardeningBonusRequiringHullUpgrades	0	7733	7734	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2044	kineticArmorCompensationHardeningBonusRequiringHullUpgrades	0	7737	7738	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2045	thermicArmorCompensationHardeningBonusRequiringHullUpgrades	0	7741	7742	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2046	emShieldResonanceBonusPostPercent	4	7743	7744	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2047	explosiveShieldResonanceBonusPostPercent	4	7745	7746	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2048	kineticShieldResonanceBonusPostPercent	4	7747	7748	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2049	thermalShieldResonanceBonusPostPercent	4	7749	7750	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2050	modifyShieldResonanceEmExpPostPercent	4	7751	7752			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2051	modifyShieldResonanceKinThermPostPercent	4	7753	7754			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2052	modifyShieldResonancePostPercent	4	7755	7756			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2053	emShieldCompensationHardeningBonusGroupShieldAmp	0	7761	7762	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2054	explosiveShieldCompensationHardeningBonusGroupShieldAmp	0	7765	7766	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2055	kineticShieldCompensationHardeningBonusGroupShieldAmp	0	7769	7770	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2056	thermalShieldCompensationHardeningBonusGroupShieldAmp	0	7773	7774	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2057	passiveEmShieldResonanceBonusRequiringTacShieldOps2	0	7779	7780	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	PassiveEmShieldResonanceBonusRequiringTacShieldOps2	0	0	0	0	\N	\N	\N	\N	\N
2058	passiveExplosiveShieldResonanceBonusRequiringTacShieldOps2	0	7781	7782	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	PassiveExplosiveShieldResonanceBonusRequiringTacShieldOps2	0	0	0	0	\N	\N	\N	\N	\N
2059	passiveKineticShieldResonanceBonusRequiringTacShieldOps2	0	7783	7784	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	PassiveKineticShieldResonanceBonusRequiringTacShieldOps2	0	0	0	0	\N	\N	\N	\N	\N
2060	passiveThermicShieldResonanceBonusRequiringTacShieldOps2	0	7785	7786	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	PassiveThermicShieldResonanceBonusRequiringTacShieldOps2	0	0	0	0	\N	\N	\N	\N	\N
2062	shieldCompensationSkillBoostHardeningBonus2	0	7793	7794	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2063	passiveEmArmorResonanceBonusGroupArmorHardener	0	7799	7800	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2064	passiveExplosiveArmorResonanceBonusGroupArmorHardener	0	7803	7804	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2065	passiveKineticArmorResonanceBonusGroupArmorHardener	0	7807	7808	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2066	passiveThermicArmorResonanceBonusGroupArmorHardener	1	7811	7812	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2069	reduceDroneControl	4	7818	7819	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2070	decreaseEwarDroneVolume	4	7826	7827	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2071	empWaveGrid	1	131	131	Triggering of a grid-wide EMP wave being broadcast into space.	effects.EMPWaveGrid	\N	1	0	73	\N	6	\N	\N	0	1		0	0	0	0	2	\N	\N	\N	\N
2076	modifyArmorResonanceActivePostPercent	1	7725	7726			\N	0	0	73	\N	6	\N	\N	0	0	modifyArmorResonancePostPercent	1	0	0	0	\N	\N	\N	\N	\N
2078	modifyEmArmorResonancePassivePostPercent	4	7849	7850	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2079	modifyExplosiveArmorResonancePassivePostPercent	4	7851	7852	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2080	modifyKineticArmorResonancePassivePostPercent	4	7853	7854	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2081	modifyThermicArmorResonancePassivePostPercent	4	7855	7856	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2082	modifyKineticThermicArmorResonancePassivePostPercent	4	7857	7858			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2083	modifyEmExplosiveArmorResonancePassivePostPercent	4	7859	7860			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2084	modifyArmorResonancePassivePostPercent	4	7861	7862			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2089	passiveEmDamageResistanceBonusMultiply	0	7881	7882	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2091	activeExplosiveDamageResistanceBonusMultiply	0	7888	7889	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2092	activeEmDamageResistanceBonusMultiply	0	7890	7891	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2093	activeKineticDamageResistanceBonusMultiply	0	7894	7895	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2094	activeThermicDamageResistanceBonusMultiply	0	7898	7899	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2095	activeKineticThermicDamageResistanceBonusMultiply	4	7900	7901			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2096	activeEmExplosiveDamageResistanceBonusMultiply	0	7902	7903			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2097	activeDamageResistanceBonusMultiply	0	7904	7905			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2098	modifyActiveArmorResonanceAndNullifyPassiveResonance	1	7906	7907			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2099	passiveExplosiveDamageResistanceBonusMultiply	0	7908	7909	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2100	passiveKineticDamageResistanceBonusMultiply	0	7910	7911	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2101	passiveThermicDamageResistanceBonusMultiply	0	7912	7913	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2102	passiveKineticThermicDamageResistanceBonusMultiply	0	7914	7915			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2103	passiveEmExplosiveDamageResistanceBonusMultiply	0	7916	7917			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2104	passiveDamageResistanceBonusMultiply	0	7918	7919			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2105	emArmorCompensationHardeningBonusGroupArmorCoating	0	7924	7925	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2106	explosiveArmorCompensationHardeningBonusGroupArmorCoating	0	7928	7929	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2107	kineticArmorCompensationHardeningBonusGroupArmorCoating	0	7932	7933	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2108	thermicArmorCompensationHardeningBonusGroupArmorCoating	0	7936	7937	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2109	emArmorCompensationHardeningBonusGroupEnergized	0	7942	7943	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2110	explosiveArmorCompensationHardeningBonusGroupEnergized	0	7946	7947	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2111	kineticArmorCompensationHardeningBonusGroupEnergized	0	7950	7951	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2112	thermicArmorCompensationHardeningBonusGroupEnergized	0	7954	7955	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2113	passiveEmArmorResonanceBonusGroupArmorHardener2	0	7957	7958	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2114	passiveExplosiveArmorResonanceBonusGroupArmorHardener2	0	7960	7961	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2115	passiveKineticArmorResonanceBonusGroupArmorHardener2	0	7963	7964	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2116	passiveThermicArmorResonanceBonusGroupArmorHardener2	0	7966	7967	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2117	modifyShieldResonancePassivePostPercent	4	7982	7983			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2118	modifyActiveShieldResonanceAndNullifyPassiveResonance	1	7968	7969		effects.ModifyShieldResonance	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2119	modifyShieldResonanceEmPassivePostPercent	4	7970	7971	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	modifyShieldResonancePassivePostPercent	0	0	0	0	\N	\N	\N	\N	\N
2120	modifyShieldResonanceExplosivePassivePostPercent	4	7972	7973	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2121	modifyShieldResonanceKineticPassivePostPercent	4	7974	7975	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2122	modifyShieldResonanceThermicPassivePostPercent	4	7976	7977	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	modifyShieldResonanceKineticmodifyShieldResonanceThermicPassivePostPercentPassivePostPercent	0	0	0	0	\N	\N	\N	\N	\N
2123	modifyShieldResonanceKineticThermicPassivePostPercent	4	7978	7979			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2124	modifyShieldResonanceEmExplosivePassivePostPercent	4	7980	7981			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2125	modifyActiveShieldResonancePostPercentTMP	2	7982	7983			\N	0	0	\N	\N	\N	\N	\N	0	0	modifyActiveShieldResonancePostPercent	0	0	0	0	\N	\N	\N	\N	\N
2126	passiveEmShieldResonanceBonusGroupArmorHardener2	0	7989	7990	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2127	passiveExplosiveShieldResonanceBonusGroupArmorHardener2	0	7993	7994	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2128	passiveKineticShieldResonanceBonusGroupArmorHardener2	0	7997	7998	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2129	passiveThermicShieldResonanceBonusGroupArmorHardener2	0	8001	8002	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2130	smallHybridMaxRangeBonus	0	8003	8004	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2131	smallEnergyMaxRangeBonus	0	8005	8006	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2132	smallProjectileMaxRangeBonus	0	8007	8008	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2133	energyTransferArrayMaxRangeBonus	0	8009	8010	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2134	shieldTransporterMaxRangeBonus	0	8015	8016	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2135	armorRepairProjectorMaxRangeBonus	0	8021	8022	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2136	trackingLinkMaxRangeBonus	0	8027	8028	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2137	miningLaserMaxRangeBonus	0	8032	8033	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2138	shipETDamageAC	0	8034	8035	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2139	dreadnoughtShipBonusDroneThermalDmgG2	0	8036	8037	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2140	dreadnoughShipBonusDroneShieldCapG2	0	8038	8039	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2141	dreadnoughShipBonusDroneArmorHPG2	0	8040	8041	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2142	dreadnoughShipBonusDroneStructureHPG2	0	8042	8043	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2143	minmatarShipEwTargetPainterMC2	0	6949	6950	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2144	commandCruiserBonusInfoWarfare	0	8047	8048	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Information Warfare Bonus	0	0	0	0	\N	\N	\N	\N	\N
2145	commandCruiserBonusSkirmishWarfare	0	8052	8053	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Skirmish Warfare Bonus	0	0	0	0	\N	\N	\N	\N	\N
2146	commandCruiserBonusSiegeWarfare	0	8057	8058	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Siege Warfare Bonus	0	0	0	0	\N	\N	\N	\N	\N
2147	commandCruiserBonusArmoredWarfare	0	8062	8063	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Armored Warfare Bonus	0	0	0	0	\N	\N	\N	\N	\N
2148	droneDamageBonusRequringDrones	0	7602	7603	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2152	jumpPortalGeneration	1	6732	6733		effects.JumpPortal	\N	0	0	1002	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2153	eliteBonusCommandShipMissileThermalDamageCS1	0	8081	8082	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2155	eliteBonusCommandShipProjectileDamageCS1	0	8087	8088	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2156	eliteBonusCommandShipProjectileFalloffCS2	0	8089	8090	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2157	eliteBonusCommandShipLaserDamageCS1	0	8091	8092	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2158	eliteBonusCommandShipLaserROFCS2	0	8093	8094	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2159	eliteBonusCommandShipHybridDamageCS1	0	8095	8096	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2160	eliteBonusCommandShipHybridFalloffCS2	0	8097	8098	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2161	eliteBonusCommandShipHybridOptimalCS1	0	8099	8100	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2162	eliteBonusCommandShipSiegeCS2	0	8101	8102	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2163	eliteBonusCommandShipProjectileTrackingCS1	0	8103	8104	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2164	eliteBonusCommandShipSkirmishCS2	0	8105	8106	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2165	eliteBonusCommandShipLaserOptimalCS1	0	8107	8108	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2166	eliteBonusCommandShipArmoredCS2	0	8109	8110	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2167	eliteBonusCommandShipDroneRangeCS1	0	8111	8112	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2168	eliteBonusCommandShipInfoCS2	0	8113	8114	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2169	eliteBonusCommandShipMissilePredictionBC1	0	8115	8116	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2170	shipBonusDroneStructureHPAC2	0	8118	8119	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2171	shipBonusDroneArmorHPAC2	0	8120	8121	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2172	shipBonusDroneShieldCapAC2	0	8124	8125	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2173	shipBonusDroneArmorAndStructureHPAC2	0	8126	8127			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2174	shipBonusDroneHitpointsAC2	0	8128	8129			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2175	shipBonusDroneStructureHPGC2	0	8130	8131	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2176	shipBonusDroneArmorHPGC2	0	8132	8133	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2177	shipBonusDroneShieldCapGC2	0	8134	8135	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2178	shipBonusDroneArmorAndStructureHPGC2	0	8136	8137			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2179	shipBonusDroneHitpointsGC2	0	8138	8139			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2180	shipBonusDronesShieldCapacityAC2	0	8140	8141	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2181	shipBonusDroneHitpointsFixedAC2	0	8142	8143			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2182	shipBonusDroneStructureHPGB2	0	8144	8145	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2183	shipBonusDroneShieldCapacityGB2	0	8146	8147	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2184	shipBonusDroneArmorHPGB2	0	8148	8149	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2185	shipBonusDroneArmorAndStructureHPGB2	0	8150	8151			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2186	shipBonusDroneHitpointsGB2	0	8152	8153			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2187	shipBonusDroneDamageMultiplierGB2	0	8154	8155	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2188	shipBonusDroneDamageMultiplierGC2	0	8156	8157	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2189	shipBonusDroneDamageMultiplierAC2	0	8158	8159	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2190	dreadnoughtShipBonusDroneDamageMultiplierG2	0	8160	8161	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2191	shipMissileVelocityDF1	0	8168	8169	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2192	entityShieldBoostingSmall	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	1006	\N
2193	entityShieldBoostingMedium	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	1007	\N
2194	entityShieldBoostingLarge	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	1008	\N
2195	entityArmorRepairingSmall	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	1009	\N
2196	entityArmorRepairingMedium	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	1010	\N
2197	entityArmorRepairingLarge	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	1011	\N
2198	eliteBonusInterdictorsLaserFalloff1	1	8175	8176	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2199	eliteBonusInterdictorsMissileThermalDamage1	0	8177	8178	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2200	eliteBonusInterdictorsMissileKineticDamage1	0	8179	8180	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2201	eliteBonusInterdictorsProjectileFalloff1	0	8181	8182	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2202	droneDmgBonusRequiringScoutDroneOP	0	8183	8184	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2203	energyDrainersModifyNpcShieldBoostDelayChanceSmall	2	8197	8198	Automatically generated effect		0	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2204	skillADDmaxJumpClone	0	8203	8204	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2205	energyDrainersModifyNpcShieldBoostDelayChanceMedium	2	8207	8208	Automatically generated effect		0	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2206	energyDrainersModifyNpcShieldBoostDelayChanceLarge	2	8211	8212	Automatically generated effect		0	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2207	energyDrainersModifyNpcArmorRepairDelayChanceLarge	2	8215	8216	Automatically generated effect		0	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2208	energyDrainersModifyNpcArmorRepairDelayChanceMedium	2	8219	8220	Automatically generated effect		0	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2209	energyDrainersModifyNpcArmorRepairDelayChanceSmall	2	8223	8224	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2210	energyDrainersModifyNpcArmorRepairDelayChanceSmall&Medium	2	8225	8226			\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2211	energyDrainersModifyNpcArmorRepairDelayChance	2	8227	8228			\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2212	energyDrainersModifyNpcShieldBoostDelayChanceSmall&Medium	2	8229	8230			\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2213	energyDrainersModifyNpcShieldBoostDelayChance	2	8231	8232			\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2214	energyDrainersModifyNpcArmorAndShieldDelayChance	2	8233	8234			\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2215	shipBonusPirateFrigateProjDamage	0	8235	8236	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2216	navigationComputerWarpAccuracyMaxRangeBonus	1	8244	8245	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2217	navigationComputerWarpAccuracyFactorBonus	1	8248	8249	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2218	navigationComputerWarpAccuracyBonus	1	8250	8251			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2219	warpNavigationWarpAccuracyFactorBonus	0	8256	8257	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2220	warpNavigationWarpAccuracyMaxRangeBonus	0	8260	8261	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2221	warpNavigationWarpAccuracyBonus	0	8262	8263			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2222	warpNavigationWarpAccuracyFactorSkillLevel	0	8266	8267	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2223	warpNavigationWarpAccuracyMaxRangeSkillLevel	0	8270	8271	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2224	warpNavigationWarpAccuracySkillLevel	0	8272	8273			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2225	scanGravimetricStrengthBonusActivate	1	8280	8281	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2226	scanMagnetometricStrengthBonusActivate	1	8282	8283	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2227	scanRadarStrengthBonusActivate	1	8285	8286	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2228	scanLadarStrengthBonusActivate	1	8288	8289	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2229	scanRadarLadarStrengthBonusActivate	1	8290	8291			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2230	scanGraviMagnetoMetricStrengthBonusActivate	1	8292	8293			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2231	scanStrengthBonusPercentActivate	1	8294	8295	Boosts some of the scan strengths for the period of activation.	effects.ScanStrengthBonusActivate	\N	0	0	73	\N	6	\N	\N	0	1		1	0	0	0	\N	\N	\N	\N	\N
2232	scanStrengthBonusPercentOnline	4	8294	8295	Modifies the various electronics scan strengths..		\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2240	scanGraviStrengthTargetPercentBonus	2	8305	8306	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2241	scanMagnetoStrengthTargetPercentBonus	2	8309	8310	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2242	scanLadarStrengthTargetPercentBonus	2	8312	8313	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2243	scanRadarStrengthTargetPercentBonus	2	8315	8316	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2244	scanGraviMagnetoStrengthTargetPercentBonus	2	8317	8318			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2245	scanRadarLadarStrengthTargetPercentBonus	2	8319	8320			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2246	scanStrengthTargetPercentBonus	2	8321	8322			\N	0	1	73	\N	6	54	158	0	0		0	1	0	0	\N	\N	\N	\N	\N
2247	dronesMaxActiveDroneBonusModAddMaxActiveActive	1	1876	1877	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2249	shipBonusDroneMiningAmountAC2	0	8329	8330	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2250	shipBonusDroneMiningAmountGC2	0	8331	8332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2251	commandshipMultiRelayEffect	0	6083	6084	commandshipMultiRelayEffect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2252	covertOpsAndReconOpsCloakModuleDelayBonus	0	8338	8339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2253	covertOpsStealthBomberTargettingDelayBonus	0	8344	8345	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2254	passiveExplosiveArmorResonanceBonusGroupArmorHardener2FIXED	0	8347	8348	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2255	tractorBeamCan	2	131	131		effects.TractorBeam	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2256	shipMissilePrecisionDF2	0	8349	8350	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2257	eliteBonusInterdictorsBubbleRoF2	0	8355	8356	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2258	eliteBargeMercoxiteCrystalBonus1	0	8361	8362	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2259	eliteBargeBonusDamageCloudReduction2	0	8364	8365	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2261	titanMinmatarProjectileRoF1	0	8376	8377	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2262	titanMinmatarGangVelocity2	0	8378	8379	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2263	titanAmarrEnergyTurretCapNeed1	0	8374	8375	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2264	titanAmarrGangCapRecharge2	0	8382	8383	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2265	titanCaldariMissileKineticDmg1	0	8384	8385	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2266	titanCaldariGangShieldHp2	0	8386	8387	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2267	titanGallenteHybridDamage1	0	8388	8389	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2268	titanGallenteGangArmorHp2	0	8390	8391	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2287	titanAmarrSkillLevel1	0	8463	8464	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2288	titanAmarrSkillLevel2	0	8466	8467	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2289	titanCaldariSkillLevel1	0	8469	8470	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2290	titanCaldariSkillLevel2	0	8472	8473	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2291	titanGallenteSkillLevel1	0	8475	8476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2292	titanGallenteSkillLevel2	0	8478	8479	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2293	titanMinmatarSkillLevel2	0	8481	8482	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2294	titanMinmatarSkillLevel1	0	8484	8485	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2295	modifyArmorResonancePostPercentPassive	0	7725	7726			\N	0	0	\N	\N	\N	\N	\N	0	0	modifyArmorResonancePostPercent	0	0	0	0	\N	\N	\N	\N	\N
2296	modifyArmorResonancePassivePostPercentPassive	0	7861	7862			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2297	modifyShieldResonancePassivePostPercentPassive	0	7982	7983			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2298	scanStrengthBonusPercentPassive	0	8294	8295	Boosts some of the scan strengths for the period of activation.	effects.ScanStrengthBonusActivate	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2299	damageControlHullResistEm&Explosive	4	8487	8488			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2300	damageControlHullResist	1	8489	8490			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2301	damageControlArmor&Hull	4	8491	8492			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2302	damageControl	1	8493	8494			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2303	energyDestabilizationNew	2	8495	8496		effects.EnergyDestabilization	\N	1	0	73	\N	6	98	\N	0	0	energyDestabilizationTEST	0	0	0	0	0	\N	\N	\N	\N
2304	energyNosferatu	2	8497	8496		effects.EnergyVampire	\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
2305	eliteReconBonusEnergyNeutAmount2	0	8502	8503	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2306	eliteReconBonusEnergyNeutRange1	0	8507	8508	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2308	eliteReconBonusAssaultLauncherROF1	0	8515	8516	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2309	droneMWDBoostOnline	4	8517	8518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2310	eliteBonusCommandShipDroneControlModuleCPUCS1	0	8523	8524	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2311	skillADDmaxJumpClones	0	8527	8528	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2312	disallowOffensiveActChar	0	8534	8535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	disallowOffensiveAct	0	0	0	0	\N	\N	\N	\N	\N
2313	carrierAmarrSkillLevel1	0	8551	8552	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2314	carrierAmarrSkillLevel2	0	8555	8556	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2315	carrierAmarrSkillLevel3	0	8559	8560	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2316	carrierCaldariSkillLevel1	0	8563	8564	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2317	carrierCaldariSkillLevel2	0	8567	8568	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2318	carrierCaldariSkillLevel3	0	8571	8572	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2319	carrierGallenteSkillLevel1	0	8575	8576	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2320	carrierGallenteSkillLevel2	0	8579	8580	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2321	carrierGallenteSkillLevel3	0	8583	8584	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2322	carrierMinmatarSkillLevel1	0	8587	8588	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2323	carrierMinmatarSkillLevel2	0	8591	8592	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2324	carrierMinmatarSkillLevel3	0	8595	8596	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2325	carrierAmarrDroneMax1	0	8597	8598	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2326	carrierCaldariDroneMax1	0	8599	8600	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2327	carrierGallenteDroneMax1	0	8601	8602	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2328	carrierMinmatarDroneMax1	0	8603	8604	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2332	carrierGallenteDroneOwnDmg2	0	8615	8616	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2334	cloneJumpAccepting	1	6742	6743			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2335	titanMinmatarGangSigRadius2	0	8619	8620	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2336	titanAmarrSkillLevel3	0	8632	8633	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2337	titanAmarrSkillLevel4	0	8636	8637	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2338	titanCaldariSkillLevel3	0	8640	8641	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2339	titanCaldariSkillLevel4	0	8644	8645	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2340	titanGallenteSkillLevel3	0	8648	8649	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2341	titanGallenteSkillLevel4	0	8652	8653	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2342	titanMinmatarSkillLevel3	0	8656	8657	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2343	titanMinmatarSkillLevel4	0	8660	8661	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2344	carrierAmarrSkillLevel4	0	8669	8670	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2345	carrierCaldariSkillLevel4	0	8673	8674	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2346	carrierGallenteSkillLevel4	0	8677	8678	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2347	titanAmarrLaserDmg3	0	8679	8680	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2348	titanAmarrLeadershipModuleAmount4	0	8685	8686	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2349	titanCaldariLeadershipModuleAmount4	0	8687	8688	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2350	titanGallenteLeadershipModuleAmount4	0	8689	8690	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2351	titanMinmatarLeadershipModuleAmount4	0	8691	8692	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2352	titanCaldariLauncherRoF3	0	8693	8694	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2353	titanMinmatarProjectileDmg3	0	8695	8696	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2354	capitalRemoteArmorRepairerCapNeedBonusSkill	0	8701	8702	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2355	capitalRemoteShieldTransferCapNeedBonusSkill	0	8707	8708	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2356	capitalRemoteEnergyTransferCapNeedBonusSkill	0	8713	8714	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2357	carrierMinmatarShieldTransferDuration2	0	8717	8718	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2358	carrierMinmatarArmorTransferDuration2	0	8721	8722	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2359	carrierMinmatarArmor&ShieldTransferDuration2	0	8723	8724			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2360	carrierAmarrLeadershipMaxGroupActive4	0	8725	8726	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2361	carrierCaldariLeadershipMaxGroupActive4	0	8727	8728	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2362	carrierGallenteLeadershipMaxGroupActive4	0	8729	8730	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2363	carrierMinmatarLeadershipMaxGroupActive4	0	8731	8732	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2364	carrierMinmatarSkillLevel4	0	8735	8736	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2365	carrierAmarrArmorResistEm2	0	8737	8738	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2366	carrierAmarrArmorResistExplosive2	0	8739	8740	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2367	carrierAmarrArmorResistKinetic2	0	8741	8742	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2368	carrierAmarrArmorResistThermal2	0	8743	8744	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2369	carrierAmarrArmorResistEm&Explosive2	0	8745	8746			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2370	carrierAmarrArmorResistKinetic&Thermal2	0	8747	8748			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2371	carrierAmarrArmorResist2	0	8749	8750			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2372	carrierCaldariShieldResistEm2	0	8751	8752	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2373	carrierCaldariShieldResistExplosive2	0	8753	8754	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2374	carrierCaldariShieldResistKinetic2	0	8755	8756	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2375	carrierCaldariShieldResistThermal2	0	8757	8758	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2376	carrierCaldariShieldResistEm&Explosive2	0	8759	8760			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2377	carrierCaldariShieldResistKinetic&Thermal2	0	8761	8762			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2378	carrierCaldariShieldResist2	0	8763	8764			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2379	carrierAmarrArmorTransferRange3	0	8767	8768	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2380	carrierAmarrEnergyTransferRange3	0	8771	8772	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2381	carrierAmarrArmor&EnergyTransferRange3	0	8773	8774			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2382	carrierCaldariShieldTransferRange3	0	8777	8778	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2383	carrierCaldariEnergyTransferRange3	0	8779	8780	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2384	carrierCaldariShield&EnergyTransferRange3	0	8781	8782			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2385	carrierGallenteArmorTransferRange3	0	8783	8784	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2386	carrierGallenteShieldTransferRange3	0	8785	8786	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2387	carrierGallenteArmor&ShieldTransferRange3	0	8787	8788			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2388	carrierMinmatarArmorTransferRange3	0	8789	8790	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2389	carrierMinmatarShieldTransferRange3	0	8791	8792	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2390	carrierMinmatarArmor&ShieldTransferRange3	0	8793	8794			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2392	iceHarvesterMiningAmountBonusMultiplier	0	8800	8801	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2393	titanJumpPortalCpuNeedBonus	0	8806	8807	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2394	titanAmarrJudgmentCpuNeedBonus	0	8812	8813	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2395	jumpPortalConsumptionBonusSkill	0	8816	8817	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2396	skillSuperWeaponEmDmgBonus	0	8822	8823	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2397	skillSuperWeaponExplosiveDmgBonus	0	8826	8827	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2398	skillSuperWeaponKineticDmgBonus	0	8830	8831	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2399	skillSuperWeaponThermalDmgBonus	0	8834	8835	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2400	skillSuperWeaponEm&ExplosiveDmgBonus	0	8836	8837			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2401	skillSuperWeaponKinetic&ThermalDmgBonus	0	8838	8839			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2402	skillSuperWeaponDmgBonus	0	8840	8841			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2403	dreadnoughtSiegeModeCpuNeedBonus	0	8844	8845	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2406	carrierFighterControlRangeBonus	0	8855	8856	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2407	interdictorBubbleProbeLauncherCpuBonus	0	8859	8860	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2408	eliteBonusCommandShipMissileKineticDamageCS1	0	8861	8862	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2409	eliteBonusInterdictorsMissileEMDamage1	0	8863	8864	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2410	cloneVatMaxJumpCloneBonusSkill	0	8869	8870	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2411	cloneVatMaxJumpCloneBonusSkillLevel	0	8873	8874	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2412	cloneVatCpuNeedBonus	0	8879	8880	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2413	snowBallLaunching	2	114	89	Launches a missile	effects.MissileDeployment	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2414	gangShieldTransporterSpeed	1	8883	8884	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2415	gangShieldBoosterAndTransporterSpeed	1	8885	8886			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2416	gangShieldTransporterCapNeed	1	8889	8890	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2418	gangShieldBoosteAndTransporterCapacitorNeed	1	8893	8894			\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2419	titanCaldariOblivionCpuNeed	0	8899	8900	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2420	titanGallenteAuroraOminaeCpuNeed	0	8905	8906	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2421	titanMinmatarFirestormCpuNeed	0	8911	8912	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2422	implantVelocityBonus	0	8917	8918	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Max Velocity Bonus	0	0	0	0	\N	\N	\N	\N	\N
2423	eliteReconHeavyMissileKineticDamage1	0	8921	8922	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2424	eliteReconLightMissileKineticDamage1	0	8925	8926	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2425	capitalShipIceMaterialVolumeReductionBonus	0	8931	8932	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2426	skillInterdictorEliteBonus1SkillLevel	0	8935	8936	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2427	skillInterdictorEliteBonus2SkillLevel	0	8939	8940	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2429	advancedDroneInterfacingMaxGroupDCUSkillLevel	0	8947	8948	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2430	maxVelocityMultiplier	0	8949	8950	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2431	energyManagementSkillBoostCapacitorCapacityBonus	0	8959	8960	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2432	energyManagementCapacitorBonusPostPercentCapacityLocationShipGroupCapacitorCapacityBonus	0	8961	8962	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2434	fightersDmgBonusSkills	0	8963	8964	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2435	cpuPenaltyToSuperWeapons	0	8972	8973	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2436	cpuBonusToSelf	0	8974	8975	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2437	miningYieldGangBonusFixed	0	8976	8977	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2438	damageControlShieldAndArmorResist	1	8978	8979			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2439	structureHPMultiplyOnline	1	494	495			\N	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2440	damageControlShieldAndArmorResistAndStructureHP	4	8980	8981			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2441	gangIceHarvestingDurationBonus	1	8984	8985	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2444	minerCpuUsageMultiplyPercent2	0	8996	8997	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2445	iceMinerCpuUsagePercent	0	8998	8999	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2447	miningUpgradeCPUPenaltyReductionModulesRequiringMiningUpgrade2	0	9002	9003	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2449	eliteeliteBonusCommandShipDroneBay1	0	9006	9007	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2450	cpuPenaltyToDamageControl	0	9012	9013	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2451	commandShipSkillMultiplier1	0	9016	9017	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2452	commandShipSkillMultiplier2	0	9019	9020	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2453	eliteBonusCommandShipLaserOptimalCS1FIXED	0	9021	9022	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2454	shipBonusMiningDroneAmountPercentGC2	0	9023	9024	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2455	vanHelsing	1	9025	9026	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Van Helsing	0	0	0	0	\N	\N	\N	\N	\N
2456	miningUpgradeCPUPenaltyReductionModulesRequiringMiningUpgradePercent	0	9029	9030	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2458	gangMiningDroneYieldBonus	1	9035	9036	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2459	shipBonusArmorResistEmAB	0	9037	9038	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2460	shipBonusArmorResistExplosiveAB	0	9039	9040	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2461	shipBonusArmorResistKineticAB	0	9041	9042	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2462	shipBonusArmorResistThermalAB	0	9043	9044	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2463	shipBonusArmorResistKineticAndThermalAB	0	9045	9046			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2464	shipBonusArmorResistEmAndExplosiveAB	0	9047	9048			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2465	shipBonusArmorResistAB	0	9049	9050			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2466	shipBonusHybridDamageCB2	0	9051	9052	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2467	shipLaserDamageBonusBC2	0	9053	9054	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2468	shipHeavyLauncherROFBC1	0	9055	9056	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2469	shipAssaultLauncherROFBC1	0	9057	9058	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2471	shipArmorRepairingBC1	0	9067	9068	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2473	shipBonusDroneDamageMultiplierBC1	0	9071	9072	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2474	shipBonusDroneHitpointsShieldCapacityBC1	0	9073	9074	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2475	shipBonusDroneHitpointsArmorHPBC1	0	9075	9076	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2476	shipBonusDroneHitpointsStructureBC1	0	9077	9078	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2477	shipBonusDroneHitpointsShieldArmorBC1	0	9079	9080			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2478	shipBonusDroneHitpointsBC1	0	9081	9082			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2479	iceHarvestCycleTimeModulesRequiringIceHarvestingOnline	4	5165	5166	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2480	decreaseTargetSpeedForStructures	2	3489	3491		effects.ModifyTargetSpeed	\N	1	0	73	\N	6	54	\N	0	1	Decrease Target Speed	0	0	0	0	\N	\N	\N	\N	\N
2481	warpScrambleForStructure	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	505	\N	6	103	\N	0	1	Warp Scramble	0	0	0	0	1	\N	504	\N	\N
2482	shipBonusSiegeLauncherROFMB1	0	9083	9084	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2483	shipBonusCruiseLauncherROFMB1	0	9085	9086	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2484	gangMiningCrystalYieldMultiplierBonusGangGroup	1	9089	9090	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2485	implantArmorHpBonus2	0	9093	9094	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2486	armorTankingGang2	0	9095	9096	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2487	skirmishWarfareVelocityBonus2	0	9099	9100	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2488	implantVelocityBonus2	0	9101	9102	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2489	shipTrackingLinkRange1Fixed	0	9103	9104	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	shipTrackinshipTrackingLinkRange1FixedgLinkRange1	0	0	0	0	\N	\N	\N	\N	\N
2490	shipTrackingLinkRange2Group	0	9105	9106	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2491	ewSkillEcmBurstRangeBonus	0	9112	9113	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2492	ewSkillEcmBurstCapNeedBonus	0	9116	9117	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	\N	\N	\N	\N
2493	gangMiningMiningAmountBonus	1	9118	9119	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2494	eliteBonusCommandShipsMissilePrecisionCS2	0	9122	9123	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2496	eliteReconBonusHeavyLauncherROF1	0	8509	8510	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2497	setLockedTarget	1	9127	9128	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	None	\N	\N	\N
2498	setScanResolution	1	9130	9131	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2499	setMaxTargettingRange	1	9133	9134	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	None	\N	\N	\N
2500	setMaxTargetsTargetRange	1	9135	9136			\N	0	0	73	\N	6	\N	\N	0	1		0	0	0	0	\N	None	\N	\N	\N
2501	targetOverride	1	9137	9138			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2502	shipLauncherRofBonusMB1	0	9139	9140	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2503	shipHTTrackingBonusGB2	0	9143	9144	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2504	shipBonusHybridTrackingGF2	0	4766	4767	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2505	eliteBonusAssaultShipsMissileKineticDamage1	0	9146	9147	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1		0	0	0	0	\N	None	\N	\N	\N
2506	eliteBonusAssaultShipMaxVelocityBonus1	0	9148	9149	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2507	droneControlUnitCpuNeedBonus	0	9151	9152	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2508	gangMiningLaserDurationBonus	1	9155	9156	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2509	shipMWDCapBonusGB2	0	9161	9162	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2510	shieldCapacityBonusBoosterEffectChance2	0	2472	2473	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1090
2511	turretOptimalBonusBoosterEffectChance4	0	1790	1791	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1092
2512	missileVelocityBonusBoosterEffectChance5	0	6861	6862	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1093
2513	capacitorCapacityBonusBoosterEffectChance1	0	8961	8962	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1089
2514	shieldBoostAmplifierCapitalShieldsAndShieldOpPassive	0	6717	6718			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2515	targetNavigationPredictionBoosterEffectChance5	0	6278	6279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1093
2516	maxVelocityBonusBoosterEffectChance1	0	2248	2249	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1089
2517	shieldBoostBonusBoosterEffectChance2	0	6717	6718			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1090
2518	armorHPBonusBoosterEffectChance3	0	1691	1692	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1091
2519	turretTrackingBonusBoosterEffectChance4	0	1786	1787	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1092
2520	explosionCloudBonusBoosterEffectChance5	0	6000	6001			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1093
2521	armorRepairAmountBonusBoosterEffectChance3	0	9164	9165	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2522	turretFalloffBonusBoosterEffectChance4	0	1810	1811	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1092
2523	armorRepairAmountBonusPassive	0	9164	9165	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2524	hybridTurretTrackingBonusPassiveTrackingSpeedMultiplier	0	9168	9169	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2525	shipBonusShieldBoosterMB1	0	9173	9174	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2527	displayCapacitorCapacityBonus	0	9182	9183	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2529	displayShieldBoostMultiplier	0	9190	9191	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2531	displayShieldCapacityBonus	0	9198	9199	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2533	displayAoeVelocityBonus	0	9206	9207	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2535	displayRangeSkillBonus	0	9214	9215	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2537	shieldCapacityPenaltyPostPercentBoosterAttribute1	0	9224	9225	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2538	setDisplayShieldCapacityBonusWithBoosterAttribute1	0	9228	9229	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2539	boosterShieldCapacityPenaltyAttributeSlot1	0	9230	9231			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1099
2540	capacitorCapacityPenaltyBoosterAttribute2	0	9234	9235	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2541	setDisplayCapacitorCapacityBonusWithBoosterAttribute2	0	9238	9239	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2542	boosterCapacitorCapacityPenaltyAttributeSlot2	0	9240	9241			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1100
2543	turretOptimalRangePenaltyBoosterAttribute4	0	9244	9245	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2544	setDisplayRangeSkillBonusWithBoosterAttribute4	0	9248	9249	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2545	boosterOptimalRangePenaltyAttributeSlot4	0	9250	9251			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1089
2546	explosionVelocityPenaltyBoosterAttribute5	0	9254	9255	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2547	displayAoeVelocityBonusWithBoosterAttribute5	0	9258	9259	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2548	boosterExplosionVelocityPenaltyAttributeSlot5	0	9260	9261			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	1093
\.


--
-- Name: dgmEffects dgmEffects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dgmEffects"
    ADD CONSTRAINT "dgmEffects_pkey" PRIMARY KEY ("effectID");


--
-- PostgreSQL database dump complete
--

\unrestrict 8T27MLJ1whzAut7mz2Rv8cDI7D2rsKiLYPblSDXm4A0uYCczYebx51UwVYuUbY2

