--
-- PostgreSQL database dump
--

\restrict hPQ3UaGKmMLSzm2LilTrSkw1diGhdxdTSPAOpyGP6PX3Z4LoHYHS1aPIJT8tL0o

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrNotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrNotes" (
    "characterID" integer NOT NULL,
    "itemID" integer NOT NULL,
    note text DEFAULT ''::text NOT NULL
);


--
-- Name: TABLE "chrNotes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."chrNotes" IS 'Per-character private note about another character. Serves character.GetNote(itemID) / SetNote(itemID, text). GetNote returns a PLAIN STRING (infosvc.py:1999 SetValue(oldnotes); notepad.py:434), and '''' is the correct empty answer (infosvc.py:1996).';


--
-- Name: COLUMN "chrNotes"."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrNotes"."characterID" IS 'INFERRED as a column: the author. GetNote/SetNote take no author argument, so the server scopes on session.charid.';


--
-- Name: COLUMN "chrNotes"."itemID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrNotes"."itemID" IS 'PROVEN: the sole argument of GetNote (infosvc.py:1998, notepad.py:426 passes a charid) and the 1st of SetNote (infosvc.py:2178). The SUBJECT of the note.';


--
-- Name: COLUMN "chrNotes".note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrNotes".note IS 'PROVEN: the 2nd argument of SetNote, truncated client-side to 5000 chars (infosvc.py:2178 text[:5000]); returned verbatim by GetNote. Clearing sends '''' (infosvc.py:2180), so store the empty string rather than deleting the row if that is simpler.';


--
-- Data for Name: chrNotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrNotes" ("characterID", "itemID", note) FROM stdin;
\.


--
-- Name: chrNotes chrNotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrNotes"
    ADD CONSTRAINT "chrNotes_pkey" PRIMARY KEY ("characterID", "itemID");


--
-- PostgreSQL database dump complete
--

\unrestrict hPQ3UaGKmMLSzm2LilTrSkw1diGhdxdTSPAOpyGP6PX3Z4LoHYHS1aPIJT8tL0o

