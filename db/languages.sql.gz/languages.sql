--
-- PostgreSQL database dump
--

\restrict mpJ8Xju9i9iR6cIV4A0EzYWrlLgqFMxSVhVVp8wxBnJgZ3muPm7asiUYmIyXTXD

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.languages (
    "languageID" text DEFAULT ''::text NOT NULL,
    "languageName" text DEFAULT ''::text NOT NULL,
    "translatedLanguageName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.languages ("languageID", "languageName", "translatedLanguageName") FROM stdin;
DE	German	Deutsch
EN	English	English
ES	Spanish	Español
FR	French	Français
IS	Icelandic	Ã^Íslenska
IT	Italian	Italiano
JA	Japanese	åe,g^Þ^Ê
KO	Korean	Õm­´Å
PT	Portuguese	Português
RU	Russian	 ^DC^DA^DA^D:^D8^D9^D
ZH	Chinese	-N^Çe
\.


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY ("languageID");


--
-- PostgreSQL database dump complete
--

\unrestrict mpJ8Xju9i9iR6cIV4A0EzYWrlLgqFMxSVhVVp8wxBnJgZ3muPm7asiUYmIyXTXD

