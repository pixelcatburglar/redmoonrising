--
-- PostgreSQL database dump
--

\restrict cerPWbm9dPO82wXQd4RjQS32xo7LQOfzkz6G5BDIsbLypW6BjtVS1lggRMhkpJE

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpApplications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpApplications" (
    "corporationID" integer NOT NULL,
    "characterID" integer NOT NULL,
    "applicationText" text DEFAULT ''::text NOT NULL,
    "applicationDateTime" bigint DEFAULT 0 NOT NULL,
    status smallint DEFAULT 0 NOT NULL,
    "corporationText" text DEFAULT ''::text NOT NULL,
    deleted smallint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "crpApplications"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."crpApplications" IS 'Membership applications. Serves corpRegistry.GetApplications / GetMyApplications / InsertApplication / UpdateApplication / UpdateApplicationOffer / DeleteApplication. Push notification: OnCorporationApplicationChanged(applicantID, corporationID, change) (bco_applications.py:28).';


--
-- Name: COLUMN "crpApplications"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications"."corporationID" IS 'PROVEN: bco_applications.py:69 key = (application.corporationID, application.characterID); 1st arg of InsertApplication/UpdateApplication/DeleteApplication.';


--
-- Name: COLUMN "crpApplications"."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications"."characterID" IS 'PROVEN: bco_applications.py:69/106; 1st arg of UpdateApplicationOffer (bco_applications.py:164).';


--
-- Name: COLUMN "crpApplications"."applicationText"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications"."applicationText" IS 'PROVEN: 2nd arg of InsertApplication/UpdateApplication (bco_applications.py:157/161); the corp UI shows it in a read-only textedit.';


--
-- Name: COLUMN "crpApplications"."applicationDateTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications"."applicationDateTime" IS 'Windows FILETIME. PROVEN: corp_ui_applications.py:310 and :318 do util.FmtDate(application.applicationDateTime); also an optional argument of UpdateApplication (bco_applications.py:160).';


--
-- Name: COLUMN "crpApplications".status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications".status IS 'PROVEN: bco_applications.py:88 and :127 filter on application.status; 3rd arg of UpdateApplication. Values are the const.crpApplication* constants. NOTE the ALLIANCE application table calls the same concept "state", not "status" (all_ui_applications.py:121) -- do not unify the two names.';


--
-- Name: COLUMN "crpApplications"."corporationText"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications"."corporationText" IS 'INFERRED. The corp''s reply/offer text; UpdateApplicationOffer carries an applicationText from the corp side (bco_applications.py:164) and it must not overwrite the applicant''s own text.';


--
-- Name: COLUMN "crpApplications".deleted; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."crpApplications".deleted IS 'INFERRED 0/1 soft-delete. DeleteApplication (bco_applications.py:137) removes the row from the client cache and the client then fabricates a removal notification; a soft delete keeps the audit trail.';


--
-- Data for Name: crpApplications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpApplications" ("corporationID", "characterID", "applicationText", "applicationDateTime", status, "corporationText", deleted) FROM stdin;
\.


--
-- Name: crpApplications crpApplications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpApplications"
    ADD CONSTRAINT "crpApplications_pkey" PRIMARY KEY ("corporationID", "characterID");


--
-- Name: crpapplications_char_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crpapplications_char_ix ON public."crpApplications" USING btree ("characterID");


--
-- Name: INDEX crpapplications_char_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.crpapplications_char_ix IS 'GetMyApplications: the PK is (corporationID, characterID), so the character-first direction needs its own index.';


--
-- PostgreSQL database dump complete
--

\unrestrict cerPWbm9dPO82wXQd4RjQS32xo7LQOfzkz6G5BDIsbLypW6BjtVS1lggRMhkpJE

