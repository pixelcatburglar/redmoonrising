--
-- PostgreSQL database dump
--

\restrict 6c1sPmMNyBmiKbCeIgOHCj5v6dUpDj0qdNfJeLtnALBRoGTue6b1EhZUx4mWg6v

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ramAssemblyLineTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ramAssemblyLineTypes" (
    "assemblyLineTypeID" integer DEFAULT 0 NOT NULL,
    "assemblyLineTypeName" text,
    description text,
    "baseTimeMultiplier" double precision,
    "baseMaterialMultiplier" double precision,
    volume double precision,
    "activityID" integer,
    "minCostPerHour" double precision
);


--
-- Data for Name: ramAssemblyLineTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ramAssemblyLineTypes" ("assemblyLineTypeID", "assemblyLineTypeName", description, "baseTimeMultiplier", "baseMaterialMultiplier", volume, "activityID", "minCostPerHour") FROM stdin;
2	Lab Slot	Copying	1	1	1	5	\N
3	Reverse Engineering	Reverse Engineering	1	1	1	7	\N
5	STATION copying	STATION copying	1	1	1	5	8.333333
6	STATION manufacturing	STATION manufacturing	1	1	1	1	333
7	STATION material productivity	STATION material productivity	1	1	1	4	8.333333
8	STATION productivity time	STATION productivity time	1	1	1	3	8.333333
10	Capital Ship Assembly	Capital Ship Assembly	1	1	1	1	\N
11	ME Research	ME Research	1	1	1	4	\N
12	PE Research	PE Research	1	1	1	3	\N
13	Manufacturing	Manufacturing	1	1	1	1	\N
17	Small Ship Assembly Array	Small Ship Assembly Array	0.75	1	1	1	\N
18	Advanced Small Ship Assembly Array	Advanced Small Ship Assembly Array	0.75	1.1	1	1	\N
19	Medium Ship Assembly Array	Medium Ship Assembly Array	0.75	1	1	1	\N
20	Advanced Medium Ship Assembly Array	Advanced Medium Ship Assembly Array	0.75	1.1	1	1	\N
21	Large Ship Assembly Array	Large Ship Assembly Array	0.75	1	1	1	\N
22	Advanced Large Ship Assembly Array	Advanced Large Ship Assembly Array	0.75	1.1	1	1	\N
23	Rapid Equipment Assembly Array	Rapid Equipment Assembly Array	0.65	1.2	1	1	\N
24	Efficient Equipment Assembly Array	Efficient Equipment Assembly Array	0.8	1	1	1	\N
25	Ammunition Assembly Array	Ammunition Assembly Array	0.75	1	1	1	\N
26	Drone Assembly Array	Drone Assembly Array	0.75	1	1	1	\N
27	Component Assembly Array	Component Assembly Array	0.75	1.1	1	1	\N
28	Mobile Laboratory ME	Mobile Laboratory ME	0.75	1	1	4	\N
29	Mobile Laboratory PE	Mobile Laboratory PE	0.75	1	1	3	\N
30	Mobile Laboratory Copying	Mobile Laboratory Copying	0.75	1	1	5	\N
31	Amarr Outpost Manufacturing	Amarr Outpost Manufacturing	0.7	1	1	1	\N
32	Caldari Outpost ME Research	Caldari Outpost ME Research	0.7	0.95	1	4	\N
33	Caldari Outpost PE Research	Caldari Outpost PE Research	0.7	0.95	1	3	\N
34	Caldari Outpost Copying	Caldari Outpost Copying	0.7	0.95	1	5	\N
35	STATION 0.5+ Manufacturing	STATION 0.5+ Manufacturing	1	1	1	1	333
36	Invention		1	1	1	8	\N
37	Booster Manufacturing	Booster Manufacturing	1	1	1	1	\N
38	STATION Invention	STATION Invention	1	1	1	8	\N
39	Mobile Laboratory Invention	Mobile Laboratory Invention	0.5	1	1	8	\N
40	Caldari Outpost Invention	Caldari Outpost Invention	1	1	1	8	\N
43	Amarr Outpost Factory1 Tier1	Amarr Outpost w/ Type 1 Tier 1	0.7	1	1	1	\N
45	Amarr Outpost Factory1(2) Tier 1(1)	Amarr Outpost w/ Type 1 Tier 1, Type 2 Tier 1	0.7	1	1	1	\N
46	Minmatar Outpost Factory1 Tier1		1	1	1	1	\N
47	Amarr Outpost Factory1(2) Tier 1(2)	Amarr Outpost w/ Type 1 Tier 1, Type 2 Tier 2	0.7	1	1	1	\N
48	Amarr Outpost Factory1(2) Tier 1(3)	Amarr Outpost w/ Type 1 Tier 1, Type 2 Tier 3	0.7	1	1	1	\N
52	Minmatar Outpost Factory1 Tier2		1	1	1	1	\N
54	Amarr Outpost Factory1 Tier2	Amarr Outpost w/ Type 1 Tier 2	0.7	1	1	1	\N
56	Amarr Outpost Factory1(2) Tier2(1)	Amarr Outpost w/ Type 1 Tier 2, Type 2 Tier 1	0.7	1	1	1	\N
57	Amarr Outpost Factory1(2) Tier2(2)	Amarr Outpost w/ Type 1 Tier 2, Type 2 Tier 2	0.7	1	1	1	\N
58	Amarr Outpost Factory1(2) Tier2(3)	Amarr Outpost w/ Type 1 Tier 2, Type 2 Tier 3	0.7	1	1	1	\N
59	Amarr Outpost Factory1 Tier 3	Amarr Outpost w/ Type 1 Tier 3	0.7	1	1	1	\N
60	Amarr Outpost Factory1(2) Tier3(1)	Amarr Outpost w/ Type 1 Tier 3, Type 2 Tier 1	0.7	1	1	1	\N
61	Amarr Outpost Factory1(2) Tier3(2)	Amarr Outpost w/ Type 1 Tier 3, Type 2 Tier 2	0.7	1	1	1	\N
62	Minmatar Outpost Factory1 Tier3		1	1	1	1	\N
63	Minmatar Oupost Research ME Tier1		0.8	1	1	4	\N
66	Amarr Outpost Factory2 Tier1	Amarr Outpost w/ Type 2 Tier 1	0.7	1	1	1	\N
67	Amarr Outpost Factory2 Tier 2	Amarr Outpost w/ Type 2 Tier 2	0.7	1	1	1	\N
68	Amarr Outpost Factory2 Tier3	Amarr Outpost w/ Type 2 Tier 3	0.7	1	1	1	\N
69	Amarr Outpost Research ME Tier 1	Amarr Outpost Tier 1 ME	1	1	1	4	\N
70	Caldari Outpost Factory Tier1	Caldari Outpost Tier 1 Factory	1	1	1	1	\N
71	Amarr Outpost Research PE Tier 1		0.8	1	1	3	\N
72	Amarr Outpost Research Copy Tier1		1	1	1	5	\N
73	Amarr Outpost Research ME Tier2		1	1	1	4	\N
74	Amarr Outpost Research PE Tier2		0.6	1	1	3	\N
75	Amarr Outpost Research Copy Tier2		1	1	1	5	\N
76	Amarr Outpost Research ME Tier3		1	1	1	4	\N
77	Amarr Outpost Research PE Tier3		0.4	1	1	3	\N
78	Amarr Outpost Research Copy Tier3		1	1	1	5	\N
79	Caldari Outpost Factory Tier2		1	1	1	1	\N
80	Caldari Outpost Factory Tier3		1	1	1	1	\N
81	Caldari Outpost Research1 ME Tier1		0.7	0.95	1	4	\N
82	Caldari Outpost Research1 PE Tier1		0.7	0.95	1	3	\N
83	Caldari Outpost Research1 Copy Tier1		0.7	0.95	1	5	\N
84	Caldari Outpost Research1 ME Tier2		0.6	0.95	1	4	\N
85	Caldari Outpost Research1 PE Tier2		0.6	0.95	1	3	\N
86	Caldari Outpost Research1 Copy Tier2		0.6	0.95	1	5	\N
87	Caldari Outpost Research1 ME Tier3		0.5	0.95	1	4	\N
88	Caldari Outpost Research1 PE Tier3		0.5	0.95	1	3	\N
89	Caldari Outpost Research1 Copy Tier3		0.5	0.95	1	5	\N
90	Caldari Outpost Research2 Tier1		0.8	1	1	8	\N
91	Caldari Outpost Research2 Tier2		0.6	1	1	8	\N
92	Caldari Outpost Research2 Tier3		0.4	1	1	8	\N
93	Gallente Outpost Factory1 Tier1		1	1	1	1	\N
94	Gallente Outpost Factory1(2) Tier1(1)		1	1	1	1	\N
95	Gallente Outpost Factory1(2) Tier1(2)		1	1	1	1	\N
96	Gallente Outpost Factory 1(2) Tier1(3)		1	1	1	1	\N
98	Gallente Outpost Factory1(2) Tier2(1)		1	1	1	1	\N
99	Gallente Outpost Factory1(2) Tier2(2)		1	1	1	1	\N
100	Gallente Outpost Factory1(2) Tier2(3)		1	1	1	1	\N
102	Gallente Outpost Factory1(2) Tier3(1)		1	1	1	1	\N
103	Gallente Outpost Factory1(2) Tier3(2)		1	1	1	1	\N
104	Gallente Outpost Factory2 Tier1		1	1	1	1	\N
105	Gallente Outpost Factory2 Tier2		1	1	1	1	\N
106	Gallente Outpost Factory2 Tier3		1	1	1	1	\N
107	Gallente Outpost Research ME Tier1		1	1	1	4	\N
108	Gallente Outpost Research PE Tier1		1	1	1	3	\N
109	Gallente Outpost Research Copy Tier1		0.8	1	1	5	\N
110	Gallente Outpost Research ME Tier2		1	1	1	4	\N
111	Gallente Outpost Research PE Tier2		1	1	1	3	\N
112	Gallente Outpost Research Copy Tier2		0.6	1	1	5	\N
113	Gallente Outpost Research ME Tier3		1	1	1	4	\N
114	Gallente Outpost Research PE Tier3		1	1	1	3	\N
115	Gallente Outpost Research Copy Tier3		0.4	1	1	5	\N
116	Minmatar Outpost Factory1(2) Tier1(1)		1	1	1	1	\N
117	Minmatar Outpost Factory1(2) Tier1(2)		1	1	1	1	\N
118	Minmatar Outpost Factory1(2) Tier1(3)		1	1	1	1	\N
119	Minmatar Outpost Factory1(2) Tier2(1)		1	1	1	1	\N
120	Minmatar Outpost Factory1(2) Tier2(2)		1	1	1	1	\N
121	Minmatar Outpost Factory1(2) Tier2(3)		1	1	1	1	\N
122	Minmatar Outpost Factory1(2) Tier3(1)		1	1	1	1	\N
123	Minmatar Outpost Factory1(2) Tier3(2)		1	1	1	1	\N
124	Minmatar Outpost Factory2 Tier1		1	1	1	1	\N
125	Minmatar Outpost Factory2 Tier2		1	1	1	1	\N
126	Minmatar Outpost Factory2 Tier3		1	1	1	1	\N
127	Minmatar Outpost Research PE Tier1		1	1	1	3	\N
128	Minmatar Outpost Research Copy Tier1		1	1	1	5	\N
129	Minmatar Outpost Research ME Tier2		0.6	1	1	4	\N
130	Minmatar Outpost Research PE Tier2		1	1	1	3	\N
131	Minmatar Outpost Research Copy Tier2		1	1	1	5	\N
132	Minmatar Outpost Research ME Tier3		0.4	1	1	4	\N
133	Minmatar Outpost Research PE Tier3		1	1	1	3	\N
134	Minmatar Outpost Research Copy Tier3		1	1	1	5	\N
136	Gallente Outpost Factory1 Tier3		1	1	1	1	\N
137	Gallente Outpost Factory1 Tier2		1	1	1	1	\N
138	Minmatar Outpost Research ME Tier1		0.8	1	1	4	\N
145	Ore Capital Ship	ore cap ship asteroid line	1	1	1	1	\N
146	Efficient Mobile Lab Copy	efficient mobile lab copy	0.65	1	1	5	\N
147	Efficient Mobile Lab ME	efficient mobile lab ME	0.75	1	1	4	\N
148	Efficient Mobile Lab PE	efficient mobile lab TE	0.85	1	1	3	\N
149	Efficient Mobile Lab invention	efficient mobile lab invention	0.5	1	1	8	\N
150	Ore Cap Ship Manufacturing	ore cap ship manufacture lines	0.8	1	1	1	\N
\.


--
-- Name: ramAssemblyLineTypes ramAssemblyLineTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ramAssemblyLineTypes"
    ADD CONSTRAINT "ramAssemblyLineTypes_pkey" PRIMARY KEY ("assemblyLineTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict 6c1sPmMNyBmiKbCeIgOHCj5v6dUpDj0qdNfJeLtnALBRoGTue6b1EhZUx4mWg6v

