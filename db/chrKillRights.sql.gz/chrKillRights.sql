--
-- PostgreSQL database dump
--

\restrict Rzk8VuAs9imMjA5K0tmSuLbkpnpczF4T1PVu08DBPIlAGyoKYjeL6NBptnYYmFJ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrKillRights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrKillRights" (
    "fromID" integer NOT NULL,
    "toID" integer NOT NULL,
    "whenTimestamp" bigint NOT NULL
);


--
-- Name: TABLE "chrKillRights"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."chrKillRights" IS 'Who may legally kill whom. Serves standing2.GetMyKillRights, which returns a 2-tuple of plain dicts keyed by the OTHER party (consider.py:206, :52-58). Push: OnKillRightChange(set, whenTimestamp, fromID, toID) (consider.py:48).';


--
-- Name: COLUMN "chrKillRights"."fromID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrKillRights"."fromID" IS 'The holder of the right. PROVEN: consider.py:51 `if fromID == session.charid` fills killRightsCache; :59-61 removes it.';


--
-- Name: COLUMN "chrKillRights"."toID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrKillRights"."toID" IS 'The killable party. PROVEN: consider.py:52-54 killRightsCache[toID] = whenTimestamp.';


--
-- Name: COLUMN "chrKillRights"."whenTimestamp"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrKillRights"."whenTimestamp" IS 'Windows FILETIME the right expires (or was granted). PROVEN: it is the dict VALUE -- consider.py:54/:58 -- and reaches the UI as ''killTime'' (infosvc.py:1620).';


--
-- Data for Name: chrKillRights; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrKillRights" ("fromID", "toID", "whenTimestamp") FROM stdin;
\.


--
-- Name: chrKillRights chrKillRights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrKillRights"
    ADD CONSTRAINT "chrKillRights_pkey" PRIMARY KEY ("fromID", "toID");


--
-- Name: chrkillrights_to_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chrkillrights_to_ix ON public."chrKillRights" USING btree ("toID");


--
-- Name: INDEX chrkillrights_to_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.chrkillrights_to_ix IS 'GetMyKillRights returns BOTH dicts, so both directions are queried (consider.py:206).';


--
-- PostgreSQL database dump complete
--

\unrestrict Rzk8VuAs9imMjA5K0tmSuLbkpnpczF4T1PVu08DBPIlAGyoKYjeL6NBptnYYmFJ

