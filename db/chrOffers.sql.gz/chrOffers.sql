--
-- PostgreSQL database dump
--

\restrict hTVOpe773YI2ZJMaGeRki7zDyg1oTueOiNaSb8bDFkhKk19ufJpyu5NFbL32d6J

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrOffers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrOffers" (
    "characterID" integer DEFAULT 0 NOT NULL,
    "offerID" integer DEFAULT 0 NOT NULL,
    "expirationTime" bigint DEFAULT 0 NOT NULL
);


--
-- Name: COLUMN "chrOffers"."expirationTime"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrOffers"."expirationTime" IS 'Windows FILETIME, tuple position 3 of a GetMyJournalDetails offer entry (journal.py:312). Same falsy-means-undefined rule as chrMissionState (journal.py:322).';


--
-- Data for Name: chrOffers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrOffers" ("characterID", "offerID", "expirationTime") FROM stdin;
\.


--
-- Name: chrOffers chrOffers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrOffers"
    ADD CONSTRAINT "chrOffers_pkey" PRIMARY KEY ("characterID", "offerID");


--
-- Name: chrOffers_offerID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chrOffers_offerID_idx" ON public."chrOffers" USING btree ("offerID");


--
-- PostgreSQL database dump complete
--

\unrestrict hTVOpe773YI2ZJMaGeRki7zDyg1oTueOiNaSb8bDFkhKk19ufJpyu5NFbL32d6J

