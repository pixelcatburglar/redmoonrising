--
-- PostgreSQL database dump
--

\restrict VfLaF8SNM9VDwFeHCqYJ9mM8BxPKp9bb7a1Gz1BFBFUbyLiy75h06lg1xxkcVXm

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpOffices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpOffices" (
    "corporationID" integer DEFAULT 0 NOT NULL,
    "stationID" integer DEFAULT 0 NOT NULL,
    "itemID" integer DEFAULT 0 NOT NULL,
    "typeID" integer DEFAULT 0 NOT NULL,
    "officeFolderID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: crpOffices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpOffices" ("corporationID", "stationID", "itemID", "typeID", "officeFolderID") FROM stdin;
\.


--
-- Name: crpOffices crpOffices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpOffices"
    ADD CONSTRAINT "crpOffices_pkey" PRIMARY KEY ("corporationID", "officeFolderID");


--
-- Name: crpOffices_itemID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "crpOffices_itemID_idx" ON public."crpOffices" USING btree ("itemID");


--
-- Name: crpoffices_station_ix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX crpoffices_station_ix ON public."crpOffices" USING btree ("stationID");


--
-- Name: INDEX crpoffices_station_ix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.crpoffices_station_ix IS 'corpRegistry.GetCorporationsWithOfficesAtStation (base_corporation.py:13) and the office-folder walk in invCache.GetStationIDOfficeFolderIDOfficeIDOfItem.';


--
-- PostgreSQL database dump complete
--

\unrestrict VfLaF8SNM9VDwFeHCqYJ9mM8BxPKp9bb7a1Gz1BFBFUbyLiy75h06lg1xxkcVXm

