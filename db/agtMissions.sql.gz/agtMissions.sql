--
-- PostgreSQL database dump
--

\restrict U5cFTU6MTSRmDbkG9u6NAkAyZOYTL60xzSworNZnxA41zbgNqA6mVqsTfbFOr65

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agtMissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."agtMissions" (
    "missionID" integer NOT NULL,
    "missionName" text DEFAULT ''::text NOT NULL,
    "missionLevel" smallint DEFAULT 0 NOT NULL,
    "missionTypeID" integer DEFAULT 0 NOT NULL,
    "importantMission" smallint DEFAULT 0 NOT NULL
);


--
-- Data for Name: agtMissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."agtMissions" ("missionID", "missionName", "missionLevel", "missionTypeID", "importantMission") FROM stdin;
\.


--
-- Name: agtMissions agtMissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."agtMissions"
    ADD CONSTRAINT "agtMissions_pkey" PRIMARY KEY ("missionID");


--
-- Name: agtMissions_missionLevel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtMissions_missionLevel_idx" ON public."agtMissions" USING btree ("missionLevel");


--
-- Name: agtMissions_missionTypeID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agtMissions_missionTypeID_idx" ON public."agtMissions" USING btree ("missionTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict U5cFTU6MTSRmDbkG9u6NAkAyZOYTL60xzSworNZnxA41zbgNqA6mVqsTfbFOr65

