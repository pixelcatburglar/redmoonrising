--
-- PostgreSQL database dump
--

\restrict 0yUolBnsM8fojlGI7GAvdOMy1SRjzpDHsY6Nf7pbQyBAE7aV9wwzeKGec3T2zr8

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invMetaGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invMetaGroups" (
    "metaGroupID" integer NOT NULL,
    "metaGroupName" text,
    description text,
    "graphicID" integer
);


--
-- Data for Name: invMetaGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invMetaGroups" ("metaGroupID", "metaGroupName", description, "graphicID") FROM stdin;
1	Tech I		\N
2	Tech II		\N
3	Storyline		\N
4	Faction		\N
5	Officer		\N
6	Deadspace	Modules found in deadspace.	\N
7	Frigates		\N
8	Elite Frigates		\N
9	Commander Frigates		\N
10	Destroyer		\N
11	Cruiser		\N
12	Elite Cruiser		\N
13	Commander Cruiser		\N
\.


--
-- Name: invMetaGroups invMetaGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invMetaGroups"
    ADD CONSTRAINT "invMetaGroups_pkey" PRIMARY KEY ("metaGroupID");


--
-- PostgreSQL database dump complete
--

\unrestrict 0yUolBnsM8fojlGI7GAvdOMy1SRjzpDHsY6Nf7pbQyBAE7aV9wwzeKGec3T2zr8

