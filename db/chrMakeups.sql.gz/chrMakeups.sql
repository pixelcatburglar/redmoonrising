--
-- PostgreSQL database dump
--

\restrict DSm6dnszyzgPgLvipSsKsUnS6E5H7FrqwTHlCQNJIxv1OVU6OZbCfEQUITugpEb

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrMakeups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrMakeups" (
    "makeupID" integer DEFAULT 0 NOT NULL,
    "makeupName" text DEFAULT ''::text NOT NULL
);


--
-- Data for Name: chrMakeups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrMakeups" ("makeupID", "makeupName") FROM stdin;
1	1
2	10
3	11
4	2
5	3
6	4
7	5
8	7
9	9
10	Black jester
11	Dark jester
12	Feline
13	Mercury
14	Mercury black
15	Metal feline
16	None
17	Redmetal feline
18	Silver stripes
19	Subtle bronze
20	6
21	8
22	Blue shade
23	Crimson pins
24	Decorative grand red
25	Decorative red
26	Golden vail
27	Mad purple
28	Mad red
29	Mad rust
30	rust
31	Silver feline
32	Silvershade
33	Subtle shade
34	Velvet
35	13
36	-none
37	12
38	14
39	15
40	20
41	21
42	22
43	23
44	Black beams
45	Dark mercury
46	Green beams
47	16
48	17
49	18
50	19
51	Green beams
52	Aqua stripes
53	Blue shine
54	Blue stripes
55	Golden stripes
56	Greenshade
57	Purple metal
58	Red metal stripes
59	Red shade
60	Brownl high
61	Dark high
62	Dark lashes
63	Eyeliner
64	Metal high
65	Strong feline
66	Subtle feline
67	Subtle flame
68	Dark overcast
69	Subtle green
70	Shade
71	Heavy bronze
72	Dark moss
73	Dark feline
74	BlueShade
75	Black feline
76	Brown lashes
\.


--
-- Name: chrMakeups chrMakeups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrMakeups"
    ADD CONSTRAINT "chrMakeups_pkey" PRIMARY KEY ("makeupID");


--
-- PostgreSQL database dump complete
--

\unrestrict DSm6dnszyzgPgLvipSsKsUnS6E5H7FrqwTHlCQNJIxv1OVU6OZbCfEQUITugpEb

