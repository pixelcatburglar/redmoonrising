--
-- PostgreSQL database dump
--

\restrict bugmtboAdUmQSfnvzYCmVtSIQoQuglrJYRIcl9lln4L2ieugqm2e7xMa86eFhpz

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: staServices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."staServices" (
    "serviceID" integer NOT NULL,
    "serviceName" text,
    description text
);


--
-- Data for Name: staServices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."staServices" ("serviceID", "serviceName", description) FROM stdin;
1	Bounty Missions	
2	Assassination Missions	
4	Courier Missions	
8	Interbus	
16	Reprocessing Plant	
32	Refinery	
64	Market	
128	Black Market	
256	Stock Exchange	
512	Cloning	
1024	Surgery	
2048	DNA Therapy	
4096	Repair Facilities	
8192	Factory	
16384	Laboratory	
32768	Gambling	
65536	Fitting	
131072	Paintshop	
262144	News	
524288	Storage	
1048576	Insurance	Used to buy insurance for ships.
2097152	Docking	
4194304	Office Rental	
8388608	Jump Clone Facility	
\.


--
-- Name: staServices staServices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."staServices"
    ADD CONSTRAINT "staServices_pkey" PRIMARY KEY ("serviceID");


--
-- PostgreSQL database dump complete
--

\unrestrict bugmtboAdUmQSfnvzYCmVtSIQoQuglrJYRIcl9lln4L2ieugqm2e7xMa86eFhpz

