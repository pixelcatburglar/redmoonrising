--
-- PostgreSQL database dump
--

\restrict jr5sgnmUXfHh6oPB9a9Ol0TaZZRbfJCO6t9E4T5rEeknlkUB3meea6yW7I5Ox2k

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrAgentResearch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrAgentResearch" (
    "characterID" integer NOT NULL,
    "agentID" integer NOT NULL,
    "typeID" integer NOT NULL,
    "pointsPerDay" double precision DEFAULT 0 NOT NULL,
    points double precision DEFAULT 0 NOT NULL,
    "researchStartDate" bigint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "chrAgentResearch"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."chrAgentResearch" IS 'R&D agent research in progress. Fills slot [2] of agentMgr.GetMyJournalDetails(), whose entries are 4-tuples (agentID, typeID, ppd, points) unpacked positionally at journal.py:340. Empty is safe (journal.py:346).';


--
-- Name: COLUMN "chrAgentResearch"."characterID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentResearch"."characterID" IS 'INFERRED as a column: GetMyJournalDetails takes no arguments, so the server scopes on session.charid.';


--
-- Name: COLUMN "chrAgentResearch"."agentID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentResearch"."agentID" IS 'PROVEN, tuple position 0: journal.py:340 and the incremental-refresh test at journal.py:219 `if research[0] == agentID`. A static agtAgents.agentID (3 000 000..4 000 000).';


--
-- Name: COLUMN "chrAgentResearch"."typeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentResearch"."typeID" IS 'PROVEN, tuple position 1: journal.py:341 cfg.invtypes.Get(typeID).name under the header "field". The research field''s invTypes row.';


--
-- Name: COLUMN "chrAgentResearch"."pointsPerDay"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentResearch"."pointsPerDay" IS 'PROVEN, tuple position 3 (`ppd`): journal.py:341 renders it with ''%-2.2f'' under the header "RP/DAY". double precision -- it is a float, not an integer.';


--
-- Name: COLUMN "chrAgentResearch".points; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentResearch".points IS 'PROVEN, tuple position 2 in the tuple order but rendered 3rd: journal.py:341 ''%-2.2f'' %% points under the header "Current RP". Accumulated research points.';


--
-- Name: COLUMN "chrAgentResearch"."researchStartDate"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."chrAgentResearch"."researchStartDate" IS 'INFERRED. Windows FILETIME. Needed to accrue points lazily instead of on a tick: points_now = points + ppd * days_since(researchStartDate).';


--
-- Data for Name: chrAgentResearch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrAgentResearch" ("characterID", "agentID", "typeID", "pointsPerDay", points, "researchStartDate") FROM stdin;
\.


--
-- Name: chrAgentResearch chrAgentResearch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrAgentResearch"
    ADD CONSTRAINT "chrAgentResearch_pkey" PRIMARY KEY ("characterID", "agentID");


--
-- PostgreSQL database dump complete
--

\unrestrict jr5sgnmUXfHh6oPB9a9Ol0TaZZRbfJCO6t9E4T5rEeknlkUB3meea6yW7I5Ox2k

