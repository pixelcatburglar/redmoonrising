--
-- PostgreSQL database dump
--

\restrict 6EgTGfadM7YCcI2MAZDOqDjcnv0nJbnWy8fBgqVxm4jBxT5DnWi7rIbDExHtea0

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: killLogParticipants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."killLogParticipants" (
    "killID" bigint NOT NULL,
    "ownerID" integer NOT NULL,
    "corporationID" integer,
    "allianceID" integer,
    "shipTypeID" integer,
    "weaponTypeID" integer,
    "damageDone" double precision DEFAULT 0 NOT NULL,
    "finalBlow" smallint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "killLogParticipants"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."killLogParticipants" IS 'INFERRED, server-internal. Aggressors on a kill. Same justification as killLog; nothing on the wire depends on it.';


--
-- Name: COLUMN "killLogParticipants"."killID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."killID" IS 'INFERRED. Parent kill.';


--
-- Name: COLUMN "killLogParticipants"."ownerID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."ownerID" IS 'INFERRED. Character or NPC that did damage. This is the set that receives kill rights and standing penalties.';


--
-- Name: COLUMN "killLogParticipants"."corporationID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."corporationID" IS 'INFERRED.';


--
-- Name: COLUMN "killLogParticipants"."allianceID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."allianceID" IS 'INFERRED.';


--
-- Name: COLUMN "killLogParticipants"."shipTypeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."shipTypeID" IS 'INFERRED.';


--
-- Name: COLUMN "killLogParticipants"."weaponTypeID"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."weaponTypeID" IS 'INFERRED.';


--
-- Name: COLUMN "killLogParticipants"."damageDone"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."damageDone" IS 'INFERRED.';


--
-- Name: COLUMN "killLogParticipants"."finalBlow"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."killLogParticipants"."finalBlow" IS 'INFERRED 0/1.';


--
-- Data for Name: killLogParticipants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."killLogParticipants" ("killID", "ownerID", "corporationID", "allianceID", "shipTypeID", "weaponTypeID", "damageDone", "finalBlow") FROM stdin;
\.


--
-- Name: killLogParticipants killLogParticipants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."killLogParticipants"
    ADD CONSTRAINT "killLogParticipants_pkey" PRIMARY KEY ("killID", "ownerID");



--
-- PostgreSQL database dump complete
--

\unrestrict 6EgTGfadM7YCcI2MAZDOqDjcnv0nJbnWy8fBgqVxm4jBxT5DnWi7rIbDExHtea0

