--
-- NPC sell orders: every item in a market group, at one hub station per region
-- and at every school's starting station. Runs after the per-table dumps.
--
-- The hub is the lowest-numbered station in the region's system with the most
-- stations. The price is the type's basePrice; a type without one is priced
-- at 110% of its reprocessing materials (two levels deep, so components count),
-- and anything still unpriced (ores) at 1000 ISK per portion.
--

WITH system_size AS (
    SELECT "regionID", "solarSystemID", count(*) AS stations, min("stationID") AS first_station
      FROM public."staStations"
     GROUP BY "regionID", "solarSystemID"
),
hub AS (
    SELECT DISTINCT ON ("regionID") first_station AS "stationID"
      FROM system_size
     ORDER BY "regionID", stations DESC, "solarSystemID"
),
school AS (
    SELECT min(st."stationID") AS "stationID"
      FROM public."chrSchools" s
      JOIN public."crpNPCCorporations" n ON n."corporationID" = s."corporationID"
      JOIN public."staStations" st ON st."corporationID" = s."corporationID"
                                  AND st."solarSystemID" = n."solarSystemID"
     GROUP BY s."schoolID"
),
outlet AS (
    SELECT st."stationID", st."corporationID", st."solarSystemID", st."regionID"
      FROM public."staStations" st
     WHERE st."stationID" IN (SELECT "stationID" FROM hub UNION SELECT "stationID" FROM school)
),
material AS (
    SELECT m."typeID", m."requiredTypeID", m."quantity"::float8 / greatest(t."portionSize", 1) AS per_unit
      FROM public."TL2MaterialsForTypeWithActivity" m
      JOIN public."invTypes" t ON t."typeID" = m."typeID"
     WHERE m."activity" = 6 AND m."damagePerJob" = 1
),
price1 AS (
    SELECT t."typeID",
           coalesce(nullif(t."basePrice", 0),
                    1.1 * (SELECT sum(mt.per_unit * mi."basePrice")
                             FROM material mt JOIN public."invTypes" mi ON mi."typeID" = mt."requiredTypeID"
                            WHERE mt."typeID" = t."typeID")) AS price
      FROM public."invTypes" t
),
priced AS (
    SELECT t."typeID",
           coalesce(nullif(p.price, 0),
                    1.1 * (SELECT sum(mt.per_unit * mp.price)
                             FROM material mt JOIN price1 mp ON mp."typeID" = mt."requiredTypeID"
                            WHERE mt."typeID" = t."typeID"),
                    1000.0 / greatest(t."portionSize", 1)) AS price
      FROM public."invTypes" t
      JOIN price1 p ON p."typeID" = t."typeID"
     WHERE t."marketGroupID" IS NOT NULL
)
INSERT INTO public.market_orders
    ("typeID", "charID", "regionID", "stationID", "range", bid, price, "volEntered",
     "volRemaining", issued, "orderState", "minVolume", contraband, "accountID", duration,
     "isCorp", "solarSystemID", escrow, jumps)
SELECT p."typeID", o."corporationID", o."regionID", o."stationID", -1, 0,
       round(greatest(p.price, 0.01)::numeric, 2)::float8, 1000000, 1000000,
       -- now, as a FILETIME
       (extract(epoch FROM now())::bigint + 11644473600) * 10000000,
       0, 1, 0, 1000, 365, 1, o."solarSystemID", 0, 1
  FROM priced p CROSS JOIN outlet o;

--
-- NPC buy orders beside every sell order, at half its price and reaching the
-- whole region, so anything can be sold back. Buying at the sell price and
-- selling at half leaves no loop to farm, reprocessing included.
--
INSERT INTO public.market_orders
    ("typeID", "charID", "regionID", "stationID", "range", bid, price, "volEntered",
     "volRemaining", issued, "orderState", "minVolume", contraband, "accountID", duration,
     "isCorp", "solarSystemID", escrow, jumps)
SELECT "typeID", "charID", "regionID", "stationID", 32767, 1,
       round(greatest(price * 0.5, 0.01)::numeric, 2)::float8, 1000000, 1000000,
       issued, 0, 1, 0, 1000, 365, 1, "solarSystemID", 0, 1
  FROM public.market_orders
 WHERE bid = 0;
