--
-- PostgreSQL database dump
--

\restrict LZnBis2bI8ddvifnaUH7bKFzb9bVGwFmukL865UPceLrJ687nRnm4GxoR9fES5y

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrAttributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrAttributes" (
    "attributeID" integer DEFAULT 0 NOT NULL,
    "attributeName" text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "graphicID" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: chrAttributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrAttributes" ("attributeID", "attributeName", description, "graphicID") FROM stdin;
1	Intelligence	Intelligence describes the person's capacity for creative and logic-based thinking and reasoning. Intelligence helps in scientific pursuits and other activities requiring good deductive skills.	1380
2	Charisma	Charisma describes the person's attractiveness to other people and how easy going it is. High charisma helps in all dealings with computer-controlled characters.	1378
3	Perception	Perception reflect the situational awareness of the person and its ability to adapt and react quickly to a rapidly changing situation. Good Reflexes helps the person on the battlefield and in other situations where swiftness is of the essence.	1382
4	Memory	Memory describes the person's ability to store and retrieve data quickly and efficiently. Good memory makes complex and repetitive activities easier to perform, such as activities of manufacturing and production.	1381
5	Willpower	Willpower describes the person's drive and determination. Willpower is very useful for commanders and greatly enhances their leadership abilities.	1379
\.


--
-- Name: chrAttributes chrAttributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrAttributes"
    ADD CONSTRAINT "chrAttributes_pkey" PRIMARY KEY ("attributeID");


--
-- PostgreSQL database dump complete
--

\unrestrict LZnBis2bI8ddvifnaUH7bKFzb9bVGwFmukL865UPceLrJ687nRnm4GxoR9fES5y

