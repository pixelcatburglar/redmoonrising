--
-- PostgreSQL database dump
--

\restrict EocDkO0fMqghPo1FKXQf6O1ICjidYpXvNgNOnUNBYzLbidP6TmwvDfSnWcJMALQ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channelMods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."channelMods" (
    id integer NOT NULL,
    "channelID" integer DEFAULT 0 NOT NULL,
    accessor integer,
    mode integer DEFAULT 0 NOT NULL,
    "untilWhen" bigint,
    "originalMode" integer,
    admin text,
    reason text
);


--
-- Name: channelMods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."channelMods_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channelMods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."channelMods_id_seq" OWNED BY public."channelMods".id;


--
-- Name: channelMods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."channelMods" ALTER COLUMN id SET DEFAULT nextval('public."channelMods_id_seq"'::regclass);


--
-- Data for Name: channelMods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."channelMods" (id, "channelID", accessor, mode, "untilWhen", "originalMode", admin, reason) FROM stdin;
\.


--
-- Name: channelMods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."channelMods_id_seq"', 1, false);


--
-- Name: channelMods channelMods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."channelMods"
    ADD CONSTRAINT "channelMods_pkey" PRIMARY KEY (id);


--
-- Name: channelMods_channelID_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "channelMods_channelID_idx" ON public."channelMods" USING btree ("channelID");


--
-- PostgreSQL database dump complete
--

\unrestrict EocDkO0fMqghPo1FKXQf6O1ICjidYpXvNgNOnUNBYzLbidP6TmwvDfSnWcJMALQ

