--
-- PostgreSQL database dump
--

\restrict xErEwcOI1UBMPctb5ed7UU7yVP1gk0gI9cJshDt3BePMKY1fTVe0khmVAp4c1Kr

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: spawns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spawns (
    "spawnID" integer NOT NULL,
    "solarSystemID" integer DEFAULT 0 NOT NULL,
    "spawnGroupID" integer DEFAULT 0 NOT NULL,
    "spawnBoundType" integer DEFAULT 0 NOT NULL,
    "spawnTimer" integer DEFAULT 0 NOT NULL,
    "respawnTimeMin" integer DEFAULT 0 NOT NULL,
    "respawnTimeMax" integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: spawns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spawns ("spawnID", "solarSystemID", "spawnGroupID", "spawnBoundType", "spawnTimer", "respawnTimeMin", "respawnTimeMax") FROM stdin;
1	30001407	1	0	0	100	1000
2	30001407	1	0	0	100	1000
3	30001407	1	0	0	100	1000
4	30001407	1	0	0	100	1000
5	30001407	1	0	0	100	1000
6	30001407	1	0	0	100	1000
7	30001407	1	0	0	100	1000
8	30001407	1	0	0	100	1000
9	30001406	1	0	0	100	1000
10	30001406	1	0	0	100	1000
\.


--
-- Name: spawns spawns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spawns
    ADD CONSTRAINT spawns_pkey PRIMARY KEY ("spawnID");


--
-- PostgreSQL database dump complete
--

\unrestrict xErEwcOI1UBMPctb5ed7UU7yVP1gk0gI9cJshDt3BePMKY1fTVe0khmVAp4c1Kr

