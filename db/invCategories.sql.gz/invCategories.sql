--
-- PostgreSQL database dump
--

\restrict GoQK0aATv9mYb7nj5m8LaUmvmIPGx03cU4qLQ0pGHQGtoDaiPhGBRK6yBKQy6YW

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invCategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invCategories" (
    "categoryID" integer NOT NULL,
    "categoryName" text,
    description text,
    "graphicID" integer
);


--
-- Data for Name: invCategories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invCategories" ("categoryID", "categoryName", description, "graphicID") FROM stdin;
0	#System		\N
1	Owner		1
2	Celestial		6
3	Station		17
4	Material		399
5	Accessories		33
6	Ship		38
7	Module		67
8	Charge		171
9	Blueprint		194
10	Trading		195
11	Entity		\N
14	Bonus	Character creation bonuses.  Like innate skills but genetic rather than learned.	0
16	Skill	Where all the skills go under.	0
17	Commodity		0
18	Drone	Player owned and controlled drones.	0
20	Implant	Implant	0
22	Deployable		0
23	Structure	Player owned structure related objects	0
24	Reaction		0
25	Asteroid		\N
\.


--
-- Name: invCategories invCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invCategories"
    ADD CONSTRAINT "invCategories_pkey" PRIMARY KEY ("categoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict GoQK0aATv9mYb7nj5m8LaUmvmIPGx03cU4qLQ0pGHQGtoDaiPhGBRK6yBKQy6YW

